package com.morefin.pg.bitandpay.processing;

import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.bitandpay.admin.apm.BitAndPayPaymentMethodTypeModule;
import io.quarkus.arc.Arc;

public class BitAndPayHppServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return BitAndPayPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return BitAndPayPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return BitAndPayPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(BitAndPayHppPaymentProcessingServiceImpl.class)) {
            return instance.get();
        }
    }
}
