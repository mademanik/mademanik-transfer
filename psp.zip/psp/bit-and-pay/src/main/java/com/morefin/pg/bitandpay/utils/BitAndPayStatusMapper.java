package com.morefin.pg.bitandpay.utils;

import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.pg.bitandpay.models.BitAndPayTransactionStatus;
import com.morefin.pg.bitandpay.models.CallbackResponseDto;

public class BitAndPayStatusMapper {

    public static ProcessingCode mapBitAndPayCodeToProcessingCode(BitAndPayTransactionStatus statusCode) {
        return switch (statusCode) {
            case PENDING_REDIRECT, PENDING -> ProcessingCode.TRX_STATUS_PENDING;
            case SUCCESS -> ProcessingCode.TRX_STATUS_APPROVED;
            case EMAIL_IN_GLOBAL_NEGATIVE_LIST, KYC_REJECTED -> ProcessingCode.RISK_FAILED_BLACKLISTED;
            case PROVIDER_DECLINED, USER_HAS_DEPOSIT_IN_PROGRESS -> ProcessingCode.TRX_STATUS_DECLINED;
            case SYSTEM_ERROR -> ProcessingCode.TRX_STATUS_FAILED;
            case WRONG_SITE_ID, UNSUPPORTED_COUNTRY, UNSUPPORTED_CURRENCY, NO_AMOUNT_IN_REQUEST, INVALID_AMOUNT,
                 MISSING_PARAMETERS, INVALID_CHECKSUM, INVALID_PARAMETER_VALUES -> ProcessingCode.INVALID_REQUEST;
            case MISSING_PAYMENT_METHOD, WRONG_PAYMENT_METHOD_FOR_PROVIDER, WRONG_PAYMENT_METHOD ->
                    ProcessingCode.INVALID_REQUEST_PAYMENT_METHOD;
            case PAYMENT_METHOD_NOT_ENABLED_FOR_SITE -> ProcessingCode.INVALID_REQUEST_PAYMENT_METHOD_NOT_SUPPORTED;
            case USER_EXCEEDED_DAILY_DEPOSIT_LIMIT, USER_EXCEEDED_DAILY_DEPOSIT_LIMIT_BY_PROVIDER ->
                    ProcessingCode.RISK_FAILED_VELOCITY_CHECK;
            case UNAUTHORIZED -> ProcessingCode.AUTHENTICATION_NOT_AUTHENTICATED;
        };
    }

    public static ExecuteTransactionResponse.Status mapBitAndPayCodeToExecuteTransactionResponseStatus(BitAndPayTransactionStatus statusCode) {
        return switch (statusCode) {
            case SUCCESS -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING_REDIRECT, PENDING -> ExecuteTransactionResponse.Status.PENDING;
            case PROVIDER_DECLINED, USER_HAS_DEPOSIT_IN_PROGRESS -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }

    public static TransactionStatus parseToGrpcTransactionStatus(CallbackResponseDto callbackDto) {
        return switch (callbackDto.status()) {
            case APPROVED -> TransactionStatus.APPROVED;
            case PENDING -> TransactionStatus.PENDING; // TODO is setting PENDING correct? It automatically is converted to CREATED
            case DECLINED -> TransactionStatus.DECLINED;
            case ZERO -> TransactionStatus.DECLINED; // TODO is setting INVALID correct? it automatically is converted to DECLINED
        };
    }
}
