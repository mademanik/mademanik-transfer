package com.morefin.pg.bitandpay.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record PaymentResponseDto(
        String status,
        String cashierId,
        String requestId,
        String redirectUrl,
        BitAndPayTransactionStatus statusCode
) {
    public PaymentResponseDto(@JsonProperty("status") String status,
                              @JsonProperty("cashier_id") String cashierId,
                              @JsonProperty("request_id") String requestId,
                              @JsonProperty("redirect_url") String redirectUrl,
                              @JsonProperty("status_code") int statusCode) {
        this(status, cashierId, requestId, redirectUrl, BitAndPayTransactionStatus.fromCode(statusCode));
    }
}
