package com.morefin.pg.bitandpay.processing;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProviderAccount;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.bitandpay.client.BitAndPayCallbackResource;
import com.morefin.pg.bitandpay.client.CashierApiClient;
import com.morefin.pg.bitandpay.models.BitAndPayException;
import com.morefin.pg.bitandpay.models.PaymentRequestDto;
import com.morefin.pg.bitandpay.models.PaymentResponseDto;
import com.morefin.pg.bitandpay.models.RuntimePaymentProviderAccountConfig;
import com.morefin.pg.bitandpay.utils.BitAndPayObjectTransformer;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.tuples.Tuple2;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.UriBuilder;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.math.BigDecimal;
import java.util.Set;
import java.util.stream.Collectors;

@ApplicationScoped
public class TransactionManager {

    @RestClient
    CashierApiClient apiClient;

    @Inject
    BitAndPayObjectTransformer objectTransformer;

    // TODO: Discussion on exception handling and introduced mechanism
    public Uni<ExecuteTransactionResponse> requestHpp(TransactionTypeContext c) {
        return Uni.createFrom().item(c)
                .map(context -> {
                    var transaction = context.getTransaction();
                    var transactionData = transaction.getTransactionData();

                    var customer = objectTransformer.mapToCustomer(transaction);
                    var runtimeAccountConfig = getRuntimeAccountConfig(context.getPaymentProviderAccount());

                    return Tuple2.of(runtimeAccountConfig, new PaymentRequestDto(
                            runtimeAccountConfig.merchantId(),
                            runtimeAccountConfig.merchantSiteId(),
                            transaction.getId(),
                            BigDecimal.valueOf(transaction.getAmount()).divide(BigDecimal.valueOf(100)).toString(),
                            transaction.getCurrency(),
                            transaction.getCustomerEmail(),
                            transaction.getCustomerCountry(), // TODO should be transactionData.getCountry() but it is null, bug in /authorize request DTO
                            UriBuilder.fromUri(context.getTenantConfig().url())
                                    .path(BitAndPayCallbackResource.class)
                                    .build().toString(),
                            transactionData.getSuccessUrl(),
                            transactionData.getSuccessUrl(), // TODO pending url - what to do if transaction will be pending
                            transactionData.getErrorUrl(),
                            transactionData.getCancelUrl(),
                            transaction.getDescription(),
                            customer)
                    );
                })
                .map(tuple -> {
                    Set<ConstraintViolation<PaymentRequestDto>> violations = getValidator().validate(tuple.getItem2());

                    if (!violations.isEmpty()) {
                        String message = violations.stream()
                                .map(violation -> String.format(
                                        "Validation failed: Property '%s' %s (invalid value: '%s')",
                                        violation.getPropertyPath(),
                                        violation.getMessage(),
                                        violation.getInvalidValue()
                                ))
                                .collect(Collectors.joining("\n"));
                        throw new BitAndPayException(c.getTransaction().getId(), message);
                    }
                    return tuple;
                })
                .flatMap(tuple -> apiClient.getCashier(tuple.getItem2(), tuple.getItem1().merchantToken()))
                .onItemOrFailure()
                .transform((response, failure) -> {
                    if (failure == null) {
                        try {
                            return response.readEntity(PaymentResponseDto.class);
                        } catch (Exception e) {
                            return new BitAndPayException(c.getTransaction().getId(), e.getMessage(), e);
                        }
                    } else {
                        if (failure instanceof WebApplicationException) {
                            return ((WebApplicationException) failure).getResponse();
                        } else {
                            return new BitAndPayException(c.getTransaction().getId(), failure.getMessage(), failure);
                        }
                    }
                })
                .map(resp -> objectTransformer.mapToExecuteTransactionResponse(resp, c.getTransaction().getId()));
    }

    private static RuntimePaymentProviderAccountConfig getRuntimeAccountConfig(TypedPaymentProviderAccount paymentProviderAccount) {
        return JsonObject.mapFrom(paymentProviderAccount.getData().getJsonObject("configuration")).mapTo(RuntimePaymentProviderAccountConfig.class);
    }

    private Validator getValidator() {
        try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            return factory.getValidator();
        }
    }

}
