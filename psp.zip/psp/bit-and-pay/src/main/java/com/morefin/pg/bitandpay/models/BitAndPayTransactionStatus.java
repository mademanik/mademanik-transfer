package com.morefin.pg.bitandpay.models;

public enum BitAndPayTransactionStatus {
    PENDING_REDIRECT(100, "Pending redirect"),
    PENDING(101, "Pending"),
    SUCCESS(200, "Success"),
    USER_HAS_DEPOSIT_IN_PROGRESS(301, "User has deposit in progress, please wait 60 seconds"),
    EMAIL_IN_GLOBAL_NEGATIVE_LIST(302, "Email is in global negative list"),
    USER_EXCEEDED_DAILY_DEPOSIT_LIMIT(303, "User exceeded daily deposit limit"),
    KYC_REJECTED(304, "KYC Rejected"),
    UNSUPPORTED_COUNTRY(401, "Unsupported country"),
    UNSUPPORTED_CURRENCY(402, "Unsupported currency"),
    PROVIDER_DECLINED(500, "Provider declined"),
    SYSTEM_ERROR(501, "System error"),
    UNAUTHORIZED(502, "Unauthorized"),
    NO_AMOUNT_IN_REQUEST(503, "No amount in the request"),
    INVALID_AMOUNT(504, "Amount is not a valid value"),
    WRONG_SITE_ID(505, "Wrong site ID"),
    MISSING_PAYMENT_METHOD(506, "Missing payment method"),
    WRONG_PAYMENT_METHOD_FOR_PROVIDER(507, "Wrong payment method for this provider"),
    WRONG_PAYMENT_METHOD(508, "Wrong payment method"),
    PAYMENT_METHOD_NOT_ENABLED_FOR_SITE(509, "Payment method not enabled for site"),
    MISSING_PARAMETERS(510, "Missing parameters"),
    INVALID_CHECKSUM(511, "Invalid checksum"),
    INVALID_PARAMETER_VALUES(512, "Invalid parameter values"),
    USER_EXCEEDED_DAILY_DEPOSIT_LIMIT_BY_PROVIDER(513, "User exceeded daily deposit limit by provider");

    private final int code;
    private final String description;

    BitAndPayTransactionStatus(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static BitAndPayTransactionStatus fromCode(int code) {
        for (BitAndPayTransactionStatus status : BitAndPayTransactionStatus.values()) {
            if (status.code == code) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown response code: " + code);
    }

}
