package com.morefin.pg.bitandpay.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class PaymentRequestDto {
    @JsonProperty("merchant_id")
    @NotNull
    String merchantId;

    @JsonProperty("merchant_site_id")
    @NotNull
    String merchantSiteId;

    @JsonProperty("request_id")
    @NotNull
    String requestId;

    @JsonProperty("amount")
    @NotNull
    String amount;

    @JsonProperty("currency")
    @NotNull
    @Size(min = 3, max = 3)
    String currency;

    @JsonProperty("email")
    @NotNull
    @Email
    String email;

    @JsonProperty("country")
    @NotNull
    @Size(min = 2, max = 2)
    String country;

    @JsonProperty("notification_link")
    @NotNull
    String notificationLink;

    @JsonProperty("success_url")
    @NotNull
    String successUrl;

    @JsonProperty("pending_url")
    @NotNull
    String pendingUrl;

    @JsonProperty("fail_url")
    @NotNull
    String failUrl;

    @JsonProperty("back_url")
    @NotNull
    String backUrl;

    @JsonProperty("display_name")
    String displayName;

    @JsonProperty("customer_info")
    @NotNull
    Customer customerInfo;

    public PaymentRequestDto(String merchantId, String merchantSiteId,
                             String requestId, String amount, String currency,
                             String email, String country, String notificationLink,
                             String successUrl, String pendingUrl, String failUrl,
                             String backUrl, String displayName, Customer customerInfo) {
        this.merchantId = merchantId;
        this.merchantSiteId = merchantSiteId;
        this.requestId = requestId;
        this.amount = amount;
        this.currency = currency;
        this.email = email;
        this.country = country;
        this.notificationLink = notificationLink;
        this.successUrl = successUrl;
        this.pendingUrl = pendingUrl;
        this.failUrl = failUrl;
        this.backUrl = backUrl;
        this.displayName = displayName;
        this.customerInfo = customerInfo;
    }

    public record Customer(@JsonProperty("first_name") String firstName, @JsonProperty("last_name") String lastName,
                           @JsonProperty("state") String state, @JsonProperty("city") String city,
                           @JsonProperty("address") String address, @JsonProperty("zip_code") String zipCode,
                           @JsonProperty("mobile") String mobile) {

    }

}

