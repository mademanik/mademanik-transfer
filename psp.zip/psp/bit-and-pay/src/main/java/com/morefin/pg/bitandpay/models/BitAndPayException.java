package com.morefin.pg.bitandpay.models;

public class BitAndPayException extends RuntimeException {

    private final String transactionId;
    private String paymentProviderResponseCode;
    private String paymentProviderResponseMessage;

    public BitAndPayException(String transactionId, String message) {
        super(message);
        this.transactionId = transactionId;
    }

    public BitAndPayException(String transactionId, String message, Throwable e) {
        super(message, e);
        this.transactionId = transactionId;
    }

    public BitAndPayException(String transactionId, String message, String paymentProviderResponseCode, String paymentProviderResponseMessage) {
        super(message);
        this.transactionId = transactionId;
        this.paymentProviderResponseCode = paymentProviderResponseCode;
        this.paymentProviderResponseMessage = paymentProviderResponseMessage;
    }

    public BitAndPayException(String transactionId, String message, String paymentProviderResponseCode, String paymentProviderResponseMessage, Throwable e) {
        super(message, e);
        this.transactionId = transactionId;
        this.paymentProviderResponseCode = paymentProviderResponseCode;
        this.paymentProviderResponseMessage = paymentProviderResponseMessage;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getPaymentProviderResponseCode() {
        return paymentProviderResponseCode;
    }

    public String getPaymentProviderResponseMessage() {
        return paymentProviderResponseMessage;
    }
}
