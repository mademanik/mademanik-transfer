package com.morefin.pg.bitandpay.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CallbackResponseDto(Status status,
                                  String orderId,
                                  String requestId,
                                  String siteId,
                                  BitAndPayTransactionStatus statusCode,
                                  String amount,
                                  String currency,
                                  String providerResponse,
                                  PaymentMethod paymentMethod,
                                  String cashierId
) {

    public CallbackResponseDto(@JsonProperty("status") String status,
                               @JsonProperty("order_id") String orderId,
                               @JsonProperty("request_id") String requestId,
                               @JsonProperty("site_id") String siteId,
                               @JsonProperty("status_code") int statusCode,
                               @JsonProperty("amount") String amount,
                               @JsonProperty("currency") String currency,
                               @JsonProperty("provider_response") String providerResponse,
                               @JsonProperty("payment_method") String paymentMethod,
                               @JsonProperty("cashier_id") String cashierId
    ) {
        this(Status.fromValue(status), orderId, requestId, siteId, BitAndPayTransactionStatus.fromCode(statusCode),
                amount, currency, providerResponse, PaymentMethod.fromValue(paymentMethod), cashierId);
    }

    public enum Status {
        APPROVED("APPROVED"),
        PENDING("PENDING"),
        DECLINED("DECLINED"),
        ZERO("0");

        private final String value;

        Status(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static Status fromValue(String value) {
            for (Status status : Status.values()) {
                if (status.value.equals(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown status value: " + value);
        }
    }

    public enum PaymentMethod {
        CC_AUTH("cc_auth"),
        MASTERCARD_VISA("mastercard-visa"),
        CC_TRUSTED("cc_trusted"),
        CASHTOCODE("cashtocode"),
        PIX("pix"),
        CRYPTO("crypto"),
        BOLETO("boleto"),
        INTERAC("interac"),
        BNPPAYBYBANK("bnppaybybank"),
        FTD_CC("ftd_cc"),
        MASTERCARD_VISA_STS("mastercard-visa-sts"),
        MOBILE_MONEY("mobile_money"),
        BANK_TRANSFER("bank_transfer"),
        DEMO("demo");

        private final String value;

        PaymentMethod(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static PaymentMethod fromValue(String value) {
            for (PaymentMethod method : PaymentMethod.values()) {
                if (method.value.equalsIgnoreCase(value)) {
                    return method;
                }
            }
            throw new IllegalArgumentException("No enum constant with value " + value);
        }
    }
}

