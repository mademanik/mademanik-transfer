package com.morefin.pg.bitandpay.utils;

public class Constants {
    public static final String CALLBACK_URL = "/psp/bitandpay/callback";

}
