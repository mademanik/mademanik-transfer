package com.morefin.pg.bitandpay.processing;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.pg.bitandpay.models.CallbackResponseDto;
import com.morefin.pg.bitandpay.utils.BitAndPayObjectTransformer;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

import java.net.URI;
import java.util.Map;
import java.util.Set;

@ApplicationScoped
public class FinalizeTransactionManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    BitAndPayObjectTransformer objectTransformer;

    private GrpcApiUser getServiceAccount() {
        return GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "service-account"
        );
    }

    public Uni<Void> finalizeTransaction(CallbackResponseDto body, String tenantId) {
        var grpc = GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                getServiceAccount(),
                Constants.LOCALHOST);
        return Uni.createFrom().item(body)
                .map(objectTransformer::mapToFinalizeTransactionRequest)
                .flatMap(req -> grpc.finalizeTransaction(req)
                        .map(result -> {
                            if (result.hasRedirect()) {
                                return Response.temporaryRedirect(URI.create(result.getRedirect().getUrl())).build();
                            } else {
                                return Response.status(400).build();
                            }
                        })).replaceWithVoid();
    }


}
