package com.morefin.pg.bitandpay.utils;

import com.morefin.pg.bitandpay.models.BitAndPayException;
import jakarta.interceptor.AroundInvoke;
import jakarta.interceptor.Interceptor;
import jakarta.interceptor.InvocationContext;

@Interceptor
@HandleBitAndPayException
public class BitAndPayExceptionInterceptor {

    @AroundInvoke
    public Object aroundInvoke(InvocationContext context) throws Exception {
        try {
            return context.proceed();
        } catch (BitAndPayException e) {
            return BitAndPayObjectTransformer.buildBitAndPayErrorTransactionResponse(e);
        }
    }
}
