package com.morefin.pg.bitandpay.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.bitandpay.processing.FinalizeTransactionManager;
import com.morefin.pg.bitandpay.models.CallbackResponseDto;
import com.morefin.pg.bitandpay.utils.Constants;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path(Constants.CALLBACK_URL)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BitAndPayCallbackResource {

    @Inject
    FinalizeTransactionManager finalizeTransactionManager;

    @Inject
    Tenant tenant;

    @POST
    public Uni<Void> returnUrl(CallbackResponseDto body) {
        return finalizeTransactionManager.finalizeTransaction(body, tenant.id());
    }
}
