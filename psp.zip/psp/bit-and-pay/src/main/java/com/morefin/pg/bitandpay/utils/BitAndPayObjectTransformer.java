package com.morefin.pg.bitandpay.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.bitandpay.models.BitAndPayException;
import com.morefin.pg.bitandpay.models.BitAndPayTransactionStatus;
import com.morefin.pg.bitandpay.models.CallbackResponseDto;
import com.morefin.pg.bitandpay.models.ErrorResponse;
import com.morefin.pg.bitandpay.models.PaymentRequestDto;
import com.morefin.pg.bitandpay.models.PaymentResponseDto;
import io.quarkus.logging.Log;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

@ApplicationScoped
public class BitAndPayObjectTransformer {

    public PaymentRequestDto.Customer mapToCustomer(ImmutableTypedTransactionEntity transaction) {
        return new PaymentRequestDto.Customer(
                transaction.getCustomerFirstName(),
                transaction.getCustomerLastName(),
                transaction.getCustomerCountry(),
                transaction.getCustomerCity(),
                transaction.getCustomerAddress(),
                transaction.getCustomerPostalCode(),
                transaction.getCustomerPhoneNumber()
        );
    }

    public FinalizeTransactionRequest mapToFinalizeTransactionRequest(CallbackResponseDto callbackDto) {
        var message = "Transaction %s : %s".formatted(callbackDto.status(), callbackDto.statusCode().getDescription());
        return FinalizeTransactionRequest.newBuilder()
                .setResponseMessage(message)
                .setPaymentProviderResponseCode(String.valueOf(callbackDto.statusCode().getCode()))
                .setPaymentProviderResponseMessage(callbackDto.providerResponse())
                .setStatus(BitAndPayStatusMapper.parseToGrpcTransactionStatus(callbackDto))
                .setReferenceNumber(callbackDto.requestId())
                .setId(callbackDto.requestId()).build();
    }

    @HandleBitAndPayException
    public ExecuteTransactionResponse mapToExecuteTransactionResponse(Object response, String transactionId) {
        ExecuteTransactionResponse transactionResp;
        if (response instanceof PaymentResponseDto) {
            transactionResp = buildPendingTransactionResponse((PaymentResponseDto) response);
        } else if (response instanceof Response) {
            transactionResp = buildErrorTransactionResponse((Response) response, transactionId);
        } else {
            throw (response instanceof BitAndPayException)
                    ? (BitAndPayException) response
                    : new BitAndPayException(transactionId, "Unexpected type of response: " + response.getClass().getName());
        }
        return transactionResp;
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(
            PaymentResponseDto response) {
        if (!BitAndPayTransactionStatus.SUCCESS.name().equals(response.status())) {
            throw new BitAndPayException(
                    response.requestId(),
                    "Unexpected response status: " + response.status(),
                    String.valueOf(response.statusCode().getCode()),
                    response.statusCode().getDescription());
        }

        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setRedirect(
                        new GrpcBuilder<>(builder)
                                .set(response.redirectUrl(), builder::setUrl)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildErrorTransactionResponse(
            Response response,
            String transactionId
    ) {
        ProcessingCode processingCode = ProcessingCode.TRX_STATUS_FAILED;
        ExecuteTransactionResponse.Status responseStatus = ExecuteTransactionResponse.Status.ERROR;

        int paymentProviderResponseCode = response.getStatus();
        String paymentProviderResponseMessage = response.getStatusInfo().getReasonPhrase();
        Object paymentProviderResponseEntity;

        if (!response.hasEntity()) {
            throw new BitAndPayException(transactionId, paymentProviderResponseMessage, String.valueOf(paymentProviderResponseCode), paymentProviderResponseMessage);
        }

        try {
            String responseBody = response.readEntity(String.class);
            var objectMapper = new ObjectMapper();

            paymentProviderResponseMessage = responseBody;

            // will read json formatted response. If something else - will go to the catch
            paymentProviderResponseEntity = objectMapper.readValue(responseBody, Object.class);

            if (response.getStatus() == 401 || response.getStatus() == 400) {
                ErrorResponse errorResponse = objectMapper.convertValue(paymentProviderResponseEntity, ErrorResponse.class);
                paymentProviderResponseMessage = errorResponse.message().toString();

                if (response.getStatus() == 401) {
                    processingCode = ProcessingCode.AUTHENTICATION_NOT_AUTHENTICATED;
                } else {
                    try {
                        BitAndPayTransactionStatus bitAndPayStatusCode = BitAndPayTransactionStatus.fromCode(errorResponse.statusCode());
                        processingCode = BitAndPayStatusMapper.mapBitAndPayCodeToProcessingCode(bitAndPayStatusCode);
                        responseStatus = BitAndPayStatusMapper.mapBitAndPayCodeToExecuteTransactionResponseStatus(bitAndPayStatusCode);

                        paymentProviderResponseCode = bitAndPayStatusCode.getCode();
                        paymentProviderResponseMessage = bitAndPayStatusCode.getDescription();
                    } catch (Exception ignored) {
                        processingCode = ProcessingCode.INVALID_REQUEST;
                    }
                }
            }
        } catch (Exception e) {
            throw new BitAndPayException(transactionId, paymentProviderResponseMessage, String.valueOf(paymentProviderResponseCode), paymentProviderResponseMessage, e);
        }

        var builder = ExecuteTransactionResponse.Response.newBuilder();

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(transactionId, builder::setId)
                                .set(processingCode.name(), builder::setResponseCode)
                                .set(StringUtils.abbreviate(paymentProviderResponseMessage,50), builder::setResponseMessage)
                                .set("", builder::setApprovalCode)
                                .setAny(String.valueOf(paymentProviderResponseCode), builder::setPaymentProviderResponseCode)
                                .setAny(paymentProviderResponseMessage, builder::setPaymentProviderResponseMessage)
                                .setAndMap(paymentProviderResponseEntity != null ? JsonObject.mapFrom(paymentProviderResponseEntity).getMap() : Map.of(), GrpcFactory::fromMap, builder::setData)
                                .set(responseStatus.toString(), builder::setPaymentProviderStatus) //TODO maybe return different status?
                                .setAny(responseStatus, builder::setStatus)
                                .getBuilder().build()
                )
                .build();
    }

    // TODO implement tests for this logic
    static ExecuteTransactionResponse buildBitAndPayErrorTransactionResponse(BitAndPayException exception) {
        Log.error("Error processing transaction %s. Message: %s".formatted(exception.getTransactionId(), exception.getMessage()), exception);

        ProcessingCode processingCode = ProcessingCode.TRX_STATUS_FAILED;
        ExecuteTransactionResponse.Status responseStatus = ExecuteTransactionResponse.Status.ERROR;
//        Object responseEntity = null;

        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(exception.getTransactionId(), builder::setId)
                                .set(processingCode.name(), builder::setResponseCode)
                                .set(StringUtils.abbreviate(exception.getMessage(), 50), builder::setResponseMessage)
                                .set("", builder::setApprovalCode)
                                .setAny(exception.getPaymentProviderResponseCode(), builder::setPaymentProviderResponseCode)
                                .setAny(exception.getPaymentProviderResponseMessage(), builder::setPaymentProviderResponseMessage)
//                                .setAndMap(responseEntity != null ? JsonObject.mapFrom(responseEntity).getMap() : Map.of(), GrpcFactory::fromMap, builder::setData)
                                .set(responseStatus.toString(), builder::setPaymentProviderStatus) //TODO maybe return different status?
                                .setAny(responseStatus, builder::setStatus)
                                .getBuilder().build()
                )
                .build();
    }

}
