package com.morefin.pg.bitandpay.client;

import com.morefin.pg.bitandpay.models.PaymentRequestDto;
import io.quarkus.rest.client.reactive.ComputedParamContext;
import io.quarkus.rest.client.reactive.NotBody;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/payment_cashier")
@RegisterRestClient(configKey = "bitAndPay")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface CashierApiClient {

    @POST
    @ClientHeaderParam(name = "merchant-token", value = "{getToken}")
    Uni<Response> getCashier(PaymentRequestDto request, @NotBody String merchantToken);

    default String getToken(ComputedParamContext context) {
        return context.methodParameters().get(1).value().toString();
    }

}
