package com.morefin.pg.bitandpay.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public record ErrorResponse(
        @JsonProperty("message")
        Object message,
        @JsonProperty("status_code")
        Integer statusCode
) {
}