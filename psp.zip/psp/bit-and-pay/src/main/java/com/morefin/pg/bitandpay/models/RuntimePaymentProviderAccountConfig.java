package com.morefin.pg.bitandpay.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimePaymentProviderAccountConfig(
        @JsonProperty("merchant-token")
        String merchantToken,
        @JsonProperty("merchant-id")
        String merchantId,
        @JsonProperty("merchant_site_id")
        String merchantSiteId
) {
}