package com.morefin.pg.networx.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.networx.models.*;
import com.morefin.pg.safeuni.ErrorDescription;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.tuples.Tuple2;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Optional;

import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class NetworxObjectTransformer {

    @Inject
    ObjectMapper objectMapper;

    @Inject
    DtoMapperService mapperService;

    public AuthorizeTransactionRequestDto.RequestData.Customer mapToCustomer(ImmutableTypedTransactionEntity transaction) {
        return new AuthorizeTransactionRequestDto.RequestData.Customer(
                transaction.getUserIp(),
                transaction.getCustomerEmail(),
                null // TODO put real birthdate
        );
    }

    public AuthorizeTransactionRequestDto.RequestData.BillingAddress mapToBillingAddress(ImmutableTypedTransactionEntity transaction) {
        return new AuthorizeTransactionRequestDto.RequestData.BillingAddress(
                transaction.getCustomerFirstName(),
                transaction.getCustomerLastName(),
                transaction.getCustomerCountry(),
                transaction.getCustomerCity(),
                transaction.getCustomerAddress(),
                transaction.getCustomerPostalCode(),
                transaction.getCustomerPhoneNumber()
        );
    }

    public FinalizeTransactionRequest mapToFinalizeTransactionRequest(PaymentResponse paymentResponse, String responseAsString) {
        PaymentResponse.Transaction transaction = paymentResponse.getTransaction();
        ApiResponseDto.Status status = ApiResponseDto.Status.fromValue(transaction.getStatus());
        ProcessingCode transactionStatus = NetworxTransactionStatusMapper.parseToProcessingCode(status);
        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder();
        if ( transaction.getType().equalsIgnoreCase("refund") && transactionStatus.equals(ProcessingCode.TRX_STATUS_APPROVED) ) {
            builder.setResponseMessage(transaction.getMessage())
                    .setPaymentProviderResponseMessage(transaction.getMessage());
        } else {
            builder.setResponseMessage(responseAsString)
                    .setPaymentProviderResponseMessage(responseAsString);
        }
        return builder
                .setId(paymentResponse.getTransaction().getTrackingId())
                .setReferenceNumber(paymentResponse.getTransaction().getUid())
                .setStatus(NetworxTransactionStatusMapper.parseToGrpcTransactionStatus(status))
                .setResponseCode(transactionStatus.getCode())
                .setPaymentProviderResponseCode(transactionStatus.getCode())
                .build();
    }

    public ExecuteTransactionResponse mapToExecuteTransactionResponse(Tuple2<Response, Throwable> processingResponse, String transactionId) {
        try {
            if (processingResponse.getItem1() != null) {
                var responseEntity = processingResponse.getItem1().readEntity(String.class);

                if (processingResponse.getItem1().getStatus() == Constants.VALIDATION_ERROR_CODE) {
                    return buildErrorTransactionResponse(transactionId, responseEntity);
                } else {
                    PaymentResponse response = mapperService.mapAndValidate(responseEntity, PaymentResponse.class);
                    return convertToCardResponse(response, responseEntity);
                }
            } else {
                if (processingResponse.getItem2() instanceof WebApplicationException wae) {
                    var errorResponse = wae.getResponse().readEntity(ErrorResponse.class);
                    return buildInvalidTransactionResponse(errorResponse, transactionId);
                } else {
                    return buildErrorTransactionResponse(transactionId,
                        JsonObject.mapFrom(processingResponse.getItem2()).encode()
                    );
                }
            }
        } catch (Exception e) {
            return buildErrorTransactionResponse(transactionId, e.getMessage());
        }
    }

    private ExecuteTransactionResponse convertToCardResponse(PaymentResponse response, String responseAsString) {
        PaymentResponse.Transaction paymentResponse = response.getTransaction();
        ApiResponseDto.Status status = ApiResponseDto.Status.fromValue(paymentResponse.getStatus());
        ExecuteTransactionResponse.Status transactionStatus = NetworxTransactionStatusMapper.parseToExecuteTransactionStatus(status);

        switch (transactionStatus) {
            case APPROVED -> {
                return buildApprovedTransactionResponse(paymentResponse.getUid(), responseAsString);
            }
            case PENDING -> {
                return buildDirect3dsTransactionResponse(paymentResponse.getUid(), paymentResponse.getRedirectUrl(), responseAsString);
            }
        }

        return buildDeclinedTransactionResponse(paymentResponse.getUid(), responseAsString);
    }

    private ExecuteTransactionResponse buildDirect3dsTransactionResponse(String referenceNumber, String redirectUrl, String responseAsString) {
        var builder = ExecuteTransactionResponse.newBuilder();
        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        builder.setResponse(
                new GrpcBuilder<>(responseBuilder)
                        .set(ProcessingCode.TRX_STATUS_PENDING.name(), responseBuilder::setResponseCode)
                        .setAny(ExecuteTransactionResponse.Status.PENDING, responseBuilder::setStatus)
                        .set(referenceNumber, responseBuilder::setReferenceNumber)
                        .set(responseAsString, responseBuilder::setResponseMessage)
                        .set(responseAsString, responseBuilder::setPaymentProviderResponseMessage)
                        .getBuilder()
                        .build()
        );
        var redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();

        builder.setRedirect(
                new GrpcBuilder<>(redirectBuilder)
                        .set(redirectUrl, redirectBuilder::setUrl)
                        .getBuilder()
                        .build()
        );
        return builder.build();
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(
            ApiResponseDto response) {
        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                //TODO: set all response data here
                .setResponse(ExecuteTransactionResponse.Response.newBuilder()
                        .setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name())
                        .setReferenceNumber(response.transactionId())
                        .build()
                )
                .setRedirect(
                        new GrpcBuilder<>(builder)
                                .set(response.redirectUrl(), builder::setUrl)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private static ExecuteTransactionResponse buildTransactionResponse(ApiResponseDto response) {
        ExecuteTransactionResponse.Status executeTransactionStatus = NetworxTransactionStatusMapper.parseToExecuteTransactionStatus(response.status());
        ProcessingCode processingCode = NetworxTransactionStatusMapper.parseToProcessingCode(response.status());

        String message = "Transaction is %s".formatted(response.status());

        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(ExecuteTransactionResponse.Response.newBuilder())
                                .set(response.trackingId(), builder::setId)
                                .set(processingCode.name(), builder::setResponseCode)
                                .set(message, builder::setResponseMessage)
                                .set("", builder::setApprovalCode)
                                .setAny(response.statusCode(), builder::setPaymentProviderResponseCode)
                                .setAny(response.status().getValue(), builder::setPaymentProviderStatus)
                                .setAny("%s : %s".formatted(response.friendlyMessage(), response.message()), builder::setPaymentProviderResponseMessage)
                                .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                                .setAny(executeTransactionStatus, builder::setStatus)
                                .set(response.transactionId(), builder::setReferenceNumber)
                                .getBuilder().build()
                )
                .build();
    }

    private static ExecuteTransactionResponse buildInvalidTransactionResponse(
            ErrorResponse response,
            String transactionId
    ) {
        var processingCode = ProcessingCode.INVALID_REQUEST;
        var responseStatus = ExecuteTransactionResponse.Status.ERROR;
        var responseMessage = "%s : %s".formatted(response.friendlyMessage(), response.message());

        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(transactionId, builder::setId)
                                .set(processingCode.name(), builder::setResponseCode)
                                .set(responseMessage, builder::setResponseMessage)
                                .set("", builder::setApprovalCode)
                                .setAny(response.code(), builder::setPaymentProviderResponseCode)
                                .set(response.status(), builder::setPaymentProviderStatus)
                                .setAny(responseMessage, builder::setPaymentProviderResponseMessage)
                                .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                                .setAny(responseStatus, builder::setStatus)
                                .getBuilder().build()
                )
                .build();
    }

    private static ExecuteTransactionResponse buildErrorTransactionResponse(String transactionId, String responseMessage) {
        var processingCode = ProcessingCode.TRX_STATUS_FAILED;
        var responseStatus = ExecuteTransactionResponse.Status.ERROR;

        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(transactionId, builder::setId)
                                .set(processingCode.name(), builder::setResponseCode)
                                .set(responseMessage, builder::setResponseMessage)
                                .set("", builder::setApprovalCode)
                                .setAny(responseStatus, builder::setStatus)
                                .getBuilder().build()
                )
                .build();
    }

    public ErrorDescription<String> buildRefundErrorDescription(NetworxRefundContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    private ErrorDescription<String> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<String>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    public RefundRequest buildPaymentRefundRequest(ManageTransactionContext context) {
        return mapRefundPaymentRequest(context).build();
    }

    private RefundRequest.RefundRequestBuilder mapRefundPaymentRequest(ManageTransactionContext context) {
        var parentTransactionRefNum = context.transactionTypeContext().getParentTransaction().getReferenceNumber();
        BigDecimal number = BigDecimal.valueOf(context.transaction().getAmount());

        String baseUrl = context.transactionTypeContext().getTenantConfig().url();
//        String baseUrl = "https://gentle-heads-sniff.loca.lt";
//        String baseUrl = "https://webhook.site/08cc2fb4-f981-4918-b179-3492684608bc";
        String webhookUrl = baseUrl + "/psp/networx/callback";

        RefundRequest.Request request = RefundRequest.Request.builder()
                .amount(number)
                .parentUid(parentTransactionRefNum)
                .reason("Need to do refund from MoreFin")
                .trackingId(context.transaction().getId())
                .notificationUrl(webhookUrl)
                .build();

        return RefundRequest.builder()
                .request(request);
    }

    public ExecuteTransactionResponse convertToCardResponse(NetworxRefundContext context) {
        if ( context.getErrorDescription() != null ) {
            return buildDeclinedTransactionResponse("", context.getErrorDescription().getResponseMessage());
        }
        RefundTransactionResponse refundResponse = context.getRefundResponse().getTransaction();
        ApiResponseDto.Status status = ApiResponseDto.Status.fromValue(refundResponse.getStatus());
        ExecuteTransactionResponse.Status transactionStatus = NetworxTransactionStatusMapper.parseToExecuteTransactionStatus(status);

        switch (transactionStatus) {
            case APPROVED -> {
                return buildApprovedTransactionResponse(refundResponse.getUid(), refundResponse.getMessage());
            }
            case PENDING -> {
                return buildPendingTransactionResponse(refundResponse.getUid(), context.getRefundResponseAsString());
            }
        }

        return buildDeclinedTransactionResponse(refundResponse.getUid(), context.getRefundResponseAsString());
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_PENDING.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.PENDING, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildApprovedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildDeclinedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_DECLINED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }
}
