package com.morefin.pg.networx.util;

public class Constants {
    public static final String CALLBACK_URL = "/psp/networx/callback";
    public static final String SIGNATURE_HEADER = "Content-Signature";

    public static final int VALIDATION_ERROR_CODE = 480;

}
