package com.morefin.pg.networx.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Map;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RefundRequest {
    @JsonProperty("request")
    private Request request;

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Request {
        @JsonProperty("parent_uid")
        private String parentUid;

        @JsonProperty("amount")
        private BigDecimal amount;

        @JsonProperty("reason")
        private String reason;

        @JsonProperty("tracking_id")
        private String trackingId;

        @JsonProperty("notification_url")
        private String notificationUrl;
    }
}
