package com.morefin.pg.networx.util;

import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.pg.networx.models.ApiResponseDto;

public class NetworxTransactionStatusMapper {

    private NetworxTransactionStatusMapper() {
    }

    public static ExecuteTransactionResponse.Status parseToExecuteTransactionStatus(ApiResponseDto.Status responseStatus) {
        return switch (responseStatus) {
            case SUCCESSFUL, COMPLETED -> ExecuteTransactionResponse.Status.APPROVED;
            case INCOMPLETE, PROCESSING -> ExecuteTransactionResponse.Status.PENDING;
            case FAILED, UNKNOWN -> ExecuteTransactionResponse.Status.DECLINED;
        };
    }

    public static ProcessingCode parseToProcessingCode(ApiResponseDto.Status responseStatus) {
        return switch (responseStatus) {
            case SUCCESSFUL, COMPLETED -> ProcessingCode.TRX_STATUS_APPROVED;
            case INCOMPLETE, PROCESSING -> ProcessingCode.TRX_STATUS_PENDING;
            case FAILED, UNKNOWN -> ProcessingCode.TRX_STATUS_DECLINED;
        };
    }

    public static TransactionStatus parseToGrpcTransactionStatus(ApiResponseDto.Status responseStatus) {
        return switch (responseStatus) {
            case SUCCESSFUL, COMPLETED -> TransactionStatus.APPROVED;
            case INCOMPLETE, PROCESSING -> TransactionStatus.PENDING;
            case FAILED, UNKNOWN -> TransactionStatus.DECLINED;
        };
    }

}
