package com.morefin.pg.networx.common;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.keymanagementspi.keys.KeyManagementService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.networx.client.NetworxApiClient;
import com.morefin.pg.networx.client.NetworxCallbackResource;
import com.morefin.pg.networx.models.*;
import com.morefin.pg.networx.util.NetworxObjectTransformer;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.DtoValidationService;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.tuples.Tuple2;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import io.quarkus.logging.Log;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;
import static com.morefin.pg.networx.util.Constants.VALIDATION_ERROR_CODE;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
public class AuthorizeTransactionManager {

    @RestClient
    NetworxApiClient apiClient;

    @Inject
    KeyManagementService keyManagementService;

    @Inject
    NetworxObjectTransformer objectTransformer;

    @Inject
    DtoValidationService dtoValidationService;

    @Inject
    DtoMapperService mapperService;

    private final BiFunction<NetworxRefundContext, Throwable, NetworxRefundContext> defaultRefundHandler = (context, failure) -> {
        failure.printStackTrace();
        context.setErrorDescription(objectTransformer.buildRefundErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext c) {
        return Uni.createFrom().item(c)
                .flatMap(this::buildPayload)
                .map(payload -> {
                    String error = dtoValidationService.validateRequest(payload.getRequestDto());
                    payload.setValidationErrorMessage(error);
                    return payload;
                })
                .flatMap(this::executeRequest)
                .onItemOrFailure()
                .transform((response, failure) -> {
                    Tuple2<Response, Throwable> tuple;
                    if (failure != null) {
                        tuple = Tuple2.of(null, failure);
                        Log.errorv("[NETWORKX] Error while processing trxId: {0}; {1}",
                            c.authorizeContext().getTransaction().getId(),  failure.getMessage());
                    } else {
                        tuple = Tuple2.of(response, null);
                    }

                    return objectTransformer.mapToExecuteTransactionResponse(tuple, c.authorizeContext().getTransaction().getId());
                });
    }

    private Uni<Payload> buildPayload(CardAuthorizeContext c) {
        return Uni.createFrom().item(c)
                .flatMap(x -> {
                    var card = x.card();
                    return keyManagementService.decrypt(
                            x.authorizeContext().getMerchant().getPrivateKey(),
                            card.encryptedCardNumber(),
                            card.encryptedCvv()
                    );
                })
                .map(list -> {
                    Log.infov("[NETWORKX] Building payload for trxId: {0}, card_month: {1}, card_year: {2}",
                        c.authorizeContext().getTransaction().getId(),
                        c.card().expirationMonth(),
                        c.card().expirationYear());

                    var transactionTypeContext = c.authorizeContext();
                    var cardDetails = new AuthorizeTransactionRequestDto.RequestData.CreditCard(
                            new String(list.get(0), StandardCharsets.UTF_8),
                            StringUtils.join(transactionTypeContext.getTransaction().getCustomerFirstName(), " ",
                                    transactionTypeContext.getTransaction().getCustomerLastName()),
                            String.valueOf(c.card().expirationMonth()),
                            String.valueOf(Utils.thousandPadYear(c.card().expirationYear())),
                            new String(list.get(1), StandardCharsets.UTF_8)
                    );
                    return buildPayload(transactionTypeContext, cardDetails);
                });
    }

    private Payload buildPayload(TransactionTypeContext transactionTypeContext, AuthorizeTransactionRequestDto.RequestData.CreditCard creditCard) {
        var transaction = transactionTypeContext.getTransaction();

        var customer = objectTransformer.mapToCustomer(transaction);
        var billingAddress = objectTransformer.mapToBillingAddress(transaction);
        var accountConfig = Utils.getRuntimeAccountConfig(transactionTypeContext.getPaymentProviderAccount(), RuntimeAccountConfig.class);

//        String baseUrl = "https://gentle-heads-sniff.loca.lt";
        String baseUrl = transactionTypeContext.getTenantConfig().url();
        var authorizeContext = new AuthorizeTransactionRequestDto(
                new AuthorizeTransactionRequestDto.RequestData(
                        transaction.getAmount(),
                        transaction.getCurrency().toUpperCase(),
                        nullSafe(transactionTypeContext.getPaymentProviderAccount()
                                .getData()
                                .getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()),
                        transaction.getId(),
                        transaction.getTransactionData().getSuccessUrl(),
                        UriBuilder.fromUri(baseUrl)
                                .path(NetworxCallbackResource.class)
                                .build().toString(),
                        accountConfig.isTest(),
                        transaction.getCustomerCountry().toLowerCase(),
                        creditCard,
                        customer,
                        billingAddress
                )
        );
        return new Payload(authorizeContext, accountConfig, null);
    }

    private Uni<Response> executeRequest(Payload payload) {
        if (payload.getValidationErrorMessage() == null) {
            var authHeader = Utils.buildBasicAuthToken(payload.getRuntimeAccountConfig().shopId(), payload.getRuntimeAccountConfig().secretKey());

            return apiClient.authorize(payload.getRequestDto(), authHeader);
        }
        return Uni.createFrom().item(() -> Response.status(VALIDATION_ERROR_CODE).entity(payload.getValidationErrorMessage()).build());
    }

    public Uni<ExecuteTransactionResponse> requestRefund(ManageTransactionContext manageContext) {
        NetworxRefundContext ctx = new NetworxRefundContext();
        return SafeUni.from(ctx, defaultRefundHandler, ctx)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateRefundContext(ctx1, manageContext))
                .safeFlatMap(PHASE_REQUEST_REFUND, this::requestPaymentRefund)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private Uni<NetworxRefundContext> requestPaymentRefund(NetworxRefundContext context) {
        var authHeader = Utils.buildBasicAuthToken(context.getRuntimeAccountConfig().shopId(), context.getRuntimeAccountConfig().secretKey());

        return SafeUni.from(context, defaultRefundHandler, context)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> apiClient.refund(context.getRefundRequest(), authHeader))
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentRefundResponse(context, response))
                .endSubPhase();
    }

    @SneakyThrows
    private NetworxRefundContext hydrateRefundContext(NetworxRefundContext context, ManageTransactionContext manageContext) {
        var parentTransactionRefNum = manageContext.transactionTypeContext().getParentTransaction().getReferenceNumber();

        RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(manageContext.transactionTypeContext().getPaymentProviderAccount(), RuntimeAccountConfig.class);
        context.setContext(manageContext);
        context.setRuntimeAccountConfig(rac);
        context.setReferenceNumber(parentTransactionRefNum);
        context.setRefundRequest(objectTransformer.buildPaymentRefundRequest(manageContext));

        return context;
    }

    @SneakyThrows
    private NetworxRefundContext parsePaymentRefundResponse(NetworxRefundContext ctx, Response response) {
        //preserve payment api invocation response for later usage
        ctx.setRefundResponseAsString(response.readEntity(String.class));

        //make attempt to transform to successful response
        ctx.setRefundResponse(mapperService.mapAndValidate(ctx.getRefundResponseAsString(), RefundResponse.class));
        return ctx;
    }
}