package com.morefin.pg.networx.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

public record ErrorResponse(
        // available in 422, 401 and 404 response errors. Status is "error", null otherwise
        @JsonProperty("status") String status,
        @JsonProperty("code") String code,
        @JsonProperty("message") String message,
        @JsonProperty("friendly_message") String friendlyMessage,
        // available in 400 response error. Null otherwise
        @JsonProperty("errors") Map<String, Object> errors
) {
}
