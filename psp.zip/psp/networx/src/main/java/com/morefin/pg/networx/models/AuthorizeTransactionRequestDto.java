package com.morefin.pg.networx.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.ToString;

import javax.annotation.Nullable;

@AllArgsConstructor
@ToString
public class AuthorizeTransactionRequestDto {
    @JsonProperty("request")
    @Valid
    private RequestData request;

    @AllArgsConstructor
    @ToString
    public static class RequestData {
        @JsonProperty("amount")
        @NotNull
        private Long amount;

        @JsonProperty("currency")
        @NotNull
        @Size(min = 3, max = 3)
        private String currency;

        @JsonProperty("description")
        @NotNull
        @Size(min = 1, max = 255)
        private String description;

        @JsonProperty("tracking_id")
        @NotNull
        @Size(min = 1, max = 255)
        private String trackingId;

        @JsonProperty("return_url")
        @NotNull
        private String returnUrl;

        @JsonProperty("notification_url")
        @NotNull
        private String notificationUrl;

        @JsonProperty("test")
        @NotNull
        private boolean test;

        @JsonProperty("language")
        @Size(min = 2, max = 2)
        @Nullable
        private String language;

        @JsonProperty("credit_card")
        @Valid
        private CreditCard creditCard;

        @JsonProperty("customer")
        @Valid
        private Customer customer;

        @JsonProperty("billing_address")
        @Valid
        private BillingAddress billingAddress;

        @AllArgsConstructor
        @ToString
        public static class CreditCard {
            @JsonProperty("number")
            @NotNull
            private String number;

            @JsonProperty("holder")
            @NotNull
//            @Size(min = 1, max = 35)
            private String holder;

            @JsonProperty("exp_month")
            @NotNull
//            @Size(min = 1, max = 2)
//            @Pattern(regexp = "^(0?[1-9]|1[0-2])$", message = "Expiration month must be a number between 1 and 12")
            private String expirationMonth;

            @JsonProperty("exp_year")
            @NotNull
//            @Digits(integer = 4, fraction = 0)
//            @Size(min = 4, max = 4)
            private String expirationYear;

            @JsonProperty("verification_value")
//            @NotNull
//            @Pattern(regexp = "^\\d{3,4}$", message = "verification_value must be 3 or 4 digits")
            private String cvv;
        }

        @AllArgsConstructor
        @ToString
        public static class Customer {
            @JsonProperty("ip")
            @NotNull
            private String ip;

            @JsonProperty("email")
            @NotNull
            @Email
            private String email;

            @JsonProperty("birth_date")
            @Nullable
            @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Date must be in the format YYYY-MM-DD")
            private String birthDate;
        }

        @AllArgsConstructor
        @ToString
        public static class BillingAddress {
            @JsonProperty("first_name")
            @NotNull
            @Size(min = 1, max = 30)
            private String firstName;

            @JsonProperty("last_name")
            @NotNull
            @Size(min = 1, max = 30)
            private String lastName;

            @JsonProperty("country")
            @NotNull
            @Size(min = 2, max = 2)
            private String country;

            @JsonProperty("city")
            @NotNull
            @Size(min = 1, max = 60)
            private String city;

            // Required for US and CA only
            //        @JsonProperty("state")
            //        @Nullable
            //        @Size(min = 2, max = 2)
            //        private String state;

            @JsonProperty("address")
            @NotNull
            @Size(min = 1, max = 255)
            private String address;

            @JsonProperty("zip")
            @NotNull
            private String zip;

            @JsonProperty("phone")
            @NotNull
            @Size(min = 1, max = 100)
            private String phone;
        }
    }
}
