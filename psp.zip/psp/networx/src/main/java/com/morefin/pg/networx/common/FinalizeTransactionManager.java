package com.morefin.pg.networx.common;

import com.morefin.common.common.payments.auth.IApiUser;
import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.domain.tables.pojos.PaymentProviderAccount;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.networx.models.ApiResponseDto;
import com.morefin.pg.networx.models.PaymentResponse;
import com.morefin.pg.networx.models.RefundResponse;
import com.morefin.pg.networx.util.NetworxObjectTransformer;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

import java.util.Map;
import java.util.Set;

@ApplicationScoped
public class FinalizeTransactionManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    NetworxObjectTransformer objectTransformer;

    @Inject
    SignatureUtils signatureUtils;

    @Inject
    Utils utils;

    @Inject
    DtoMapperService mapperService;

    public Uni<Response> finalizeTransaction(String responseBody, String signature, String tenantId) {
        var grpc = GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                getServiceAccount(),
                Constants.LOCALHOST);

        return Uni.createFrom().item(mapperService.mapAndValidate(responseBody, PaymentResponse.class))
                .flatMap(paymentResponse -> validateCallbackResponse(paymentResponse.getTransaction().getTrackingId(), responseBody, signature, tenantId)
                        .replaceWith(paymentResponse)
                )
                .map(paymentResponse -> objectTransformer.mapToFinalizeTransactionRequest(paymentResponse, responseBody))
                .flatMap(grpc::finalizeTransaction)
                .map(result -> {
                    return Response.ok().build();
                });
    }

    public Uni<Void> validateCallbackResponse(
            String transactionId,
            String rawBody,
            String signature,
            String tenantId
    ) {
        return signatureUtils.findPaymentProviderSignatureSecret(transactionId, tenantId, this::getPublicKey)
                .flatMap(publicKeyBase64 -> {
                    if (!SignatureUtils.verifySha256Signature(rawBody, signature, publicKeyBase64)) {
                        Log.errorf("Invalid signature for transaction: %s", transactionId);
                        return Uni.createFrom().failure(new SecurityException("Invalid signature"));
                    }
                    return Uni.createFrom().voidItem();
                });
    }

    private String getPublicKey(PaymentProviderAccount account) {
        return Utils.getRuntimeAccountConfig(account, RuntimeAccountConfig.class).publicKey();
    }

    private IApiUser getServiceAccount() {
        return GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "networx-service-account"
        );
    }
}
