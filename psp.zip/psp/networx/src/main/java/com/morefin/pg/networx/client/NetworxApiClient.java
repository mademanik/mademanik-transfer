package com.morefin.pg.networx.client;

import com.morefin.pg.networx.models.AuthorizeTransactionRequestDto;
import com.morefin.pg.networx.models.RefundRequest;
import io.quarkus.rest.client.reactive.ClientExceptionMapper;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/transactions")
@RegisterRestClient(configKey = "networx")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface NetworxApiClient {

    @POST
    @Path("/payments")
    Uni<Response> authorize(
            AuthorizeTransactionRequestDto request,
            @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader
    );

    @POST
    @Path("/refunds")
    Uni<Response> refund(
            RefundRequest request,
            @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader
    );

    @ClientExceptionMapper
    static RuntimeException toException(Response response) {
        String responseAsString = response.readEntity(String.class);
        return new RuntimeException(response.getStatusInfo().getReasonPhrase() + "; body: " + responseAsString);
    }
}
