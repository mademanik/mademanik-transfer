package com.morefin.pg.networx.common;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
        @JsonProperty("shop_id")
        String shopId,
        @JsonProperty("secret_key")
        String secretKey,
        @JsonProperty("public_key")
        String publicKey,
        @JsonProperty("is_test")
        boolean isTest
) {
}