package com.morefin.pg.networx.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentResponse implements Serializable {
    @JsonProperty("transaction")
    private Transaction transaction;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Transaction {

        @JsonProperty("uid")
        private String uid;

        @JsonProperty("status")
        private String status;

        @JsonProperty("amount")
        private Integer amount;

        @JsonProperty("currency")
        private String currency;

        @JsonProperty("description")
        private String description;

        @JsonProperty("type")
        private String type;

        @JsonProperty("payment_method_type")
        private String paymentMethodType;

        @JsonProperty("tracking_id")
        private String trackingId;

        @JsonProperty("message")
        private String message;

        @JsonProperty("test")
        private Boolean test;

        @JsonProperty("created_at")
        private String createdAt;

        @JsonProperty("updated_at")
        private String updatedAt;

        @JsonProperty("paid_at")
        private String paidAt;

        @JsonProperty("expired_at")
        private String expiredAt;

        @JsonProperty("recurring_type")
        private String recurringType;

        @JsonProperty("closed_at")
        private String closedAt;

        @JsonProperty("settled_at")
        private String settledAt;

        @JsonProperty("manually_corrected_at")
        private String manuallyCorrectedAt;

        @JsonProperty("language")
        private String language;

        @JsonProperty("credit_card")
        private CreditCard creditCard;

        @JsonProperty("receipt_url")
        private String receiptUrl;

        @JsonProperty("status_code")
        private String statusCode;

        @JsonProperty("gateway")
        private Gateway gateway;

        @JsonProperty("mute_notifications")
        private Boolean muteNotifications;

        @JsonProperty("version")
        private Integer version;

        @JsonProperty("psp_settled_at")
        private String pspSettledAt;

        @JsonProperty("registry_id")
        private String registryId;

        @JsonProperty("three_ds_expired_at")
        private String threeDsExpiredAt;

        @JsonProperty("id")
        private String id;

        @JsonProperty("redirect_url")
        private String redirectUrl;

        @JsonProperty("code")
        private String code;

        @JsonProperty("friendly_message")
        private String friendlyMessage;

        @JsonProperty("smart_routing_verification")
        private SmartRoutingVerification smartRoutingVerification;

        @JsonProperty("payment")
        private Payment payment;

        @JsonProperty("avs_cvc_verification")
        private AvsCvcVerification avsCvcVerification;

        @JsonProperty("customer")
        private Customer customer;

        @JsonProperty("billing_address")
        private BillingAddress billingAddress;

        // getters & setters omitted for brevity
        // (generate via IDE: Alt+Insert)
    }

    public static class CreditCard {

        @JsonProperty("holder")
        private String holder;

        @JsonProperty("stamp")
        private String stamp;

        @JsonProperty("brand")
        private String brand;

        @JsonProperty("last_4")
        private String last4;

        @JsonProperty("first_1")
        private String first1;

        @JsonProperty("bin")
        private String bin;

        @JsonProperty("bin_8")
        private String bin8;

        @JsonProperty("issuer_country")
        private String issuerCountry;

        @JsonProperty("issuer_name")
        private String issuerName;

        @JsonProperty("product")
        private String product;

        @JsonProperty("exp_month")
        private Integer expMonth;

        @JsonProperty("exp_year")
        private Integer expYear;

        @JsonProperty("token_provider")
        private String tokenProvider;

        @JsonProperty("token")
        private String token;
    }

    public static class Gateway {

        @JsonProperty("iframe")
        private Boolean iframe;
    }

    public static class SmartRoutingVerification {

        @JsonProperty("status")
        private String status;
    }

    public static class Payment {

        @JsonProperty("auth_code")
        private String authCode;

        @JsonProperty("bank_code")
        private String bankCode;

        @JsonProperty("rrn")
        private String rrn;

        @JsonProperty("ref_id")
        private String refId;

        @JsonProperty("message")
        private String message;

        @JsonProperty("amount")
        private Integer amount;

        @JsonProperty("currency")
        private String currency;

        @JsonProperty("billing_descriptor")
        private String billingDescriptor;

        @JsonProperty("gateway_id")
        private Integer gatewayId;

        @JsonProperty("status")
        private String status;
    }

    public static class AvsCvcVerification {

        @JsonProperty("avs_verification")
        private ResultVerification avsVerification;

        @JsonProperty("cvc_verification")
        private ResultVerification cvcVerification;
    }

    public static class ResultVerification {

        @JsonProperty("result_code")
        private String resultCode;
    }

    public static class Customer {

        @JsonProperty("ip")
        private String ip;

        @JsonProperty("email")
        private String email;

        @JsonProperty("device_id")
        private String deviceId;

        @JsonProperty("birth_date")
        private String birthDate;

        @JsonProperty("external_id")
        private String externalId;
    }

    public static class BillingAddress {

        @JsonProperty("first_name")
        private String firstName;

        @JsonProperty("last_name")
        private String lastName;

        @JsonProperty("address")
        private String address;

        @JsonProperty("country")
        private String country;

        @JsonProperty("city")
        private String city;

        @JsonProperty("zip")
        private String zip;

        @JsonProperty("state")
        private String state;

        @JsonProperty("phone")
        private String phone;
    }
}
