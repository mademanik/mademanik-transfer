package com.morefin.pg.networx.authentication;

import com.morefin.common.authenticationgatewayspi.spi.AuthenticationServiceProvider;
import com.morefin.common.authenticationgatewayspi.spi.BaseAuthenticationService;
import io.quarkus.arc.Arc;

public class NetworxAuthenticationServiceProvider implements AuthenticationServiceProvider {

    @Override
    public BaseAuthenticationService create() {

        try (var instance = Arc.container().instance(NetworxCardAuthenticationService.class)) {
            return instance.get();
        }
    }
}
