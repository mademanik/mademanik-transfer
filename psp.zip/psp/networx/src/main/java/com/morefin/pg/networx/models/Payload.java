package com.morefin.pg.networx.models;

import com.morefin.pg.networx.common.RuntimeAccountConfig;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class Payload {
    AuthorizeTransactionRequestDto requestDto;
    RuntimeAccountConfig runtimeAccountConfig;
    String validationErrorMessage;
}
