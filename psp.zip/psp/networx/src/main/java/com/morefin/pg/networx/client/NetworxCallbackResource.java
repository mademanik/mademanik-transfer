package com.morefin.pg.networx.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.networx.common.FinalizeTransactionManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.Map;

import static com.morefin.pg.networx.util.Constants.CALLBACK_URL;
import static com.morefin.pg.networx.util.Constants.SIGNATURE_HEADER;

@Path(CALLBACK_URL)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class NetworxCallbackResource {

    @Inject
    FinalizeTransactionManager finalizeTransactionManager;

    @Inject
    Tenant tenant;

    @POST
    public Uni<Response> receiveCallback(
            String rawJson,
            @HeaderParam(SIGNATURE_HEADER) String signature
    ) {
        return finalizeTransactionManager.finalizeTransaction(rawJson, signature, tenant.id())
                .onFailure(SecurityException.class)
                .recoverWithItem(() ->
                        Response.status(Response.Status.BAD_REQUEST)
                                .entity(Map.of("error", "Invalid signature")).build()
                )
                .onFailure()
                .recoverWithItem(throwable ->
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                                .entity(Map.of("error", throwable.getMessage())).build()
                );
    }
}
