package com.morefin.pg.networx.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RefundTransactionResponse implements Serializable {
    @JsonProperty("uid")
    private String uid;

    @JsonProperty("status")
    private String status;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("reason")
    private String reason;

    @JsonProperty("type")
    private String type;

    @JsonProperty("message")
    private String message;

    @JsonProperty("test")
    private Boolean test;

    @JsonProperty("created_at")
    private String createdAt;

    @JsonProperty("updated_at")
    private String updatedAt;

    @JsonProperty("paid_at")
    private String paidAt;

    @JsonProperty("closed_at")
    private String closedAt;

    @JsonProperty("settled_at")
    private String settledAt;

    @JsonProperty("manually_corrected_at")
    private String manuallyCorrectedAt;

    @JsonProperty("parent_uid")
    private String parentUid;

    @JsonProperty("receipt_url")
    private String receiptUrl;

    @JsonProperty("status_code")
    private String statusCode;

    @JsonProperty("mute_notifications")
    private Boolean muteNotifications;

    @JsonProperty("version")
    private Integer version;

    @JsonProperty("psp_settled_at")
    private String pspSettledAt;

    @JsonProperty("registry_id")
    private String registryId;

    @JsonProperty("tracking_id")
    private String trackingId;

    @JsonProperty("id")
    private String id;

    @JsonProperty("code")
    private String code;

    @JsonProperty("friendly_message")
    private String friendlyMessage;

    @JsonProperty("refund")
    private RefundTransactionRefundResponse refund;
}
