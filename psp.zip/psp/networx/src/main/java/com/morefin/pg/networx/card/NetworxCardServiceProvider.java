package com.morefin.pg.networx.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import com.morefin.pg.networx.card.admin.NetworxAdminServiceProvider;
import io.quarkus.arc.Arc;

import java.util.List;

public class NetworxCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {

    NetworxAdminServiceProvider adminServiceProvider;

    public NetworxCardServiceProvider() {
        adminServiceProvider = new NetworxAdminServiceProvider();
    }

    @Override
    public String name() {
        return adminServiceProvider.name();
    }

    @Override
    public String id() {
        return adminServiceProvider.id();
    }

    @Override
    public String type() {
        return adminServiceProvider.type();
    }

    @Override
    public EcommerceCardPaymentProcessingService create() {
        try (var instance = Arc.container().instance(NetworxPaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return adminServiceProvider.types();
    }
}
