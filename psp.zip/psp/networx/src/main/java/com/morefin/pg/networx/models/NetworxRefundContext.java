package com.morefin.pg.networx.models;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.pg.networx.common.RuntimeAccountConfig;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class NetworxRefundContext extends BaseTransactionContext<String> {

    ManageTransactionContext context;
    RuntimeAccountConfig runtimeAccountConfig;

    RefundRequest refundRequest;
    RefundResponse refundResponse;
    String refundResponseAsString;

    String referenceNumber;

    public NetworxRefundContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}