package com.morefin.pg.networx.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RefundTransactionRefundResponse implements Serializable {
    @JsonProperty("message")
    private String message;

    @JsonProperty("ref_id")
    private String refId;

    @JsonProperty("rrn")
    private String rrn;

    @JsonProperty("auth_code")
    private String authCode;

    @JsonProperty("bank_code")
    private String bankCode;

    @JsonProperty("gateway_id")
    private Integer gatewayId;

    @JsonProperty("status")
    private String status;
}
