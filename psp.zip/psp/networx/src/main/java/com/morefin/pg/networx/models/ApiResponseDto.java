package com.morefin.pg.networx.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;


@JsonIgnoreProperties(ignoreUnknown = true)
public record ApiResponseDto(
        @JsonProperty("uid") String transactionId,
        @JsonProperty("tracking_id") String trackingId,
        @JsonProperty("status") Status status,
        @JsonProperty("code") String statusCode,
        @JsonProperty("friendly_message") String friendlyMessage,
        @JsonProperty("message") String message,
        @JsonProperty("redirect_url") String redirectUrl
) {

    @AllArgsConstructor
    @Getter
    public enum Status {
        SUCCESSFUL("successful"),
        INCOMPLETE("incomplete"),
        FAILED("failed"),
        PROCESSING("processing"),
        UNKNOWN("unknown"),
        COMPLETED("completed");

        private final String value;

        @JsonCreator
        public static Status fromValue(String value) {
            for (Status status : Status.values()) {
                if (status.value.equalsIgnoreCase(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown status value: " + value);
        }
    }
}