package com.morefin.psp.db.processing;

import com.morefin.common.common.payments.services.payment_gateway.common.ListUtil;
import com.morefin.common.common.payments.services.payment_gateway.common.domain.BaseRepository;
import com.morefin.psp.db.domain.Tables;
import com.morefin.psp.db.domain.tables.daos.StripeAccountsDao;
import com.morefin.psp.db.domain.tables.mappers.RowMappers;
import com.morefin.psp.db.domain.tables.pojos.StripeAccounts;
import com.morefin.psp.db.domain.tables.records.StripeAccountsRecord;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.unchecked.Unchecked;
import io.vertx.mutiny.sqlclient.SqlConnection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.jooq.Condition;
import org.jooq.DSLContext;
import org.jooq.conf.ParamType;

import java.util.List;
import java.util.Optional;


@ApplicationScoped
public class StripeRepository extends BaseRepository {

    public static final com.morefin.psp.db.domain.tables.StripeAccounts TABLE = Tables.STRIPE_ACCOUNTS;
    @Inject
    StripeAccountsDao dao;

    @Inject
    DSLContext dslContext;


    public Uni<Integer> insert(StripeAccounts stripeAccount) {
       return  dao.insert(stripeAccount);
    }



    public Uni<StripeAccountsRecord> insert(SqlConnection connection, StripeAccounts entity) {
        return connection.query(
                dslContext.insertInto(TABLE)
                        .set(entity.into(new StripeAccountsRecord()))
                        .returning(TABLE.asterisk())
                        .getSQL(ParamType.INLINED)
        ).execute().map(Unchecked.function(r -> {
            if (r.rowCount() > 0) {
                return new StripeAccountsRecord(RowMappers.getStripeAccountsMapper().apply(r.iterator().next().getDelegate()));
            } else {
                throw new IllegalStateException("Insert failed");
            }
        }));
    }


    public Uni<Optional<StripeAccounts>> findByMerchantIdAndMail(String merchantId, String ppa, String email) {
        return dao.findManyByCondition(
                TABLE.MERCHANT_ID.eq(merchantId)
                        .and(TABLE.EMAIL.eq(email).and(TABLE.PAYMENT_PROVIDER_ACCOUNT_ID.eq(ppa)))
        ).map(ListUtil::getFirstOrEmpty);
    }

    public Uni<StripeAccounts> update(SqlConnection connection, String query) {
        return connection.query(query)
                .execute().map(Unchecked.function(r -> {
                    if (r.rowCount() > 0) {
                        return RowMappers.getStripeAccountsMapper().apply(r.iterator().next().getDelegate());
                    } else {
                        throw new IllegalStateException("Update failed");
                    }
                }));
    }

    public Uni<List<StripeAccounts>> list(Condition condition) {
        return dao.findManyByCondition(condition, 50, TABLE.CREATED_AT.desc());
    }

}
