package com.morefin.psp.db.processing;

import com.morefin.psp.db.domain.tables.daos.StripeAccountsDao;
import com.morefin.psp.db.domain.tables.daos.X1AccountsDao;
import io.vertx.mutiny.pgclient.PgPool;
import jakarta.enterprise.inject.Default;
import jakarta.enterprise.inject.Produces;
import org.jooq.Configuration;

public class Module {

    @Default
    @Produces
    public X1AccountsDao x1AccountsDao(Configuration configuration, PgPool client) {
        return new X1AccountsDao(configuration, client);
    }

    @Default
    @Produces
    public StripeAccountsDao stripeAccountsDao(Configuration configuration, PgPool client) {
        return new StripeAccountsDao(configuration, client);
    }
}
