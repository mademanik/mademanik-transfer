package com.morefin.psp.filter;

import com.morefin.paymentgateway.service.gateway.grpc.processing.services.actionlogs.ActionLogsService;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.ClientResponseContext;
import jakarta.ws.rs.client.ClientResponseFilter;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.Provider;
import org.jboss.logging.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@Provider
@Priority(Priorities.USER)
public class PspCallFilter implements ClientRequestFilter, ClientResponseFilter {
    private static final Logger LOGGER = Logger.getLogger(PspCallFilter.class);

    @Inject
    CallContext pspCallContext;

    @Inject
    ActionLogsService actionLogsService;

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {

    }

    @Override
    public void filter(ClientRequestContext requestContext, ClientResponseContext responseContext) throws IOException {
        try {
            if(pspCallContext.getTenantId() == null)
            {
                LOGGER.infof("PspCallFilter called without context for URI: %s", requestContext.getUri());
                return;
            }

            String responsePayload = null;
            if (responseContext.hasEntity() && responseContext.getStatus() != 204) {
                byte[] responseBytes = responseContext.getEntityStream().readAllBytes();
                responsePayload = new String(responseBytes, StandardCharsets.UTF_8);
                responseContext.setEntityStream(new ByteArrayInputStream(responseBytes));
            }

            var tenant = pspCallContext.getTenantId() ;
            var merchant = pspCallContext.getMerchantId();
            var logRequest = new ActionLogsService.LogRequest("request",
                requestContext.getMethod(), "transaction", pspCallContext.getTransactionId(),
                requestContext.getUri().toString(),
                new JsonObject()
                    .put("request", new JsonObject()
                        .put("headers", normalizeHeaders(requestContext.getHeaders()))
                        .put("body", normalizeRequestEntity(requestContext.getEntity()))
                    )
                    .put("response", normalizeResponsePayload(responsePayload))
            );
            actionLogsService.logRequest(tenant, merchant, logRequest)
                .subscribe().with(test -> {});

        } catch (RuntimeException e) {
        }
    }

    private Object normalizeRequestEntity(Object entity) {
        if (entity == null) {
            return null;
        }
        if (entity instanceof MultivaluedMap<?, ?> multivaluedMap) {
            return normalizeMap(multivaluedMap);
        }
        if (entity instanceof Map<?, ?> map) {
            return normalizeMap(map);
        }
        return entity;
    }


    private JsonObject normalizeHeaders(MultivaluedMap<String, Object> headers) {
        JsonObject jsonObject = new JsonObject();
        for (Map.Entry<String, List<Object>> entry : headers.entrySet()) {
            Object rawValue = entry.getValue();
            if (rawValue instanceof List<?> values) {
                if (values.isEmpty()) {
                    jsonObject.put(entry.getKey(), "");
                } else if (values.size() == 1) {
                    jsonObject.put(entry.getKey(), values.get(0));
                } else {
                    jsonObject.put(entry.getKey(), String.join(",", values.stream().map(String::valueOf).toList()));
                }
            } else {
                jsonObject.put(entry.getKey(), "");
            }
        }
        return jsonObject;
    }

    private JsonObject normalizeMap(Map<?, ?> map) {
        JsonObject jsonObject = new JsonObject();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            String key = String.valueOf(entry.getKey());
            jsonObject.put(key, normalizeMapValue(entry.getValue()));
        }
        return jsonObject;
    }

    private Object normalizeMapValue(Object value) {
        if (value instanceof List<?> list) {
            if (list.size() == 1) {
                return list.get(0);
            }
            return new JsonArray(list);
        }
        return value;
    }

    private Object normalizeResponsePayload(String responsePayload) {
        if (responsePayload == null || responsePayload.isBlank()) {
            return null;
        }
        try {
            return new JsonObject(responsePayload);
        } catch (RuntimeException ignored) {
        }
        try {
            return new JsonArray(responsePayload);
        } catch (RuntimeException ignored) {
        }
        return responsePayload;
    }
}
