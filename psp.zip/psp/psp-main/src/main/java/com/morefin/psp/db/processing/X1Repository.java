package com.morefin.psp.db.processing;

import com.morefin.common.common.payments.services.payment_gateway.common.ListUtil;
import com.morefin.common.common.payments.services.payment_gateway.common.domain.BaseRepository;
import com.morefin.psp.db.domain.Tables;
import com.morefin.psp.db.domain.tables.daos.X1AccountsDao;
import com.morefin.psp.db.domain.tables.mappers.RowMappers;
import com.morefin.psp.db.domain.tables.pojos.X1Accounts;
import com.morefin.psp.db.domain.tables.records.X1AccountsRecord;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.unchecked.Unchecked;
import io.vertx.mutiny.sqlclient.SqlConnection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.jooq.Condition;
import org.jooq.DSLContext;
import org.jooq.conf.ParamType;

import java.util.List;
import java.util.Optional;


@ApplicationScoped
public class X1Repository extends BaseRepository {

    public static final com.morefin.psp.db.domain.tables.X1Accounts TABLE = Tables.X1_ACCOUNTS;
    @Inject
    X1AccountsDao dao;

    @Inject
    DSLContext dslContext;


    public Uni<Integer> insert(X1Accounts x1Account) {
       return  dao.insert(x1Account);
    }



    public Uni<X1AccountsRecord> insert(SqlConnection connection, X1Accounts entity) {
        return connection.query(
                dslContext.insertInto(TABLE)
                        .set(entity.into(new X1AccountsRecord()))
                        .returning(TABLE.asterisk())
                        .getSQL(ParamType.INLINED)
        ).execute().map(Unchecked.function(r -> {
            if (r.rowCount() > 0) {
                return new X1AccountsRecord(RowMappers.getX1AccountsMapper().apply(r.iterator().next().getDelegate()));
            } else {
                throw new IllegalStateException("Insert failed");
            }
        }));
    }


    public Uni<Optional<X1Accounts>> findByMerchantIdAndMail(String merchantId, String email) {
        return dao.findManyByCondition(
                TABLE.MERCHANT_ID.eq(merchantId)
                        .and(TABLE.EMAIL.eq(email))
        ).map(ListUtil::getFirstOrEmpty);
    }

    public Uni<X1Accounts> update(SqlConnection connection, String query) {
        return connection.query(query)
                .execute().map(Unchecked.function(r -> {
                    if (r.rowCount() > 0) {
                        return RowMappers.getX1AccountsMapper().apply(r.iterator().next().getDelegate());
                    } else {
                        throw new IllegalStateException("Update failed");
                    }
                }));
    }

    public Uni<List<X1Accounts>> list(Condition condition) {
        return dao.findManyByCondition(condition, 50, TABLE.CREATED_AT.desc());
    }

}
