package com.morefin.psp.db.domain.tables.mappers;

import io.vertx.sqlclient.Row;
import java.util.function.Function;

public class RowMappers {

        private RowMappers(){}

        public static Function<Row,com.morefin.psp.db.domain.tables.pojos.StripeAccounts> getStripeAccountsMapper() {
                return row -> {
                        com.morefin.psp.db.domain.tables.pojos.StripeAccounts pojo = new com.morefin.psp.db.domain.tables.pojos.StripeAccounts();
                        pojo.setCreatedAt(row.getOffsetDateTime("created_at"));
                        pojo.setUpdatedAt(row.getOffsetDateTime("updated_at"));
                        pojo.setMerchantId(row.getString("merchant_id"));
                        pojo.setEmail(row.getString("email"));
                        pojo.setCustomerId(row.getString("customer_id"));
                        pojo.setTenantId(row.getString("tenant_id"));
                        pojo.setPaymentProviderAccountId(row.getString("payment_provider_account_id"));
                        return pojo;
                };
        }

        public static Function<Row,com.morefin.psp.db.domain.tables.pojos.X1Accounts> getX1AccountsMapper() {
                return row -> {
                        com.morefin.psp.db.domain.tables.pojos.X1Accounts pojo = new com.morefin.psp.db.domain.tables.pojos.X1Accounts();
                        pojo.setCreatedAt(row.getOffsetDateTime("created_at"));
                        pojo.setUpdatedAt(row.getOffsetDateTime("updated_at"));
                        pojo.setMerchantId(row.getString("merchant_id"));
                        pojo.setEmail(row.getString("email"));
                        pojo.setAuthToken(row.getString("auth_token"));
                        return pojo;
                };
        }

}
