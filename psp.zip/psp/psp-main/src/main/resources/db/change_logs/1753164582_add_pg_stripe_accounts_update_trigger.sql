CREATE OR REPLACE FUNCTION psp_svc.update_stripe_accounts_timestamp()
    RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trg_stripe_accounts_update
    BEFORE UPDATE ON psp_svc.stripe_accounts
    FOR EACH ROW
    WHEN (OLD.* IS DISTINCT FROM NEW.*) -- Only if values change
        EXECUTE FUNCTION psp_svc.update_stripe_accounts_timestamp();

