package com.morefin.pg.processtransact.card;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.TransactionExecuteRequest;
import com.morefin.common.keymanagementspi.keys.KeyManagementService;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessinggatewayspi.spi.transactiontype.TransactionActionContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.processtransact.Config;
import com.morefin.pg.processtransact.admin.card.ProcessTransactCardAdminPaymentProcessingService;
import com.morefin.pg.processtransact.http.ApiClient;
import com.morefin.pg.processtransact.model.AccountConfig;
import com.morefin.pg.processtransact.model.PurchaseRequest;
import com.morefin.pg.processtransact.model.PurchaseResponse;
import com.morefin.pg.processtransact.model.RefundRequest;
import com.morefin.pg.utils.Utils;
import io.quarkus.arc.Unremovable;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.unchecked.Unchecked;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse.Status;
import static com.morefin.common.paymentprocessingspi.ProcessingCode.*;

@ApplicationScoped
@Unremovable
public class ProcessTransactCardPaymentProcessingService implements EcommerceCardPaymentProcessingService {
    private static final short CARD = 1;
    private static final short PURCHASE = 0;
    private static final short REFUND = 5;

    @Inject
    ProcessTransactCardAdminPaymentProcessingService adminProcessingService;

    @Inject
    KeyManagementService keyManagementService;

    @Inject
    @RestClient
    ApiClient restClient;

    @Inject
    Config config;

    @Override
    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext cardAuthorizeContext) {
        return keyManagementService.decrypt(
                cardAuthorizeContext.authorizeContext().getMerchant().getPrivateKey(),
                cardAuthorizeContext.card().encryptedCardNumber(),
                cardAuthorizeContext.card().encryptedCvv()
            ).flatMap(d -> {
                var accountConfig = Utils.getRuntimeAccountConfig(cardAuthorizeContext.authorizeContext().getPaymentProviderAccount(), AccountConfig.class);
                var transaction = cardAuthorizeContext.authorizeContext().getTransaction();
                var context = (TransactionActionContext<TransactionExecuteRequest, com.morefin.common.grpc.transaction.ExecuteTransactionResponse>) cardAuthorizeContext.authorizeContext();
                var req = new PurchaseRequest(
                    CARD,
                    PURCHASE,
                    accountConfig.name(),
                    accountConfig.password(),
                    transaction.getId(),
                    transaction.getCurrency(),
                    transaction.getAmount().toString(),
                    cardAuthorizeContext.card().brand(),
                    transaction.getCustomerFirstName() + " " + transaction.getCustomerLastName(),
                    new String(d.get(0), StandardCharsets.UTF_8),
                    cardAuthorizeContext.card().expirationYear().toString(),
                    cardAuthorizeContext.card().expirationMonth().toString(),
                    new String(d.get(1), StandardCharsets.UTF_8),
                    transaction.getCustomerFirstName(),
                    transaction.getCustomerLastName(),
                    transaction.getCustomerAddress(),
                    List.of(),
                    transaction.getCustomerCity(),
                    transaction.getCustomerPostalCode(),
                    transaction.getCustomerCity(),
                    transaction.getCustomerCountry(),
                    transaction.getCustomerEmail(),
                    transaction.getCustomerPhoneNumber(),
                    "", //dob
                    transaction.getUserIp(), //ip,
                    context.request().getReturnUrl(),
                    context.request().getErrorUrl(),
                    config.callbackHost() + "/psp/process-transact/callback"
                );
                Log.infov("[ProcessTransact] Sending purchase request, req={0}", req.MerchantRef());
                return restClient.post(req);
            })
            .invoke(t -> {
                Log.infov("[ProcessTransact] Received response, response={0}", JsonObject.mapFrom(t));
            })
            .flatMap(Unchecked.function(resp -> {
                var respCode = resp.ResponseCode();
                var transaction = cardAuthorizeContext.authorizeContext().getTransaction();
                return getResponse(transaction, resp, respCode);
            }));
    }

    @Override
    public Uni<ExecuteTransactionResponse> manage(ManageTransactionContext manageTransactionContext) {
        var transactionType = manageTransactionContext.transactionType();
        if (!transactionType.equalsIgnoreCase("refund"))
            return Uni.createFrom().failure(new IllegalStateException("Unsupported transaction type: " + transactionType));

        if(manageTransactionContext.transactionTypeContext().getParentTransaction() == null)
            return Uni.createFrom().failure(new IllegalStateException("Parent transaction is null: " + manageTransactionContext.transaction().getId()));

        var accountConfig = Utils.getRuntimeAccountConfig(manageTransactionContext.paymentProviderAccount(), AccountConfig.class);
        var req = new RefundRequest(
            CARD,
            REFUND,
            accountConfig.name(),
            accountConfig.password(),
            manageTransactionContext.transactionTypeContext().getParentTransaction().getId(),
            manageTransactionContext.transactionTypeContext().getParentTransaction().getReferenceNumber()
        );

        Log.infov("[ProcessTransact] Sending refund request, req={0}", req.MerchantRef());
        var transaction = manageTransactionContext.transaction();
        return restClient
            .post(req)
            .flatMap(Unchecked.function(
                resp -> getResponse(transaction, resp, resp.ResponseCode()))
            );
    }

    private Uni<ExecuteTransactionResponse> getResponse(ImmutableTypedTransactionEntity transaction, PurchaseResponse resp, int respCode) {
        var status = switch (respCode) {
            case 0 -> Status.APPROVED;
            case 600 -> Status.PENDING;
            default -> respCode > 500 ?
                Status.ERROR :
                Status.DECLINED;
        };

        var processingCode = switch (status) {
            case APPROVED -> TRX_STATUS_APPROVED;
            case PENDING -> TRX_STATUS_PENDING;
            case ERROR -> TRX_STATUS_FAILED;
            case DECLINED -> TRX_STATUS_DECLINED;
            default -> throw new IllegalStateException("Unexpected value: " + status);
        };

        var trnResp = switch (processingCode) {
            case TRX_STATUS_APPROVED, TRX_STATUS_FAILED, TRX_STATUS_DECLINED ->
                buildResponse(status, processingCode, transaction.getId(), resp);
            case TRX_STATUS_PENDING ->
                buildPendingResponse(status, processingCode, transaction.getId(), resp);
            default -> throw new IllegalStateException("Unexpected value: " + status);
        };

        return Uni.createFrom().item(trnResp);
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return this.adminProcessingService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }

    private ExecuteTransactionResponse buildResponse(Status status, ProcessingCode responseCode, String transactionId, PurchaseResponse response) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
            .setResponse(new GrpcBuilder<>(builder)
                .set(responseCode.name(), builder::setResponseCode)
                .set(String.valueOf(response.TransactionID()), builder::setReferenceNumber)
                .set(response.ResponseDescription(), builder::setResponseMessage)
                .set(transactionId, builder::setId)
                .set("", builder::setApprovalCode)
                .set(JsonObject.mapFrom(response).toString(), builder::setPaymentProviderResponseMessage)
                .set(String.valueOf(response.ResponseCode()), builder::setPaymentProviderResponseCode)
                .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                .set(status.toString(), builder::setPaymentProviderStatus)
                .setAny(status, builder::setStatus)
                .getBuilder().build())
            .build();
    }

    private ExecuteTransactionResponse buildPendingResponse(Status status, ProcessingCode responseCode, String transactionId, PurchaseResponse response) {
        var redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
            .setResponse(new GrpcBuilder<>(builder)
                .set(responseCode.name(), builder::setResponseCode)
                .set(String.valueOf(response.TransactionID()), builder::setReferenceNumber)
                .set(response.ResponseDescription(), builder::setResponseMessage)
                .set(transactionId, builder::setId)
                .set("", builder::setApprovalCode)
                .set(JsonObject.mapFrom(response).toString(), builder::setPaymentProviderResponseMessage)
                .set(String.valueOf(response.ResponseCode()), builder::setPaymentProviderResponseCode)
                .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                .set(status.toString(), builder::setPaymentProviderStatus)
                .setAny(status, builder::setStatus)
                .getBuilder().build())
            .setRedirect(
                new GrpcBuilder<>(redirectBuilder)
                    .set(response.RedirectURL(), redirectBuilder::setUrl)
                    .getBuilder()
                    .build()
            )
            .build();
    }


}