package com.morefin.pg.processtransact.model;

public record RefundRequest(
    short PaymentTypeID,    // smallint (must be "1" for card payment)
    short TransTypeID,      // smallint (must be "4" for cancel)
    String MerchantName,    // varchar(50)
    String MerchantPassword,// nvarchar(50)
    String MerchantRef,     // nvarchar(255)
    String TransactionID      // bigint
) {
}