package com.morefin.pg.processtransact.http;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.pg.processtransact.model.AccountConfig;
import com.morefin.pg.processtransact.model.CallbackRequest;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.unchecked.Unchecked;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.Map;
import java.util.Set;

@Path("/psp/process-transact")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class Callback {
    @Inject
    Tenant tenant;

    @Inject
    SignatureUtils signatureUtils;

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Path("/callback")
    @POST
    public Uni<Response> callbackUrl(CallbackRequest transactionCallback) {
        return signatureUtils.findPaymentProviderAccountData(tenant.id(), String.valueOf(transactionCallback.MerchantRef()))
            .map(Unchecked.function(ppa -> {
                if(ppa ==null)
                    throw new IllegalArgumentException("ppa can not be null");

                var config = Utils.getRuntimeAccountConfig(ppa, AccountConfig.class);
                var concatenated = "%s%s%s%s%s%s".formatted(
                    config.password(),
                    transactionCallback.TransactionID(),
                    transactionCallback.MerchantRef(),
                    transactionCallback.Currency(),
                    transactionCallback.Amount(),
                    transactionCallback.ResponseCode()
                );
                var hashed = signatureUtils.generateSha1Hex(concatenated);

                if(!hashed.equals(transactionCallback.Signature()))
                    throw new IllegalArgumentException("Invalid signature for transaction: " + transactionCallback.TransactionID());

                return FinalizeTransactionRequest
                    .newBuilder()
                    .setPaymentProviderResponseCode(String.valueOf(transactionCallback.ResponseCode()))
                    .setResponseMessage(transactionCallback.ResponseDescription())
                    .setPaymentProviderResponseMessage(transactionCallback.BankDescription())
                    .setStatus(TransactionStatus.APPROVED) // map status
                    .setId(transactionCallback.MerchantRef())
                    .build();
            })).flatMap(finalizeTransactionRequestUni ->
                getTransactionGrpc(tenant.id()).finalizeTransaction(finalizeTransactionRequestUni)
            ).map(
                trxResp -> trxResp.getError().getErrorList().isEmpty() ?
                    Response.ok().build() : Response.serverError().entity(trxResp.getError()).build()
            );
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
            Set.of(),
            Map.of(),
            "processtransact-service-account"
        );
        return GrpcClientFactory.grpc(
            transactionGrpc,
            tenantId,
            serviceAccount,
            Constants.LOCALHOST);
    }
}