package com.morefin.pg.processtransact.http;

import com.morefin.pg.processtransact.model.PurchaseRequest;
import com.morefin.pg.processtransact.model.PurchaseResponse;
import com.morefin.pg.processtransact.model.RefundRequest;
import com.morefin.pg.processtransact.model.RefundResponse;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/")
@RegisterRestClient(configKey = "processtransact")
@Produces(MediaType.APPLICATION_JSON)
public interface ApiClient {
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<PurchaseResponse> post(Object body);
}