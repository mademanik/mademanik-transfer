package com.morefin.pg.processtransact.model;

public record PurchaseResponse(
    short TransTypeID,              // smallint
    String MerchantRef,             // nvarchar(255)
    String Currency,                // char(3)
    long Amount,                    // bigint
    long TransactionID,             // bigint
    String BusinessCase,            // varchar(50)
    String Descriptor,              // varchar(100)
    String Bank,                    // varchar(50)
    int ResponseCode,               // int
    String ResponseDescription,     // varchar(255)
    String BankCode,                // varchar(50)
    String BankDescription,         // varchar(255)
    String RedirectURL              // varchar(255) (nullable if not returned)
) {

}
