package com.morefin.pg.processtransact.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.PaymentProviderType;
import com.morefin.pg.processtransact.admin.card.ProcessTransactCardProcessingModule;
import io.quarkus.arc.Arc;

import java.util.List;

public class ProcessTransactCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {
    @Override
    public EcommerceCardPaymentProcessingService create() {
        try(var instance = Arc.container().instance(ProcessTransactCardPaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return List.of("card", "saved_card");
    }

    @Override
    public String name() {
        return ProcessTransactCardProcessingModule.MODULE_ID;
    }

    @Override
    public String id() {
        return ProcessTransactCardProcessingModule.MODULE_ID;
    }

    @Override
    public String type() {
        return PaymentProviderType.CARD.name();
    }
}
