package com.morefin.pg.processtransact;


import io.smallrye.config.ConfigMapping;
import jakarta.enterprise.context.ApplicationScoped;

@ConfigMapping(prefix = "pt")
public interface Config {
    String callbackHost();
}
