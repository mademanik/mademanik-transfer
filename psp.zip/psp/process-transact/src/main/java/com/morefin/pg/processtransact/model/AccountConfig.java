package com.morefin.pg.processtransact.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public record AccountConfig(
    @JsonProperty("merchant_name")
    String name,
    @JsonProperty("merchant_password")
    String password
) { }
