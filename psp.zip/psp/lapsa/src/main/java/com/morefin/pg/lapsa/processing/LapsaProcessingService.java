package com.morefin.pg.lapsa.processing;

import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.pg.lapsa.LapsaTypeModule;
import com.morefin.pg.lapsa.admin.LapsaAdminService;
import com.morefin.pg.lapsa.http.LapsaApiClient;
import com.morefin.pg.lapsa.http.LapsaClientBuilder;
import com.morefin.pg.lapsa.http.LapsaHttpConstants;
import com.morefin.pg.lapsa.model.ClientData;
import com.morefin.pg.lapsa.model.Config;
import com.morefin.pg.lapsa.model.CreateOrderRequest;
import com.morefin.pg.lapsa.model.CreateOrderResponse;
import com.morefin.pg.lapsa.model.LapsaRuntimeConfig;
import com.morefin.pg.lapsa.model.LocationData;
import com.morefin.pg.lapsa.model.OptionsData;
import com.morefin.pg.utils.Utils;
import io.quarkus.arc.Unremovable;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Base64;
import java.util.Currency;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.function.Function;

@ApplicationScoped
@Unremovable
public class LapsaProcessingService implements APMProcessingService {
    @Inject
    LapsaAdminService lapsaAdminService;

    @ConfigProperty(name = "quarkus.rest-client.lapsa.url")
    String lapsaBaseUrl;

    @Inject
    Config config;

    @Override
    public Uni<ExecuteTransactionResponse> request(TransactionTypeContext context) {
        var runtimeConfig = Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), LapsaRuntimeConfig.class);
        var clientConfiguration = LapsaClientBuilder.createClientConfiguration(lapsaBaseUrl, runtimeConfig);
        var orderRequest = buildCreateOrderRequest(context, runtimeConfig);

        return clientConfiguration.apiClient()
                .createOrder(orderRequest, clientConfiguration.authorizationHeader())
                .map(response -> handleCreateOrderResponse(context, response))
                .onFailure().recoverWithItem(throwable -> handleRequestFailure(context, throwable));
    }

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return LapsaTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return lapsaAdminService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return lapsaAdminService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }


    private CreateOrderRequest buildCreateOrderRequest(TransactionTypeContext context, LapsaRuntimeConfig runtimeConfig) {
        var transaction = context.getTransaction();

        var amount = toMajorAmount(transaction);
        var currency = transaction.getCurrency();

        var description = StringUtils.trimToNull(transaction.getDescription());
        if (description == null) {
            description = "Order %s".formatted(transaction.getId());
        }

        var client = buildClientData(transaction);
        var options = buildOptionsData(context, runtimeConfig);

        return new CreateOrderRequest(
                amount,
                currency,
                transaction.getId(),
                null,
                description,
                client,
                null,
                null, //location,
                options,
                null
        );
    }

    private ClientData buildClientData(ImmutableTypedTransactionEntity transaction) {
        var fullName = resolveFullName(transaction);

        var address = StringUtils.trimToNull(transaction.getCustomerAddress());
        var city = StringUtils.trimToNull(transaction.getCustomerCity());
        var country = StringUtils.trimToNull(transaction.getCustomerCountry());
        var email = StringUtils.trimToNull(transaction.getCustomerEmail());
        var phone = StringUtils.trimToNull(transaction.getCustomerPhoneNumber());
        var postalCode = StringUtils.trimToNull(transaction.getCustomerPostalCode());

        return new ClientData(
                address,
                city,
                country,
                email,
                fullName,
                phone,
                null,
                postalCode,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                address,
                null,
                null,
                null,
                null,
                null
        );
    }

    private String resolveFullName(ImmutableTypedTransactionEntity transaction) {
        var fullName = Stream.of(transaction.getCustomerFirstName(), transaction.getCustomerLastName())
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(" "));
        return StringUtils.trimToNull(fullName);
    }

    private OptionsData buildOptionsData(TransactionTypeContext context, LapsaRuntimeConfig runtimeConfig) {
        var returnUrl = buildReturnUrl(context);
        var templateId = StringUtils.trimToNull(runtimeConfig.template());
        return new OptionsData(
                null,
                null,
                1,
                null,
                returnUrl,
                templateId,
                null,
                null,
                null,
                runtimeConfig.applePay() ? 1 : 0,
                runtimeConfig.googlePay() ? 1 : 0,
                returnUrl,
                null,
                null
        );
    }

    private String buildReturnUrl(TransactionTypeContext context) {
        var transactionData = context.getTransaction().getTransactionData();
        var successUrl = transactionData != null ? StringUtils.trimToNull(transactionData.getSuccessUrl()) : null;

        if (successUrl == null) {
            throw new IllegalArgumentException("Lapsa success URL is required to build return path");
        }
        return successUrl;
    }

    private ExecuteTransactionResponse handleCreateOrderResponse(TransactionTypeContext context, Response httpResponse) {
        return withResponse(httpResponse, response -> {
            ensureSuccessStatus(response);
            var redirectUrl = requireRedirectUrl(response);
            var order = requireFirstOrder(response.readEntity(CreateOrderResponse.class));
            return buildRedirectResponse(context, order, redirectUrl);
        });
    }

    private ExecuteTransactionResponse buildRedirectResponse(TransactionTypeContext context, CreateOrderResponse.Order order, String redirectUrl) {
        var providerStatus = StringUtils.defaultIfBlank(order.status(), "pending");
        var providerCode = Optional.ofNullable(StringUtils.trimToNull(order.authCode())).orElse(providerStatus);
        var providerMessage = buildProviderMessage(order);

        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        var grpcBuilder = new GrpcBuilder<>(responseBuilder)
                .set(context.getTransaction().getId(), responseBuilder::setId)
                .set(ProcessingCode.TRX_STATUS_PENDING.name(), responseBuilder::setResponseCode)
                .set("Redirect to Lapsa checkout", responseBuilder::setResponseMessage)
                .set(order.id(), responseBuilder::setReferenceNumber)
                .setAny(providerStatus, responseBuilder::setPaymentProviderStatus)
                .setAny(providerCode, responseBuilder::setPaymentProviderResponseCode)
                .setAny(providerMessage, responseBuilder::setPaymentProviderResponseMessage)
                .setAny(ExecuteTransactionResponse.Status.PENDING, responseBuilder::setStatus);

        var redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();
        var grpcRedirect = new GrpcBuilder<>(redirectBuilder)
                .set(redirectUrl, redirectBuilder::setUrl)
                .getBuilder()
                .build();

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(grpcBuilder.getBuilder().build())
                .setRedirect(grpcRedirect)
                .build();
    }

    private Optional<String> extractRedirectUrl(Response response) {
        return Optional.ofNullable(response)
                .map(res -> StringUtils.trimToNull(res.getHeaderString("Location")));
    }

    private String requireRedirectUrl(Response response) {
        return extractRedirectUrl(response)
                .orElseThrow(() -> new IllegalStateException("Lapsa response does not include redirect URL"));
    }

    private CreateOrderResponse.Order requireFirstOrder(CreateOrderResponse payload) {
        if (payload == null) {
            throw new IllegalStateException("Lapsa response body is empty");
        }
        return Optional.ofNullable(payload.orders())
                .filter(list -> !list.isEmpty())
                .map(list -> list.get(0))
                .orElseThrow(() -> new IllegalStateException("Lapsa response does not include any orders"));
    }

    private void ensureSuccessStatus(Response response) {
        if (response == null) {
            throw new IllegalStateException("Lapsa response is null");
        }
        if (response.getStatusInfo().getFamily() != Response.Status.Family.SUCCESSFUL) {
            throw new WebApplicationException(response);
        }
    }

    private <T> T withResponse(Response response, Function<Response, T> mapper) {
        if (response == null) {
            throw new IllegalStateException("Lapsa response is null");
        }
        try {
            return mapper.apply(response);
        } finally {
            closeQuietly(response);
        }
    }

    private void closeQuietly(Response response) {
        if (response == null) {
            return;
        }
        try {
            response.close();
        } catch (Exception ignored) {
            // best effort
        }
    }

    private ExecuteTransactionResponse handleRequestFailure(TransactionTypeContext context, Throwable throwable) {
        return switch (throwable) {
            case WebApplicationException wa -> handleErrorResponse(context, wa.getResponse());
            default -> buildExceptionResponse(context, throwable);
        };
    }

    private ExecuteTransactionResponse handleErrorResponse(TransactionTypeContext context, Response response) {
        int status = response != null ? response.getStatus() : 500;
        String body = readErrorBody(response);

        Log.warnf("Lapsa createOrder failed with status %d and body: %s", status, body);

        var processingCode = mapProcessingCode(status);
        var message = StringUtils.defaultIfBlank(body, "Lapsa request failed with status " + status);

        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        var grpcBuilder = new GrpcBuilder<>(responseBuilder)
                .set(context.getTransaction().getId(), responseBuilder::setId)
                .set(processingCode.name(), responseBuilder::setResponseCode)
                .setAny(message, responseBuilder::setResponseMessage)
                .setAny(String.valueOf(status), responseBuilder::setPaymentProviderResponseCode)
                .setAny("ERROR", responseBuilder::setPaymentProviderStatus)
                .setAny(message, responseBuilder::setPaymentProviderResponseMessage)
                .setAny(ExecuteTransactionResponse.Status.ERROR, responseBuilder::setStatus);

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(grpcBuilder.getBuilder().build())
                .build();
    }

    private ExecuteTransactionResponse buildExceptionResponse(TransactionTypeContext context, Throwable throwable) {
        var message = Optional.ofNullable(StringUtils.trimToNull(throwable.getMessage()))
                .orElse("Lapsa request failed");

        Log.error("Lapsa createOrder invocation failed", throwable);

        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        var grpcBuilder = new GrpcBuilder<>(responseBuilder)
                .set(context.getTransaction().getId(), responseBuilder::setId)
                .set(ProcessingCode.TRX_STATUS_FAILED.name(), responseBuilder::setResponseCode)
                .setAny(message, responseBuilder::setResponseMessage)
                .setAny(throwable.getClass().getSimpleName(), responseBuilder::setPaymentProviderResponseCode)
                .setAny(message, responseBuilder::setPaymentProviderResponseMessage)
                .setAny(ExecuteTransactionResponse.Status.ERROR, responseBuilder::setStatus);

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(grpcBuilder.getBuilder().build())
                .build();
    }

    private String buildProviderMessage(CreateOrderResponse.Order order) {
        if(order.operations() == null)
            return "No operation send by lapsa";

        var parts = Stream.of(order.failureMessage())
                .filter(StringUtils::isNotBlank)
                .distinct()
                .collect(Collectors.toList());

        if (parts.isEmpty()) {
            return "Order status: " + StringUtils.defaultIfBlank(order.status(), "pending");
        }
        return String.join(" - ", parts);
    }

    private ProcessingCode mapProcessingCode(int status) {
        return switch (status) {
            case 400, 422 -> ProcessingCode.INVALID_REQUEST;
            default -> ProcessingCode.TRX_STATUS_FAILED;
        };
    }

    private String readErrorBody(Response response) {
        if (response == null) {
            return null;
        }
        try {
            if (!response.hasEntity()) {
                return null;
            }
            return response.readEntity(String.class);
        } catch (IllegalStateException illegalStateException) {
            Log.debug("Unable to read Lapsa error response body", illegalStateException);
            return null;
        } finally {
            try {
                response.close();
            } catch (Exception ignored) {
                // best effort
            }
        }
    }

    private BigDecimal toMajorAmount(ImmutableTypedTransactionEntity transaction) {
        long amountMinor = transaction.getAmount();
        try {
            var currency = Currency.getInstance(transaction.getCurrency());
            int fractionDigits = Math.max(currency.getDefaultFractionDigits(), 0);
            return BigDecimal.valueOf(amountMinor, fractionDigits);
        } catch (IllegalArgumentException exception) {
            return BigDecimal.valueOf(amountMinor, 2);
        }
    }


}
