package com.morefin.pg.lapsa.model;


import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "lapsa")
public interface Config {
    String callbackHost();
}
