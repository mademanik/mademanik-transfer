package com.morefin.pg.lapsa.http;

/**
 * Shared HTTP constants for the Katarun PSP module.
 */
public final class LapsaHttpConstants {
    public static final String BASE_URL = "/psp/lapsa";
    public static final String CALLBACK_URL = "/callback";
    public static final String NOTIFICATIONS_URL = "/notification";
}
