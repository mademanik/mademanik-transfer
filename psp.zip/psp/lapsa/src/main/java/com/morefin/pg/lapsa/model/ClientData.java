package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record ClientData(
    @JsonProperty("address") String address,
    @JsonProperty("city") String city,
    @JsonProperty("country") String country,
    @JsonProperty("email") String email,
    @JsonProperty("name") String name,
    @JsonProperty("phone") String phone,
    @JsonProperty("state") String state,
    @JsonProperty("zip") String zip,
    @JsonProperty("login") String login,
    @JsonProperty("cc") List<String> cc,
    @JsonProperty("bcc") List<String> bcc,
    @JsonProperty("bank_code") String bankCode,
    @JsonProperty("brand_name") String brandName,
    @JsonProperty("legal_name") String legalName,
    @JsonProperty("tax_number") String taxNumber,
    @JsonProperty("client_type") String clientType,
    @JsonProperty("bank_account") String bankAccount,
    @JsonProperty("personal_code") String personalCode,
    @JsonProperty("shipping_city") String shippingCity,
    @JsonProperty("shipping_state") String shippingState,
    @JsonProperty("street_address") String streetAddress,
    @JsonProperty("delivery_methods") List<DeliveryMethod> deliveryMethods,
    @JsonProperty("shipping_country") String shippingCountry,
    @JsonProperty("shipping_zip_code") String shippingZipCode,
    @JsonProperty("registration_number") String registrationNumber,
    @JsonProperty("shipping_street_address") String shippingStreetAddress) {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record DeliveryMethod(
      @JsonProperty("method") String method, @JsonProperty("options") Object options) {}
}
