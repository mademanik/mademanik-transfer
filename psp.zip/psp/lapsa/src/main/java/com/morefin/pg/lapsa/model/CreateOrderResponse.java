package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record CreateOrderResponse(@JsonProperty("orders") List<Order> orders) {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Order(
      @JsonProperty("id") String id,
      @JsonProperty("merchant_order_id") String merchantOrderId,
      @JsonProperty("amount") BigDecimal amount,
      @JsonProperty("amount_charged") BigDecimal amountCharged,
      @JsonProperty("amount_refunded") BigDecimal amountRefunded,
      @JsonProperty("failure_message") String failureMessage,
      @JsonProperty("auth_code") String authCode,
      @JsonProperty("card") Card card,
      @JsonProperty("client") Client client,
      @JsonProperty("created") String created,
      @JsonProperty("currency") String currency,
      @JsonProperty("custom_fields") Map<String, Object> customFields,
      @JsonProperty("description") String description,
      @JsonProperty("descriptor") String descriptor,
      @JsonProperty("issuer") Issuer issuer,
      @JsonProperty("location") Location location,
      @JsonProperty("operations") List<Operation> operations,
      @JsonProperty("pan") String pan,
      @JsonProperty("secure3d") Map<String, Object> secure3d,
      @JsonProperty("segment") String segment,
      @JsonProperty("status") String status,
      @JsonProperty("updated") String updated) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Card(
      @JsonProperty("holder") String holder,
      @JsonProperty("subtype") String subtype,
      @JsonProperty("type") String type) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Client(
      @JsonProperty("address") String address,
      @JsonProperty("city") String city,
      @JsonProperty("country") String country,
      @JsonProperty("email") String email,
      @JsonProperty("name") String name,
      @JsonProperty("phone") String phone,
      @JsonProperty("state") String state,
      @JsonProperty("zip") String zip) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Operation(
      @JsonProperty("type") String type,
      @JsonProperty("iso_message") String isoMessage,
      @JsonProperty("created") String created,
      @JsonProperty("amount") BigDecimal amount,
      @JsonProperty("auth_code") String authCode,
      @JsonProperty("iso_response_code") String isoResponseCode,
      @JsonProperty("cashflow") Cashflow cashflow,
      @JsonProperty("currency") String currency,
      @JsonProperty("status") String status,
      @JsonProperty("arn") String arn) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Cashflow(
      @JsonProperty("incoming") BigDecimal incoming,
      @JsonProperty("fee") BigDecimal fee,
      @JsonProperty("receivable") BigDecimal receivable,
      @JsonProperty("amount") BigDecimal amount,
      @JsonProperty("currency") String currency,
      @JsonProperty("reserve") BigDecimal reserve) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Issuer(
      @JsonProperty("bin") String bin,
      @JsonProperty("country") String country,
      @JsonProperty("title") String title) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Location(@JsonProperty("ip") String ip) {}
}
