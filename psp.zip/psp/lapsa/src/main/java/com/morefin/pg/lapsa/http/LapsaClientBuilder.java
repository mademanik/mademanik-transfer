package com.morefin.pg.lapsa.http;

import com.morefin.pg.lapsa.model.ClientConfiguration;
import com.morefin.pg.lapsa.model.LapsaRuntimeConfig;
import com.morefin.pg.lapsa.processing.LapsaProcessingService;
import com.morefin.pg.utils.Utils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Base64;
import java.util.Objects;

public class LapsaClientBuilder {
    public static ClientConfiguration createClientConfiguration(String lapsaBaseUrl, LapsaRuntimeConfig runtimeConfig) {
        var apiClient = buildApiClient(lapsaBaseUrl, runtimeConfig);
        var authorizationHeader = buildAuthorizationHeader(runtimeConfig);
        return new ClientConfiguration(apiClient, authorizationHeader);
    }

    private static LapsaApiClient buildApiClient(String lapsaBaseUrl, LapsaRuntimeConfig runtimeConfig) {
        try {
            var keyStore = loadKeyStore(runtimeConfig);
            return RestClientBuilder.newBuilder()
                .baseUri(URI.create(lapsaBaseUrl))
                .keyStore(keyStore, runtimeConfig.certificatePassword())
                .build(LapsaApiClient.class);
        } catch (GeneralSecurityException | IOException exception) {
            throw new IllegalStateException("Unable to initialize Lapsa API client keystore", exception);
        }
    }

    private static KeyStore loadKeyStore(LapsaRuntimeConfig runtimeConfig) throws GeneralSecurityException, IOException {
        var certificate = Objects.requireNonNull(runtimeConfig.certificate(), "Lapsa runtime certificate is missing");
        var certificateFile = Objects.requireNonNull(certificate.file(), "Lapsa runtime certificate content is missing");
        if (StringUtils.isBlank(certificateFile)) {
            throw new IllegalStateException("Lapsa runtime certificate content is blank");
        }

        var certificatePassword = Objects.requireNonNull(runtimeConfig.certificatePassword(), "Lapsa runtime certificate password is missing");
        byte[] certificateBytes = Base64.getDecoder().decode(certificateFile.replaceAll("\\s", ""));

        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        try (var keyStoreStream = new ByteArrayInputStream(certificateBytes)) {
            keyStore.load(keyStoreStream, certificatePassword.toCharArray());
        }

        return keyStore;
    }

    private static String buildAuthorizationHeader(LapsaRuntimeConfig runtimeConfig) {
        var username = Objects.requireNonNull(runtimeConfig.basicAuthUsername(), "Lapsa runtime basic auth username is missing");
        var password = Objects.requireNonNull(runtimeConfig.basicAuthPassword(), "Lapsa runtime basic auth password is missing");
        return Utils.buildBasicAuthToken(username, password);
    }

}
