package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record Secure3dData(
    @JsonProperty("xid") String xid,
    @JsonProperty("cavv") String cavv,
    @JsonProperty("eci") String eci,
    @JsonProperty("ds_trans_id") String dsTransId,
    @JsonProperty("browser_details") Secure3dBrowserDetails browserDetails,
    @JsonProperty("force_challenge") Integer forceChallenge) {}
