package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record RecurringDetails(
    @JsonProperty("parent_order_id") String parentOrderId,
    @JsonProperty("trace_id") String traceId,
    @JsonProperty("indicator") String indicator) {}
