package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record Secure3dBrowserDetails(
    @JsonProperty("browser_accept_header") String browserAcceptHeader,
    @JsonProperty("browser_color_depth") String browserColorDepth,
    @JsonProperty("browser_ip") String browserIp,
    @JsonProperty("browser_language") String browserLanguage,
    @JsonProperty("browser_screen_height") Integer browserScreenHeight,
    @JsonProperty("browser_screen_width") Integer browserScreenWidth,
    @JsonProperty("browser_timezone") Integer browserTimezone,
    @JsonProperty("browser_user_agent") String browserUserAgent,
    @JsonProperty("browser_java_enabled") String browserJavaEnabled,
    @JsonProperty("window_width") Integer windowWidth,
    @JsonProperty("window_height") Integer windowHeight) {}
