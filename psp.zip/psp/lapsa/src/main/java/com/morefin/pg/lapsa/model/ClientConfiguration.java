package com.morefin.pg.lapsa.model;

import com.morefin.pg.lapsa.http.LapsaApiClient;

public record ClientConfiguration(LapsaApiClient apiClient, String authorizationHeader) {
}
