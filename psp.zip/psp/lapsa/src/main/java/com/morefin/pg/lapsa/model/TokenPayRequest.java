package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record TokenPayRequest(
    @JsonProperty("amount") BigDecimal amount,
    @JsonProperty("currency") String currency,
    @JsonProperty("dsrp") DsrpData dsrp,
    @JsonProperty("location") LocationData location,
    @JsonProperty("description") String description,
    @JsonProperty("payment_type") String paymentType,
    @JsonProperty("client") ClientData client,
    @JsonProperty("custom_fields") Map<String, Object> customFields) {}
