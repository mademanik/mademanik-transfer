package com.morefin.pg.lapsa.processing;

import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.lapsa.LapsaTypeModule;
import io.quarkus.arc.Arc;

public class LapsaProcessingServiceProvider implements APMProcessingServiceProvider {
    @Override
    public APMProcessingService create() {
        try(var instance = Arc.container().instance(LapsaProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return LapsaTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return LapsaTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return LapsaTypeModule.MODULE_ID;
    }
}
