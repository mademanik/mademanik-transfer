package com.morefin.pg.lapsa.http;

import com.morefin.pg.lapsa.model.*;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * REST client for the Lapsa payment gateway.
 *
 * <p>The interface mirrors the documented HTTP endpoints. Individual request payloads should be
 * supplied as JSON objects defined by the caller.</p>
 */
@RegisterRestClient(configKey = "lapsa")
@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface LapsaApiClient {

    @GET
    @Path("/ping")
    Uni<Response> ping(@HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/create")
    Uni<Response> createOrder(CreateOrderRequest request,
                              @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/authorize")
    Uni<Response> authorizeOrder(AuthorizeOrderRequest request,
                                 @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @PUT
    @Path("/orders/{orderId}/reverse")
    Uni<Response> reverseOrder(@PathParam("orderId") String orderId,
                               @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @PUT
    @Path("/orders/{orderId}/charge")
    Uni<Response> chargeOrder(@PathParam("orderId") String orderId,
                              AmountRequest request,
                              @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @PUT
    @Path("/orders/{orderId}/refund")
    Uni<Response> refundOrder(@PathParam("orderId") String orderId,
                              AmountRequest request,
                              @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @PUT
    @Path("/orders/{orderId}/cancel")
    Uni<Response> cancelOrder(@PathParam("orderId") String orderId,
                              AmountRequest request,
                              @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/{orderId}/rebill")
    Uni<Response> rebillOrder(@PathParam("orderId") String orderId,
                              RebillRequest request,
                              @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/{orderId}/credit")
    Uni<Response> creditOrder(@PathParam("orderId") String orderId,
                              CreditOrderRequest request,
                              @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/credit")
    Uni<Response> creditWithoutOrder(CreditWithoutOrderRequest request,
                                     @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/token_pay")
    Uni<Response> tokenPay(TokenPayRequest request,
                           @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/{orderId}/complete")
    Uni<Response> complete3ds1(@PathParam("orderId") String orderId,
                               Complete3dsRequest request,
                               @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/{orderId}/complete3d20")
    Uni<Response> complete3ds2(@PathParam("orderId") String orderId,
                               Complete3ds20Request request,
                               @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @POST
    @Path("/orders/{orderId}/resume")
    Uni<Response> resume3dsMethod(@PathParam("orderId") String orderId,
                                  @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @GET
    @Path("/orders/{orderId}")
    Uni<Response> getOrder(@PathParam("orderId") String orderId,
                           @QueryParam("expand") String expand,
                           @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @GET
    @Path("/orders/")
    Uni<Response> listOrders(@QueryParam("status") String status,
                             @QueryParam("created_from") String createdFrom,
                             @QueryParam("created_to") String createdTo,
                             @QueryParam("merchant_order_id") String merchantOrderId,
                             @QueryParam("card.type") String cardType,
                             @QueryParam("card.subtype") String cardSubtype,
                             @QueryParam("location.ip") String locationIp,
                             @QueryParam("client.name") String clientName,
                             @QueryParam("client.email") String clientEmail,
                             @QueryParam("issuer.country") String issuerCountry,
                             @QueryParam("issuer.bin") String issuerBin,
                             @QueryParam("issuer.title") String issuerTitle,
                             @QueryParam("page") Integer page,
                             @QueryParam("page_size") Integer pageSize,
                             @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @GET
    @Path("/operations/")
    Uni<Response> listOperations(@QueryParam("status") String status,
                                 @QueryParam("type") String type,
                                 @QueryParam("created_from") String createdFrom,
                                 @QueryParam("created_to") String createdTo,
                                 @QueryParam("expand") String expand,
                                 @QueryParam("page") Integer page,
                                 @QueryParam("page_size") Integer pageSize,
                                 @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    @GET
    @Path("/exchange_rates/")
    Uni<Response> exchangeRates(@QueryParam("date") String date,
                                @QueryParam("date_from") String dateFrom,
                                @QueryParam("date_to") String dateTo,
                                @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);



}
