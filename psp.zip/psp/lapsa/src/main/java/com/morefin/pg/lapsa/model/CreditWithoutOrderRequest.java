package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record CreditWithoutOrderRequest(
    @JsonProperty("amount") BigDecimal amount,
    @JsonProperty("currency") String currency,
    @JsonProperty("pan") String pan,
    @JsonProperty("card") CardData card,
    @JsonProperty("location") LocationData location,
    @JsonProperty("options") OptionsData options,
    @JsonProperty("client") ClientData client,
    @JsonProperty("custom_fields") Map<String, Object> customFields) {}
