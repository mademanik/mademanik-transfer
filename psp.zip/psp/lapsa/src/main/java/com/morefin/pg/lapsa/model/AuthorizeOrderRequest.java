package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record AuthorizeOrderRequest(
    @JsonProperty("amount") BigDecimal amount,
    @JsonProperty("currency") String currency,
    @JsonProperty("pan") String pan,
    @JsonProperty("card") CardData card,
    @JsonProperty("location") LocationData location,
    @JsonProperty("client") ClientData client,
    @JsonProperty("description") String description,
    @JsonProperty("merchant_order_id") String merchantOrderId,
    @JsonProperty("segment") String segment,
    @JsonProperty("custom_fields") Map<String, Object> customFields,
    @JsonProperty("options") OptionsData options,
    @JsonProperty("secure3d") Secure3dData secure3d,
    @JsonProperty("recurring_details") RecurringDetails recurringDetails) {}
