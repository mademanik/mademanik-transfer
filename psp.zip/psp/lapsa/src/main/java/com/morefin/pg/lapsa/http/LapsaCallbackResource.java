package com.morefin.pg.lapsa.http;

import com.morefin.pg.lapsa.processing.LapsaCallbackService;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import static com.morefin.pg.lapsa.http.LapsaHttpConstants.*;

@ApplicationScoped
@Path(BASE_URL)
public class LapsaCallbackResource {

    @Inject
    LapsaCallbackService callbackService;

    @GET
    @Path(NOTIFICATIONS_URL)
    @Produces(MediaType.TEXT_HTML)
    public Uni<Response> finalizeNotification(@QueryParam("order_id") String orderId, @QueryParam("status") String status) {
        return callbackService.finalizeTransaction(orderId, status);
    }
}
