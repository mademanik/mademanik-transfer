package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record CardData(
    @JsonProperty("cvv") String cvv,
    @JsonProperty("holder") String holder,
    @JsonProperty("expiration_month") Integer expirationMonth,
    @JsonProperty("expiration_year") Integer expirationYear,
    @JsonProperty("type") String type,
    @JsonProperty("subtype") String subtype,
    @JsonProperty("expiration") String expiration) {}
