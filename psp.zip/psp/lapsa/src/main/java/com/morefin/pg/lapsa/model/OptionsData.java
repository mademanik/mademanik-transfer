package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record OptionsData(
    @JsonProperty("expiration_timeout") String expirationTimeout,
    @JsonProperty("force3d") Integer force3d,
    @JsonProperty("auto_charge") Integer autoCharge,
    @JsonProperty("language") String language,
    @JsonProperty("return_url") String returnUrl,
    @JsonProperty("template") String template,
    @JsonProperty("mobile") Integer mobile,
    @JsonProperty("terminal") String terminal,
    @JsonProperty("recurring") Integer recurring,
    @JsonProperty("apple_pay_enabled") Integer applePayEnabled,
    @JsonProperty("google_pay_enabled") Integer googlePayEnabled,
    @JsonProperty("secure3d20_return_url") String secure3d20ReturnUrl,
    @JsonProperty("exemption_mit") Integer exemptionMit,
    @JsonProperty("static_link") Integer staticLink) {}
