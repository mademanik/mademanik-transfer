package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record RebillRequest(
    @JsonProperty("amount") BigDecimal amount,
    @JsonProperty("cvv") String cvv,
    @JsonProperty("location") LocationData location,
    @JsonProperty("options") OptionsData options,
    @JsonProperty("recurring_details") RecurringDetails recurringDetails,
    @JsonProperty("custom_fields") Map<String, Object> customFields) {}
