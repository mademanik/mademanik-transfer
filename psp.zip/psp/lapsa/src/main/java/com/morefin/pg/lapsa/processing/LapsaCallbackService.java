package com.morefin.pg.lapsa.processing;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.RetrieveTransactionRequest;
import com.morefin.common.grpc.transaction.Transaction;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.grpc.transaction.TransactionResponse;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.domain.tables.pojos.PaymentProviderAccount;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.pg.lapsa.http.LapsaClientBuilder;
import com.morefin.pg.lapsa.model.CreateOrderResponse;
import com.morefin.pg.lapsa.model.LapsaRuntimeConfig;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

@ApplicationScoped
public class LapsaCallbackService {
    static final String PREPARED = "prepared";//    prepared Waiting for outside action —
    static final String AUTHORIZED = "authorized";//     Authorization completed reverse, charge,rebill
    static final String CHARGED = "charged";//    charged Order has been charged refund, credit, rebill
    static final String REVERSED = "reversed"; //     Authorization has been cancelled rebill
    static final String REFUNDED = "refunded";//     Order was fully or partially refunded refund, credit, rebill
    static final String REJECTED = "rejected";//     Order has been rejected rebill
    static final String FRAUD = "fraud"; //     Order has been determined as a fraud and rejected because of that rebill
    static final String DECLINED = "declined";//     Order has been declined by the acquirer rebill
    static final String CHARGEBACK = "chargedback"; //     Order is marked as chargeback rebill
    static final String CREDITED = "credited";  //     Order has been credited (OCT) rebill
    static final String ERROR = "error"; //    error

    private static final String SERVICE_ACCOUNT = "lapsa-service";
    private static final Set<String> SUCCESS_STATUSES = Set.of("success", "authorized", "charged", "captured", "completed", "approved");

    @Inject
    Tenant tenant;

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @ConfigProperty(name = "quarkus.rest-client.lapsa.url")
    String lapsaBaseUrl;

    @Inject
    SignatureUtils signatureUtils;

    public Uni<Response> finalizeTransaction(String orderId, String status) {
        var tenantId = tenant.id();
        var grpcClient = GrpcClientFactory.grpc(transactionGrpc, tenantId, serviceAccount(), Constants.LOCALHOST);

        var tnrUnwrapped =grpcClient
            .retrieveTransaction(retrieveByOrder(orderId));

        return tnrUnwrapped
            .map(this::unwrapTransaction)
            .flatMap(transaction -> buildContext(tenantId, transaction))
            .flatMap(context -> fetchOrderAndBuildResponse(context, grpcClient));
    }

    private RetrieveTransactionRequest retrieveByOrder(String orderId) {
        return RetrieveTransactionRequest.newBuilder()
            .setId("DUMMYIDHACK")
            .setReferenceNumber(orderId).build();
    }

    private Transaction unwrapTransaction(TransactionResponse response) {
        return switch (response.getKindCase()) {
            case RESPONSE -> response.getResponse();
            case ERROR -> throw new IllegalStateException("Unable to retrieve transaction: " + response.getError().getErrorList());
            case KIND_NOT_SET -> throw new IllegalStateException("Transaction response kind not set");
        };
    }

    private Uni<CallbackContext> buildContext(String tenantId, Transaction transaction) {
        return signatureUtils
                .findPaymentProviderAccountData(tenantId, transaction.getId())
                .map(account -> new CallbackContext(transaction, runtimeConfig(account)));
    }

    private LapsaRuntimeConfig runtimeConfig(PaymentProviderAccount account) {
        return Utils.getRuntimeAccountConfig(account, LapsaRuntimeConfig.class);
    }

    private Uni<Response> fetchOrderAndBuildResponse(CallbackContext context, TransactionGrpc grpcClient) {
        var clientConfiguration = LapsaClientBuilder.createClientConfiguration(lapsaBaseUrl, context.runtimeConfig());
        var orderId = resolveOrderId(context.transaction());

        return clientConfiguration.apiClient()
                .getOrder(orderId, null, clientConfiguration.authorizationHeader())
                .flatMap(response -> finalizeAndBuildResponse(context.transaction(), response, grpcClient));
    }

    private Uni<Response> finalizeAndBuildResponse(Transaction transaction, Response httpResponse, TransactionGrpc grpcClient) {
        return withResponse(httpResponse, response -> {
            ensureSuccessful(response);
            var payload = response.readEntity(CreateOrderResponse.class);
            var order = requireFirstOrder(payload);
            var finalizeRequest = buildFinalizeRequest(transaction, order);
             return grpcClient.finalizeTransaction(finalizeRequest)
                    .map(ignore -> Response.ok().build());
        });
    }

    private CreateOrderResponse.Order requireFirstOrder(CreateOrderResponse payload) {
        if (payload == null) {
            throw new IllegalStateException("Lapsa response body is empty");
        }
        return Optional.ofNullable(payload.orders())
                .filter(list -> !list.isEmpty())
                .map(list -> list.get(0))
                .orElseThrow(() -> new IllegalStateException("Lapsa response does not include any orders"));
    }

    private void ensureSuccessful(Response response) {
        if (response == null) {
            throw new IllegalStateException("Lapsa response is null");
        }
        if (response.getStatusInfo().getFamily() != Response.Status.Family.SUCCESSFUL) {
            throw new WebApplicationException(response);
        }
    }

    private String resolveOrderId(Transaction transaction) {
        if (transaction.hasProcessingResult() && transaction.getProcessingResult().hasReferenceNumber()) {
            var referenceNumber = StringUtils.trimToNull(transaction.getProcessingResult().getReferenceNumber());
            if (referenceNumber != null) {
                return referenceNumber;
            }
        }
        var fallback = StringUtils.trimToNull(transaction.getReference());
        if (fallback != null) {
            return fallback;
        }
        throw new IllegalStateException("Transaction is missing reference number");
    }

    private FinalizeTransactionRequest buildFinalizeRequest(Transaction transaction, CreateOrderResponse.Order order) {
        var processingCode = switch (order.status()) {
            case CREDITED, CHARGED -> ProcessingCode.TRX_STATUS_APPROVED;
            case PREPARED, AUTHORIZED -> ProcessingCode.TRX_STATUS_PENDING;
            case REVERSED, REJECTED, FRAUD, DECLINED -> ProcessingCode.TRX_STATUS_DECLINED;
            default -> ProcessingCode.TRX_STATUS_FAILED;
        };

        var builder = FinalizeTransactionRequest.newBuilder()
                .setId(transaction.getId())
                .setStatus(processingCode.getStatus())
                .setResponseCode(processingCode.getCode())
                .setResponseMessage(buildFinalizeResponseMessage(order));

        Optional.ofNullable(StringUtils.trimToNull(order.id()))
                .ifPresent(builder::setReferenceNumber);

        Optional.ofNullable(StringUtils.trimToNull(order.authCode()))
                .ifPresentOrElse(builder::setPaymentProviderResponseCode,
                        () -> Optional.ofNullable(StringUtils.trimToNull(order.status()))
                                .ifPresent(builder::setPaymentProviderResponseCode));

        Optional.ofNullable(StringUtils.trimToNull(order.status()))
                .ifPresent(builder::setPaymentProviderResponseMessage);

        Optional.ofNullable(StringUtils.trimToNull(buildFinalizeResponseMessage(order)))
                .ifPresent(builder::setPaymentProviderResponseMessage);

        return builder.build();
    }

    private String buildFinalizeResponseMessage(CreateOrderResponse.Order order) {
        var parts = Optional.ofNullable(order.failureMessage())
                .filter(StringUtils::isNotBlank)
                .orElse("success");

        if (!parts.isEmpty()) {
            return String.join(" - ", parts);
        }
        return "Lapsa order status: " + StringUtils.defaultIfBlank(order.status(), "unknown");
    }

    private <T> T withResponse(Response response, Function<Response, T> mapper) {
        if (response == null) {
            throw new IllegalStateException("Lapsa response is null");
        }
        try {
            return mapper.apply(response);
        } finally {
            closeQuietly(response);
        }
    }

    private void closeQuietly(Response response) {
        try {
            if (response != null) {
                response.close();
            }
        } catch (Exception ignored) {
            // best effort
        }
    }

    private GrpcApiUser serviceAccount() {
        return GrpcApiUser.serviceAccount(Set.of(), Map.of(), SERVICE_ACCOUNT);
    }

    private record CallbackContext(Transaction transaction, LapsaRuntimeConfig runtimeConfig) {
    }
}
