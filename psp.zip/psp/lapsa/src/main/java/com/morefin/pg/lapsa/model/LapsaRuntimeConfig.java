package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record LapsaRuntimeConfig(
        @JsonProperty("apple_pay")
        boolean applePay,
        @JsonProperty("google_pay")
        boolean googlePay,
        @JsonProperty("basic_auth_password")
        String basicAuthPassword,
        @JsonProperty("certificate")
        LapsaRuntimeConfigCertificate certificate,
        @JsonProperty("certificate_password")
        String certificatePassword,
        @JsonProperty("basic_auth_username")
        String basicAuthUsername,
        @JsonProperty("template")
        String template
) {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record LapsaRuntimeConfigCertificate(
            @JsonProperty("fileName")
            String fileName,
            @JsonProperty("file")
            String file
    ) {
    }
}
