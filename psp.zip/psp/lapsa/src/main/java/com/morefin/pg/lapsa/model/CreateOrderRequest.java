package com.morefin.pg.lapsa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record CreateOrderRequest(
    @JsonProperty("amount") BigDecimal amount,
    @JsonProperty("currency") String currency,
    @JsonProperty("merchant_order_id") String merchantOrderId,
    @JsonProperty("segment") String segment,
    @JsonProperty("description") String description,
    @JsonProperty("client") ClientData client,
    @JsonProperty("custom_fields") Map<String, Object> customFields,
    @JsonProperty("location") LocationData location,
    @JsonProperty("options") OptionsData options,
    @JsonProperty("recurring_details") RecurringDetails recurringDetails) {}
