package com.morefin.pg.genome.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WebhookRequest implements Serializable {
    @JsonProperty("reference")
    private String reference;

    @JsonProperty("code")
    private String code;

    @JsonProperty("transaction_unique_id")
    private String transactionUniqueId;

    @JsonProperty("checkSum")
    private String checkSum;

    @JsonProperty("message")
    private String message;

    @JsonProperty("token")
    private String token;

    @JsonProperty("status")
    private String status;
}