package com.morefin.pg.genome.processing;

import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingService;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingServiceProvider;
import com.morefin.pg.genome.GenomeTypeModule;
import io.quarkus.arc.Arc;

public class GenomeWithdrawalServiceProvider implements WithdrawalPaymentProcessingServiceProvider {
    @Override
    public WithdrawalPaymentProcessingService create() {
        try(var instance = Arc.container().instance(GenomeAPMProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return GenomeTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return GenomeTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return GenomeTypeModule.MODULE_ID;
    }
}
