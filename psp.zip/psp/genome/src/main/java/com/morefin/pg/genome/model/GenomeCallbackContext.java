package com.morefin.pg.genome.model;

import com.morefin.common.grpc.transaction.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionEntity;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.genome.common.RuntimeAccountConfig;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class GenomeCallbackContext extends BaseTransactionContext<String> {

    RuntimeAccountConfig runtimeAccountConfig;

    Boolean isWebhook = false;
    String tenantId;
    String referenceNumber;
    String transactionId;
    WebhookRequest webhookRequest;

    String callbackRequestAsString;

    TypedTransactionEntity transactionEntity;
    TransactionGrpc transactionGrpc;

    FinalizeTransactionRequest finalizeRequest;
    ExecuteTransactionResponse finalizeResponse;

    public GenomeCallbackContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}