package com.morefin.pg.genome.common;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.gatewaygrpcservices.payments.paymentgateway.services.paymentprovider.PaymentProviderRepository;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.transaction.resourceactions.TransactionRepository;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.genome.model.GenomeCallbackContext;
import com.morefin.pg.genome.model.WebhookRequest;
import com.morefin.pg.genome.util.GenomeObjectTransformer;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;

@ApplicationScoped
public class FinalizeManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    GenomeObjectTransformer objectTransformer;

    @Inject
    TransactionRepository transactionRepository;

    @Inject
    PaymentProviderRepository paymentProviderRepository;

    @Inject
    DtoMapperService mapperService;

    BiFunction<GenomeCallbackContext, Throwable, GenomeCallbackContext> defaultFinalizeExceptionHandler = (context, failure) -> {
        System.out.printf("Error finalize Genome: %s", failure.getMessage());
        context.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(context, failure));
        return context;
    };

    public Uni<Response> finalizeWebhookTransaction(String callbackRequest, String tenantId) {
        GenomeCallbackContext ctx = new GenomeCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateWebhookContext(ctx1, callbackRequest, tenantId))
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifyChecksum)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinalResponse);
    }

    private Uni<GenomeCallbackContext> hydrateWebhookContext(GenomeCallbackContext ctx, String callbackRequestAsString, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseWebhookRequest(ctx, callbackRequestAsString, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    @SneakyThrows
    private GenomeCallbackContext parseWebhookRequest(GenomeCallbackContext ctx, String callbackRequestAsString, String tenantId) {
        //Additional step to preserve the request payload for future logging
        ctx.setIsWebhook(true);
        ctx.setTenantId(tenantId);
        ctx.setCallbackRequestAsString(callbackRequestAsString);

        String callbackAsJson = mapperService.urlEncodeToJson(callbackRequestAsString);

        ctx.setWebhookRequest(mapperService.mapAndValidate(callbackAsJson, WebhookRequest.class));

        ctx.setReferenceNumber(ctx.getWebhookRequest().getTransactionUniqueId());
        ctx.setTransactionId(ctx.getWebhookRequest().getTransactionUniqueId());

        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    @SneakyThrows
    private GenomeCallbackContext verifyChecksum(GenomeCallbackContext ctx) {
        try {
            String decoded = URLDecoder.decode(ctx.getCallbackRequestAsString(), StandardCharsets.UTF_8);
            String[] pairs = Arrays.stream(
                    decoded.split("&")
            ).filter(x -> !x.startsWith("checkSum")).toArray(String[]::new);
            Arrays.sort(pairs, String.CASE_INSENSITIVE_ORDER);
            String[] newPairs = new String[pairs.length+1];
            for (int i = 0; i < pairs.length; i++) {
                newPairs[i] = pairs[i];
            }
            newPairs[pairs.length] = ctx.getRuntimeAccountConfig().signatureKey();

            String sortedData = String.join("|", newPairs);

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(sortedData.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }

            if ( ctx.getWebhookRequest().getCheckSum().equals(hexString.toString()) ) {
                return ctx;
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        throw new BadRequestException("Wrong checksum");
    }

    private Uni<GenomeCallbackContext> getTransactionData(GenomeCallbackContext ctx) {
        return transactionRepository.withTransaction(connection -> {
            return transactionRepository.findByReferenceNumber(connection, ctx.getTenantId(), ctx.getReferenceNumber())
                    .map(optionalTransaction -> optionalTransaction
                            .map(transaction -> {
                                ctx.setTransactionEntity(transaction);
                                ctx.setTransactionId(transaction.getId());
                                return ctx;
                            })
                            .orElseThrow(() -> new IllegalStateException("Transaction not found")));
        });
    }

    private Uni<GenomeCallbackContext> getPaymentProviderAccountDataByPpaId(GenomeCallbackContext ctx) {
        return paymentProviderRepository.findAccountBy(ctx.getTenantId(), ctx.getTransactionEntity().getPaymentProviderAccountId())
                .map(optionalAccount -> optionalAccount
                        .map(ppa -> {
                            ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, RuntimeAccountConfig.class));
                            return ctx;
                        })
                        .orElseThrow(() -> new IllegalStateException("PaymentProviderAccount not found")));
    }

    private Response buildFinalResponse(GenomeCallbackContext ctx) {
        Response.ResponseBuilder responseBuilder = Response.status(Response.Status.OK);
        if ( ctx.getErrorDescription() != null ) {
            responseBuilder
                    .entity(Map.of("error", ctx.getErrorDescription().getResponseMessage()));
        } else {
            responseBuilder.entity("OK");
        }
        return responseBuilder.build();
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }

    private Uni<GenomeCallbackContext> sendGrpcFinalizeRequest(GenomeCallbackContext ctx) {
        if ( ctx.getErrorDescription() != null ) {
            return Uni.createFrom().item(ctx);
        }
        return ctx.getTransactionGrpc().
                finalizeTransaction(ctx.getFinalizeRequest())
                .map(response -> {
                    ctx.setFinalizeResponse(response);
                    return ctx;
                });
    }
}
