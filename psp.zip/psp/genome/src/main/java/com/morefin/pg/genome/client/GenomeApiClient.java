package com.morefin.pg.genome.client;

import com.morefin.pg.genome.model.GetTransactionRequest;
import com.morefin.pg.genome.model.WithdrawalRequest;
import io.quarkus.rest.client.reactive.*;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "genome")
@Produces(MediaType.APPLICATION_JSON)
@Path("/api/mp")
public interface GenomeApiClient {

    @POST
    @Path("/payout")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> withdrawal(WithdrawalRequest request);

    @POST
    @Path("/transaction")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> getTransaction(GetTransactionRequest request);

    @ClientExceptionMapper
    static RuntimeException toException(Response response) {
        String responseAsString = response.readEntity(String.class);
        return new RuntimeException(response.getStatusInfo().getReasonPhrase() + "; body: " + responseAsString);
    }
}