package com.morefin.pg.genome.util;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;

public class TransactionStatusMapper {
    public static ExecuteTransactionResponse.Status parseTransactionStatus(GenomeTransactionStatus transactionStatus) {
        return switch (transactionStatus) {
            case SUCCESS -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING -> ExecuteTransactionResponse.Status.PENDING;
            case DECLINED, FRAUDED -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }
}