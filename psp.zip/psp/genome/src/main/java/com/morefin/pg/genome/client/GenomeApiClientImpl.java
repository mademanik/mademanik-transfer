package com.morefin.pg.genome.client;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

@ApplicationScoped
public class GenomeApiClientImpl {

    @Produces
    GenomeApiClient apiClient() {
        return RestClientBuilder.newBuilder()
                .build(GenomeApiClient.class);
    }
}
