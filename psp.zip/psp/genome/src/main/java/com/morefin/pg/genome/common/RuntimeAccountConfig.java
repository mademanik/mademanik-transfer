package com.morefin.pg.genome.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Set;

public record RuntimeAccountConfig(
        @JsonProperty("merchant_account")
        String merchantAccount,
        @JsonProperty("merchant_password")
        String merchantPassword,
        @JsonProperty("signature_key")
        String signatureKey,
        @JsonProperty("mid_reference")
        String midReference
) {
}
