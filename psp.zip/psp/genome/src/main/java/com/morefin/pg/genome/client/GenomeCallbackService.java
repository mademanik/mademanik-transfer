package com.morefin.pg.genome.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.genome.common.FinalizeManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

@Path("/psp/genome")
@Produces(MediaType.APPLICATION_JSON)
public class GenomeCallbackService {

    @Inject
    FinalizeManager finalizeManager;

    @Inject
    Tenant tenant;

    @Path("/callback")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Uni<Response> callbackUrl(String callbackRequest) {
        return finalizeManager.finalizeWebhookTransaction(callbackRequest, tenant.id());
    }
}