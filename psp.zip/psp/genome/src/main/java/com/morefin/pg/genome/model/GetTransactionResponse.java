package com.morefin.pg.genome.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetTransactionResponse implements Serializable {
    @JsonProperty("api_version")
    private Double apiVersion;

    @JsonProperty("merchant_account")
    private String merchantAccount;

    @JsonProperty("session_id")
    private String sessionId;

    @JsonProperty("transactions")
    private Transaction[] transactions;

    @JsonProperty("status")
    private String status;

    @JsonProperty("code")
    private Integer code;

    @JsonProperty("message")
    private String message;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Transaction {

        @JsonProperty("reference")
        private String reference;

        @JsonProperty("transaction_unique_id")
        private String transactionUniqueId;

        @JsonProperty("transaction_type")
        private String transactionType;

        @JsonProperty("status")
        private String status;

        @JsonProperty("code")
        private Integer code;

        @JsonProperty("message")
        private String message;

        @JsonProperty("token")
        private String token;

        @JsonProperty("timestamp")
        private Long timestamp;

        @JsonProperty("authcode")
        private String authcode;
    }
}
