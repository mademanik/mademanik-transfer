package com.morefin.pg.genome.util;

import com.google.gson.Gson;
import com.google.i18n.phonenumbers.Phonenumber;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.genome.common.RuntimeAccountConfig;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.genome.model.*;
import com.morefin.pg.utils.Utils;
import io.quarkus.logging.Log;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

import java.math.BigDecimal;
import java.util.Map;

import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class GenomeObjectTransformer {

    public static final String DEFAULT_STATE_NA = "NA";

    public Customer groupCustomerData(ImmutableTypedTransactionEntity transaction) {
        return Customer.builder().firstName(transaction.getCustomerFirstName())
                .lastName(transaction.getCustomerLastName())
                .phone(transaction.getCustomerPhoneNumber())
                .email(transaction.getCustomerEmail())
                .category("Gaming")
                .address(
                        Address.builder().
                                streetAddress(transaction.getCustomerAddress())
                                .city(transaction.getCustomerCity())
                                .country(transaction.getCustomerCountry())
                                .postcode(transaction.getCustomerPostalCode())
                                .state(DEFAULT_STATE_NA)
                                .build())
                .build();
    }

    public WithdrawalRequest mapToWithdrawalRequest(GenomeTransactionContext context) {
        return mapWithdrawalRequest(context).build();
    }

    public GetTransactionRequest mapToGetTransactionRequest(GenomeTransactionContext context) {
        return mapGetTransactionRequest(context).build();
    }

    public ExecuteTransactionResponse convertToCardResponse(GenomeTransactionContext context) {
        String id = context.getTransactionContext().getTransaction().getId();
        String responseAsString = context.getTransactionResponseAsString() != null ? context.getTransactionResponseAsString() : context.getWithdrawalResponseAsString();

        if ( context.getErrorDescription() == null && context.getTransactionResponse() != null ) {
            GetTransactionResponse transactionResponse = context.getTransactionResponse();
            GetTransactionResponse.Transaction transaction = transactionResponse.getTransactions()[0];
            GenomeTransactionStatus transactionStatus = GenomeTransactionStatus.valueOf(transaction.getStatus());
            ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

            switch (status) {
                case APPROVED -> {
                    return buildDirectApprovedTransactionResponse(id, responseAsString);
                }
                case PENDING -> {
                    return buildPendingTransactionResponse(id, responseAsString);
                }
            }
        }

        String message = context.getErrorDescription() != null ? context.getErrorDescription().getResponseMessage() : "";
        return buildDeclinedTransactionResponse(id, message + " " + responseAsString);
    }

    private WithdrawalRequest.WithdrawalRequestBuilder mapWithdrawalRequest(GenomeTransactionContext context) {
        String baseUrl = context.getTransactionContext().getTenantConfig().url();
//        String baseUrl = "https://webhook.site/366d6608-be93-4476-9b9c-eca87a51fd8c";
//        String baseUrl = "https://blue-bottles-bow.loca.lt";
        String webhookUrl = baseUrl + "/psp/genome/callback";
        Address address = context.getCustomerData().getAddress();

        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();
        var transaction = context.getTransactionContext().getTransaction();
        BigDecimal number = BigDecimal.valueOf(transaction.getAmount()).divide(BigDecimal.valueOf(100));
        return WithdrawalRequest.builder()
                .apiVersion(1)
                .method("init")
                .merchantAccount(rac.merchantAccount())
                .merchantPassword(rac.merchantPassword())
                .midReference(rac.midReference())
                .transactionUniqueId(transaction.getId())
                .amount(number)
                .currency(transaction.getCurrency())
                .type("sepa")
                .transferDescription("Payout for SEPA with MoreFin")
                .receiverIban(context.getIban())
                .receiverBic(context.getBic())
                .receiverName(context.getReceiverName())
                .callbackUrl(webhookUrl)
                .receiverAddress(address.getStreetAddress())
                .receiverCity(address.getCity())
                .receiverCountry(context.getCountryIso3())
                .receiverZip(address.getPostcode());
    }

    private GetTransactionRequest.GetTransactionRequestBuilder mapGetTransactionRequest(GenomeTransactionContext context) {
        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();
        var transaction = context.getTransactionContext().getTransaction();
        return GetTransactionRequest.builder()
                .apiVersion(1)
                .merchantAccount(rac.merchantAccount())
                .merchantPassword(rac.merchantPassword())
                .transactionUniqueId(transaction.getId())
                .transactionType("CHECK");
    }

    private ExecuteTransactionResponse buildDirectApprovedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildDeclinedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_DECLINED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_PENDING.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.PENDING, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }


    public ErrorDescription<String> buildErrorDescription(GenomeTransactionContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

//        return switch (context.getPhase()) {
//            default:
//                yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
//        };
        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    private ErrorDescription<String> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<String>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    public ErrorDescription<?> buildFinalizeErrorDescription(GenomeCallbackContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during processing of transaction {0} with message {1} during phase {2} and sub-phase {3} ",
                context.getTransactionId(), failure, context.getPhase(), context.getSubPhase());
        reason = "Bad request";
        return ErrorDescription.<Response.Status>builder()
                .reason(reason)
                .errorResponse(Response.Status.BAD_REQUEST)
                .responseMessage(failure.getMessage())
                .build();
    }

    public GenomeCallbackContext buildFinalizeTransactionRequest(GenomeCallbackContext context) {
        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder();
        builder.setReferenceNumber(context.getReferenceNumber())
                .setId(context.getTransactionId());

        GenomeTransactionStatus status = GenomeTransactionStatus.valueOf(context.getWebhookRequest().getStatus());
        ExecuteTransactionResponse.Status transactionStatus = TransactionStatusMapper.parseTransactionStatus(status);

        builder.setResponseMessage(context.getCallbackRequestAsString())
                .setPaymentProviderResponseMessage(context.getCallbackRequestAsString());

        switch (transactionStatus) {
            case APPROVED -> {
                String code = ProcessingCode.TRX_STATUS_APPROVED.name();
                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.APPROVED);
            }
            case PENDING -> {
                String code = ProcessingCode.TRX_STATUS_PENDING.name();

                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.PENDING);
            }
            default -> {
                builder.setStatus(TransactionStatus.DECLINED);
                if ( context.getErrorDescription() == null ) {
                    String code = ProcessingCode.TRX_STATUS_DECLINED.name();
                    builder.setResponseCode(code)
                            .setPaymentProviderResponseCode(code);
                }
            }
        }

        context.setFinalizeRequest(builder.build());

        return context;
    }
}

