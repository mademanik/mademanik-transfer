package com.morefin.pg.genome.util;

import lombok.Getter;

@Getter
public enum GenomeTransactionStatus {
    SUCCESS("transaction processed successfully"),
    ERROR("transaction error"),
    DECLINED("transaction declined"),
    PENDING("transaction processing"),
    FRAUDED("transaction fraud");

    private final String description;

    GenomeTransactionStatus(String description) {
        this.description = description;
    }
}