package com.morefin.pg.genome.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.genome.client.GenomeApiClient;
import com.morefin.pg.genome.model.*;
import com.morefin.pg.genome.util.GenomeObjectTransformer;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Map;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
public class TransactionManager {

    @Inject
    @RestClient
    GenomeApiClient apiClient;

    @Inject
    GenomeObjectTransformer objectTransformer;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    DtoMapperService mapperService;

    @Inject
    Utils pspUtils;

    private final BiFunction<GenomeTransactionContext, Throwable, GenomeTransactionContext> defaultExceptionHandler = (context, failure) -> {
        System.out.printf("Error execute Genome: %s", failure.getMessage());
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> withdrawal(TransactionTypeContext authContext) {
        GenomeTransactionContext ctx = new GenomeTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydratePaymentContext(ctx, authContext))
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::registerWithdrawalRequest)
                .safeFlatMap(PHASE_GET_PAYMENT, this::getTransaction)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private String mapToJson(Map<String, String> map) {
        Gson gson = new Gson();
        return gson.toJson(map);
    }

    private Uni<GenomeTransactionContext> hydratePaymentContext(GenomeTransactionContext context, TransactionTypeContext authContext) {
        var transaction = authContext.getTransaction();
        var paymentProviderAccount = authContext.getPaymentProviderAccount();

        String jsonData = this.mapToJson(authContext.getPaymentMethod().data());
        PaymentMethodData paymentMethodData = mapperService.mapAndValidate(jsonData, PaymentMethodData.class);

        var browserInfo = objectMapper.convertValue(transaction.getTransactionData().getOptions().get("browser_info"), BrowserInfo.class);
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx -> {
                    RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(paymentProviderAccount, RuntimeAccountConfig.class);
                    context.setTransactionContext(authContext);
                    context.setRuntimeAccountConfig(rac);
                    context.setIsHpp(true);

                    context.setCustomerData(objectTransformer.groupCustomerData(transaction));
                    context.setAmount(transaction.getAmount());
                    context.setCurrency(transaction.getCurrency());
                    context.setTransactionType(transaction.getTransactionType());
                    context.setStatementDescriptor(authContext.getMerchant().getName());
                    context.setDescription(nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()));

                    context.setIban(paymentMethodData.getIban());
                    context.setBic(paymentMethodData.getBic());
                    context.setReceiverName(paymentMethodData.getName());

                    context.setReference(transaction.getId());
                    context.setUserIp(transaction.getUserIp());
                    context.setBrowserInfo(browserInfo);
                    context.setSuccessUrl(transaction.getTransactionData().getSuccessUrl());
                    context.setCancelUrl(transaction.getTransactionData().getCancelUrl());
                    context.setFailureUrl(transaction.getTransactionData().getErrorUrl());

                    return context;
                })
                .safeFlatMap(PHASE_GRPC_INVOKE, ctx -> pspUtils.convertIso2toIso3CountryCode(ctx.getCustomerData().getAddress().getCountry(), ctx.getTransactionContext().getTenantConfig().id()))
                .safeMap(PHASE_HYDRATE_CONTEXT, countryIso3 -> {
                    context.setCountryIso3(countryIso3);
                    return context;
                }).endSubPhase();
    }

    private Uni<GenomeTransactionContext> registerWithdrawalRequest(GenomeTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_BUILD_PAYLOAD, objectTransformer::mapToWithdrawalRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, req -> apiClient.withdrawal(req))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseWithdrawalResponse(context, resp))
                .endSubPhase();
    }

    private Uni<GenomeTransactionContext> getTransaction(GenomeTransactionContext context) {
        if ( context.getWithdrawalResponse() == null || context.getWithdrawalResponse().getStatus().equals("error") ) {
            return Uni.createFrom().item(context).map(ctx -> ctx);
        }
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_BUILD_PAYLOAD, objectTransformer::mapToGetTransactionRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, req -> apiClient.getTransaction(req))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseTransactionResponse(context, resp))
                .endSubPhase();
    }

    @SneakyThrows
    private GenomeTransactionContext parseWithdrawalResponse(GenomeTransactionContext context, Response response) {
        context.setWithdrawalResponseAsString(response.readEntity(String.class));
        context.setWithdrawalResponse(mapperService.mapAndValidate(
                context.getWithdrawalResponseAsString(),
                WithdrawalResponse.class
        ));

        return context;
    }

    @SneakyThrows
    private GenomeTransactionContext parseTransactionResponse(GenomeTransactionContext context, Response response) {
        context.setTransactionResponseAsString(response.readEntity(String.class));
        System.out.println(context.getTransactionResponseAsString());
        context.setTransactionResponse(mapperService.mapAndValidate(
                context.getTransactionResponseAsString(),
                GetTransactionResponse.class
        ));

        return context;
    }
}
