package com.morefin.pg.genome.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorDetail {
    @JsonProperty("errorType")
    private String type;

    @JsonProperty("code")
    private String code;

    @JsonProperty("parameter")
    private String parameter;

    @JsonProperty("message")
    private String message;
}