package com.morefin.pg.genome.processing;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.genome.GenomeTypeModule;
import io.quarkus.arc.Arc;

public class GenomeHppServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return GenomeTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return GenomeTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return GenomeTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(GenomeAPMProcessingService.class)) {
            return instance.get();
        }
    }
}
