package com.morefin.pg.genome.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WithdrawalRequest {
    @JsonProperty("api_version")
    private Integer apiVersion;

    @JsonProperty("method")
    private String method;

    @JsonProperty("merchant_account")
    private String merchantAccount;

    @JsonProperty("merchant_password")
    private String merchantPassword;

    @JsonProperty("transaction_unique_id")
    private String transactionUniqueId;

    @JsonProperty("mid_reference")
    private String midReference;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("callback_url")
    private String callbackUrl;

    @JsonProperty("receiver_iban")
    private String receiverIban;

    @JsonProperty("type")
    private String type;

    @JsonProperty("receiver_bic")
    private String receiverBic;

    @JsonProperty("receiver_name")
    private String receiverName;

    @JsonProperty("transfer_description")
    private String transferDescription;

    @JsonProperty("receiver_address")
    private String receiverAddress;

    @JsonProperty("receiver_city")
    private String receiverCity;

    @JsonProperty("receiver_country")
    private String receiverCountry;

    @JsonProperty("receiver_zip")
    private String receiverZip;
}
