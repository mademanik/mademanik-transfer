package com.morefin.pg.gate2way.client;

import com.morefin.pg.gate2way.model.BaseTransactionRequest;
import com.morefin.pg.gate2way.model.DirectPaymentRequest;
import com.morefin.pg.gate2way.model.RefundRequest;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/api/v1/transactions")
@RegisterRestClient(configKey = "gate2way")
public interface Gate2WayApiClient {

    @POST
    Uni<Response> performHPPTransaction(BaseTransactionRequest requestPayload, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @POST
    Uni<Response> requestDirectPayment(DirectPaymentRequest requestPayload, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @GET
    @Path("/{id}")
    Uni<Response> getTransactionStatus(@PathParam("id") String id, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @POST
    @Path("/refund/{transaction_no}")
    Uni<Response> requestRefund(@PathParam("transaction_no") String transactionNo, RefundRequest requestPayload, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

}