package com.morefin.pg.gate2way.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.gatewaygrpcservices.payments.paymentgateway.services.paymentprovider.PaymentProviderRepository;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.keymanagementspi.keys.KeyManagementService;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.paymentgateway.services.transaction.TransactionRepository;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.domain.tables.pojos.PaymentProviderAccount;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProviderAccount;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionEntity;
import com.morefin.pg.gate2way.client.Gate2WayApiClient;
import com.morefin.pg.gate2way.model.AuthContext;
import com.morefin.pg.gate2way.model.ErrorDetail;
import com.morefin.pg.gate2way.model.ErrorResponse;
import com.morefin.pg.gate2way.model.PaymentTransactionResponse;
import com.morefin.pg.gate2way.model.RefundRequest;
import com.morefin.pg.gate2way.model.TransactionCallbackRequest;
import com.morefin.pg.gate2way.util.Gate2WayObjectTransformer;
import com.morefin.pg.gate2way.util.TransactionStatusMapper;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.tuples.Tuple3;
import io.smallrye.mutiny.unchecked.Unchecked;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

import static com.morefin.pg.common.Constants.PPA_DEFAULT_DESCRIPTION;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
public class TransactionManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    @RestClient
    Gate2WayApiClient apiClient;

    @Inject
    KeyManagementService keyManagementService;

    @Inject
    Gate2WayObjectTransformer objectTransformer;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    TransactionRepository transactionRepository;

    @Inject
    PaymentProviderRepository paymentProviderRepository;

    public Uni<ExecuteTransactionResponse> executeHPPRequest(TransactionTypeContext c) {
        return Uni.createFrom().item(c)
                .map(this::buildHppAuthContext)
                .flatMap(this::requestHpp);
    }

    public Uni<ExecuteTransactionResponse> executeDirectPaymentRequest(CardAuthorizeContext c) {
        return Uni.createFrom().item(c)
                .flatMap(this::decryptCardDetails)
                .map(Unchecked.function((list) -> this.buildCardAuthContext(c, list)))
                .flatMap(this::authorizePaymentRequest);
    }

    public Uni<TransactionCallbackRequest> validateCallbackResponse(String body, String signature, String tenantId) {
        return Uni.createFrom().item(() -> deserializeRequestBody(body))
                .flatMap(resp -> findPaymentProviderAccountApiKey(resp.getData().getReference(), tenantId)
                        .flatMap(apiKey -> verifySignature(body, signature, apiKey)
                                .flatMap(isValid -> {
                                    if (!isValid) {
                                        Log.errorv("Received request with invalid signature {0} \n body:\n{1}", signature, body);
                                        return Uni.createFrom().failure(new IllegalArgumentException("Invalid signature"));
                                    }
                                    return Uni.createFrom().item(resp);
                                })));
    }

    public Uni<Void> finalizeTransaction(TransactionCallbackRequest respBody, String tenantId) {
        var grpc = GrpcClientFactory.grpc(transactionGrpc, tenantId, getServiceAccount(), Constants.LOCALHOST);
        return findTransactionById(tenantId, respBody.getData().getReference())
                .flatMap(optionalTransaction -> {
                    if (optionalTransaction.isEmpty()) {
                        return Uni.createFrom().failure(new IllegalArgumentException("Transaction not found"));
                    }
                    TypedTransactionEntity transaction = optionalTransaction.get();
                    return Uni.createFrom().item(transaction.getReference());
                })
                .map(reference -> fromBody(respBody, reference))
                .flatMap(req -> grpc.finalizeTransaction(req)
                        .map(result -> {
                            if (result.hasRedirect()) {
                                return Response.temporaryRedirect(URI.create(result.getRedirect().getUrl())).build();
                            } else {
                                return Response.status(400).build();
                            }
                        })).replaceWithVoid();
    }

    public Uni<ExecuteTransactionResponse> performRefundRequest(ManageTransactionContext context) {
        return Uni.createFrom().item(context).map(Unchecked.function((ctx) -> {
                    var gate2wayTransactionId = ctx.transactionTypeContext().getParentTransaction().getReferenceNumber();
                    if (gate2wayTransactionId == null || gate2wayTransactionId.isBlank()) {
                        throw new IllegalStateException("Gate2Way transaction ID not found in parent transaction");
                    }
                    
                    var amount = java.math.BigDecimal.valueOf(ctx.transaction().getAmount())
                            .divide(java.math.BigDecimal.valueOf(100L), 2, java.math.RoundingMode.HALF_UP);
                    var requestBody = RefundRequest.builder().amount(amount).build();
                    return Tuple3.of(gate2wayTransactionId, requestBody, buildBasicAuthToken(getRuntimeAccountConfig(ctx.paymentProviderAccount())));
                }))
                .flatMap(tuple -> callApiService(
                        () -> apiClient.requestRefund(tuple.getItem1(), tuple.getItem2(), tuple.getItem3())))
                .map(resp -> objectTransformer.convertToCardResponse(resp, context.transaction().getId()));
    }

    private AuthContext buildHppAuthContext(TransactionTypeContext c) {
        var transaction = c.getTransaction();
        var runtimeAccountConfig = getRuntimeAccountConfig(c.getPaymentProviderAccount());
        return new AuthContext(
                runtimeAccountConfig,
                objectTransformer.groupCustomerData(transaction),
                transaction.getTransactionType(),
                transaction.getPaymentMethodBrand(),
                transaction.getAmount(),
                transaction.getCurrency(),
                null,
                null,
                null,
                null,
                c.getMerchant().getName(),
                transaction.getDescription(),
                transaction.getId(),
                transaction.getUserIp(),
                transaction.getTransactionData().getSuccessUrl(),
                transaction.getTransactionData().getCancelUrl(),
                transaction.getTransactionData().getErrorUrl()
        );
    }


    private AuthContext buildCardAuthContext(CardAuthorizeContext c, List<byte[]> list) {
        var transaction = c.authorizeContext().getTransaction();
        var runtimeAccountConfig = getRuntimeAccountConfig(c.authorizeContext().getPaymentProviderAccount());
        var paymentProviderAccount = c.authorizeContext().getPaymentProviderAccount();
        return new AuthContext(
                runtimeAccountConfig,
                objectTransformer.groupCustomerData(c.authorizeContext().getTransaction()),
                transaction.getTransactionType(),
                transaction.getPaymentMethodBrand(),
                transaction.getAmount(),
                transaction.getCurrency(),
                new String(list.get(0), StandardCharsets.UTF_8),
                new String(list.get(1), StandardCharsets.UTF_8),
                c.card().expirationMonth(),
                c.card().expirationYear(),
                c.authorizeContext().getMerchant().getName(),
                nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()),
                transaction.getId(),
                transaction.getUserIp(),
                transaction.getTransactionData().getSuccessUrl(),
                transaction.getTransactionData().getCancelUrl(),
                transaction.getTransactionData().getErrorUrl()
        );
    }

    private Uni<List<byte[]>> decryptCardDetails(CardAuthorizeContext x) {
        return keyManagementService.decrypt(
                x.authorizeContext().getMerchant().getPrivateKey(),
                x.card().encryptedCardNumber(),
                x.card().encryptedCvv()
        );
    }

    private Uni<ExecuteTransactionResponse> requestHpp(AuthContext context) {
        return Uni.createFrom().item(context)
                .map(objectTransformer::mapToHppRequest)
                .flatMap(req -> callApiService(() -> apiClient.performHPPTransaction(req, buildBasicAuthToken(context.runtimeAccountConfig()))))
                .map(resp -> objectTransformer.convertToCardResponse(resp, context.reference()));
    }

    private Uni<ExecuteTransactionResponse> authorizePaymentRequest(AuthContext context) {
        return Uni.createFrom().item(context)
                .map(objectTransformer::mapToDirectPaymentRequest)
                .flatMap(req -> callApiService(() -> apiClient.requestDirectPayment(req, buildBasicAuthToken(context.runtimeAccountConfig()))))
                .map(resp -> objectTransformer.convertToCardResponse(resp, context.reference()));
    }

    private Uni<Boolean> verifySignature(String body, String signature, String apiKey) {
        return Uni.createFrom().item(() -> {
            if (signature == null || signature.isBlank()) {
                return false;
            }
            String dataToHash = body + apiKey;
            String calculatedSignature = objectTransformer.calculateRequestHash(dataToHash);
            return calculatedSignature.equals(signature);
        });
    }

    private FinalizeTransactionRequest fromBody(TransactionCallbackRequest callbackResp, String reference) {
        var message = Optional.ofNullable(callbackResp.getData().getDeclineReason())
                .orElse("Transaction %s".formatted(callbackResp.getData().getStatus()));
        return FinalizeTransactionRequest
                .newBuilder()
                .setResponseMessage(message)
                .setPaymentProviderResponseMessage(message)
                .setStatus(TransactionStatusMapper.parseTransactionStatus(callbackResp))
                .setReferenceNumber(reference)
                .setId(callbackResp.getData().getReference())
                .build();
    }

    private GrpcApiUser getServiceAccount() {
        return GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "gate2way-service-account"
        );
    }

    private Uni<Optional<TypedTransactionEntity>> findTransactionById(String tenantId, String transactionId) {
        return transactionRepository.withConnection(connection -> {
            return transactionRepository.findBy(connection, transactionId, tenantId);
        });
    }

    private Uni<Optional<PaymentProviderAccount>> findPaymentProviderAccountById(String tenantId, String paymentProviderAccountId) {
        return paymentProviderRepository.findAccountBy(tenantId, paymentProviderAccountId);
    }

    private Uni<String> findPaymentProviderAccountApiKey(String transactionId, String tenantId) {
        return findTransactionById(tenantId, transactionId).onItem().transformToUni(optionalTransaction -> {
            if (optionalTransaction.isPresent()) {
                String paymentProviderAccountId = optionalTransaction.get().getPaymentProviderAccountId();
                return findPaymentProviderAccountById(tenantId, paymentProviderAccountId);
            } else {
                return Uni.createFrom().failure(new IllegalStateException("Transaction not found"));
            }
        }).onItem().transform(optionalAccount -> {
            if (optionalAccount.isPresent()) {
                PaymentProviderAccount account = optionalAccount.get();
                JsonObject data = account.getData();
                return data.getJsonObject("configuration").getString("api_key");
            } else {
                throw new IllegalStateException("PaymentProviderAccount not found");
            }
        });
    }

    private TransactionCallbackRequest deserializeRequestBody(String body) {
        try {
            return objectMapper.readValue(body, TransactionCallbackRequest.class);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Invalid request body: " + body);
        }
    }

    private RuntimeAccountConfig getRuntimeAccountConfig(TypedPaymentProviderAccount tppa) {
        return tppa.getData().getJsonObject("configuration").mapTo(RuntimeAccountConfig.class);
    }

    private String buildBasicAuthToken(RuntimeAccountConfig runtimeAccountConfig) {
        return Utils.buildBasicAuthToken(runtimeAccountConfig.apiKey(), runtimeAccountConfig.apiSecret());
    }

    private Uni<?> callApiService(Supplier<Uni<Response>> supplier) {

        return supplier.get().onItemOrFailure().transform((response, failure) -> {
            if (failure == null) {
                var resp = response.readEntity(PaymentTransactionResponse.class);
                    if (!StringUtils.isEmpty(resp.getDeclineCode()) && !StringUtils.isEmpty(resp.getDeclineMessage())) {
                        return ErrorResponse.builder().errors(List.of(ErrorDetail.builder()
                                        .code(TransactionStatus.DECLINED.toString())
                                        .type(ExecuteTransactionResponse.Status.ERROR.toString())
                                        .parameter("request")
                                        .message(objectTransformer.getMessage(resp.getDeclineCode()) + " " + resp.getDeclineMessage())
                                        .build()))
                                .build();
                    }
                    return resp;
            }
            try {
                Response serverResponse = ((WebApplicationException) failure).getResponse();
                return serverResponse.readEntity(ErrorResponse.class);
            } catch (Exception e) {
                return ErrorResponse.builder().errors(List.of(ErrorDetail.builder()
                                .code(TransactionStatus.UNRECOGNIZED.toString())
                                .type(ExecuteTransactionResponse.Status.ERROR.toString())
                                .parameter("request")
                                .message(failure.getMessage())
                                .build()))
                        .build();
            }
        });
    }
}
