package com.morefin.pg.gate2way.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.gate2way.common.TransactionManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.Map;

@Path("/psp/gate2way")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class Gate2WayCallbackService {

    @Inject
    TransactionManager transactionManager;

    @Inject
    Tenant tenant;

    @Path("/callback")
    @POST
    public Uni<Response> callbackUrl(String callbackRequest, @Context HttpHeaders headers) {
        return transactionManager.validateCallbackResponse(callbackRequest, headers.getHeaderString("signature"), tenant.id())
                .onItem().transformToUni(mappedRequest ->
                        transactionManager.finalizeTransaction(mappedRequest, tenant.id())
                                .map(result -> Response.status(Response.Status.OK).build())
                )
                .onFailure().recoverWithItem(throwable ->
                        Response.status(Response.Status.BAD_REQUEST).entity(Map.of("error", throwable.getMessage())).build()
                );
    }
}