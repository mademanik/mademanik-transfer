package com.morefin.pg.gate2way.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseTransactionRequest {
    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("action")
    private String action;

    @JsonProperty("customer")
    private Customer customer;

    @JsonProperty("source")
    private Source source;

    @JsonProperty("statementDescriptor")
    private String statementDescriptor;

    @JsonProperty("description")
    private String description;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("ipAddress")
    private String ipAddress;

    @JsonProperty("successUrl")
    private String successUrl;

    @JsonProperty("cancelUrl")
    private String cancelUrl;

    @JsonProperty("failureUrl")
    private String failureUrl;
}
