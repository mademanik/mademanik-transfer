package com.morefin.pg.gate2way.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentTransactionResponse implements Serializable {
    @JsonProperty("Id")
    private String id;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("Amount")
    private double amount;

    @JsonProperty("Currency")
    private String currency;

    @JsonProperty("Reference")
    private String reference;

    @JsonProperty("DeclineCode")
    private String declineCode;

    @JsonProperty("DeclineMessage")
    private String declineMessage;

    @JsonProperty("Source")
    private Source source;

    @JsonProperty("Customer")
    private Customer customer;

    @JsonProperty("Created")
    private String created;

    @JsonProperty("Links")
    private List<Link> links;

    @JsonProperty("NextAction")
    private NextAction nextAction;

    @JsonProperty("StatusMessage")
    private String statusMessage;

    @JsonProperty("SuccessUrl")
    private String successUrl;

    @JsonProperty("FailureUrl")
    private String failureUrl;

}
