package com.morefin.pg.gate2way.config;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.quarkus.jackson.ObjectMapperCustomizer;
import jakarta.inject.Singleton;

@Singleton
public class Gate2WayObjectMapperCustomizer implements ObjectMapperCustomizer {

    @Override
    @SuppressWarnings("deprecation")
    public void customize(ObjectMapper objectMapper) {
        // Enable case-insensitive property matching to handle Gate2Way API's inconsistent casing:
        // - Requests use camelCase (firstName, lastName, paymentMethod)
        // - Responses use PascalCase (FirstName, LastName, PaymentMethod, Status, Id)
        objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
    }
}

