package com.morefin.pg.gate2way.util;

import lombok.Getter;

@Getter
public enum Gate2WayTransactionStatus {
    PENDING("For 3DS payments, is displayed while the system waits for the customer to pass the required checks."),
    REQUESTED("For HPP requests, is displayed when the hpp request is successfully and redirect url is returned."),
    REFUNDED("A refund was successfully issued to the customer and funds were transferred from your merchant account back to the customer."),
    DECLINED("Final status when the Auth request is not approved by the gateway or by the cardholder’s issuing bank"),
    AUTHORISED("Final status when the transaction was successfully processed."),
    CAPTURED("Final status when the funds of a successfully authorized transaction have been captured."),
    VOIDED("Final status when the Auth transaction is voided successfully upon your request, or our system automatically voided it for not being captured within seven days of being authorized. transaction has failed.");

    private final String description;

    Gate2WayTransactionStatus(String description) {
        this.description = description;
    }

}