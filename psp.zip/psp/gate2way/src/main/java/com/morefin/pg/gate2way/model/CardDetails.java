package com.morefin.pg.gate2way.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CardDetails implements Serializable {

    @JsonProperty("cardNumber")
    private String cardNumber;

    @JsonProperty("cvc")
    private String cvc;

    @JsonProperty("expiryMonth")
    private Integer expiryMonth;

    @JsonProperty("expiryYear")
    private Integer expiryYear;

}

