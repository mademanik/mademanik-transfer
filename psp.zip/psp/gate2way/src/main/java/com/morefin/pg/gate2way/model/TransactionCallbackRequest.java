package com.morefin.pg.gate2way.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionCallbackRequest {

    @JsonProperty("Id")
    private String id;

    @JsonProperty("Mode")
    private String mode;

    @JsonProperty("Type")
    private String type;

    @JsonProperty("Data")
    private TransactionData data;

    @JsonProperty("Created")
    private String created;

}
