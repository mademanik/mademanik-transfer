package com.morefin.pg.gate2way.processing.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.pg.gate2way.admin.card.Gate2WayCardAdminPaymentProcessingService;
import com.morefin.pg.gate2way.common.TransactionManager;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class Gate2WayCardPaymentProcessingService implements EcommerceCardPaymentProcessingService {

    @Inject
    Gate2WayCardAdminPaymentProcessingService adminPaymentProcessingService;

    @Inject
    TransactionManager authorizationManager;

    @Inject
    TransactionManager transactionManager;

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext context) {
        return authorizationManager.executeDirectPaymentRequest(context);
    }

    @Override
    public Uni<ExecuteTransactionResponse> manage(ManageTransactionContext manageTransactionContext) {
        String transactionType = manageTransactionContext.transactionType().toLowerCase();
        return switch (transactionType) {
            case "refund" -> transactionManager.performRefundRequest(manageTransactionContext);
            default ->
                    Uni.createFrom().failure(new IllegalArgumentException("transaction type=%s not supported".formatted(transactionType)));
        };
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    /**
     * @return Payment Processing Service Admin
     */
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }

}
