package com.morefin.pg.gate2way.model;

import com.morefin.pg.gate2way.common.RuntimeAccountConfig;

public record AuthContext(
        RuntimeAccountConfig runtimeAccountConfig,
        Customer customerData,
        String transactionType,
        String paymentMethodBrand,
        Long amount,
        String currency,
        String cardNumber,
        String cvc,
        Integer expirationMonth,
        Integer expirationYear,
        String statementDescriptor,
        String description,
        String reference,
        String userIp,
        String successUrl,
        String cancelUrl,
        String failureUrl
) {
}