package com.morefin.pg.gate2way.util;

import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.pg.gate2way.model.TransactionCallbackRequest;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;

public class TransactionStatusMapper {

    public static ExecuteTransactionResponse.Status parseTransactionStatus(Gate2WayTransactionStatus transactionStatus) {
        return switch (transactionStatus) {
            case CAPTURED, REFUNDED -> ExecuteTransactionResponse.Status.APPROVED;
            case AUTHORISED, REQUESTED, PENDING -> ExecuteTransactionResponse.Status.PENDING;
            case DECLINED -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }

    public static TransactionStatus parseTransactionStatus(TransactionCallbackRequest callbackDto) {
        return switch (callbackDto.getData().getStatus()) {
            case "Captured", "Refunded" -> TransactionStatus.APPROVED;
            case "Authorised", "Requested", "Pending" -> TransactionStatus.PENDING;
            case "Declined" -> TransactionStatus.DECLINED;
            default -> TransactionStatus.UNRECOGNIZED;
        };
    }

}