package com.morefin.pg.gate2way.processing.apm;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.pg.gate2way.admin.apm.Gate2WayAPMAdminPaymentProcessingService;
import com.morefin.pg.gate2way.admin.apm.Gate2WayAPMTypeModule;
import com.morefin.pg.gate2way.common.TransactionManager;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class Gate2WayAPMProcessingService implements APMProcessingService {

    @Inject
    Gate2WayAPMAdminPaymentProcessingService adminPaymentProcessingService;

    @Inject
    TransactionManager authorizationManager;

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return Gate2WayAPMTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public Uni<ExecuteTransactionResponse> request(TransactionTypeContext context) {
        return authorizationManager.executeHPPRequest(context);
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }
}
