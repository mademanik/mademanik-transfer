package com.morefin.pg.gate2way.processing.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import com.morefin.common.grpc.payment_provider.PaymentProviderType;
import com.morefin.pg.gate2way.admin.card.Gate2WayCardProcessingModule;
import io.quarkus.arc.Arc;

import java.util.List;

public class Gate2WayCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {


    @Override
    public String name() {
        return Gate2WayCardProcessingModule.MODULE_ID;
    }

    @Override
    public String id() {
        return Gate2WayCardProcessingModule.MODULE_ID;
    }

    @Override
    public String type() {
        return PaymentProviderType.CARD.name();
    }

    @Override
    public EcommerceCardPaymentProcessingService create() {
        try (var instance = Arc.container().instance(Gate2WayCardPaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return List.of(
                "card",
                "saved_card"
        );
    }
}
