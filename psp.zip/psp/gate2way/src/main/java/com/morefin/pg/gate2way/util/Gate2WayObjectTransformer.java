package com.morefin.pg.gate2way.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.domain.domain.payment_gateway.CustomerDto;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.gate2way.model.Address;
import com.morefin.pg.gate2way.model.AuthContext;
import com.morefin.pg.gate2way.model.BaseTransactionRequest;
import com.morefin.pg.gate2way.model.CardDetails;
import com.morefin.pg.gate2way.model.Customer;
import com.morefin.pg.gate2way.model.DirectPaymentRequest;
import com.morefin.pg.gate2way.model.ErrorResponse;
import com.morefin.pg.gate2way.model.PaymentTransactionResponse;
import com.morefin.pg.gate2way.model.Source;
import com.morefin.pg.utils.Utils;
import io.vertx.core.json.JsonObject;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

@ApplicationScoped
public class Gate2WayObjectTransformer {

    public static final String DEFAULT_STATE_NA = "NA";
    private static final int MAX_STATEMENT_LENGTH = 35;
    public static final String ALL = "ALL";
    private Map<String, String> responseMessages;
    @Inject
    ObjectMapper objectMapper;

    @PostConstruct
    public void initialize() {
        initializeErrorCodes();
    }

    public ProcessingCode getResponseCode(String errorType) {
        return switch (errorType) {
            case "invalidRequest", "paymentError" -> ProcessingCode.TRX_STATUS_DECLINED;
            case "authentication_error", "api_error" -> ProcessingCode.TRX_STATUS_FAILED;
            default -> ProcessingCode.INVALID_REQUEST;
        };
    }

    public ExecuteTransactionResponse.Status getResponseStatus(ProcessingCode errorCode) {
        return switch (errorCode) {
            case TRX_STATUS_DECLINED -> ExecuteTransactionResponse.Status.DECLINED;
            case TRX_STATUS_FAILED -> ExecuteTransactionResponse.Status.ERROR;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }

    public Customer groupCustomerData(ImmutableTypedTransactionEntity transaction) {
        return Customer.builder().firstName(transaction.getCustomerFirstName())
                .lastName(transaction.getCustomerLastName())
                .phone(transaction.getCustomerPhoneNumber())
                .email(transaction.getCustomerEmail())
                .accountReference(transaction.getCustomerId())
                .address(
                        Address.builder().
                                streetAddress(transaction.getCustomerAddress())
                                .city(transaction.getCustomerCity())
                                .country(transaction.getCustomerCountry())
                                .postcode(transaction.getCustomerPostalCode())
                                .state(DEFAULT_STATE_NA)
                                .build())
                .build();
    }
    public Customer groupCustomerData(Map<String, String> customerData) {
        CustomerDto customerDto = objectMapper.convertValue(customerData, CustomerDto.class);
        return Customer.builder().firstName(customerDto.firstName())
                .lastName(customerDto.lastName())
                .phone(customerDto.phone())
                .email(customerDto.email())
                .category(customerDto.category())
                .accountReference(customerDto.customerId())
                .address(
                        Address.builder().
                                streetAddress(customerDto.address())
                                .city(customerDto.city())
                                .country(customerDto.country())
                                .postcode(customerDto.postalCode())
                                .state(DEFAULT_STATE_NA)
                                .build())
                .build();
    }

    public BaseTransactionRequest mapToHppRequest(AuthContext context) {
        String hppPaymentMethod = context.runtimeAccountConfig().paymentMethods();
        // Normalize: remove surrounding quotes if present (handles "\"ALL\"" from DB)
        String normalized = !StringUtils.isBlank(hppPaymentMethod) 
            ? hppPaymentMethod.replaceAll("^\"|\"$", "").trim() 
            : null;
        
        Source source = Source.builder()
                .paymentMethods(normalized != null && !normalized.equalsIgnoreCase(ALL) ? normalized : null)
                .billingAddress(context.customerData().getAddress())
                .build();
        
        return mapBaseRequest(context).source(source).build();
    }

    public DirectPaymentRequest mapToDirectPaymentRequest(AuthContext context) {
        return mapBaseRequest(context)
                .source(mapToSourceModel(context))
                .cardDetails(mapToCardDetails(context))
                .build();
    }

    public ExecuteTransactionResponse convertToCardResponse(Object resp, String transactionId) {
        ExecuteTransactionResponse transactionResp;
        if (resp instanceof PaymentTransactionResponse) {
            transactionResp = convertToCardResponse((PaymentTransactionResponse) resp);
        } else if (resp instanceof ErrorResponse) {
            transactionResp = convertToCardResponse((ErrorResponse) resp, transactionId);
        } else {
            throw new IllegalStateException("Unexpected type of response: " + resp.getClass().getName());
        }
        return transactionResp;
    }

    public String calculateRequestHash(String dataToHash) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] messageDigest = md.digest(dataToHash.getBytes());
            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);
            // Convert message digest into hex value
            String hashtext = no.toString(16);
            // Add preceding 0s to make it 32 bit
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-512 algorithm not available", e);
        }
    }

    private Source mapToSourceModel(AuthContext context) {
        return Source.builder()
                .paymentMethod(mapPaymentMethodBrand(context.paymentMethodBrand()))
                .billingAddress(context.customerData().getAddress())
                .build();
    }

    private CardDetails mapToCardDetails(AuthContext context) {
        if (!StringUtils.isEmpty(context.cardNumber()) && !StringUtils.isEmpty(context.cvc())) {
            return CardDetails.builder()
                    .cardNumber(context.cardNumber())
                    .cvc(context.cvc())
                    .expiryMonth(context.expirationMonth())
                    .expiryYear(Utils.trimExpirationYear(context.expirationYear()))
                    .build();
        } else {
            return null;
        }
    }

    private String mapPaymentMethodBrand(String brand) {
        return switch (brand.toUpperCase()) {
            case "VISA" -> "VISA-Z";
            case "MASTERCARD" -> "MASTERCARD-Z";
            default -> throw new IllegalArgumentException("Unexpected value: " + brand);
        };
    }

    private DirectPaymentRequest.DirectPaymentRequestBuilder mapBaseRequest(AuthContext context) {
        BigDecimal number = BigDecimal.valueOf(context.amount());
        BigDecimal divisorBD = BigDecimal.valueOf(100L);
        var amountAfterTransform = number.divide(divisorBD, 2, RoundingMode.HALF_UP);
        return DirectPaymentRequest.builder()
                .amount(amountAfterTransform)
                .currency(context.currency())
                .action(StringUtils.capitalize(context.transactionType().toLowerCase()))
                .customer(context.customerData())
                .statementDescriptor(trimToLength(context.statementDescriptor(), MAX_STATEMENT_LENGTH))
                .description(context.description())
                .reference(context.reference())
                .ipAddress(context.userIp())
                .successUrl(context.successUrl())
                .cancelUrl(context.cancelUrl())
                .failureUrl(context.failureUrl());
    }

    private ExecuteTransactionResponse convertToCardResponse(PaymentTransactionResponse response) {
        var paymentProviderResponseCode = TransactionStatusMapper.parseTransactionStatus(Gate2WayTransactionStatus.valueOf(response.getStatus().toUpperCase()));
        var responseCode = switch (paymentProviderResponseCode) {
            case APPROVED -> ProcessingCode.TRX_STATUS_APPROVED;
            case PENDING -> ProcessingCode.TRX_STATUS_PENDING;
            case DECLINED -> ProcessingCode.TRX_STATUS_DECLINED;
            case ERROR -> ProcessingCode.TRX_STATUS_FAILED;
            default -> throw new IllegalStateException("Unexpected value: " + paymentProviderResponseCode);
        };

        String message;
        switch (paymentProviderResponseCode) {
            case PENDING -> {
                return buildPendingResponse(response);
            }
            case DECLINED, APPROVED -> {
                message = "Transaction is %s".formatted(response.getStatus());
            }
            case ERROR, UNRECOGNIZED -> {
                message = "An error occurred";
            }
            default -> throw new IllegalArgumentException("Unexpected value: " + paymentProviderResponseCode);
        }
        return toExecuteTransactionResponse(responseCode, response, paymentProviderResponseCode, message);
    }

    private static ExecuteTransactionResponse toExecuteTransactionResponse(ProcessingCode responseCode, PaymentTransactionResponse response, ExecuteTransactionResponse.Status paymentProviderResponseCode, String message) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(ExecuteTransactionResponse.Response.newBuilder())
                        .set(responseCode.name(), builder::setResponseCode)
                        .set(StringUtils.abbreviate(message, 50), builder::setResponseMessage)
                        .set(response.getReference(), builder::setId)
                        .set("", builder::setApprovalCode)
                        .setAny(message, builder::setPaymentProviderResponseMessage)
                        .setAny(response.getStatus(), builder::setPaymentProviderResponseCode)
                        .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                        .set(paymentProviderResponseCode.toString(), builder::setPaymentProviderStatus)
                        .setAny(paymentProviderResponseCode, builder::setStatus)
                        .getBuilder().build())
                .build();
    }

    private static ExecuteTransactionResponse toExecuteTransactionResponse(ProcessingCode responseCode, ErrorResponse response, ExecuteTransactionResponse.Status paymentProviderResponseCode, String transactionId, String message) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        var error = response.getErrors().stream().findFirst().get();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(builder)
                        .set(responseCode.name(), builder::setResponseCode)
                        .set(StringUtils.abbreviate(error.getMessage(), 50), builder::setResponseMessage)
                        .set(transactionId, builder::setId)
                        .set("", builder::setApprovalCode)
                        .setAny(message, builder::setPaymentProviderResponseMessage)
                        .setAny(response.getErrors().get(0).getType(), builder::setPaymentProviderResponseCode)
                        .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                        .set(paymentProviderResponseCode.toString(), builder::setPaymentProviderStatus)
                        .setAny(paymentProviderResponseCode, builder::setStatus)
                        .getBuilder().build())
                .build();
    }

    private ExecuteTransactionResponse buildPendingResponse(PaymentTransactionResponse response) {
        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
            //TODO: set all response data here
            .setResponse(ExecuteTransactionResponse.Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name()).build())
            .setRedirect(new GrpcBuilder<>(builder).set(response.getLinks().get(0).getHref(), builder::setUrl).getBuilder().build()).build();
    }

    private ExecuteTransactionResponse convertToCardResponse(ErrorResponse response, String transactionId) {
        var responseCode = getResponseCode(response.getErrors().stream().findFirst().get().getType());
        return buildErrorResponse(responseCode, response, transactionId);
    }

    private ExecuteTransactionResponse buildErrorResponse(ProcessingCode responseCode, ErrorResponse response, String transactionId) {
        String errorMessage = getMessage(response.getErrors().stream().findFirst().get().getCode());
        return toExecuteTransactionResponse(responseCode, response, getResponseStatus(responseCode), transactionId, errorMessage);
    }

    private static String trimToLength(String input, int maxLength) {
        if (input == null) {
            return "";
        }
        return input.length() > maxLength ? input.substring(0, maxLength) : input;
    }

    private void initializeErrorCodes() {
        this.responseMessages = new HashMap<>();

        responseMessages.put("invalidTransactionStatus", "Invalid transaction status.");
        responseMessages.put("invalidTransactionType", "Invalid transaction type.");
        responseMessages.put("invalidPaymentMethod", "Invalid payment method.");
        responseMessages.put("invalidPaymentChannel", "Invalid payment channel.");
        responseMessages.put("invalidCvc", "Invalid or not provided CVC parameter.");
        responseMessages.put("invalidRefundAmount", "Refund amount needs to be less or equal to available refund amount.");
        responseMessages.put("declinedByAcquirer", "Declined by acquirer.");
        responseMessages.put("amountTooLarge", "The specified amount is greater than the maximum amount allowed.");
        responseMessages.put("amountTooSmall", "The specified amount is less than the minimum amount allowed.");
        responseMessages.put("maxVolumeExceeded", "Max volume exceeded.");
        responseMessages.put("restrictionByPid", "Restriction by Payment ID.");
        responseMessages.put("restrictionByEmail", "Restriction by email.");
        responseMessages.put("blacklisted", "Transaction blacklisted.");
        responseMessages.put("invalidPaymentSource", "Invalid Payment Source.");
        responseMessages.put("invalidBillingAddressCountry", "Invalid Billing AddressCountry.");
        responseMessages.put("invalidCurrency", "Invalid Currency.");
        responseMessages.put("declinedByBank", "Common decline by bank.");
        responseMessages.put("declinedByThreeDSecure", "Declined by 3D Secure.");
        responseMessages.put("authorizationFailure", "Authorization failure.");
        responseMessages.put("authorizationToTheChannelFailure", "Authorization to the channel failure.");
        responseMessages.put("channelConnectionError", "Channel connection error.");
        responseMessages.put("channelInvalidRefundRequest", "Channel error, invalid refund request.");
        responseMessages.put("threeDSecureCardNotEnrolled", "The requested card is not 3D Secure enrolled.");
        responseMessages.put("threeDSecureEnrolmentError", "T3D Secure Enrolment Error.");
        responseMessages.put("threeDSecureAuthenticationError", "3D Secure Authentication Error.");
    }

    public String getMessage(String errorCode) {
        return responseMessages.getOrDefault(errorCode, "Unknown response code");
    }

}

