package com.morefin.pg.gate2way.client;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

@ApplicationScoped
public class Gate2WayApiClientImpl {

    @Produces
    Gate2WayApiClient apiClient() {
        return RestClientBuilder.newBuilder()
                .build(Gate2WayApiClient.class);
    }
}
