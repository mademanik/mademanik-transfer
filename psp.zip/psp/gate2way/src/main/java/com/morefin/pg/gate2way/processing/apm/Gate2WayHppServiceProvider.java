package com.morefin.pg.gate2way.processing.apm;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.gate2way.admin.apm.Gate2WayAPMTypeModule;
import io.quarkus.arc.Arc;

public class Gate2WayHppServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return Gate2WayAPMTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return Gate2WayAPMTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return Gate2WayAPMTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(Gate2WayAPMProcessingService.class)) {
            return instance.get();
        }
    }
}
