package com.morefin.pg.gate2way.common;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
        @JsonProperty("api_key")
        String apiKey,
        @JsonProperty("api_secret")
        String apiSecret,
        @JsonProperty("payment_methods")
        String paymentMethods
) {
}
