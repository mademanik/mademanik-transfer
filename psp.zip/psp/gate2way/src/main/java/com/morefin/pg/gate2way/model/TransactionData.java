package com.morefin.pg.gate2way.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionData {
    @JsonProperty("Id")
    private String id;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    @JsonProperty("Amount")
    private String amount;

    @JsonProperty("Currency")
    private String currency;

    @JsonProperty("recurring")
    private Boolean recurring;

    @JsonProperty("firstRecurringTransactionId")
    private String firstRecurringTransactionId;
    @JsonProperty("remainingAmount")
    private Long remainingAmount;

    @JsonProperty("Reference")
    private String reference;

    @JsonProperty("DeclineReason")
    private String declineReason;

    @JsonProperty("DeclineCode")
    private String declineCode;

    @JsonProperty("Created")
    private String created;

    @JsonProperty("customer")
    private Customer customer;

    @JsonProperty("PayerDetails")
    private PayerDetails payerDetails;
}