package com.morefin.pg.gate2way.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Source implements Serializable {
    @JsonProperty("Id")
    private String id;

    @JsonProperty("PaymentMethod")
    private String paymentMethod;

    @JsonProperty("paymentMethods")
    private String paymentMethods;

    @JsonProperty("billingAddress")
    private Address billingAddress;
}
