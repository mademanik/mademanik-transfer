package com.morefin.pg.gate2way.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Link implements Serializable {

    @JsonProperty("Href")
    private String href;

    @JsonProperty("Rel")
    private String rel;

    @JsonProperty("Method")
    private String method;

}
