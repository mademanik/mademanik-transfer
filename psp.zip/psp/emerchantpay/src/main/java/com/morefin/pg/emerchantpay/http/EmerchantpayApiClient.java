package com.morefin.pg.emerchantpay.http;

import com.morefin.pg.emerchantpay.model.PaymentRequest;
import com.morefin.pg.emerchantpay.model.ReconcileRequest;
import com.morefin.pg.emerchantpay.model.RefundRequest;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import static com.morefin.pg.emerchantpay.util.Constants.SIGNATURE;


@RegisterRestClient(configKey = "emerchantpay")
@Produces(MediaType.APPLICATION_XML)
@Consumes(MediaType.APPLICATION_XML)
public interface EmerchantpayApiClient {

    @POST
    @Path("/process/{terminalToken}")
    Uni<Response> requestDirectPayment(PaymentRequest requestPayload,
                                       @PathParam("terminalToken") String terminalToken,
                                       @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @POST
    @Path("/process/{terminalToken}")
    Uni<Response> refund(RefundRequest requestPayload,
                         @PathParam("terminalToken") String terminalToken,
                         @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @PUT
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Path("/threeds/threeds_method/{uniqueId}")
    Uni<Response> continue3ds(@FormParam(SIGNATURE) String signature, @PathParam("uniqueId") String uniqueId);

    @POST
    @Path("/reconcile/{terminalToken}")
    Uni<Response> reconcile(ReconcileRequest requestPayload, @PathParam("terminalToken") String terminalToken,  @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);
}
