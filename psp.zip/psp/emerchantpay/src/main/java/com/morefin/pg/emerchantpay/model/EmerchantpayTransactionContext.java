package com.morefin.pg.emerchantpay.model;

import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@ToString
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmerchantpayTransactionContext extends BaseTransactionContext<PaymentResponse> {
    RuntimeAccountConfig runtimeAccountConfig;
    PaymentResponse paymentResponse;
    String authToken;
    String transactionId;
}
