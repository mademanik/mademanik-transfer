package com.morefin.pg.emerchantpay.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class Control {
    @XmlElement(name = "device_type")
    private String deviceType;
    @XmlElement(name = "challenge_window_size")
    private String challengeWindowSize;
    @XmlElement(name = "challenge_indicator")
    private String challengeIndicator;
}
