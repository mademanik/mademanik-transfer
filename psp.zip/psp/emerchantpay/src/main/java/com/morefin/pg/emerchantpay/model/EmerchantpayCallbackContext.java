package com.morefin.pg.emerchantpay.model;

import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.transaction.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionEntity;
import com.morefin.pg.safeuni.BaseTransactionContext;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmerchantpayCallbackContext extends BaseTransactionContext<PaymentResponse> {

    RuntimeAccountConfig runtimeAccountConfig;
    FinalizeTransactionRequest finalizeRequest;
    ExecuteTransactionResponse finalizeResponse;
    TransactionCallbackRequest callbackRequest;
    TypedTransactionEntity transactionEntity;
    MultivaluedMap<String, String> callbackRequestAsMap;
    String tenantId;
    String callbackRequestSignature;
    String paymentRequestSignature;
    String transactionId;
    String transactionRespStatusCode;
    boolean isFrictionlessCallback;
    boolean isReconcileNeeded;
    boolean isStatusTerminal;
    int delayInterval;
    int retryCount;
    TransactionStatus transactionStatus;
    TransactionGrpc transactionGrpc;
    PaymentResponse paymentResponse;

    public EmerchantpayCallbackContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}