package com.morefin.pg.emerchantpay.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@XmlAccessorType(XmlAccessType.FIELD)
public class BillingAddress {

    @XmlElement(name = "first_name")
     String firstName;

    @XmlElement(name = "last_name")
     String lastName;

    @XmlElement(name = "address1")
     String address1;

    @XmlElement(name = "zip_code")
     String zipCode;

    @XmlElement(name = "city")
     String city;

    @XmlElement(name = "country")
     String country;
}
