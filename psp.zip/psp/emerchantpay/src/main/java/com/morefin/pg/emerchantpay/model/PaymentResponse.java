package com.morefin.pg.emerchantpay.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(name = "payment_response")
@XmlAccessorType(XmlAccessType.FIELD)
@Builder
public class PaymentResponse {

    @XmlElement(name = "transaction_type")
    private String transactionType;
    private String status;
    @XmlElement(name = "unique_id")
    private String uniqueId;
    @XmlElement(name = "transaction_id")
    private String transactionId;
    @XmlElement(name = "technical_message")
    private String technicalMessage;
    private String message;
    @XmlElement(name = "redirect_url")
    private String redirectUrl;
    @XmlElement(name = "redirect_url_type")
    private String redirectUrlType;
    @XmlElement(name = "threeds_method_url")
    private String threedsMethodUrl;
    @XmlElement(name = "threeds_method_continue_url")
    private String threedsMethodContinueUrl;
    private String mode;
    private Integer code;
    private String timestamp;
    private String descriptor;
    private Integer amount;
    private String currency;
    private Threeds threeds;
    @XmlElement(name = "sent_to_acquirer")
    private Boolean sentToAcquirer;
}
