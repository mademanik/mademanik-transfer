package com.morefin.pg.emerchantpay.manager;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.transaction.resourceactions.TransactionRepository;
import com.morefin.pg.emerchantpay.http.EmerchantpayApiClient;
import com.morefin.pg.emerchantpay.model.EmerchantpayCallbackContext;
import com.morefin.pg.emerchantpay.model.PaymentResponse;
import com.morefin.pg.emerchantpay.model.ReconcileRequest;
import com.morefin.pg.emerchantpay.model.RuntimeAccountConfig;
import com.morefin.pg.emerchantpay.model.TransactionCallbackRequest;
import com.morefin.pg.emerchantpay.util.EmerchantpayObjectTransformer;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.net.URI;
import java.time.Duration;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.PHASE_BUILD_FINALIZE_REQUEST;
import static com.morefin.pg.common.Constants.PHASE_DB_GET_DATA;
import static com.morefin.pg.common.Constants.PHASE_DB_GET_PPA_DATA;
import static com.morefin.pg.common.Constants.PHASE_DB_GET_TRANSACTION_DATA;
import static com.morefin.pg.common.Constants.PHASE_GRPC_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_READ_PAYLOAD;
import static com.morefin.pg.common.Constants.PHASE_VERIFY_CALLBACK;
import static com.morefin.pg.emerchantpay.util.Constants.BASE_CALLBACK_URL;
import static com.morefin.pg.emerchantpay.util.Constants.CALLBACK_3DS;
import static com.morefin.pg.emerchantpay.util.Constants.PHASE_INVOKE_3DS_CONTINUE;
import static com.morefin.pg.emerchantpay.util.Constants.PHASE_INVOKE_3DS_RECONCILE;
import static com.morefin.pg.emerchantpay.util.Constants.SIGNATURE;

@ApplicationScoped
public class FinalizeManager {
    @Inject
    SignatureUtils signatureUtils;

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    EmerchantpayObjectTransformer objectTransformer;

    @Inject
    TransactionRepository transactionRepository;

    private static final ObjectMapper mapper = new ObjectMapper().setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);

    BiFunction<EmerchantpayCallbackContext, Throwable, EmerchantpayCallbackContext> defaultFinalizeExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(context, failure));
        return context;
    };

    BiFunction<EmerchantpayCallbackContext, Throwable, EmerchantpayCallbackContext> defaultContinue3dsExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.handle3dsContinueException(context, failure));
        return context;
    };

    @Inject
    @RestClient
    EmerchantpayApiClient emerchantpayApiClient;

    public Uni<Response> finalizeTransaction(MultivaluedMap<String, String> callbackRequest, String tenantId) {
        EmerchantpayCallbackContext ctx = new EmerchantpayCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateCallbackContext(ctx1, callbackRequest, tenantId))
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifySignature)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .flatMap(this::buildFinalResponse);
    }

    public Uni<Response> finalizeFrictionlessTransaction(MultivaluedMap<String, String> callbackRequest, String tenantId) {
        EmerchantpayCallbackContext ctx = new EmerchantpayCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateFrictionlessCallbackContext(ctx1, callbackRequest, tenantId))
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifySignature)
                .safeFlatMap(PHASE_PSP_INVOKE, this::getTransactionStatus)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .flatMap(this::buildFinalResponse);
    }

    private Uni<EmerchantpayCallbackContext> getTransactionStatus(EmerchantpayCallbackContext context) {
        return SafeUni.from(context, defaultContinue3dsExceptionHandler, context)
                .safeFlatMap(PHASE_INVOKE_3DS_CONTINUE, this::request3dsContinueMethod)
                .safeFlatMap(PHASE_INVOKE_3DS_RECONCILE, continueResp -> this.request3dsReconcile(context, continueResp))
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentResponse(context, response))
                .endSubPhase();
    }

    private Uni<Response> request3dsContinueMethod(EmerchantpayCallbackContext ctx) {
        if (!ctx.isReconcileNeeded()) {
            return emerchantpayApiClient.continue3ds(
                            ctx.getTransactionEntity().getData().getString(SIGNATURE),
                            ctx.getCallbackRequest().getUniqueId()
                    ).onFailure(WebApplicationException.class)
                    .recoverWithUni(failure -> objectTransformer.handleAlreadyStarted3dsContinue(ctx, failure));
        }
        return Uni.createFrom().item(Response.ok(PaymentResponse.builder().status("in_progress").build()).build());
    }

    private Uni<Response> request3dsReconcile(EmerchantpayCallbackContext ctx, Response continueResp) {
        if (ctx.isReconcileNeeded())
            return emerchantpayApiClient.reconcile(
                            new ReconcileRequest(ctx.getCallbackRequest().getUniqueId()),
                            ctx.getRuntimeAccountConfig().terminalToken(),
                            Utils.buildBasicAuthToken(ctx.getRuntimeAccountConfig().username(), ctx.getRuntimeAccountConfig().password())
                    ).onFailure(WebApplicationException.class)
                    .recoverWithUni(failure -> objectTransformer.handleAlreadyStarted3dsContinue(ctx, failure));
        return Uni.createFrom().item(continueResp);
    }

    @SneakyThrows
    private EmerchantpayCallbackContext parsePaymentResponse(EmerchantpayCallbackContext ctx, Response response) {
        ctx.setPaymentResponse(response.readEntity(PaymentResponse.class));
        var transactionStatus = objectTransformer.parseFinalizeType(ctx.getPaymentResponse());
        ctx.setTransactionStatus(transactionStatus);
        ctx.setStatusTerminal(!TransactionStatus.PENDING.equals(transactionStatus));
        return ctx;
    }

    private Uni<Response> buildFinalResponse(EmerchantpayCallbackContext ctx) {
        if (ctx.getErrorDescription() == null) {
            if (ctx.isFrictionlessCallback()) {
                if (ctx.isStatusTerminal() && ctx.getFinalizeResponse() != null && ctx.getFinalizeResponse().hasRedirect()) {
                    return Uni.createFrom().item(Response.temporaryRedirect(URI.create(ctx.getFinalizeResponse().getRedirect().getUrl())).build());
                } else {
                    // if the transaction is still in progress, re-invoke the same API to reconcile and retry max 10 counts
                    // before redirect to empty page
                    if (ctx.getRetryCount() < 11) {
                        Log.infov("Performing reconciliation attempt {0} for transaction {1} with unique_id {2}",
                                ctx.getRetryCount(), ctx.getTransactionId(), ctx.getCallbackRequest().getUniqueId());
                        ctx.getCallbackRequestAsMap().putSingle("is_reconcile_needed", "true");
                        ctx.getCallbackRequestAsMap().putSingle("retry_count", String.valueOf(ctx.getRetryCount()));
                        String redirectUri = BASE_CALLBACK_URL + CALLBACK_3DS + "?" + objectTransformer.stringifyFormParams(ctx.getCallbackRequestAsMap());
                        return Uni.createFrom().item(() -> Response.temporaryRedirect(URI.create(redirectUri)).build())
                                .onItem().delayIt().by(Duration.ofSeconds(ctx.getDelayInterval()));
                    }
                }
            }
            return Uni.createFrom().item(Response.ok().build());
        }
        return Uni.createFrom().item(Response.status((Response.Status) ctx.getErrorDescription().getErrorResponse())
                .entity(Map.of("error", ctx.getErrorDescription()
                        .getResponseMessage()))
                .build());
    }


    private Uni<EmerchantpayCallbackContext> sendGrpcFinalizeRequest(EmerchantpayCallbackContext ctx) {
        if (ctx.isStatusTerminal()) {
            return ctx.getTransactionGrpc().
                    finalizeTransaction(ctx.getFinalizeRequest())
                    .map(response -> {
                        ctx.setFinalizeResponse(response);
                        return ctx;
                    });
        }
        return Uni.createFrom().item(ctx);
    }

    private Uni<EmerchantpayCallbackContext> hydrateCallbackContext(EmerchantpayCallbackContext ctx, MultivaluedMap<String, String> callbackRequestAsMap, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseCallbackRequest(ctx, callbackRequestAsMap))
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx2 -> this.hydrateWithDtoData(ctx2, tenantId, false))
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByTransactionId)
                .endSubPhase();
    }

    private Uni<EmerchantpayCallbackContext> hydrateFrictionlessCallbackContext(EmerchantpayCallbackContext ctx, MultivaluedMap<String, String> callbackRequestAsMap, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseCallbackRequest(ctx, callbackRequestAsMap))
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx2 -> this.hydrateWithDtoData(ctx2, tenantId, true))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_PPA_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    private Uni<EmerchantpayCallbackContext> getPaymentProviderAccountDataByTransactionId(EmerchantpayCallbackContext ctx) {
        return signatureUtils.findPaymentProviderAccountData(ctx.getTenantId(), ctx.getCallbackRequest().getTransactionId())
                .map(ppa -> {
                    ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, RuntimeAccountConfig.class));
                    return ctx;
                });
    }

    private Uni<EmerchantpayCallbackContext> getPaymentProviderAccountDataByPpaId(EmerchantpayCallbackContext ctx) {
        return signatureUtils.findPaymentProviderAccountById(ctx.getTenantId(), ctx.getTransactionEntity().getPaymentProviderAccountId())
                .map(optionalAccount -> optionalAccount
                        .map(ppa -> {
                            ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, RuntimeAccountConfig.class));
                            return ctx;
                        })
                        .orElseThrow(() -> new IllegalStateException("PaymentProviderAccount not found")));
    }

    private Uni<EmerchantpayCallbackContext> getTransactionData(EmerchantpayCallbackContext ctx) {
        return transactionRepository.withTransaction(connection -> {
            return transactionRepository.findByReferenceNumber(connection, ctx.getTenantId(), ctx.getCallbackRequest().getUniqueId())
                    .map(optionalTransaction -> optionalTransaction
                            .map(transaction -> {
                                ctx.setTransactionEntity(transaction);
                                ctx.setTransactionId(transaction.getId());
                                return ctx;
                            })
                            .orElseThrow(() -> new IllegalStateException("Transaction not found")));
        });
    }

    private EmerchantpayCallbackContext parseCallbackRequest(EmerchantpayCallbackContext ctx, MultivaluedMap<String, String> callbackRequestAsMap) {
        //Additional step to preserve the request payload for future logging
        ctx.setCallbackRequestAsMap(callbackRequestAsMap);
        ctx.setCallbackRequest(mapper.convertValue(flatten(callbackRequestAsMap), TransactionCallbackRequest.class));
        return ctx;
    }


    /**
     * Flatten MultivaluedMap<String, String> to Map<String, String>
     * (taking only the first value for each key).
     */
    private static java.util.Map<String, String> flatten(MultivaluedMap<String, String> multiMap) {
        java.util.Map<String, String> result = new java.util.HashMap<>();
        multiMap.forEach((key, values) ->
                result.put(key, (values != null && !values.isEmpty()) ? values.get(0) : "")
        );
        return result;
    }


    @SneakyThrows
    private EmerchantpayCallbackContext hydrateWithDtoData(EmerchantpayCallbackContext ctx, String tenantId, boolean isFrictionlessCallback) {
        //make attempt to transform to successful response
        ctx.setFrictionlessCallback(isFrictionlessCallback);
        ctx.setTenantId(tenantId);
        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        ctx.setCallbackRequestSignature(ctx.getCallbackRequest().getSignature());
        ctx.setTransactionId(ctx.getCallbackRequest().getTransactionId());

        if (isFrictionlessCallback) {
            // increment retryCount on each request
            ctx.setRetryCount(ctx.getCallbackRequest().getRetryCount() + 1);
            ctx.setReconcileNeeded(ctx.getCallbackRequest().isReconcileNeeded());
            //set delay interval before redirect from 2,4,8,16 and then on every 32 seconds in loop for 10 times;
            ctx.setDelayInterval((int) (Math.pow(2, Math.min(ctx.getRetryCount(), 5))));
        } else {
            var transactionStatus = objectTransformer.parseFinalizeType(ctx.getCallbackRequest());
            ctx.setTransactionStatus(transactionStatus);
            ctx.setStatusTerminal(!TransactionStatus.PENDING.equals(transactionStatus));
        }
        return ctx;
    }

    private EmerchantpayCallbackContext verifySignature(EmerchantpayCallbackContext ctx) {
        try {
            if (StringUtils.isBlank(ctx.getCallbackRequestSignature())) {
                Log.errorv("Received callback request with blank signature header.");
                ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, new SecurityException("Missing signature")));
                return ctx;
            }
            String input = ctx.isFrictionlessCallback() ? buildFrictionlessCallbackMessage(ctx) : buildCallbackMessage(ctx);
            String calculatedSignature = ctx.isFrictionlessCallback() ? SignatureUtils.encryptWithSha512(input) : SignatureUtils.encryptWithSha1(input);
            if (!calculatedSignature.equals(ctx.getCallbackRequestSignature())) {
                Log.errorv("Received request with unexpected signature.");
                ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, new SecurityException("Invalid signature")));
            }
        } catch (Exception e) {
            Log.errorv("Exception while verifying signature.", e);
            ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, e));
        }
        return ctx;
    }

    private String buildCallbackMessage(EmerchantpayCallbackContext ctx) {
        return ctx.getCallbackRequest().getUniqueId() + ctx.getRuntimeAccountConfig().password();
    }

    private String buildFrictionlessCallbackMessage(EmerchantpayCallbackContext ctx) {
        return "%s%s%s".formatted(ctx.getCallbackRequest().getUniqueId(),
                ctx.getCallbackRequest().getThreedsMethodStatus(),
                ctx.getRuntimeAccountConfig().password()
        );
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "emerchantpay-service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }
}
