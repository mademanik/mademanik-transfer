package com.morefin.pg.emerchantpay.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "payment_transaction")
public class RefundRequest {

    @XmlElement(name = "transaction_type")
    private String transactionType;

    @XmlElement(name = "transaction_id")
    private String transactionId;

    @XmlElement(name = "reference_id")
    private String reference_id;

    @XmlElement(name = "usage")
    private String usage;

    @XmlElement(name = "remote_ip")
    private String remoteIp;

    @XmlElement(name = "amount")
    private Long amount;

    @XmlElement(name = "currency")
    private String currency;
}