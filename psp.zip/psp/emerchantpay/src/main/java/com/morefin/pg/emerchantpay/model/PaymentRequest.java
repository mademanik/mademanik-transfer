package com.morefin.pg.emerchantpay.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@FieldDefaults(level = AccessLevel.PRIVATE)
@XmlRootElement(name = "payment_transaction")
public class PaymentRequest {

    @XmlElement(name = "transaction_type")
    private String transactionType;

    @XmlElement(name = "transaction_id")
    private String transactionId;

    @XmlElement(name = "usage")
    private String usage;

    @XmlElement(name = "remote_ip")
    private String remoteIp;

    @XmlElement(name = "amount")
    private Long amount;

    @XmlElement(name = "currency")
    private String currency;

    @XmlElement(name = "card_holder")
    private String cardHolder;

    @XmlElement(name = "card_number")
    private String cardNumber;

    @XmlElement(name = "expiration_month")
    private Integer expirationMonth;

    @XmlElement(name = "expiration_year")
    private Integer expirationYear;

    @XmlElement(name = "cvv")
    private String cvv;

    @XmlElement(name = "customer_email")
    private String customerEmail;

    @XmlElement(name = "customer_phone")
    private String customerPhone;

    @XmlElement(name = "billing_address")
    private BillingAddress billingAddress;

    @XmlElement(name = "notification_url")
    private String notificationUrl;

    @XmlElement(name = "return_success_url")
    private String returnSuccessUrl;

    @XmlElement(name = "return_failure_url")
    private String returnFailureUrl;

    @XmlElement(name = "threeds_v2_params")
    private ThreedsV2Params threedsV2Params;

    @XmlElement(name = "sca_params")
    private ScaParams scaParams;
}
