package com.morefin.pg.emerchantpay.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(name = "authentication")
@XmlAccessorType(XmlAccessType.FIELD)
public class Authentication {
    private String code;
    private String status_reason_code;
}
