package com.morefin.pg.emerchantpay.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import com.morefin.common.grpc.payment_provider.PaymentProviderType;
import com.morefin.pg.emerchantpay.admin.card.EmerchantpayCardProcessingModule;
import io.quarkus.arc.Arc;

import java.util.List;

public class EmerchantpayCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {

    @Override
    public String name() {
        return EmerchantpayCardProcessingModule.MODULE_ID;
    }

    @Override
    public String id() {
        return EmerchantpayCardProcessingModule.MODULE_ID;
    }

    @Override
    public String type() {
        return PaymentProviderType.CARD.name();
    }

    @Override
    public EcommerceCardPaymentProcessingService create() {
        try (var instance = Arc.container().instance(EmerchantpayCardPaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return List.of(
                "card",
                "saved_card"
        );
    }
}
