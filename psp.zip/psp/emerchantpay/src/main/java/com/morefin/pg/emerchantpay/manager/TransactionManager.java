package com.morefin.pg.emerchantpay.manager;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.common.TransactionUtils;
import com.morefin.pg.emerchantpay.http.EmerchantpayApiClient;
import com.morefin.pg.emerchantpay.model.EmerchantpayPaymentTransactionContext;
import com.morefin.pg.emerchantpay.model.EmerchantpayRefundTransactionContext;
import com.morefin.pg.emerchantpay.model.EmerchantpayTransactionContext;
import com.morefin.pg.emerchantpay.model.PaymentResponse;
import com.morefin.pg.emerchantpay.model.RefundRequest;
import com.morefin.pg.emerchantpay.model.RuntimeAccountConfig;
import com.morefin.pg.emerchantpay.util.EmerchantpayObjectTransformer;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.List;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.PHASE_DECRYPT_CARD_DETAILS;
import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_READ_PAYLOAD;
import static com.morefin.pg.common.Constants.PHASE_REQUEST_PAYMENT;
import static com.morefin.pg.common.Constants.PHASE_REQUEST_REFUND;

@ApplicationScoped
public class TransactionManager {

    @Inject
    TransactionUtils transactionUtils;

    @Inject
    EmerchantpayObjectTransformer objectTransformer;

    @Inject
    @RestClient
    EmerchantpayApiClient emerchantpayApiClient;

    private final BiFunction<EmerchantpayTransactionContext, Throwable, EmerchantpayTransactionContext> defaultExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> executeDirectPaymentRequest(CardAuthorizeContext authContext) {
        EmerchantpayPaymentTransactionContext ctx = new EmerchantpayPaymentTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_DECRYPT_CARD_DETAILS, transactionUtils::decryptCardDetails)
                .safeMap(PHASE_HYDRATE_CONTEXT, decrypted -> hydrateInitialPaymentContext(ctx, authContext, decrypted))
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::requestPaymentTransaction)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private EmerchantpayPaymentTransactionContext hydrateInitialPaymentContext(EmerchantpayPaymentTransactionContext context, CardAuthorizeContext authContext, List<byte[]> decryptedCardData) {
        RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(authContext.authorizeContext().getPaymentProviderAccount(), RuntimeAccountConfig.class);
        context.setRuntimeAccountConfig(rac);
        context.setCardContext(authContext);
        context.setTransactionId(authContext.authorizeContext().getTransaction().getId());
        context.setPaymentRequest(objectTransformer.buildPaymentRequest(authContext, decryptedCardData));
        context.setAuthToken(Utils.buildBasicAuthToken(rac.username(), rac.password()));
        return context;
    }

    private Uni<EmerchantpayTransactionContext> requestPaymentTransaction(EmerchantpayPaymentTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx ->
                        emerchantpayApiClient.requestDirectPayment(
                                context.getPaymentRequest(),
                                context.getRuntimeAccountConfig().terminalToken(),
                                context.getAuthToken()
                        )
                )
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentResponse(context, response))
                .endSubPhase();
    }

    @SneakyThrows
    private EmerchantpayTransactionContext parsePaymentResponse(EmerchantpayTransactionContext ctx, Response response) {
        ctx.setPaymentResponse(response.readEntity(PaymentResponse.class));
        return ctx;
    }

    public Uni<ExecuteTransactionResponse> executeRefundRequest(ManageTransactionContext manageTransactionContext) {
        EmerchantpayRefundTransactionContext ctx = new EmerchantpayRefundTransactionContext();

        return SafeUni.from(manageTransactionContext, defaultExceptionHandler, ctx)
                .safeMap(PHASE_HYDRATE_CONTEXT, manageContext -> buildRefundContext(ctx, manageContext))
                .safeFlatMap(PHASE_REQUEST_REFUND, this::requestRefundTransaction)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private EmerchantpayRefundTransactionContext buildRefundContext(EmerchantpayRefundTransactionContext context, ManageTransactionContext manageTransactionContext) {
        ImmutableTypedTransactionEntity transaction = manageTransactionContext.transaction();
        context.setManageTransactionRequest(manageTransactionContext);
        context.setTransactionId(transaction.getId());
        context.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(manageTransactionContext.paymentProviderAccount(), RuntimeAccountConfig.class));
        context.setAuthToken(Utils.buildBasicAuthToken(context.getRuntimeAccountConfig().username(), context.getRuntimeAccountConfig().password()));
        var remoteIP = transaction.getMetadata().getString("user_ip", manageTransactionContext.transactionTypeContext().getTransaction().getMetadata().getString("customer_ip", transaction.getUserIp()));
        context.setRefundRequest(new RefundRequest(
                "refund",
                transaction.getId(),
                context.getManageTransactionRequest().transactionTypeContext().getParentTransaction().getReferenceNumber(),
                transaction.getDescription(),
                remoteIP,
                transaction.getAmount(),
                transaction.getCurrency()
        ));
        return context;
    }

    private Uni<EmerchantpayTransactionContext> requestRefundTransaction(EmerchantpayRefundTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> emerchantpayApiClient.refund(
                        context.getRefundRequest(),
                        context.getRuntimeAccountConfig().terminalToken(),
                        context.getAuthToken())
                )
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentResponse(context, response))
                .endSubPhase();
    }

}
