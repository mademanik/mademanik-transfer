package com.morefin.pg.emerchantpay.http;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.emerchantpay.manager.FinalizeManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import static com.morefin.pg.emerchantpay.util.Constants.BASE_CALLBACK_URL;
import static com.morefin.pg.emerchantpay.util.Constants.CALLBACK;
import static com.morefin.pg.emerchantpay.util.Constants.CALLBACK_3DS;

@Path(BASE_CALLBACK_URL)
@Produces(MediaType.APPLICATION_XML)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public class EmerchantpayCallbackService {
    @Inject
    Tenant tenant;
    @Inject
    FinalizeManager finalizeManager;

    @POST
    @Path(CALLBACK)
    public Uni<Response> callbackUrl(MultivaluedMap<String, String> callbackRequest) {
        return finalizeManager.finalizeTransaction(callbackRequest, tenant.id());
    }

    @POST
    @Path(CALLBACK_3DS)
    public Uni<Response> frictionlessCallbackUrl(MultivaluedMap<String, String> callbackRequest) {
        return finalizeManager.finalizeFrictionlessTransaction(callbackRequest, tenant.id());
    }
}