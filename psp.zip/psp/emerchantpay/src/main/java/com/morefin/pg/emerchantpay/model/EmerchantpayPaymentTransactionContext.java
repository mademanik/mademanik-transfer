package com.morefin.pg.emerchantpay.model;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@ToString
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmerchantpayPaymentTransactionContext extends EmerchantpayTransactionContext {
    CardAuthorizeContext cardContext;
    PaymentRequest paymentRequest;
}
