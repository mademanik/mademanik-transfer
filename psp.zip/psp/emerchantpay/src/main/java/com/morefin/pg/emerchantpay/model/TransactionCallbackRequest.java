package com.morefin.pg.emerchantpay.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.ws.rs.FormParam;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionCallbackRequest {

    @FormParam("transaction_id")
    String transactionId;
    @FormParam("unique_id")
    String uniqueId;
    @FormParam("terminal_token")
    String terminalToken;
    @FormParam("transaction_type")
    String transactionType;
    @FormParam("status")
    String status;
    @FormParam("threeds_authentication_flow")
    String threedsAuthenticationFlow;
    @FormParam("signature")
    String signature;
    @FormParam("amount")
    int amount;
    @FormParam("threeds_method_status")
    String threedsMethodStatus;
    @FormParam("threeds_target_protocol_version")
    String threedsTargetProtocolVersion;
    @FormParam("threeds_concrete_protocol_version")
    String threedsConcreteProtocolVersion;
    @FormParam("threeds_protocol_sub_version")
    String threedsProtocolSubVersion;
    @FormParam("is_reconcile_needed")
    boolean isReconcileNeeded;
    @FormParam("retry_count")
    int retryCount;


}
