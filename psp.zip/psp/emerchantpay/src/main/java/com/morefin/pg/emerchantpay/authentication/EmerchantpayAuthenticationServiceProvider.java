package com.morefin.pg.emerchantpay.authentication;

import com.morefin.common.authenticationgatewayspi.spi.AuthenticationServiceProvider;
import com.morefin.common.authenticationgatewayspi.spi.BaseAuthenticationService;
import io.quarkus.arc.Arc;

public class EmerchantpayAuthenticationServiceProvider implements AuthenticationServiceProvider {

    @Override
    public BaseAuthenticationService create() {

        try (var instance = Arc.container().instance(EmerchantpayCardAuthenticationService.class)) {
            return instance.get();
        }
    }
}
