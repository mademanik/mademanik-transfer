package com.morefin.pg.emerchantpay.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
        @JsonProperty("username")
        String username,
        @JsonProperty("password")
        String password,
        @JsonProperty("terminal_token")
        String terminalToken
) {
}
