package com.morefin.pg.emerchantpay.util;

public class Constants {
    public static final String BASE_CALLBACK_URL = "/psp/emerchantpay";
    public static final String TYPE_REDIRECT = "pending_async";
    public static final String TYPE_APPROVED = "approved";
    public static final String PHASE_INVOKE_3DS_CONTINUE = "PHASE_INVOKE_3DS_CONTINUE";
    public static final String PHASE_INVOKE_3DS_RECONCILE = "PHASE_INVOKE_3DS_RECONCILE";
    public static final String SIGNATURE = "signature";
    public static final String UNIQUE_ID = "unique_id";
    public static final String CALLBACK = "/callback";
    public static final String CALLBACK_3DS = "/3dsCallback";



}
