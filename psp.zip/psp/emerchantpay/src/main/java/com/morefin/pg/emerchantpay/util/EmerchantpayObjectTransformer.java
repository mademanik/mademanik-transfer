package com.morefin.pg.emerchantpay.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.Struct;
import com.google.protobuf.Value;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.pg.common.TransactionStatusMapper;
import com.morefin.pg.common.TransactionUtils;
import com.morefin.pg.emerchantpay.model.BillingAddress;
import com.morefin.pg.emerchantpay.model.Browser;
import com.morefin.pg.emerchantpay.model.Control;
import com.morefin.pg.emerchantpay.model.EmerchantpayCallbackContext;
import com.morefin.pg.emerchantpay.model.EmerchantpayTransactionContext;
import com.morefin.pg.emerchantpay.model.PaymentRequest;
import com.morefin.pg.emerchantpay.model.PaymentResponse;
import com.morefin.pg.emerchantpay.model.ThreedsMethod;
import com.morefin.pg.emerchantpay.model.ThreedsV2Params;
import com.morefin.pg.emerchantpay.model.TransactionCallbackRequest;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.utils.SignatureUtils;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.tuples.Tuple2;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.morefin.pg.common.Constants.PHASE_DB_GET_DATA;
import static com.morefin.pg.common.Constants.PHASE_DECRYPT_CARD_DETAILS;
import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_READ_PAYLOAD;
import static com.morefin.pg.common.Constants.PHASE_REQUEST_PAYMENT;
import static com.morefin.pg.common.Constants.PHASE_VERIFY_CALLBACK;
import static com.morefin.pg.common.Constants.REASON_API_INVOCATION_FAILURE;
import static com.morefin.pg.common.Constants.REASON_INVALID_CARD_DETAILS;
import static com.morefin.pg.common.Constants.REASON_INVALID_INPUT;
import static com.morefin.pg.common.Constants.REASON_INVALID_SIGNATURE;
import static com.morefin.pg.common.Constants.REASON_PAYLOAD_VALIDATION_FAILURE;
import static com.morefin.pg.common.Constants.REASON_PSP_CONFIGURATION_ERROR;
import static com.morefin.pg.common.Constants.REASON_PSP_DECLINE_BLACKLISTED;
import static com.morefin.pg.common.Constants.REASON_PSP_DECLINE_DUE_RISK;
import static com.morefin.pg.common.Constants.REASON_PSP_PROCESSING_ERROR;
import static com.morefin.pg.common.Constants.REASON_PSP_REQUEST_LIMIT_ERROR;
import static com.morefin.pg.common.Constants.REASON_REQUESTED;
import static com.morefin.pg.common.Constants.REASON_SUCCESS;
import static com.morefin.pg.common.Constants.REASON_TIMEOUT;
import static com.morefin.pg.common.Constants.REASON_TRANSACTION_DECLINED;
import static com.morefin.pg.common.Constants.REASON_TRANSACTION_DECLINED_INSUFFICIENT_FUNDS;
import static com.morefin.pg.common.Constants.REASON_UNAUTHORIZED;
import static com.morefin.pg.common.Constants.REASON_UNKNOWN_API_ERROR;
import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;
import static com.morefin.pg.emerchantpay.util.Constants.BASE_CALLBACK_URL;
import static com.morefin.pg.emerchantpay.util.Constants.CALLBACK;
import static com.morefin.pg.emerchantpay.util.Constants.CALLBACK_3DS;
import static com.morefin.pg.emerchantpay.util.Constants.PHASE_INVOKE_3DS_CONTINUE;
import static com.morefin.pg.emerchantpay.util.Constants.PHASE_INVOKE_3DS_RECONCILE;
import static com.morefin.pg.emerchantpay.util.Constants.SIGNATURE;
import static com.morefin.pg.emerchantpay.util.Constants.TYPE_APPROVED;
import static com.morefin.pg.emerchantpay.util.Constants.TYPE_REDIRECT;
import static com.morefin.pg.emerchantpay.util.Constants.UNIQUE_ID;

@ApplicationScoped
public class EmerchantpayObjectTransformer {

    @Inject
    TransactionUtils transactionUtils;
    @Inject
    ObjectMapper objectMapper;

    public ErrorDescription<?> handle3dsContinueException(EmerchantpayCallbackContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during processing of transaction {0} with message {1} during phase {2} and sub-phase {3}",
                context.getTransactionId(), failure, context.getPhase(), context.getSubPhase());
        return switch (context.getSubPhase()) {
            case PHASE_INVOKE_3DS_CONTINUE, PHASE_INVOKE_3DS_RECONCILE:
                reason = transactionUtils.getApiFailureReason(failure);
                yield handle3dsContinueInvocationFailure(failure, reason);
            case PHASE_READ_PAYLOAD:
                reason = transactionUtils.getDeserializationFailureReason(failure);
                yield buildInternalErrorResponse(reason, failure);
            default:
                reason = transactionUtils.getContextPreparationFailureReason(failure);
                yield transactionUtils.buildInternalErrorCallbackResponse(reason, failure);
        };
    }

    public ErrorDescription<?> buildFinalizeErrorDescription(EmerchantpayCallbackContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during processing of transaction {0} with message {1} during phase {2} and sub-phase {3} ",
                context.getTransactionId(), failure, context.getPhase(), context.getSubPhase());
        return switch (context.getPhase()) {
            case PHASE_HYDRATE_CONTEXT:
                yield switch (context.getSubPhase()) {
                    case PHASE_HYDRATE_CONTEXT:
                        reason = transactionUtils.getContextPreparationFailureReason(failure);
                        yield transactionUtils.buildUnexpectedCallbackFormatError(stringifyFormParams(context.getCallbackRequestAsMap()), reason);
                    case PHASE_DB_GET_DATA:
                        reason = transactionUtils.getDeserializationFailureReason(failure);
                        Log.errorv("Exception during obtaining the PPA data from DB for transaction {0} with failure. {1}", context.getCallbackRequest().getTransactionId(), failure.getMessage());
                        yield transactionUtils.handleDbOperationFailure(stringifyFormParams(context.getCallbackRequestAsMap()), context.getCallbackRequest().getTransactionId(), reason, failure);
                    default:
                        reason = transactionUtils.getContextPreparationFailureReason(failure);
                        yield transactionUtils.buildInternalErrorCallbackResponse(reason, failure);
                };
            case PHASE_VERIFY_CALLBACK: {
                if (failure instanceof SecurityException) {
                    yield transactionUtils.buildBadRequestCallbackResponse(REASON_INVALID_SIGNATURE, failure);
                } else {
                    yield transactionUtils.buildInternalErrorCallbackResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
                }
            }
            // This case also covers the logic for building an error response in the following phases PHASE_BUILD_FINALIZE_REQUEST,PHASE_GRPC_INVOKE:
            default:
                yield transactionUtils.buildInternalErrorCallbackResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
        };
    }

    public PaymentRequest buildPaymentRequest(CardAuthorizeContext cardContext, List<byte[]> decryptedData) {
        var transaction = cardContext.authorizeContext().getTransaction();
        var remoteIP = transaction.getMetadata().getString("user_ip", transaction.getMetadata().getString("customer_ip", transaction.getUserIp()));
        var browserInfoNode = objectMapper.convertValue(cardContext.authorizeContext().getTransaction().getTransactionData().getOptions().get("browser_info"), JsonNode.class);
        String notificationUrl = cardContext.authorizeContext().getTenantConfig().url() + BASE_CALLBACK_URL + CALLBACK;
        String callbackUrl = cardContext.authorizeContext().getTenantConfig().url() + BASE_CALLBACK_URL + CALLBACK_3DS;
        return PaymentRequest.builder()
                .transactionType("sale3d")
                .transactionId(transaction.getId())
                .usage(transaction.getDescription())
                //TODO get the user remote IP
                .remoteIp(remoteIP)
                .amount(transaction.getAmount())
                .currency(transaction.getCurrency())
                .cardHolder(transaction.getCustomerFirstName() + " " + transaction.getCustomerLastName())
                .cardNumber(new String(decryptedData.get(0), StandardCharsets.UTF_8))
                .cvv(new String(decryptedData.get(1), StandardCharsets.UTF_8))
                .expirationMonth(cardContext.card().expirationMonth())
                .expirationYear(cardContext.card().expirationYear())
                .customerEmail(transaction.getCustomerEmail())
                .customerPhone(transaction.getCustomerPhoneNumber())
                .notificationUrl(notificationUrl)
                .returnSuccessUrl(cardContext.authorizeContext().getTransaction().getTransactionData().getSuccessUrl())
                .returnFailureUrl(cardContext.authorizeContext().getTransaction().getTransactionData().getErrorUrl())
                .billingAddress(BillingAddress.builder()
                        .firstName(transaction.getCustomerFirstName())
                        .lastName(transaction.getCustomerLastName())
                        .address1(transaction.getCustomerAddress())
                        .zipCode(transaction.getCustomerPostalCode())
                        .city(transaction.getCustomerCity())
                        .country(transaction.getCustomerCountry())
                        .build())
                .threedsV2Params(ThreedsV2Params.builder()
                        .threedsMethod(new ThreedsMethod(callbackUrl))
                        .control(Control.builder()
                                .deviceType("browser")
                                .challengeIndicator("preference")
                                .challengeWindowSize("full_screen")
                                .build())
                        .browser(Browser.builder()
                                .acceptHeader(browserInfoNode.get("accept_header").asText())
                                .javaEnabled(browserInfoNode.get("java_enabled").asText())
                                .language(browserInfoNode.get("language").asText())
                                .colorDepth(Math.max(browserInfoNode.get("color_depth").asInt(), 15))
                                .screenHeight(browserInfoNode.get("screen_height").asInt())
                                .screenWidth(browserInfoNode.get("screen_width").asInt())
                                .timeZoneOffset(browserInfoNode.get("time_zone_offset").asInt())
                                .userAgent(browserInfoNode.get("user_agent").asText())
                                .build())
                        .build())
                .build();
    }

    public ExecuteTransactionResponse convertToCardResponse(EmerchantpayTransactionContext context) {
        if (context.getErrorDescription() != null) {
            return buildErrorTransactionResponse(context);
        } else if (context.getPaymentResponse().getStatus().equals(TYPE_REDIRECT)) {
            return buildPendingTransactionResponse(context);
        } else if (context.getPaymentResponse().getStatus().equals(TYPE_APPROVED)) {
            context.getPaymentResponse().setCode(0);
        }
        return buildTransactionResponse(context);
    }

    public ErrorDescription<PaymentResponse> buildErrorDescription(EmerchantpayTransactionContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during processing of transaction {0} with message {1} ",
                context.getTransactionId(), failure);
        return switch (context.getPhase()) {
            case PHASE_DECRYPT_CARD_DETAILS, PHASE_HYDRATE_CONTEXT:
                reason = transactionUtils.getContextPreparationFailureReason(failure);
                yield buildInternalErrorResponse(reason, failure);
            case PHASE_REQUEST_PAYMENT:
                yield switch (context.getSubPhase()) {
                    case PHASE_PSP_INVOKE:
                        reason = transactionUtils.getApiFailureReason(failure);
                        yield handlePaymentRequestFailure(reason, failure);
                    case PHASE_READ_PAYLOAD:
                        reason = transactionUtils.getDeserializationFailureReason(failure);
                        yield buildInternalErrorResponse(reason, failure);
                    default:
                        yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
                };
            default:
                yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
        };
    }

    public EmerchantpayCallbackContext buildFinalizeTransactionRequest(EmerchantpayCallbackContext context) {
        if (context.isStatusTerminal()) {
            if (context.isFrictionlessCallback()) {
                context.setFinalizeRequest(FinalizeTransactionRequest
                        .newBuilder()
                        .setPaymentProviderResponseCode(context.getPaymentResponse().getStatus())
                        .setReferenceNumber(context.getPaymentResponse().getUniqueId())
                        .setResponseMessage(context.getPaymentResponse().getMessage())
                        .setPaymentProviderResponseMessage(context.getPaymentResponse().getTechnicalMessage())
                        .setStatus(context.getTransactionStatus())
                        .setId(context.getPaymentResponse().getTransactionId())
                        .build());
            } else {
                context.setFinalizeRequest(FinalizeTransactionRequest
                        .newBuilder()
                        .setPaymentProviderResponseCode(context.getCallbackRequest().getStatus())
                        .setReferenceNumber(context.getCallbackRequest().getUniqueId())
                        .setResponseMessage(context.getCallbackRequest().getThreedsAuthenticationFlow())
                        .setPaymentProviderResponseMessage(stringifyFormParams(context.getCallbackRequestAsMap()))
                        .setStatus(context.getTransactionStatus())
                        .setId(context.getCallbackRequest().getTransactionId())
                        .build());
            }
        }
        return context;
    }

    public Uni<Response> handleAlreadyStarted3dsContinue(EmerchantpayCallbackContext ctx, Throwable failure) {
        WebApplicationException wae = (WebApplicationException) failure;
        Response httpResponse = wae.getResponse();

        if (httpResponse.getStatus() == HttpStatus.SC_CONFLICT) {
            // 409 - Already invoked, continue with reconcile
            PaymentResponse resp = httpResponse.readEntity(PaymentResponse.class);
            Log.errorv("3DS continue method is already invoked, proceeding with reconcile operation.");
            ctx.setPaymentResponse(resp);
            ctx.setReconcileNeeded(true);

            return Uni.createFrom().item(Response.ok().entity(resp).build());
        } else if (httpResponse.getStatus() == HttpStatus.SC_UNPROCESSABLE_ENTITY) {
            // 422 - Method not required, create dummy response
            Log.errorv("3DS method is not required, continue with the flow.");
            ctx.setPaymentResponse(PaymentResponse.builder().status("in_progress").build());
            ctx.setReconcileNeeded(false);

            return Uni.createFrom().nullItem();
        }

        // for any other failure: rethrow (will be caught later in the pipeline)
        return Uni.createFrom().failure(failure);
    }

    private ErrorDescription<?> handle3dsContinueInvocationFailure(Throwable failure, String reason) {
        PaymentResponse resp = null;
        String pspMessage;
        String respMessage = "Reason:%s Error Message: %s".formatted(reason, failure.getMessage());
        if (reason.equalsIgnoreCase(REASON_INVALID_INPUT)) {
            if (failure.getClass().isInstance(WebApplicationException.class)) {
                Response httpResponse = ((WebApplicationException) failure).getResponse();
                pspMessage = httpResponse.readEntity(String.class);
            } else {
                pspMessage = failure.getMessage();
            }
        } else {
            pspMessage = failure.getMessage();
        }
        return ErrorDescription.<PaymentResponse>builder()
                .reason(reason)
                .responseMessage(respMessage)
                .errorResponse(resp)
                .paymentProviderResponseCode(reason)
                .paymentProviderResponseMessage(pspMessage)
                .build();
    }

    private ErrorDescription<PaymentResponse> handlePaymentRequestFailure(String reason, Throwable failure) {
        PaymentResponse resp = null;
        Tuple2<String, String> pspErrorInfo = switch (reason) {
            case REASON_TIMEOUT, REASON_UNAUTHORIZED ->
                    Tuple2.of(reason, "Error Message: %s".formatted(failure.getMessage()));
            case REASON_API_INVOCATION_FAILURE -> {
                resp = ((WebApplicationException) failure).getResponse().readEntity(PaymentResponse.class);
                yield Tuple2.of(REASON_API_INVOCATION_FAILURE, resp.getMessage());
            }
            case REASON_INVALID_INPUT -> {
                resp = ((WebApplicationException) failure).getResponse().readEntity(PaymentResponse.class);
                //Handle declined transaction in case populated field status
                yield Tuple2.of(REASON_TRANSACTION_DECLINED, formatErrors(resp));
            }
            default -> Tuple2.of(REASON_UNKNOWN_API_ERROR, failure.getMessage());
        };

        String respMessage = "Reason:%s Message:%s".formatted(reason, failure.getMessage());

        return ErrorDescription.<PaymentResponse>builder()
                .reason(pspErrorInfo.getItem1())
                .responseMessage(respMessage)
                .errorResponse(resp)
                .paymentProviderResponseCode(pspErrorInfo.getItem1())
                .paymentProviderResponseMessage(pspErrorInfo.getItem2())
                .build();
    }

    private TransactionStatus parseFinalizeType(String status, String transactionId, String uniqueId) {
        return switch (status) {
            case "pending", "pending_async", "pending_hold", "pending_review", "in_progress" ->
                    TransactionStatus.PENDING;
            case "cancelled" -> TransactionStatus.CANCELED;
            case "declined", "error" -> TransactionStatus.DECLINED;
            case "approved", "refunded", "chargebacked", "voided", "chargeback_reversed", "second_chargebacked",
                 "representment_reversed", "represented" -> TransactionStatus.APPROVED;
            case "timeout" -> TransactionStatus.SESSION_EXPIRED;
            default -> {
                Log.errorv("Received unexpected event type {0} for transaction with id {1} and psp id {2}", status, transactionId, uniqueId);

                yield TransactionStatus.INVALID;
            }
        };
    }

    public TransactionStatus parseFinalizeType(TransactionCallbackRequest callbackDto) {
        return parseFinalizeType(callbackDto.getStatus(), callbackDto.getTransactionId(), callbackDto.getUniqueId());
    }


    public TransactionStatus parseFinalizeType(PaymentResponse paymentResponse) {
        return parseFinalizeType(paymentResponse.getStatus(), paymentResponse.getTransactionId(), paymentResponse.getUniqueId());

    }

    private ErrorDescription<PaymentResponse> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<PaymentResponse>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    private String formatErrors(PaymentResponse resp) {
        return "Status: %s Code: %s Technical Message: %s".formatted(resp.getStatus(), resp.getCode(), resp.getTechnicalMessage());
    }

    private ExecuteTransactionResponse buildTransactionResponse(EmerchantpayTransactionContext context) {
        String errorReason = getTransactionErrorReason(context.getPaymentResponse());
        TransactionStatusMapper responseMapping = TransactionStatusMapper.fromValue(errorReason);
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        var respBody = context.getPaymentResponse();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(builder)
                        .set(responseMapping.getResponseCode().name(), builder::setResponseCode)
                        .set(StringUtils.abbreviate(context.getPaymentResponse().getMessage(), 49), builder::setResponseMessage)
                        .setAny(context.getPaymentResponse().getTechnicalMessage(), builder::setPaymentProviderResponseMessage)
                        .setAny(context.getPaymentResponse().getCode().toString(), builder::setPaymentProviderResponseCode)
                        .setAndMap(JsonObject.mapFrom(respBody != null ? respBody : Map.of()).getMap(), GrpcFactory::fromMap, builder::setData)
                        .set(context.getPaymentResponse().getStatus(), builder::setPaymentProviderStatus)
                        .setAny(responseMapping.getTransactionStatus(), builder::setStatus)
                        .set(context.getPaymentResponse().getUniqueId(), builder::setReferenceNumber)
                        .getBuilder().build())
                .build();
    }

    private ExecuteTransactionResponse buildErrorTransactionResponse(EmerchantpayTransactionContext context) {
        String errorReason = getTransactionErrorReason(context.getPaymentResponse());
        TransactionStatusMapper responseMapping = TransactionStatusMapper.fromValue(errorReason);
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        var respBody = context.getErrorDescription().getErrorResponse();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(builder)
                        .set(responseMapping.getResponseCode().name(), builder::setResponseCode)
                        .set(StringUtils.abbreviate(context.getErrorDescription().getResponseMessage(),50), builder::setResponseMessage)
                        .setAny(context.getErrorDescription().getPaymentProviderResponseMessage(), builder::setPaymentProviderResponseMessage)
                        .setAny(context.getErrorDescription().getPaymentProviderResponseCode(), builder::setPaymentProviderResponseCode)
                        .setAndMap(JsonObject.mapFrom(respBody != null ? respBody : Map.of()).getMap(), GrpcFactory::fromMap, builder::setData)
                        .set(context.getErrorDescription().getReason(), builder::setPaymentProviderStatus)
                        .setAny(responseMapping.getTransactionStatus(), builder::setStatus)
                        .getBuilder().build())
                .build();
    }

    private String getTransactionErrorReason(PaymentResponse response) {
        var responseCode = ((response != null && response.getCode() != null) ? response.getCode() : -1);
        return switch (responseCode) {
            case 0 -> REASON_SUCCESS;
            case 110 -> REASON_UNAUTHORIZED;
            case 120, 803 -> REASON_PSP_CONFIGURATION_ERROR;
            //Input Data Errors
            case 300, 310, 320, 330, 340, 350, 360 -> REASON_PAYLOAD_VALIDATION_FAILURE;
            //Workflow Errors
            case 400, 410, 420, 430, 440, 450, 460, 470, 480, 490, 609, 690, 750, 751 -> REASON_INVALID_INPUT;
            //Processing Errors
            //  Invalid Card Details
            case 510, 520 -> REASON_INVALID_CARD_DETAILS;
            //  Declined by Issuer
            case 500, 501, 511, 530, 540, 550, 551 -> REASON_TRANSACTION_DECLINED;
            //Risk Errors
            case 600, 629, 695, 800, 801, 802, 804, 805, 806 -> REASON_PSP_DECLINE_DUE_RISK;
            //Communication Errors
            case 610, 611, 612, 613, 614, 615, 693, 692, 694, 696 -> REASON_PSP_DECLINE_BLACKLISTED;
            case 620, 621, 622, 623, 624, 625, 626, 627 -> REASON_PSP_REQUEST_LIMIT_ERROR;
            case 628 -> REASON_TRANSACTION_DECLINED_INSUFFICIENT_FUNDS;
            case 630 -> REASON_REQUESTED;
            case 100, 101, 200, 210, 220, 230, 240, 250, 700, 701, 702, 703, 720, 730, 731, 732, 740, 741, 742, 743,
                 744, 900, 910, 920, 930, 940, 950 -> REASON_PSP_PROCESSING_ERROR;
            default -> REASON_UNKNOWN_API_ERROR;
        };
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(EmerchantpayTransactionContext context) {
        if (!StringUtils.isBlank(context.getPaymentResponse().getRedirectUrl())) {
            return buildRedirectResponse(context.getPaymentResponse());
        } else {
            return buildFormSubmitResponse(context);
        }
    }

    private static ExecuteTransactionResponse buildFormSubmitResponse(EmerchantpayTransactionContext context) {
        Map<String, String> params = new HashMap<>();
        String signature = SignatureUtils.encryptWithSha512(
                "%s%s%s%s".formatted(
                        context.getPaymentResponse().getUniqueId(),
                        context.getPaymentResponse().getAmount(),
                        context.getPaymentResponse().getTimestamp(),
                        context.getRuntimeAccountConfig().password())
        );
        params.put(UNIQUE_ID, context.getPaymentResponse().getUniqueId());
        params.put(SIGNATURE, signature);

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(ExecuteTransactionResponse.Response.newBuilder()
                        .setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name())
                        .setReferenceNumber(context.getPaymentResponse().getUniqueId())
                        .setData(Struct.newBuilder()
                                .putFields(SIGNATURE, Value.newBuilder().setStringValue(signature).build())
                                .build()).build())
                .setFormSubmit(ExecuteTransactionResponse.FormSubmit.newBuilder()
                        .setUrl(context.getPaymentResponse().getThreedsMethodUrl())
                        .putAllData(params).build()).build();
    }

    private ExecuteTransactionResponse buildRedirectResponse(PaymentResponse paymentResponse) {
        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(ExecuteTransactionResponse.Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name())
                        .setReferenceNumber(paymentResponse.getUniqueId()).build())
                .setRedirect(
                        new GrpcBuilder<>(builder)
                                .set(paymentResponse.getRedirectUrl(), builder::setUrl)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    public String stringifyFormParams(MultivaluedMap<String, String> multiMap) {
        return multiMap.entrySet().stream()
                .map(e -> e.getValue().stream()
                        .map(v -> encode(e.getKey()) + "=" + encode(v))
                        .reduce((a, b) -> a + "&" + b)
                        .orElse(encode(e.getKey()) + "="))
                .reduce((a, b) -> a + "&" + b)
                .orElse("");
    }

    private static String encode(String value) {
        return URLEncoder.encode(value != null ? value : "", StandardCharsets.UTF_8);
    }
}
