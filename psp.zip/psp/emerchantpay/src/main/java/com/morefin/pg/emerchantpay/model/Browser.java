package com.morefin.pg.emerchantpay.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Browser {
    @XmlElement(name = "accept_header")
    String acceptHeader;
    @XmlElement(name = "java_enabled")
    String javaEnabled;
    @XmlElement(name = "language")
    String language;
    @XmlElement(name = "color_depth")
    Integer colorDepth;
    @XmlElement(name = "screen_height")
    Integer screenHeight;
    @XmlElement(name = "screen_width")
    Integer screenWidth;
    @XmlElement(name = "time_zone_offset")
    Integer timeZoneOffset;
    @XmlElement(name = "user_agent")
    String userAgent;
}
