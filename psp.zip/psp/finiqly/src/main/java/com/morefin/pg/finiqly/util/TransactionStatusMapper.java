package com.morefin.pg.finiqly.util;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;

public class TransactionStatusMapper {
    public static ExecuteTransactionResponse.Status parseTransactionStatus(FiniqlyTransactionStatus transactionStatus) {
        return switch (transactionStatus) {
            case COMPLETED -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING, CHECKOUT, AUTHORIZED -> ExecuteTransactionResponse.Status.PENDING;
            case DECLINED, CANCELLED -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }
}