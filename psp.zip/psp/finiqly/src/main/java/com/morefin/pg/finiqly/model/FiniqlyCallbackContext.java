package com.morefin.pg.finiqly.model;

import com.morefin.common.grpc.transaction.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionEntity;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.finiqly.common.RuntimeAccountConfig;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FiniqlyCallbackContext extends BaseTransactionContext<String> {

    RuntimeAccountConfig runtimeAccountConfig;

    Boolean isWebhook = false;
    String tenantId;
    String referenceNumber;
    String signature;
    String transactionId;
    MultivaluedMap<String, String> callbackRequestAsMap;
    String callbackRequestAsString;
    PaymentResult webhookRequest;

    TypedTransactionEntity transactionEntity;
    TransactionGrpc transactionGrpc;

    PaymentTransactionResponse paymentTransactionResponse;
    String paymentTransactionResponseAsString;

    FinalizeTransactionRequest finalizeRequest;
    ExecuteTransactionResponse finalizeResponse;

    public FiniqlyCallbackContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}