package com.morefin.pg.finiqly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentResult implements Serializable {
    @JsonProperty("id")
    private String id;

    @JsonProperty("referenceId")
    private String referenceId;

    @JsonProperty("created")
    private String created;

    @JsonProperty("paymentType")
    private String paymentType;

    @JsonProperty("state")
    private String state;

    @JsonProperty("description")
    private String description;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    @JsonProperty("paymentMethodDetails")
    private PaymentMethodDetailResponse paymentMethodDetails;

    @JsonProperty("amount")
    private Double amount;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("redirectUrl")
    private String redirectUrl;

    @JsonProperty("customer")
    private Customer customer;

    @JsonProperty("billingAddress")
    private BillingAddress billingAddress;

    @JsonProperty("shopName")
    private String shopName;

    @JsonProperty("additionalParameters")
    private Map<String, String> additionalParameters;

    @JsonProperty("errorCode")
    private String errorCode;

    @JsonProperty("errorMessage")
    private String errorMessage;
}
