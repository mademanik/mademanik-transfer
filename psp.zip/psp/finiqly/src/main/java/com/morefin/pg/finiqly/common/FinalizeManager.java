package com.morefin.pg.finiqly.common;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.gatewaygrpcservices.payments.paymentgateway.services.paymentprovider.PaymentProviderRepository;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.transaction.resourceactions.TransactionRepository;
import com.morefin.pg.finiqly.client.FiniqlyApiClient;
import com.morefin.pg.finiqly.model.*;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.finiqly.util.FiniqlyObjectTransformer;
import com.morefin.pg.finiqly.util.FiniqlyTransactionStatus;
import com.morefin.pg.finiqly.util.TransactionStatusMapper;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;

@ApplicationScoped
public class FinalizeManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    FiniqlyObjectTransformer objectTransformer;

    @Inject
    TransactionRepository transactionRepository;

    @Inject
    PaymentProviderRepository paymentProviderRepository;

    @Inject
    DtoMapperService mapperService;

    @Inject
    @RestClient
    FiniqlyApiClient apiClient;

    BiFunction<FiniqlyCallbackContext, Throwable, FiniqlyCallbackContext> defaultFinalizeExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(context, failure));
        return context;
    };

    public Uni<Response> finalizeTransaction(String transactionId, String tenantId) {
        FiniqlyCallbackContext ctx = new FiniqlyCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateCallbackContext(ctx1, transactionId, tenantId))
                .safeFlatMap(PHASE_VERIFY_CALLBACK, this::getPaymentResponse)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinalRedirectResponse);
    }

    public Uni<Response> finalizeWebhookTransaction(String signature, String callbackRequest, String tenantId) {
        FiniqlyCallbackContext ctx = new FiniqlyCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateWebhookContext(ctx1, signature, callbackRequest, tenantId))
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifySignature)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinalResponse);
    }

    private Uni<FiniqlyCallbackContext> hydrateWebhookContext(FiniqlyCallbackContext ctx, String signature, String callbackRequestAsString, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseWebhookRequest(ctx, signature, callbackRequestAsString, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    private Uni<FiniqlyCallbackContext> hydrateCallbackContext(FiniqlyCallbackContext ctx, String transactionId, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseCallbackRequest(ctx, transactionId, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    private FiniqlyCallbackContext parseCallbackRequest(FiniqlyCallbackContext ctx, String transactionId, String tenantId) {
        //Additional step to preserve the request payload for future logging
        ctx.setTenantId(tenantId);
        ctx.setTransactionId(transactionId);

        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    @SneakyThrows
    private FiniqlyCallbackContext parseWebhookRequest(FiniqlyCallbackContext ctx, String signature, String callbackRequestAsString, String tenantId) {
        //Additional step to preserve the request payload for future logging
        ctx.setIsWebhook(true);
        ctx.setTenantId(tenantId);
        ctx.setSignature(signature);
        ctx.setCallbackRequestAsString(callbackRequestAsString);
        ctx.setWebhookRequest(mapperService.mapAndValidate(ctx.getCallbackRequestAsString(), PaymentResult.class));
        ctx.setReferenceNumber(ctx.getWebhookRequest().getId());
        ctx.setTransactionId(ctx.getWebhookRequest().getReferenceId());

        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    private Uni<FiniqlyCallbackContext> getTransactionData(FiniqlyCallbackContext ctx) {
        return transactionRepository.withTransaction(connection -> {
            return transactionRepository.findById(ctx.getTransactionId(), ctx.getTenantId())
                    .map(optionalTransaction -> optionalTransaction
                            .map(transaction -> {
                                ctx.setTransactionEntity(transaction);
                                ctx.setReferenceNumber(transaction.getReferenceNumber());
                                return ctx;
                            })
                            .orElseThrow(() -> new IllegalStateException("Transaction not found")));
        });
    }

    private Uni<FiniqlyCallbackContext> getPaymentProviderAccountDataByPpaId(FiniqlyCallbackContext ctx) {
        return paymentProviderRepository.findAccountBy(ctx.getTenantId(), ctx.getTransactionEntity().getPaymentProviderAccountId())
                .map(optionalAccount -> optionalAccount
                        .map(ppa -> {
                            ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, RuntimeAccountConfig.class));
                            return ctx;
                        })
                        .orElseThrow(() -> new IllegalStateException("PaymentProviderAccount not found")));
    }

    private FiniqlyCallbackContext verifySignature(FiniqlyCallbackContext ctx) {
        RuntimeAccountConfig rac = ctx.getRuntimeAccountConfig();
        Boolean correctSignature = false;
        byte[] signingKey = rac.signingKey().getBytes(StandardCharsets.UTF_8);
        byte[] payload = ctx.getCallbackRequestAsString().getBytes(StandardCharsets.UTF_8);

        try {
            Mac mac = Mac.getInstance("HmacSHA256");

            SecretKeySpec secretKeySpec = new SecretKeySpec(signingKey, "HmacSHA256");

            mac.init(secretKeySpec);

            mac.doFinal(payload);

            correctSignature = true;

        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            e.printStackTrace();
            throw new BadRequestException("Wrong configuration");
        }
        if ( !correctSignature ) {
            throw new BadRequestException("Wrong signature");
        }
        return ctx;
    }

    private Response buildFinalRedirectResponse(FiniqlyCallbackContext ctx) {
        PaymentResult result = ctx.getPaymentTransactionResponse().getResult();
        FiniqlyTransactionStatus transactionStatus = FiniqlyTransactionStatus.valueOf(result.getState());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        switch (status) {
            case APPROVED, PENDING -> {
                URI locationUri = URI.create(ctx.getTransactionEntity().getTransactionData().getSuccessUrl());
                return Response.seeOther(locationUri).build();
            }
            default -> {
                URI locationUri;
                if ( transactionStatus.equals(FiniqlyTransactionStatus.CANCELLED) ) {
                    locationUri = URI.create(ctx.getTransactionEntity().getTransactionData().getCancelUrl());
                } else {
                    locationUri = URI.create(ctx.getTransactionEntity().getTransactionData().getErrorUrl());
                }
                 ;
                return Response.seeOther(locationUri).build();
            }
        }
    }

    private Response buildFinalResponse(FiniqlyCallbackContext ctx) {
        if ( ctx.getErrorDescription() != null ) {
            return Response.status((Response.Status) ctx.getErrorDescription().getErrorResponse())
                    .entity(Map.of("error", ctx.getErrorDescription().getResponseMessage())).build();
        }
        return Response.status(Response.Status.OK).build();
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }

    private Uni<FiniqlyCallbackContext> sendGrpcFinalizeRequest(FiniqlyCallbackContext ctx) {
        return ctx.getTransactionGrpc().
                finalizeTransaction(ctx.getFinalizeRequest())
                .map(response -> {
                    ctx.setFinalizeResponse(response);
                    return ctx;
                });
    }

    private Uni<FiniqlyCallbackContext> getPaymentResponse(FiniqlyCallbackContext context) {
        return SafeUni.from(context, defaultFinalizeExceptionHandler, context)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> apiClient.getPayment(context.getReferenceNumber(), addBearer(context.getRuntimeAccountConfig().apiKey())))
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentResponse(context, response))
                .endSubPhase();
    }

    private String addBearer(String token) {
        return "Bearer " + token;
    }

    @SneakyThrows
    private FiniqlyCallbackContext parsePaymentResponse(FiniqlyCallbackContext context, Response response) {
        context.setPaymentTransactionResponseAsString(response.readEntity(String.class));
        context.setPaymentTransactionResponse(mapperService.mapAndValidate(context.getPaymentTransactionResponseAsString(), PaymentTransactionResponse.class));

        return context;
    }

}
