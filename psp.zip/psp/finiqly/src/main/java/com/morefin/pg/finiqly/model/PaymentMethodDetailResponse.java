package com.morefin.pg.finiqly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentMethodDetailResponse implements Serializable {
    @JsonProperty("customerAccountNumber")
    private String customerAccountNumber;

    @JsonProperty("cardholderName")
    private String cardholderName;

    @JsonProperty("cardExpiryMonth")
    private String cardExpiryMonth;

    @JsonProperty("cardExpiryYear")
    private String cardExpiryYear;

    @JsonProperty("cardBrand")
    private String cardBrand;

    @JsonProperty("cardIssuingCountryCode")
    private String cardIssuingCountryCode;

    @JsonProperty("cardToken")
    private String cardToken;
}
