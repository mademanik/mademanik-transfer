package com.morefin.pg.finiqly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RefundPaymentResponse implements Serializable {
    @JsonProperty("type")
    private String type;

    @JsonProperty("id")
    private String id;

    @JsonProperty("created_on")
    private long createdOn;

    @JsonProperty("updated_on")
    private long updatedOn;

    @JsonProperty("client")
    private ClientDetail client;

    @JsonProperty("payment")
    private PaymentResponse payment;

    @JsonProperty("transaction_data")
    private Map<String, Object> transactionData;

    @JsonProperty("related_to")
    private RelatedTo relatedTo;

    @JsonProperty("reference_generated")
    private String referenceGenerated;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("account_id")
    private String accountId;

    @JsonProperty("company_id")
    private String companyId;

    @JsonProperty("is_test")
    private boolean isTest;

    @JsonProperty("user_id")
    private String userId;

    @JsonProperty("brand_id")
    private String brandId;

    public static class RelatedTo {
        @JsonProperty("type")
        private String type;

        @JsonProperty("id")
        private String id;

        @JsonProperty("reference")
        private String reference;
    }
}
