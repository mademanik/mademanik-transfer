package com.morefin.pg.finiqly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RegisterPaymentRequest {
    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("card")
    private Card card;

    @JsonProperty("customer")
    private Customer customer;

    @JsonProperty("returnUrl")
    private String returnUrl;

    @JsonProperty("webhookUrl")
    private String webhookUrl;

    @JsonProperty("description")
    private String description;

    @JsonProperty("paymentType")
    private String paymentType;

    @JsonProperty("referenceId")
    private String referenceId;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    @JsonProperty("billingAddress")
    private BillingAddress billingAddress;

    @JsonProperty("additionalParameters")
    private Map<String, String> additionalParameters;

    @JsonProperty("parentPaymentId")
    private String parentPaymentId;
}
