package com.morefin.pg.finiqly.model;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.finiqly.common.RuntimeAccountConfig;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FiniqlyTransactionContext extends BaseTransactionContext<String> {

    TransactionTypeContext transactionContext;
    ImmutableTypedTransactionEntity transaction;
    RuntimeAccountConfig runtimeAccountConfig;
    Boolean isHpp = false;

    Customer customerData;
    BillingAddress billingAddress;
    String transactionType;
    Long amount;
    String currency;
    String cardNumber;
    String cvc;
    Integer expirationMonth;
    Integer expirationYear;
    String statementDescriptor;
    String description;
    String reference;
    String userIp;
    String successUrl;
    String cancelUrl;
    String failureUrl;

    BrowserInfo browserInfo;

    PaymentTransactionResponse paymentTransactionResponse;
    String paymentTransactionResponseAsString;

    public FiniqlyTransactionContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}