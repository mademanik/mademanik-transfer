package com.morefin.pg.finiqly.client;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

@ApplicationScoped
public class FiniqlyApiClientImpl {

    @Produces
    FiniqlyApiClient apiClient() {
        return RestClientBuilder.newBuilder()
                .build(FiniqlyApiClient.class);
    }
}
