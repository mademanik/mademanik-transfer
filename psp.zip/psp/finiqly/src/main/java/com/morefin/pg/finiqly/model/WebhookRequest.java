package com.morefin.pg.finiqly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WebhookRequest implements Serializable {
    @JsonProperty("id")
    private String id;

    @JsonProperty("due")
    private Long due;

    @JsonProperty("type")
    private String type;

    @JsonProperty("client")
    private ClientDetail client;

    @JsonProperty("issued")
    private String issued;

    @JsonProperty("status")
    private String status;

    @JsonProperty("is_test")
    private Boolean isTest;

    @JsonProperty("payment")
    private PaymentResponse payment;

    @JsonProperty("product")
    private String product;

    @JsonProperty("user_id")
    private String userId;

    @JsonProperty("brand_id")
    private String brandId;

    @JsonProperty("order_id")
    private String orderId;

    @JsonProperty("platform")
    private String platform;

    @JsonProperty("purchase")
    private PurchaseDetail purchase;

    @JsonProperty("client_id")
    private String clientId;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("viewed_on")
    private Long viewedOn;

    @JsonProperty("company_id")
    private String companyId;

    @JsonProperty("created_on")
    private Long createdOn;

    @JsonProperty("event_type")
    private String eventType;

    @JsonProperty("updated_on")
    private Long updatedOn;

    @JsonProperty("invoice_url")
    private String invoiceUrl;

    @JsonProperty("can_retrieve")
    private Boolean canRetrieve;

    @JsonProperty("checkout_url")
    private String checkoutUrl;

    @JsonProperty("send_receipt")
    private Boolean sendReceipt;

    @JsonProperty("skip_capture")
    private Boolean skipCapture;

    @JsonProperty("creator_agent")
    private String creatorAgent;

    @JsonProperty("referral_code")
    private String referralCode;

    @JsonProperty("can_chargeback")
    private Boolean canChargeback;

    @JsonProperty("marked_as_paid")
    private Boolean markedAsPaid;

    @JsonProperty("status_history")
    private StatusHistoryResponse[] statusHistories;

    @JsonProperty("cancel_redirect")
    private String cancelRedirect;

    @JsonProperty("created_from_ip")
    private String createdFromIp;

    @JsonProperty("direct_post_url")
    private String directPostUrl;

    @JsonProperty("force_recurring")
    private Boolean forceRecurring;

    @JsonProperty("recurring_token")
    private String recurringToken;

    @JsonProperty("failure_redirect")
    private String failureRedirect;

    @JsonProperty("pending_redirect")
    private String pendingRedirect;

    @JsonProperty("success_callback")
    private String successCallback;

    @JsonProperty("success_redirect")
    private String successRedirect;

    @JsonProperty("transaction_data")
    private TransactionData transactionData;

    @JsonProperty("upsell_campaigns")
    private Object[] upsellCampaigns;

    @JsonProperty("refundable_amount")
    private Integer refundableAmount;

    @JsonProperty("is_recurring_token")
    private Boolean isRecurringToken;

    @JsonProperty("billing_template_id")
    private String billingTemplateId;

    @JsonProperty("currency_conversion")
    private Object currencyConversion;

    @JsonProperty("reference_generated")
    private String referenceGenerated;

    @JsonProperty("refund_availability")
    private String refundAvailability;

    @JsonProperty("referral_campaign_id")
    private String referralCampaignId;

    @JsonProperty("retain_level_details")
    private Object retainLevelDetails;

    @JsonProperty("referral_code_details")
    private Object referralCodeDetails;

    @JsonProperty("referral_code_generated")
    private String referralCodeGenerated;

    @JsonProperty("payment_method_whitelist")
    private Object paymentMethodWhitelist;

    public static class TransactionData {
        @JsonProperty("flow") public String flow;
        @JsonProperty("extra") public Map<String, Object> extra;
        @JsonProperty("country") public String country;
        @JsonProperty("attempts") public Attempt[] attempts;
        @JsonProperty("payment_method") public String paymentMethod;
    }

    public static class Attempt {
        @JsonProperty("flow") public String flow;
        @JsonProperty("type") public String type;
        @JsonProperty("error") public Object error;
        @JsonProperty("extra") public Map<String, Object> extra;
        @JsonProperty("country") public String country;
        @JsonProperty("client_ip") public String clientIp;
        @JsonProperty("fee_amount") public Integer feeAmount;
        @JsonProperty("successful") public Boolean successful;
        @JsonProperty("payment_method") public String paymentMethod;
        @JsonProperty("processing_time") public Long processingTime;
    }
}
