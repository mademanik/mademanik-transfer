package com.morefin.pg.finiqly.util;

public class Constants {
    public static final String PURCHASE_ENDPOINT = "/purchases/?s2s=true";

    public static final String STATUS_EXECUTED = "executed";
    public static final String STATUS_3DS_REQUIRED = "3DS_required";
}
