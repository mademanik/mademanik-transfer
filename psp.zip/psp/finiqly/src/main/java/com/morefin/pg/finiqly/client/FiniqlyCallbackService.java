package com.morefin.pg.finiqly.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.finiqly.common.FinalizeManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

@Path("/psp/finiqly")
@Produces(MediaType.APPLICATION_JSON)
public class FiniqlyCallbackService {

    @Inject
    FinalizeManager finalizeManager;

    @Inject
    Tenant tenant;

    @Path("/return/{id}")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Uni<Response> handleReturn(@PathParam("id") String transactionId, @Context HttpHeaders headers) {
        return finalizeManager.finalizeTransaction(transactionId, tenant.id());
    }

    @Path("/callback")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Uni<Response> callbackUrl(String callbackRequest, @Context HttpHeaders headers) {
        return finalizeManager.finalizeWebhookTransaction(headers.getHeaderString("signature"), callbackRequest, tenant.id());
    }
}