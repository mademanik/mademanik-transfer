package com.morefin.pg.finiqly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrowserInfo {
    @JsonProperty("accept_header")
    private String acceptHeader;

    @JsonProperty("color_depth")
    private int colorDepth;

    @JsonProperty("java_enabled")
    private boolean javaEnabled;

    @JsonProperty("language")
    private String language;

    @JsonProperty("screen_height")
    private int screenHeight;

    @JsonProperty("screen_width")
    private int screenWidth;

    @JsonProperty("time_zone_offset")
    private int timeZoneOffset;

    @JsonProperty("user_agent")
    private String userAgent;
}
