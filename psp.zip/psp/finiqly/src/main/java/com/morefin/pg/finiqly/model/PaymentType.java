package com.morefin.pg.finiqly.model;

public enum PaymentType {
    DEPOSIT, WITHDRAWAL, REFUND
}
