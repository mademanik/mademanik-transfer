package com.morefin.pg.finiqly.client;

import com.morefin.pg.finiqly.model.RefundPaymentRequest;
import com.morefin.pg.finiqly.model.RegisterPaymentRequest;
import io.quarkus.rest.client.reactive.ClientExceptionMapper;
import io.quarkus.rest.client.reactive.ClientQueryParam;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "finiqly")
@Produces(MediaType.APPLICATION_JSON)
@Path("/api/v1")
public interface FiniqlyApiClient {
    @POST
    @Path("/payments")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> registerPaymentRequest(RegisterPaymentRequest requestPayload, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @GET
    @Path("/payments/{id}")
    Uni<Response> getPayment(@PathParam("id") String id, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @ClientExceptionMapper
    static RuntimeException toException(Response response) {
        String responseAsString = response.readEntity(String.class);
        return new RuntimeException(response.getStatusInfo().getReasonPhrase() + "; body: " + responseAsString);
    }
}