package com.morefin.pg.finiqly.util;

import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.finiqly.model.*;
import com.morefin.pg.utils.Utils;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.Response;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class FiniqlyObjectTransformer {

    public static final String DEFAULT_STATE_NA = "NA";

    public Customer groupCustomerData(ImmutableTypedTransactionEntity transaction, String routingGroup) {
        return Customer.builder()
                .firstName(transaction.getCustomerFirstName())
                .lastName(transaction.getCustomerLastName())
                .phone(Utils.separatePhoneNumberCode(transaction.getCustomerPhoneNumber()))
                .email(transaction.getCustomerEmail())
                .citizenshipCountryCode(transaction.getCustomerCountry())
                .locale("EN")
                .referenceId(transaction.getId())
//                .routingGroup("lilloise_cards")
                .routingGroup(routingGroup)
                .ip(transaction.getUserIp())
                .build();
    }

    public BillingAddress getBillingAddress(ImmutableTypedTransactionEntity transaction) {
        return BillingAddress.builder()
                .city(transaction.getCustomerCity())
                .state(DEFAULT_STATE_NA)
                .postalCode(transaction.getCustomerPostalCode())
                .countryCode(transaction.getCustomerCountry())
                .addressLine1(transaction.getCustomerAddress())
                .build();
    }

    public RegisterPaymentRequest mapToRegisterPaymentRequest(FiniqlyTransactionContext context) {
        return mapRegisterPaymentRequest(context).build();
    }

    public ExecuteTransactionResponse convertToCardResponse(FiniqlyTransactionContext context) {
        PaymentTransactionResponse paymentTransactionResponse = context.getPaymentTransactionResponse();

        if ( paymentTransactionResponse.getStatus() != 200 ) {
            throw new IllegalStateException("Unexpected value: " + paymentTransactionResponse.getStatus());
        }

        PaymentResult result = paymentTransactionResponse.getResult();

        FiniqlyTransactionStatus transactionStatus = FiniqlyTransactionStatus.valueOf(result.getState());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        switch (status) {
            case APPROVED -> {
                return buildDirectApprovedTransactionResponse(result.getId(), context.getPaymentTransactionResponseAsString());
            }
            case PENDING -> {
                return buildRedirectTransactionResponse(
                        result.getId(),
                        context
                );
            }
            case DECLINED, ERROR -> {
                String message = context.getErrorDescription() != null ? context.getErrorDescription().getResponseMessage() : "";
                String responseAsString = getErrorMessage(result, message + " " + context.getPaymentTransactionResponseAsString());
                return buildDeclinedTransactionResponse(result.getId(), responseAsString);
            }
            default -> throw new IllegalStateException("Unexpected value: " + status);
        }
    }

    public ExecuteTransactionResponse convertToCardResponse(FiniqlyRefundContext context) {
        PaymentTransactionResponse refundPaymentResponse = context.getRefundPaymentResponse();
        PaymentResult result = refundPaymentResponse.getResult();

        FiniqlyTransactionStatus transactionStatus = FiniqlyTransactionStatus.valueOf(result.getState());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        switch (status) {
            case APPROVED -> {
                return buildDirectApprovedTransactionResponse(result.getId(), context.getRefundResponseAsString());
            }
            case PENDING -> {
                return buildPendingTransactionResponse(result.getId(), context.getRefundResponseAsString());
            }
        }

        String responseAsString = getErrorMessage(
            context.getRefundPaymentResponse().getResult(),
            context.getRefundResponseAsString());

        return buildDeclinedTransactionResponse(result.getId(), responseAsString);
    }

    private RegisterPaymentRequest.RegisterPaymentRequestBuilder mapRegisterPaymentRequest(FiniqlyTransactionContext context) {
        BigDecimal number = BigDecimal.valueOf(context.getAmount())
                .divide(BigDecimal.valueOf(100L), 2, RoundingMode.HALF_UP);
        BrowserInfo browserInfo = context.getBrowserInfo();

        Customer customer = context.getCustomerData();

        Card card = null;
        String paymentMethod = context.getRuntimeAccountConfig().paymentMethod();
        if ( !context.getIsHpp() ) {
            paymentMethod = "BASIC_CARD";
            card = Card.builder()
                    .cardNumber(context.getCardNumber())
                    .cardSecurityCode(context.getCvc())
                    .cardholderName(customer.getFirstName() + " " + customer.getLastName())
                    .expiryMonth(Utils.zeroPadMonth(context.getExpirationMonth()))
                    .expiryYear(Utils.thousandPadYear(context.getExpirationYear()))
                    .build();
        } else if ( context.getRuntimeAccountConfig().paymentMethod().equals("ALL") ) {
            paymentMethod = "";
        }

        ImmutableTypedTransactionEntity transaction = context.getTransaction();

        Map<String, String> additionalParameters = new HashMap<>();
        additionalParameters.put("userIp", context.getUserIp());
        additionalParameters.put("customerUserAgent", browserInfo.getUserAgent());

        String baseUrl = context.getTransactionContext().getTenantConfig().url();
//        String baseUrl = "https://ninety-ends-press.loca.lt";
        String webhookUrl = baseUrl + "/psp/finiqly/callback";
        String returnUrl = baseUrl + "/psp/finiqly/return/" + transaction.getId();

        return RegisterPaymentRequest.builder()
                .paymentType(PaymentType.DEPOSIT.name())
                .customer(customer)
                .billingAddress(context.getBillingAddress())
                .currency(context.getCurrency())
                .amount(number)
                .paymentMethod(paymentMethod)
                .card(card)
                .returnUrl(returnUrl)
                .webhookUrl(webhookUrl)
                .description(transaction.getId())
                .referenceId(transaction.getId())
                .additionalParameters(additionalParameters);
    }

    private ExecuteTransactionResponse buildDirectApprovedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildRedirectTransactionResponse(String referenceNumber, FiniqlyTransactionContext context) {
        var builder = ExecuteTransactionResponse.newBuilder();
        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        builder.setResponse(
                new GrpcBuilder<>(responseBuilder)
                        .set(ProcessingCode.TRX_STATUS_PENDING.name(), responseBuilder::setResponseCode)
                        .setAny(ExecuteTransactionResponse.Status.PENDING, responseBuilder::setStatus)
                        .set(referenceNumber, responseBuilder::setReferenceNumber)
                        .set(context.getPaymentTransactionResponseAsString(), responseBuilder::setResponseMessage)
                        .set(context.getPaymentTransactionResponseAsString(), responseBuilder::setPaymentProviderResponseMessage)
                        .getBuilder()
                        .build()
        );
        var redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();

        builder.setRedirect(
                new GrpcBuilder<>(redirectBuilder)
                        .set(context.getPaymentTransactionResponse().getResult().getRedirectUrl(), redirectBuilder::setUrl)
                        .getBuilder()
                        .build()
        );
        return builder.build();
    }

    private ExecuteTransactionResponse buildDeclinedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_DECLINED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_PENDING.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.PENDING, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }


    public ErrorDescription<String> buildErrorDescription(FiniqlyTransactionContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    public ErrorDescription<String> buildRefundErrorDescription(FiniqlyRefundContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    private ErrorDescription<String> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<String>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    public ErrorDescription<?> buildFinalizeErrorDescription(FiniqlyCallbackContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during processing of transaction {0} with message {1} during phase {2} and sub-phase {3} ",
                context.getTransactionId(), failure, context.getPhase(), context.getSubPhase());
        reason = "Bad request";
        return ErrorDescription.<Response.Status>builder()
                .reason(reason)
                .errorResponse(Response.Status.BAD_REQUEST)
                .responseMessage(failure.getMessage())
                .build();
    }

    public FiniqlyCallbackContext buildFinalizeTransactionRequest(FiniqlyCallbackContext context) {
        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder();
        builder.setReferenceNumber(context.getReferenceNumber())
                .setId(context.getTransactionId());

        ExecuteTransactionResponse.Status status;

        if (context.getIsWebhook() != null && context.getIsWebhook()) {
            FiniqlyTransactionStatus transactionStatus = FiniqlyTransactionStatus.valueOf(context.getWebhookRequest().getState());
            status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

            builder.setResponseMessage(context.getCallbackRequestAsString())
                    .setPaymentProviderResponseMessage(context.getCallbackRequestAsString());
        } else {
            PaymentResult result = context.getPaymentTransactionResponse().getResult();
            FiniqlyTransactionStatus transactionStatus = FiniqlyTransactionStatus.valueOf(result.getState());
            status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

            builder.setResponseMessage(context.getPaymentTransactionResponseAsString())
                .setPaymentProviderResponseMessage(context.getPaymentTransactionResponseAsString());
        }

        switch (status) {
            case APPROVED -> {
                String code = ProcessingCode.TRX_STATUS_APPROVED.name();
                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.APPROVED);
            }
            case PENDING -> {
                String code = ProcessingCode.TRX_STATUS_PENDING.name();

                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.PENDING);
            }
            default -> {
                builder.setStatus(TransactionStatus.DECLINED);
                if ( context.getErrorDescription() != null ) {
                    ErrorDescription errorDescription = context.getErrorDescription();
                    com.morefin.pg.common.TransactionStatusMapper responseMapping = com.morefin.pg.common.TransactionStatusMapper.fromValue(errorDescription.getReason());

                    builder.setResponseCode(responseMapping.getResponseCode().name())
                            .setPaymentProviderResponseCode(responseMapping.getResponseCode().name())
                            .setResponseMessage(errorDescription.getPaymentProviderResponseMessage())
                            .setPaymentProviderResponseMessage(errorDescription.getPaymentProviderResponseMessage());

                } else {
                    String code = ProcessingCode.TRX_STATUS_DECLINED.name();
                    builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code);

                    Optional.ofNullable(context.getPaymentTransactionResponse())
                        .flatMap(response -> Optional.ofNullable(response.getResult())
                            .map(PaymentResult::getErrorMessage))
                        .ifPresentOrElse(
                                errorMessage -> builder.setResponseMessage(errorMessage)
                                    .setPaymentProviderResponseMessage(errorMessage),
                            () -> {
                                var errorMessage = context.getWebhookRequest().getErrorMessage();
                                builder.setResponseMessage(errorMessage)
                                    .setPaymentProviderResponseMessage(errorMessage);
                            }
                        );
                }
            }
        }

        context.setFinalizeRequest(builder.build());

        return context;
    }

    public RegisterPaymentRequest buildPaymentRefundRequest(ManageTransactionContext context) {
        return mapRefundPaymentRequest(context).build();
    }

    private RegisterPaymentRequest.RegisterPaymentRequestBuilder mapRefundPaymentRequest(ManageTransactionContext context) {
        var parentTransactionRefNum = context.transactionTypeContext().getParentTransaction().getReferenceNumber();
        BigDecimal number = BigDecimal.valueOf(context.transaction().getAmount())
                .divide(BigDecimal.valueOf(100L), 2, RoundingMode.HALF_UP);

        String baseUrl = context.transactionTypeContext().getTenantConfig().url();
//        String baseUrl = "https://ninety-ends-press.loca.lt";
        String webhookUrl = baseUrl + "/psp/finiqly/callback";

        return RegisterPaymentRequest.builder()
                .amount(number)
                .currency(context.transaction().getCurrency())
                .paymentType(PaymentType.REFUND.name())
                .parentPaymentId(parentTransactionRefNum)
                .webhookUrl(webhookUrl);
    }

    private String getErrorMessage(PaymentResult result, String optionalMessage) {
        return Optional.ofNullable(result.getErrorMessage())
            .orElse(optionalMessage);
    }
}

