package com.morefin.pg.finiqly.processing.apm;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.finiqly.admin.apm.FiniqlyAPMTypeModule;
import io.quarkus.arc.Arc;

public class FiniqlyHppServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return FiniqlyAPMTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return FiniqlyAPMTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return FiniqlyAPMTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(FiniqlyAPMProcessingService.class)) {
            return instance.get();
        }
    }
}
