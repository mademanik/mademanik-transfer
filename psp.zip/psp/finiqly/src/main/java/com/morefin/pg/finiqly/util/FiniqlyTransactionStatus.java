package com.morefin.pg.finiqly.util;

import lombok.Getter;

@Getter
public enum FiniqlyTransactionStatus {
    CHECKOUT("Need to redirect user to payment page"),
    PENDING("Payment is sent and waiting for result"),
    AUTHORIZED("AUTHORIZED"),
    CANCELLED("Payment is cancelled"),
    DECLINED("DECLINED"),
    COMPLETED("Payment is complete");

    private final String value;

    FiniqlyTransactionStatus(String value) {
        this.value = value;
    }

    public static FiniqlyTransactionStatus fromValue(String value) {
        FiniqlyTransactionStatus status = null;
        for ( FiniqlyTransactionStatus CONSTANT : FiniqlyTransactionStatus.values() ) {
            if ( CONSTANT.getValue().equalsIgnoreCase(value) ) {
                status = CONSTANT;
                break;
            }
        }
        if ( status == null ) {
            throw new IllegalArgumentException(String.format("FiniqlyTransactionStatus is not found: %s", value));
        }
        return status;
    }

}