package com.morefin.pg.finiqly.util;

import java.util.Arrays;

public class SupportedWebhookEvents {
    private static String[] supportedEvents = {
            "purchase.paid",
            "purchase.payment_failure",
            "payment.refunded",
    };

    public static boolean isEventSupported(String event) {
        return Arrays.stream(supportedEvents).anyMatch(x -> x.equals(event));
    }
}
