package com.morefin.pg.finiqly.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Set;

public record RuntimeAccountConfig(
        @JsonProperty("api_key")
        String apiKey,
        @JsonProperty("signing_key")
        String signingKey,
        @JsonProperty("routing_group")
        String routingGroup,
        @JsonProperty("payment_method")
        String paymentMethod
) {
}
