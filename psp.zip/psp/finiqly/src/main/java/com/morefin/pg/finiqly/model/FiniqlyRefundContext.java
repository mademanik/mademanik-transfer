package com.morefin.pg.finiqly.model;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.finiqly.common.RuntimeAccountConfig;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FiniqlyRefundContext extends BaseTransactionContext<String> {

    ManageTransactionContext context;
    RuntimeAccountConfig runtimeAccountConfig;

    RegisterPaymentRequest refundPaymentRequest;
    PaymentTransactionResponse refundPaymentResponse;
    String refundResponseAsString;

    String referenceNumber;

    public FiniqlyRefundContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}