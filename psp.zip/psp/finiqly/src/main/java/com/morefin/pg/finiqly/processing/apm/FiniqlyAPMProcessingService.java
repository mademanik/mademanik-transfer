package com.morefin.pg.finiqly.processing.apm;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.pg.finiqly.admin.apm.FiniqlyAPMAdminPaymentProcessingService;
import com.morefin.pg.finiqly.admin.apm.FiniqlyAPMTypeModule;
import com.morefin.pg.finiqly.common.TransactionManager;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class FiniqlyAPMProcessingService implements APMProcessingService {

    @Inject
    FiniqlyAPMAdminPaymentProcessingService adminPaymentProcessingService;

    @Inject
    TransactionManager transactionManager;

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return FiniqlyAPMTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public Uni<ExecuteTransactionResponse> request(TransactionTypeContext context) {
        return transactionManager.executeHPPRequest(context);
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }
}
