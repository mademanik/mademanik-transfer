package com.morefin.pg.finiqly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Customer implements Serializable {
    @JsonProperty("referenceId")
    private String referenceId;

    @JsonProperty("citizenshipCountryCode")
    private String citizenshipCountryCode;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("dateOfBirth")
    private String dateOfBirth;

    @JsonProperty("email")
    private String email;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("locale")
    private String locale;

    @JsonProperty("routingGroup")
    private String routingGroup;

    @JsonProperty("kycStatus")
    private Boolean kycStatus;

    @JsonProperty("paymentInstrumentKycStatus")
    private Boolean paymentInstrumentKycStatus;

    @JsonProperty("ip")
    private String ip;
}
