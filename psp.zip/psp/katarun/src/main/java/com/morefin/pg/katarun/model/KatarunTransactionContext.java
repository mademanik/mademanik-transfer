package com.morefin.pg.katarun.model;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.katarun.client.KatarunDirectApiClient;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class KatarunTransactionContext extends BaseTransactionContext<String> {

    CardAuthorizeContext context;
    KatarunConfig runtimeAccountConfig;
    ImmutableTypedTransactionEntity transaction;

    Long amount;
    String currency;
    String reference;
    String userIp;
    String successUrl;
    String cancelUrl;
    String failureUrl;
    String description;

    String cardholderName;
    String cardNumber;
    String cvc;
    Integer expirationMonth;
    Integer expirationYear;

    BrowserInfo browserInfo;

    KatarunPurchaseResponse purchaseResponse;
    KatarunDirectApiClient directApiClient;

    KatarunDirectPaymentResponse directPaymentResponse;
    String directPaymentResponseAsString;

    public KatarunTransactionContext() {
        super("INITIAL_PAYMENT_PHASE");
    }

}
