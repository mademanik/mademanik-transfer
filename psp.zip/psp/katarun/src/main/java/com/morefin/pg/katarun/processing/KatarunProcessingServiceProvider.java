package com.morefin.pg.katarun.processing;

import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.katarun.KatarunTypeModule;
import io.quarkus.arc.Arc;

public class KatarunProcessingServiceProvider implements APMProcessingServiceProvider {
    @Override
    public APMProcessingService create() {
        try(var instance = Arc.container().instance(KatarunProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return KatarunTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return KatarunTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return KatarunTypeModule.MODULE_ID;
    }
}
