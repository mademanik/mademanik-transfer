package com.morefin.pg.katarun.util;

import lombok.Getter;

@Getter
public enum KatarunTransactionStatus {
    EXECUTED("executed"),
    AUTHORIZED("authorized"),
    PENDING("pending"),
    THREEDS_REQUIRED("3DS_required"),
    PAID("paid"),
    REFUNDED("refunded"),
    CAPTURED("captured"),
    CANCELLED("cancelled"),
    CREATED("created"),

    PENDING_EXECUTE("pending_execute"),
    PENDING_CHARGE("pending_charge"),
    PENDING_CAPTURE("pending_capture"),
    PANDING_REFUND("pending_refund"),

    ERROR("error");

    private final String value;

    KatarunTransactionStatus(String value) {
        this.value = value;
    }

    public static KatarunTransactionStatus fromValue(String value) {
        for (KatarunTransactionStatus status : KatarunTransactionStatus.values()) {
            if (status.getValue().equalsIgnoreCase(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException(String.format("KatarunTransactionStatus is not found: %s", value));
    }
}
