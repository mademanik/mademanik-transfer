package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KatarunDirectPaymentResponse implements Serializable {
    @JsonProperty("status")
    private String status;

    @JsonProperty("Method")
    private String method;

    @JsonProperty("PaReq")
    private String paReq;

    @JsonProperty("MD")
    private String md;

    @JsonProperty("URL")
    private String url;

    @JsonProperty("callback_url")
    private String callbackUrl;
}
