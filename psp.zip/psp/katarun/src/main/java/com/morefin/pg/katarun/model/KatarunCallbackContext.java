package com.morefin.pg.katarun.model;

import com.morefin.common.grpc.transaction.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionEntity;
import com.morefin.pg.katarun.client.Katarun3dsAuthorizeApiClient;
import com.morefin.pg.safeuni.BaseTransactionContext;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class KatarunCallbackContext extends BaseTransactionContext<String> {

    KatarunConfig runtimeAccountConfig;

    String tenantId;
    String referenceNumber;
    String transactionId;
    MultivaluedMap<String, String> callbackRequestAsMap;

    TypedTransactionEntity transactionEntity;
    TransactionGrpc transactionGrpc;
    Katarun3dsAuthorizeApiClient katarun3dsAuthorizeApiClient;
    KatarunDirectPaymentResponse directPaymentResponse;
    String directPaymentResponseAsString;

    FinalizeTransactionRequest finalizeRequest;
    ExecuteTransactionResponse finalizeResponse;

    public KatarunCallbackContext() {
        super("INITIAL_PAYMENT_PHASE");
    }
}
