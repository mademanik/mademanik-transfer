package com.morefin.pg.katarun.http;

import com.morefin.pg.katarun.model.KatarunWebhookPayload;
import com.morefin.pg.katarun.processing.KatarunCallbackService;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import static com.morefin.pg.katarun.http.KatarunHttpConstants.CALLBACK_URL;

/**
 * Exposes callback endpoints for Katarun to notify the gateway about payment results.
 */
@Path(CALLBACK_URL)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class KatarunCallbackResource {

    @Inject
    KatarunCallbackService callbackService;


    @POST
    public Uni<Response> webHook(KatarunWebhookPayload payload) {
        Log.infov("webhook payload={0}", payload);

        return callbackService.processEvent(payload).map(r -> r);
    }
}
