package com.morefin.pg.katarun.processing;

import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.pg.katarun.KatarunTypeModule;
import com.morefin.pg.katarun.admin.KatarunAdminService;
import com.morefin.pg.katarun.http.KatarunApiClient;
import com.morefin.pg.katarun.http.KatarunHttpConstants;
import com.morefin.pg.katarun.model.KatarunClient;
import com.morefin.pg.katarun.model.KatarunConfig;
import com.morefin.pg.katarun.model.KatarunPurchaseDetails;
import com.morefin.pg.katarun.model.KatarunPurchaseProduct;
import com.morefin.pg.katarun.model.KatarunPurchaseRequest;
import com.morefin.pg.katarun.model.KatarunPurchaseResponse;
import com.morefin.pg.utils.Utils;
import io.quarkus.arc.Unremovable;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@ApplicationScoped
@Unremovable
public class KatarunProcessingService implements APMProcessingService {

    @Inject
    KatarunAdminService katarunAdminService;

    @RestClient
    KatarunApiClient apiClient;


    @Override
    public Uni<ExecuteTransactionResponse> request(TransactionTypeContext context) {
        var config = Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), KatarunConfig.class);
        var purchaseRequest = buildPurchaseRequest(context, config);
        var authorization = buildAuthorizationHeader(config);

        return apiClient.createPurchase(purchaseRequest, authorization)
                .map(response -> buildRedirectResponse(context, response))
                .onFailure().recoverWithItem(throwable -> buildErrorResponse(context, throwable));
    }

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return KatarunTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return katarunAdminService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return katarunAdminService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }

    private KatarunPurchaseRequest buildPurchaseRequest(TransactionTypeContext context, KatarunConfig config) {
        var transaction = context.getTransaction();
        var transactionData = transaction.getTransactionData();

        var product = new KatarunPurchaseProduct(
                resolveProductName(transaction),
                transaction.getAmount(),
                "1",
                null,
                null,
                null,
                null
        );

        var purchaseDetails = new KatarunPurchaseDetails(
                transaction.getCurrency(),
                List.of(product),
                null,
                null,
                buildPurchaseMetadata(transaction)
        );

        var paymentMethodListEmpty = config.paymentMethodWhitelist() == null || config.paymentMethodWhitelist().isEmpty();
        return new KatarunPurchaseRequest(
                buildClient(transaction),
                purchaseDetails,
                config.brandId(),
                paymentMethodListEmpty ? null : config.paymentMethodWhitelist(),
                transactionData != null ? transactionData.getSuccessUrl() : null,
                transactionData != null ? transactionData.getErrorUrl() : null,
                transactionData != null ? transactionData.getCancelUrl() : null,
                null,
                null,
                transaction.getId(),
                buildPurchaseMetadata(transaction)
        );
    }

    private Map<String, Object> buildPurchaseMetadata(ImmutableTypedTransactionEntity transaction) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("transaction_id", transaction.getId());
        if (StringUtils.isNotBlank(transaction.getDescription())) {
            metadata.put("description", transaction.getDescription());
        }
        return metadata;
    }

    private KatarunClient buildClient(ImmutableTypedTransactionEntity transaction) {
        String fullName = Stream.of(transaction.getCustomerFirstName(), transaction.getCustomerLastName())
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(" "));
        fullName = StringUtils.defaultIfBlank(fullName, null);

        return new KatarunClient(
                transaction.getCustomerId(),
                transaction.getCustomerEmail(),
                transaction.getCustomerPhoneNumber(),
                transaction.getCustomerCountry(),
                fullName,
            transaction.getCustomerAddress(),
            transaction.getCustomerPostalCode(),
            transaction.getCustomerCity()
        );
    }

    private String buildAuthorizationHeader(KatarunConfig config) {
        return "Bearer " + config.secretKey();
    }

    private ExecuteTransactionResponse buildRedirectResponse(TransactionTypeContext context, KatarunPurchaseResponse response) {
        var redirectUrl = Optional.ofNullable(response.checkoutUrl()).orElse(response.directPostUrl());

        if (StringUtils.isBlank(redirectUrl)) {
            throw new IllegalStateException("Katarun response does not contain redirect URL");
        }

        var redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();
        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();

        var grpcResponse = new GrpcBuilder<>(responseBuilder)
                .set(context.getTransaction().getId(), responseBuilder::setId)
                .set(ProcessingCode.TRX_STATUS_PENDING.name(), responseBuilder::setResponseCode)
                .set("Redirect to Katarun checkout", responseBuilder::setResponseMessage)
                .setAny(response.status(), responseBuilder::setPaymentProviderStatus)
                .setAny(response.status(), responseBuilder::setPaymentProviderResponseCode)
                .setAny(ExecuteTransactionResponse.Status.PENDING, responseBuilder::setStatus)
                .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, responseBuilder::setData)
                .getBuilder()
                .build();

        var grpcRedirect = new GrpcBuilder<>(redirectBuilder)
                .set(redirectUrl, redirectBuilder::setUrl)
                .getBuilder()
                .build();

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(grpcResponse)
                .setRedirect(grpcRedirect)
                .build();
    }

    private ExecuteTransactionResponse buildErrorResponse(TransactionTypeContext context, Throwable throwable) {
        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        var grpcBuilder = new GrpcBuilder<>(responseBuilder)
                .set(context.getTransaction().getId(), responseBuilder::setId)
                .set(ProcessingCode.TRX_STATUS_FAILED.name(), responseBuilder::setResponseCode)
                .setAny("ERROR", responseBuilder::setPaymentProviderStatus)
                .setAny(ExecuteTransactionResponse.Status.ERROR, responseBuilder::setStatus);

        var baseMessage = defaultErrorMessage(throwable);
        String responseBody = null;

        if (throwable instanceof WebApplicationException webApplicationException) {
            Response response = webApplicationException.getResponse();
            String providerCode = String.valueOf(response.getStatus());
            responseBody = readResponseBody(response);

            grpcBuilder
                    .setAny(providerCode, responseBuilder::setPaymentProviderResponseCode)
                    .setAny(responseBody, responseBuilder::setPaymentProviderResponseMessage);

            Log.warnf("Katarun API call failed with status %s and body: %s",
                    providerCode,
                    responseBody);
        } else {
            grpcBuilder
                    .setAny(throwable.getClass().getSimpleName(), responseBuilder::setPaymentProviderResponseCode)
                    .setAny(baseMessage, responseBuilder::setPaymentProviderResponseMessage);

            Log.warn("Katarun API call failed", throwable);
        }

        grpcBuilder.set(composeResponseMessage(baseMessage, responseBody), responseBuilder::setResponseMessage);

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(grpcBuilder.getBuilder().build())
                .build();
    }

    private String resolveProductName(ImmutableTypedTransactionEntity transaction) {
        return Optional.ofNullable(transaction.getDescription())
                .filter(StringUtils::isNotBlank)
                .orElse("Order " + transaction.getId());
    }

    private String buildTenantUrl(String base, String... segments) {
        UriBuilder builder = UriBuilder.fromUri(base);
        for (String segment : segments) {
            builder.path(segment);
        }
        return builder.build().toString();
    }

    private String readResponseBody(Response response) {
        if (response == null || !response.hasEntity()) {
            return null;
        }
        try {
            return response.readEntity(String.class);
        } catch (IllegalStateException illegalStateException) {
            Log.debug("Unable to read Katarun error response body", illegalStateException);
            return null;
        } finally {
            try {
                response.close();
            } catch (Exception ignored) {
                // ignore closing issues
            }
        }
    }

    private String defaultErrorMessage(Throwable throwable) {
        return Optional.ofNullable(throwable.getMessage())
                .filter(StringUtils::isNotBlank)
                .orElse("Katarun request failed");
    }

    private String composeResponseMessage(String message, String body) {
        if (StringUtils.isBlank(body)) {
            return message;
        }
        if (StringUtils.isBlank(message)) {
            return body;
        }
        return message + " | body: " + body;
    }
}
