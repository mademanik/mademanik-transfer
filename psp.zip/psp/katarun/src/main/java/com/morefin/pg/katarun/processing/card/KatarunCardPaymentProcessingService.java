package com.morefin.pg.katarun.processing.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.pg.katarun.admin.KatarunAdminService;
import com.morefin.pg.katarun.common.KatarunTransactionManager;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class KatarunCardPaymentProcessingService implements EcommerceCardPaymentProcessingService {

    @Inject
    KatarunAdminService adminPaymentProcessingService;

    @Inject
    KatarunTransactionManager transactionManager;

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext context) {
        return transactionManager.executeDirectPaymentRequest(context);
    }

    @Override
    public Uni<ExecuteTransactionResponse> manage(ManageTransactionContext manageTransactionContext) {
        if (manageTransactionContext.transactionType().equalsIgnoreCase("refund")) {
            return transactionManager.requestRefund(manageTransactionContext);
        }
        return Uni.createFrom()
                .failure(new IllegalArgumentException("Transaction type %s not supported".formatted(manageTransactionContext.transactionType().toLowerCase())));
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }
}
