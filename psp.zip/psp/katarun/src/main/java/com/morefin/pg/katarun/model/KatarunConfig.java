package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

public record KatarunConfig(
    @JsonProperty("brand_id")
    String brandId,
    @JsonProperty("secret_key")
    String secretKey,
    @JsonProperty("s2s_token")
    String s2sToken,
    @JsonProperty("public_key")
    String publicKey,
    @JsonProperty("payment_method_whitelist")
    Set<String> paymentMethodWhitelist
) {
}
