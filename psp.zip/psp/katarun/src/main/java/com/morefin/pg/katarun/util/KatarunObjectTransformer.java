package com.morefin.pg.katarun.util;

import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.katarun.model.BrowserInfo;
import com.morefin.pg.katarun.model.KatarunCallbackContext;
import com.morefin.pg.katarun.model.KatarunClient;
import com.morefin.pg.katarun.model.KatarunDirectPaymentRequest;
import com.morefin.pg.katarun.model.KatarunDirectPaymentResponse;
import com.morefin.pg.katarun.model.KatarunPurchaseDetails;
import com.morefin.pg.katarun.model.KatarunPurchaseProduct;
import com.morefin.pg.katarun.model.KatarunPurchaseRequest;
import com.morefin.pg.katarun.model.KatarunPurchaseResponse;
import com.morefin.pg.katarun.model.KatarunRefundContext;
import com.morefin.pg.katarun.model.KatarunRefundRequest;
import com.morefin.pg.katarun.model.KatarunTransactionContext;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.utils.Utils;
import io.quarkus.logging.Log;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class KatarunObjectTransformer {

    public KatarunPurchaseRequest mapToPurchaseRequest(KatarunTransactionContext context) {
        ImmutableTypedTransactionEntity transaction = context.getTransaction();
        var product = new KatarunPurchaseProduct(
                resolveProductName(transaction),
                transaction.getAmount(),
                "1",
                null,
                null,
                null,
                null
        );

        var purchaseDetails = new KatarunPurchaseDetails(
                transaction.getCurrency(),
                List.of(product),
                null,
                null,
                buildPurchaseMetadata(transaction)
        );

        return new KatarunPurchaseRequest(
                buildClient(transaction),
                purchaseDetails,
                context.getRuntimeAccountConfig() != null ? context.getRuntimeAccountConfig().brandId() : null,
                null,
                context.getSuccessUrl(),
                context.getFailureUrl(),
                context.getCancelUrl(),
                null,
                null,
                context.getReference(),
                buildPurchaseMetadata(transaction)
        );
    }

    public KatarunDirectPaymentRequest mapToDirectPaymentRequest(KatarunTransactionContext context) {
        BrowserInfo browserInfo = Optional.ofNullable(context.getBrowserInfo()).orElseGet(BrowserInfo::new);
        return KatarunDirectPaymentRequest.builder()
                .cardholderName(context.getCardholderName())
                .cardNumber(context.getCardNumber())
                .expires(Utils.zeroPadMonth(context.getExpirationMonth()) + "/" + Utils.trimExpirationYear(context.getExpirationYear()))
                .cvc(context.getCvc())
                .rememberCard("off")
                .remoteIp(context.getUserIp())
                .userAgent(browserInfo.getUserAgent())
                .acceptHeader(browserInfo.getAcceptHeader())
                .language(browserInfo.getLanguage())
                .javaEnabled(browserInfo.isJavaEnabled())
                .javascriptEnabled(true)
                .colorDepth(browserInfo.getColorDepth())
                .utcOffset(browserInfo.getTimeZoneOffset())
                .screenWidth(browserInfo.getScreenWidth())
                .screenHeight(browserInfo.getScreenHeight())
                .build();
    }

    public ExecuteTransactionResponse convertToCardResponse(KatarunTransactionContext context) {
        if (context.getErrorDescription() != null && context.getDirectPaymentResponse() == null) {
            return buildDeclinedTransactionResponse(resolveReference(context), context.getErrorDescription().getResponseMessage());
        }

        KatarunDirectPaymentResponse directPaymentResponse = context.getDirectPaymentResponse();
        if (directPaymentResponse == null) {
            return buildDeclinedTransactionResponse(resolveReference(context), "Katarun direct payment response is empty");
        }

        KatarunTransactionStatus transactionStatus = KatarunTransactionStatus.fromValue(directPaymentResponse.getStatus());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        switch (status) {
            case APPROVED -> {
                return buildDirectApprovedTransactionResponse(resolveReference(context), context.getDirectPaymentResponseAsString());
            }
            case PENDING -> {
                if (transactionStatus.equals(KatarunTransactionStatus.THREEDS_REQUIRED)) {
                    String baseUrl = context.getContext().authorizeContext().getTenantConfig().url();
                    String callbackUrl = baseUrl + "/psp/katarun/3dsCallback/" + resolveReference(context);
                    return buildDirect3dsTransactionResponse(resolveReference(context), directPaymentResponse, callbackUrl);
                }
                return buildPendingTransactionResponse(resolveReference(context), context.getDirectPaymentResponseAsString());
            }
            case DECLINED, ERROR -> {
                String message = context.getErrorDescription() != null ? context.getErrorDescription().getResponseMessage() : "";
                return buildDeclinedTransactionResponse(resolveReference(context), message + " " + context.getDirectPaymentResponseAsString());
            }
            default -> throw new IllegalStateException("Unexpected value: " + status);
        }
    }

    public ExecuteTransactionResponse convertToCardResponse(KatarunRefundContext context) {
        KatarunPurchaseResponse refundResponse = context.getRefundResponse();
        if (refundResponse == null) {
            return buildDeclinedTransactionResponse(context.getReferenceNumber(), context.getRefundResponseAsString());
        }

        KatarunTransactionStatus transactionStatus = KatarunTransactionStatus.fromValue(refundResponse.status());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        return switch (status) {
            case APPROVED -> buildDirectApprovedTransactionResponse(context.getReferenceNumber(), context.getRefundResponseAsString());
            case PENDING -> buildPendingTransactionResponse(context.getReferenceNumber(), context.getRefundResponseAsString());
            default -> buildDeclinedTransactionResponse(context.getReferenceNumber(), context.getRefundResponseAsString());
        };
    }

    public ErrorDescription<String> buildErrorDescription(KatarunTransactionContext context, Throwable failure) {
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);
        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    public ErrorDescription<String> buildRefundErrorDescription(KatarunRefundContext context, Throwable failure) {
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);
        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    public ErrorDescription<?> buildFinalizeErrorDescription(KatarunCallbackContext context, Throwable failure) {
        Log.errorv("Exception caught during processing of transaction {0} with message {1} during phase {2} and sub-phase {3}",
                context.getTransactionId(), failure, context.getPhase(), context.getSubPhase());
        return ErrorDescription.builder()
                .reason("Bad request")
                .errorResponse(jakarta.ws.rs.core.Response.Status.BAD_REQUEST)
                .responseMessage(failure.getMessage())
                .build();
    }

    public KatarunCallbackContext buildFinalizeTransactionRequest(KatarunCallbackContext context) {
        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder();
        builder.setReferenceNumber(context.getReferenceNumber())
                .setId(context.getTransactionId());

        KatarunTransactionStatus transactionStatus = KatarunTransactionStatus.fromValue(context.getDirectPaymentResponse().getStatus());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        builder.setResponseMessage(context.getDirectPaymentResponseAsString())
                .setPaymentProviderResponseMessage(context.getDirectPaymentResponseAsString());

        switch (status) {
            case APPROVED -> {
                String code = ProcessingCode.TRX_STATUS_APPROVED.name();
                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.APPROVED);
            }
            case PENDING -> {
                String code = ProcessingCode.TRX_STATUS_PENDING.name();
                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.PENDING);
            }
            default -> {
                builder.setStatus(TransactionStatus.DECLINED);
                if (context.getErrorDescription() != null) {
                    ErrorDescription<?> errorDescription = context.getErrorDescription();
                    com.morefin.pg.common.TransactionStatusMapper responseMapping = com.morefin.pg.common.TransactionStatusMapper.fromValue(errorDescription.getReason());

                    builder.setResponseCode(responseMapping.getResponseCode().name())
                            .setPaymentProviderResponseCode(responseMapping.getResponseCode().name())
                            .setResponseMessage(errorDescription.getPaymentProviderResponseMessage())
                            .setPaymentProviderResponseMessage(errorDescription.getPaymentProviderResponseMessage());

                } else {
                    String code = ProcessingCode.TRX_STATUS_DECLINED.name();
                    builder.setResponseCode(code)
                            .setPaymentProviderResponseCode(code);
                }
            }
        }

        context.setFinalizeRequest(builder.build());
        return context;
    }

    public KatarunRefundRequest buildRefundRequest(ManageTransactionContext context) {
        return new KatarunRefundRequest(
                context.transaction().getAmount(),
                "refund",
                context.transaction().getDescription()
        );
    }

    private ExecuteTransactionResponse buildDirectApprovedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildDirect3dsTransactionResponse(String referenceNumber, KatarunDirectPaymentResponse directPaymentResponse, String callbackUrl) {
        var builder = ExecuteTransactionResponse.newBuilder();
        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        builder.setResponse(
                new GrpcBuilder<>(responseBuilder)
                        .set(ProcessingCode.TRX_STATUS_PENDING.name(), responseBuilder::setResponseCode)
                        .setAny(ExecuteTransactionResponse.Status.PENDING, responseBuilder::setStatus)
                        .set(referenceNumber, responseBuilder::setReferenceNumber)
                        .setAndMap(JsonObject.mapFrom(directPaymentResponse).getMap(), GrpcFactory::fromMap, responseBuilder::setData)
                        .getBuilder()
                        .build()
        );
        String mdValue = directPaymentResponse.getMd() == null ? "" : directPaymentResponse.getMd();
        if ("POST".equalsIgnoreCase(directPaymentResponse.getMethod())) {
            var formBuilder = ExecuteTransactionResponse.FormSubmit.newBuilder();
            Map<String, String> formData = new HashMap<>();
            formData.put("PaReq", directPaymentResponse.getPaReq());
            formData.put("MD", mdValue);
            formData.put("TermUrl", callbackUrl);
            builder.setFormSubmit(
                    formBuilder
                            .setUrl(directPaymentResponse.getUrl())
                            .putAllData(formData)
                            .build()
            );
        } else if ("GET".equalsIgnoreCase(directPaymentResponse.getMethod())) {
            var redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();
            String redirectUrl = String.format("%s?%s=%s&%s=%s&%s=%s",
                    directPaymentResponse.getUrl(),
                    "PaReq", directPaymentResponse.getPaReq(),
                    "MD", mdValue,
                    "TermUrl", callbackUrl
            );

            builder.setRedirect(
                    new GrpcBuilder<>(redirectBuilder)
                            .set(redirectUrl, redirectBuilder::setUrl)
                            .getBuilder()
                            .build()
            );
        }
        return builder.build();
    }

    private ExecuteTransactionResponse buildDeclinedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_DECLINED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_PENDING.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.PENDING, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ErrorDescription<String> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<String>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    private String resolveReference(KatarunTransactionContext context) {
        if (context.getPurchaseResponse() != null && StringUtils.isNotBlank(context.getPurchaseResponse().id())) {
            return context.getPurchaseResponse().id();
        }
        return context.getReference();
    }

    private String resolveProductName(ImmutableTypedTransactionEntity transaction) {
        return Optional.ofNullable(transaction.getDescription())
                .filter(StringUtils::isNotBlank)
                .orElse("Order " + transaction.getId());
    }

    private Map<String, Object> buildPurchaseMetadata(ImmutableTypedTransactionEntity transaction) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("transaction_id", transaction.getId());
        if (StringUtils.isNotBlank(transaction.getDescription())) {
            metadata.put("description", transaction.getDescription());
        }
        return metadata;
    }

    private KatarunClient buildClient(ImmutableTypedTransactionEntity transaction) {
        String fullName = Stream.of(transaction.getCustomerFirstName(), transaction.getCustomerLastName())
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(" "));
        fullName = StringUtils.defaultIfBlank(fullName, null);

        return new KatarunClient(
                transaction.getCustomerId(),
                transaction.getCustomerEmail(),
                transaction.getCustomerPhoneNumber(),
                transaction.getCustomerCountry(),
                fullName,
                transaction.getCustomerAddress(),
                transaction.getCustomerPostalCode(),
                transaction.getCustomerCity()
        );
    }
}
