package com.morefin.pg.katarun.http;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.katarun.common.Katarun3dsFinalizeManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.jboss.resteasy.reactive.RestPath;

@Path("/psp/katarun")
@Produces(MediaType.APPLICATION_JSON)
public class KatarunCardCallbackResource {

    @Inject
    Katarun3dsFinalizeManager finalizeManager;

    @Inject
    Tenant tenant;

    @Path("/3dsCallback/{referenceNumber}")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Uni<Response> threedsCallbackUrl(@RestPath String referenceNumber, MultivaluedMap<String, String> callbackRequest, @Context HttpHeaders headers) {
        return finalizeManager.finalize3dTransaction(referenceNumber, callbackRequest, tenant.id());
    }
}
