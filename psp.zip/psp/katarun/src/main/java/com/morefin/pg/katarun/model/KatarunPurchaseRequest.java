package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record KatarunPurchaseRequest(
        @JsonProperty(value = "client") KatarunClient client,
        //@JsonProperty(value = "client_id") String clientId,
        @JsonProperty("purchase") KatarunPurchaseDetails purchase,
        @JsonProperty("brand_id") String brandId,
        @JsonProperty("payment_method_whitelist") Set<String> paymentMethodWhitelist,
        @JsonProperty("success_redirect") String successRedirect,
        @JsonProperty("failure_redirect") String failureRedirect,
        @JsonProperty("cancel_redirect") String cancelRedirect,
        @JsonProperty("success_callback") String successCallback,
        @JsonProperty("skip_capture") Boolean skipCapture,
        @JsonProperty("reference") String reference,
        @JsonProperty("metadata") Map<String, Object> metadata
) {
}
