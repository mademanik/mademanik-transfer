package com.morefin.pg.katarun.model;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class KatarunRefundContext extends BaseTransactionContext<String> {

    ManageTransactionContext context;
    KatarunConfig runtimeAccountConfig;
    String referenceNumber;

    KatarunRefundRequest refundRequest;
    KatarunPurchaseResponse refundResponse;
    String refundResponseAsString;

    public KatarunRefundContext() {
        super("INITIAL_PAYMENT_PHASE");
    }
}
