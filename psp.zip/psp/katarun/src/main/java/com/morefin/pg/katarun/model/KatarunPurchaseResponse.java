package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Map;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record KatarunPurchaseResponse(
        @JsonProperty("id") String id,
        @JsonProperty("status") String status,
        @JsonProperty("brand_id") String brandId,
        @JsonProperty("shop_id") String shopId,
        @JsonProperty("test") Boolean test,
        @JsonProperty("validation_key") String validationKey,
        @JsonProperty("transaction_id") String transactionId,
        @JsonProperty("created_on") Instant createdOn,
        @JsonProperty("updated_on") Instant updatedOn,
        @JsonProperty("checkout_url") String checkoutUrl,
        @JsonProperty("direct_post_url") String directPostUrl,
        @JsonProperty("success_redirect") String successRedirect,
        @JsonProperty("failure_redirect") String failureRedirect,
        @JsonProperty("cancel_redirect") String cancelRedirect,
        @JsonProperty("success_callback") String successCallback,
        @JsonProperty("failure_callback") String failureCallback,
        @JsonProperty("reference") String reference,
        @JsonProperty("payment_method_whitelist") Set<String> paymentMethodWhitelist,
        @JsonProperty("metadata") Map<String, Object> metadata,
        @JsonProperty("client") KatarunClient client,
        @JsonProperty("purchase") KatarunPurchaseDetails purchase
) {
}
