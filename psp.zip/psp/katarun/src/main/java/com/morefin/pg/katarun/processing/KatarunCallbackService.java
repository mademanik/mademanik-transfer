package com.morefin.pg.katarun.processing;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.pg.katarun.model.KatarunWebhookPayload;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Handles Katarun webhook callbacks and bridges them into the gateway pipeline.
 */
@ApplicationScoped
public class KatarunCallbackService {

    private static final String SERVICE_ACCOUNT = "katarun-service-account";
    private static final Set<String> SUPPORTED_EVENTS = Set.of("purchase.paid", "purchase.payment_failure");

    @Inject
    Tenant tenant;

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;


    public Uni<Response> processEvent(KatarunWebhookPayload payload) {
        var tenantId = tenant.id();
        logIncomingEvent("webhook", payload, tenantId);

        if (StringUtils.isBlank(payload.eventType())) {
            Log.warnv("Ignoring Katarun callback without event_type: {0}", payload);
            return Uni.createFrom().item(Response.status(Response.Status.BAD_REQUEST).build());
        }

        if(!SUPPORTED_EVENTS.contains(payload.eventType())) {
            Log.debugf("Ignoring Katarun callback event_type: {0}", payload);
            return Uni.createFrom().item(Response.ok().build());
        }

        return Uni.createFrom().item(payload)
            .map(this::buildFinalizeRequest)
            .flatMap(request -> GrpcClientFactory.grpc(transactionGrpc, tenantId, serviceAccount(), Constants.LOCALHOST)
                .finalizeTransaction(request))
            .map(result -> {
                if (result.hasRedirect()) {
                    Log.debugf("Finalize transaction returned redirect for Katarun payload reference=%s", payload.reference());
                }
                return Response.ok().build();
            });

    }


    private FinalizeTransactionRequest buildFinalizeRequest(KatarunWebhookPayload payload) {
        String transactionId = Optional.ofNullable(payload.reference())
                .orElseThrow(() -> new IllegalStateException("Unable to resolve transaction id from Katarun callback payload"));

        var status = switch (payload.eventType()) {
            case "purchase.paid" -> ProcessingCode.TRX_STATUS_APPROVED;
            case "purchase.payment_failure" -> ProcessingCode.TRX_STATUS_DECLINED;
            default -> throw new IllegalStateException("Unknown event type: " + payload.eventType());
        };

        var responseMessage =
            status == ProcessingCode.TRX_STATUS_DECLINED ?
            getErrorMessageFromAttempt(payload) : "success";

        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder()
                .setId(transactionId)
                .setStatus(status.getStatus())
                .setResponseCode(status.getCode())
                .setResponseMessage(responseMessage)
                .setPaymentProviderResponseMessage(responseMessage);

        Optional.ofNullable(payload.status()).ifPresent(builder::setPaymentProviderResponseCode);

        return builder.build();
    }

    private String getErrorMessageFromAttempt(KatarunWebhookPayload payload) {
        if(payload.transactionData() == null) {
            return "Transaction data is null";
        }

        var attempts = payload.transactionData().attempts();
        if(attempts == null || attempts.isEmpty()) {
            return "Transaction data attempts not found!";
        }
        var errors = attempts.stream()
            .map(KatarunWebhookPayload.TransactionData.Attempt::error)
            .filter(Objects::nonNull)
            .toList();

        return new JsonArray(errors).encode();
    }

    private GrpcApiUser serviceAccount() {
        return GrpcApiUser.serviceAccount(Set.of(), Map.of(), SERVICE_ACCOUNT);
    }

    private void logIncomingEvent(String outcome, KatarunWebhookPayload payload, String tenantId) {
        Log.infov(
                "Received Katarun {0} callback for tenant {1}: event={2}, reference={3}, status={4}",
                outcome,
                tenantId,
                Optional.ofNullable(payload).map(KatarunWebhookPayload::eventType).orElse("unknown"),
                Optional.ofNullable(payload).map(KatarunWebhookPayload::reference).orElse("n/a"),
                Optional.ofNullable(payload).map(KatarunWebhookPayload::status).orElse("n/a")
        );
    }
}
