package com.morefin.pg.katarun.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.keymanagementspi.keys.KeyManagementService;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProviderAccount;
import com.morefin.pg.katarun.client.KatarunDirectApiClient;
import com.morefin.pg.katarun.http.KatarunApiClient;
import com.morefin.pg.katarun.model.BrowserInfo;
import com.morefin.pg.katarun.model.KatarunConfig;
import com.morefin.pg.katarun.model.KatarunDirectPaymentResponse;
import com.morefin.pg.katarun.model.KatarunRefundContext;
import com.morefin.pg.katarun.model.KatarunTransactionContext;
import com.morefin.pg.katarun.util.KatarunObjectTransformer;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.RestClientBuilder;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.morefin.pg.common.Constants.*;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
public class KatarunTransactionManager {

    @Inject
    @RestClient
    KatarunApiClient apiClient;

    @Inject
    KeyManagementService keyManagementService;

    @Inject
    KatarunObjectTransformer objectTransformer;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    DtoMapperService mapperService;

    private final BiFunction<KatarunTransactionContext, Throwable, KatarunTransactionContext> defaultExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, failure));
        return context;
    };

    private final BiFunction<KatarunRefundContext, Throwable, KatarunRefundContext> defaultRefundHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildRefundErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> executeDirectPaymentRequest(CardAuthorizeContext authContext) {
        KatarunTransactionContext ctx = new KatarunTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_DECRYPT_CARD_DETAILS, this::decryptCardDetails)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, decrypted -> hydratePaymentContext(ctx, authContext, decrypted))
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::registerPaymentRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::doDirectPaymentRequest)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private Uni<KatarunTransactionContext> hydratePaymentContext(KatarunTransactionContext context, CardAuthorizeContext authContext, List<byte[]> decryptedCardData) {
        var transaction = authContext.authorizeContext().getTransaction();
        TypedPaymentProviderAccount paymentProviderAccount = authContext.authorizeContext().getPaymentProviderAccount();

        final BrowserInfo browserInfo = (transaction.getTransactionData() != null && transaction.getTransactionData().getOptions() != null)
                ? objectMapper.convertValue(transaction.getTransactionData().getOptions().get("browser_info"), BrowserInfo.class)
                : null;

        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx -> {
                    KatarunConfig rac = Utils.getRuntimeAccountConfig(paymentProviderAccount, KatarunConfig.class);
                    context.setContext(authContext);
                    context.setRuntimeAccountConfig(rac);
                    context.setTransaction(transaction);

                    context.setCardNumber(new String(decryptedCardData.get(0), StandardCharsets.UTF_8));
                    context.setCvc(new String(decryptedCardData.get(1), StandardCharsets.UTF_8));
                    context.setExpirationMonth(authContext.card().expirationMonth());
                    context.setExpirationYear(authContext.card().expirationYear());

                    context.setCardholderName(buildCardholderName(transaction.getCustomerFirstName(), transaction.getCustomerLastName()));
                    context.setAmount(transaction.getAmount());
                    context.setCurrency(transaction.getCurrency());
                    context.setReference(transaction.getId());
                    context.setUserIp(transaction.getUserIp());
                    context.setBrowserInfo(browserInfo);
                    if (transaction.getTransactionData() != null) {
                        context.setSuccessUrl(transaction.getTransactionData().getSuccessUrl());
                        context.setCancelUrl(transaction.getTransactionData().getCancelUrl());
                        context.setFailureUrl(transaction.getTransactionData().getErrorUrl());
                    }
                    context.setDescription(nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()));

                    return context;
                }).endSubPhase();
    }

    private Uni<List<byte[]>> decryptCardDetails(CardAuthorizeContext x) {
        return keyManagementService.decrypt(
                x.authorizeContext().getMerchant().getPrivateKey(),
                x.card().encryptedCardNumber(),
                x.card().encryptedCvv()
        );
    }

    private Uni<KatarunTransactionContext> registerPaymentRequest(KatarunTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_BUILD_PAYLOAD, objectTransformer::mapToPurchaseRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, req -> apiClient.createPurchase(req, addBearer(context.getRuntimeAccountConfig().secretKey())))
                .safeMap(PHASE_READ_PAYLOAD, response -> {
                    context.setPurchaseResponse(response);
                    return context;
                })
                .endSubPhase();
    }

    private Uni<KatarunTransactionContext> doDirectPaymentRequest(KatarunTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeFlatMap(PHASE_PREPARE_API_CLIENT, this::getDirectApiClient)
                .safeMap(PHASE_BUILD_PAYLOAD, objectTransformer::mapToDirectPaymentRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, req -> context.getDirectApiClient()
                        .directPaymentRequest(req, addBearer(resolveS2sToken(context))))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseDirectPaymentResponse(context, resp))
                .endSubPhase();
    }

    private Uni<KatarunTransactionContext> getDirectApiClient(KatarunTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_PREPARE_API_CLIENT, ctx -> {
                    if (context.getPurchaseResponse() == null || StringUtils.isBlank(context.getPurchaseResponse().directPostUrl())) {
                        throw new IllegalStateException("Katarun response does not contain direct post URL");
                    }
                    KatarunDirectApiClient directApiClient = RestClientBuilder.newBuilder()
                            .baseUri(context.getPurchaseResponse().directPostUrl())
                            .build(KatarunDirectApiClient.class);
                    ctx.setDirectApiClient(directApiClient);
                    return Uni.createFrom().item(ctx);
                })
                .endSubPhase();
    }

    private String addBearer(String token) {
        return "Bearer " + token;
    }

    private String resolveS2sToken(KatarunTransactionContext context) {
        if (context.getRuntimeAccountConfig() == null) {
            return "";
        }
        String token = context.getRuntimeAccountConfig().s2sToken();
        if (StringUtils.isBlank(token)) {
            token = context.getRuntimeAccountConfig().secretKey();
        }
        return token;
    }

    @SneakyThrows
    private KatarunTransactionContext parseDirectPaymentResponse(KatarunTransactionContext context, Response response) {
        context.setDirectPaymentResponseAsString(response.readEntity(String.class));
        context.setDirectPaymentResponse(mapperService.mapAndValidate(
                context.getDirectPaymentResponseAsString(),
                KatarunDirectPaymentResponse.class
        ));

        return context;
    }

    public Uni<ExecuteTransactionResponse> requestRefund(ManageTransactionContext manageContext) {
        KatarunRefundContext ctx = new KatarunRefundContext();
        return SafeUni.from(ctx, defaultRefundHandler, ctx)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateRefundContext(ctx1, manageContext))
                .safeFlatMap(PHASE_REQUEST_REFUND, this::requestPaymentRefund)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private KatarunRefundContext hydrateRefundContext(KatarunRefundContext context, ManageTransactionContext manageContext) {
        var parentTransactionRefNum = manageContext.transactionTypeContext().getParentTransaction().getReferenceNumber();

        KatarunConfig rac = Utils.getRuntimeAccountConfig(manageContext.transactionTypeContext().getPaymentProviderAccount(), KatarunConfig.class);
        context.setContext(manageContext);
        context.setRuntimeAccountConfig(rac);
        context.setReferenceNumber(parentTransactionRefNum);
        context.setRefundRequest(objectTransformer.buildRefundRequest(manageContext));

        return context;
    }

    private Uni<KatarunRefundContext> requestPaymentRefund(KatarunRefundContext context) {
        return SafeUni.from(context, defaultRefundHandler, context)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> apiClient.refundPurchase(context.getReferenceNumber(), context.getRefundRequest(), addBearer(context.getRuntimeAccountConfig().secretKey())))
                .safeMap(PHASE_READ_PAYLOAD, response -> {
                    context.setRefundResponse(response);
                    context.setRefundResponseAsString(JsonObject.mapFrom(response).toString());
                    return context;
                })
                .endSubPhase();
    }

    private String buildCardholderName(String firstName, String lastName) {
        return Stream.of(firstName, lastName)
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.joining(" "));
    }
}
