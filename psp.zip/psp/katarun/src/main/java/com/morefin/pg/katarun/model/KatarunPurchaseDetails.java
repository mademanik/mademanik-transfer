package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record KatarunPurchaseDetails(
        @JsonProperty("currency") String currency,
        @JsonProperty("products") List<KatarunPurchaseProduct> products,
        @JsonProperty("language") String language,
        @JsonProperty("notes") String notes,
        @JsonProperty("metadata") Map<String, Object> metadata
) {
}
