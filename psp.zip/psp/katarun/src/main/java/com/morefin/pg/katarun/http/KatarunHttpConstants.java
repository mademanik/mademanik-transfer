package com.morefin.pg.katarun.http;

/**
 * Shared HTTP constants for the Katarun PSP module.
 */
public final class KatarunHttpConstants {
    public static final String CALLBACK_URL = "psp/katarun/callback";
}
