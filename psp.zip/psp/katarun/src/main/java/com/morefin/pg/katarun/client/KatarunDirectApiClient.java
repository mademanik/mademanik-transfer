package com.morefin.pg.katarun.client;

import com.morefin.pg.katarun.model.KatarunDirectPaymentRequest;
import io.quarkus.rest.client.reactive.ClientQueryParam;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Produces(MediaType.APPLICATION_JSON)
public interface KatarunDirectApiClient {
    @POST
    @ClientQueryParam(name = "s2s", value = "true")
    Uni<Response> directPaymentRequest(KatarunDirectPaymentRequest requestPayload,
                                       @HeaderParam(HttpHeaders.AUTHORIZATION) String s2sToken);
}
