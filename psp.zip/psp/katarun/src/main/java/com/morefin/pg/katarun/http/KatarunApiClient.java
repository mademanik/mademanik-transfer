package com.morefin.pg.katarun.http;

import com.morefin.pg.katarun.model.KatarunCaptureRequest;
import com.morefin.pg.katarun.model.KatarunPurchaseRequest;
import com.morefin.pg.katarun.model.KatarunPurchaseResponse;
import com.morefin.pg.katarun.model.KatarunRefundRequest;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 * REST client for interacting with Katarun public API.
 */
@Path("/purchases")
@RegisterRestClient(configKey = "katarun")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface KatarunApiClient {

    /**
     * Create a new purchase in Katarun.
     */
    @POST
    @Path("/")
    Uni<KatarunPurchaseResponse> createPurchase(
            KatarunPurchaseRequest request,
            @HeaderParam(HttpHeaders.AUTHORIZATION) String authorization
    );

    /**
     * Retrieve purchase details from Katarun.
     */
    @GET
    @Path("/{id}/")
    Uni<KatarunPurchaseResponse> getPurchase(
            @PathParam("id") String purchaseId,
            @HeaderParam(HttpHeaders.AUTHORIZATION) String authorization
    );

    /**
     * Capture a previously authorized purchase.
     */
    @POST
    @Path("/{id}/capture/")
    Uni<KatarunPurchaseResponse> capturePurchase(
            @PathParam("id") String purchaseId,
            KatarunCaptureRequest request,
            @HeaderParam(HttpHeaders.AUTHORIZATION) String authorization
    );

    /**
     * Refund a purchase.
     */
    @POST
    @Path("/{id}/refund/")
    Uni<KatarunPurchaseResponse> refundPurchase(
            @PathParam("id") String purchaseId,
            KatarunRefundRequest request,
            @HeaderParam(HttpHeaders.AUTHORIZATION) String authorization
    );
}
