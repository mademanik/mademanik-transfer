package com.morefin.pg.katarun.util;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;

public class TransactionStatusMapper {
    public static ExecuteTransactionResponse.Status parseTransactionStatus(KatarunTransactionStatus transactionStatus) {
        return switch (transactionStatus) {
            case EXECUTED, AUTHORIZED, CAPTURED, REFUNDED, PAID, CANCELLED -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING, PENDING_CAPTURE, PENDING_CHARGE, PENDING_EXECUTE, THREEDS_REQUIRED, CREATED -> ExecuteTransactionResponse.Status.PENDING;
            case ERROR -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }
}
