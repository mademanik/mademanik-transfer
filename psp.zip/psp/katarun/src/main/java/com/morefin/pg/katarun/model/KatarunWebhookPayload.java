package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record KatarunWebhookPayload(
    @JsonProperty("id") String id,
    @JsonProperty("due") Long due,
    @JsonProperty("type") String type,
    @JsonProperty("event_type") String eventType,
    @JsonProperty("status") String status,
    @JsonProperty("reference") String reference,
    @JsonProperty("is_test") Boolean isTest,
    @JsonProperty("brand_id") String brandId,
    @JsonProperty("success_redirect") String successRedirect,
    @JsonProperty("failure_redirect") String failureRedirect,
    @JsonProperty("cancel_redirect") String cancelRedirect,
    @JsonProperty("payment") Payment payment,
    @JsonProperty("purchase") Purchase purchase,
    @JsonProperty("client") Client client,
    @JsonProperty("transaction_data") TransactionData transactionData,
    @JsonProperty("payment_method_whitelist") List<String> paymentMethodWhitelist,
    @JsonProperty("issued") String issued,
    @JsonProperty("product") String product,
    @JsonProperty("user_id") String userId,
    @JsonProperty("order_id") String orderId,
    @JsonProperty("platform") String platform,
    @JsonProperty("client_id") String clientId,
    @JsonProperty("viewed_on") Long viewedOn,
    @JsonProperty("company_id") String companyId,
    @JsonProperty("created_on") Long createdOn,
    @JsonProperty("updated_on") Long updatedOn,
    @JsonProperty("invoice_url") String invoiceUrl,
    @JsonProperty("can_retrieve") Boolean canRetrieve,
    @JsonProperty("checkout_url") String checkoutUrl,
    @JsonProperty("send_receipt") Boolean sendReceipt,
    @JsonProperty("skip_capture") Boolean skipCapture,
    @JsonProperty("creator_agent") String creatorAgent,
    @JsonProperty("referral_code") String referralCode,
    @JsonProperty("can_chargeback") Boolean canChargeback,
    @JsonProperty("issuer_details") IssuerDetails issuerDetails,
    @JsonProperty("marked_as_paid") Boolean markedAsPaid,
    @JsonProperty("status_history") List<StatusHistory> statusHistory,
    @JsonProperty("created_from_ip") String createdFromIp,
    @JsonProperty("direct_post_url") String directPostUrl,
    @JsonProperty("force_recurring") Boolean forceRecurring,
    @JsonProperty("recurring_token") String recurringToken,
    @JsonProperty("upsell_campaigns") List<String> upsellCampaigns,
    @JsonProperty("refundable_amount") Long refundableAmount,
    @JsonProperty("is_recurring_token") Boolean recurringTokenFlag,
    @JsonProperty("billing_template_id") String billingTemplateId,
    @JsonProperty("currency_conversion") Map<String, Object> currencyConversion,
    @JsonProperty("reference_generated") String referenceGenerated,
    @JsonProperty("refund_availability") String refundAvailability,
    @JsonProperty("referral_campaign_id") String referralCampaignId,
    @JsonProperty("retain_level_details") Map<String, Object> retainLevelDetails,
    @JsonProperty("referral_code_details") Map<String, Object> referralCodeDetails,
    @JsonProperty("referral_code_generated") String referralCodeGenerated) {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Payment(
      @JsonProperty("amount") Long amount,
      @JsonProperty("currency") String currency,
      @JsonProperty("fee_amount") Long feeAmount,
      @JsonProperty("net_amount") Long netAmount,
      @JsonProperty("payment_type") String paymentType,
      @JsonProperty("pending_amount") Long pendingAmount,
      @JsonProperty("paid_on") Long paidOn) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Purchase(
      @JsonProperty("total") Long total,
      @JsonProperty("currency") String currency,
      @JsonProperty("language") String language,
      @JsonProperty("metadata") Map<String, Object> metadata,
      @JsonProperty("products") List<Product> products,
      @JsonProperty("debt") Long debt,
      @JsonProperty("notes") String notes,
      @JsonProperty("timezone") String timezone,
      @JsonProperty("due_strict") Boolean dueStrict,
      @JsonProperty("email_message") String emailMessage,
      @JsonProperty("total_override") Long totalOverride,
      @JsonProperty("shipping_options") List<Map<String, Object>> shippingOptions,
      @JsonProperty("subtotal_override") Long subtotalOverride,
      @JsonProperty("total_tax_override") Long totalTaxOverride,
      @JsonProperty("has_upsell_products") Boolean hasUpsellProducts,
      @JsonProperty("payment_method_details") Map<String, Object> paymentMethodDetails,
      @JsonProperty("request_client_details") List<String> requestClientDetails,
      @JsonProperty("total_discount_override") Long totalDiscountOverride) {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Product(
        @JsonProperty("name") String name,
        @JsonProperty("price") Long price,
        @JsonProperty("quantity") String quantity,
        @JsonProperty("category") String category,
        @JsonProperty("discount") Long discount,
        @JsonProperty("tax_percent") String taxPercent,
        @JsonProperty("total_price_override") Long totalPriceOverride) {}
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record Client(
      @JsonProperty("email") String email,
      @JsonProperty("cc") List<String> cc,
      @JsonProperty("bcc") List<String> bcc,
      @JsonProperty("city") String city,
      @JsonProperty("phone") String phone,
      @JsonProperty("state") String state,
      @JsonProperty("country") String country,
      @JsonProperty("zip_code") String zipCode,
      @JsonProperty("bank_code") String bankCode,
      @JsonProperty("full_name") String fullName,
      @JsonProperty("brand_name") String brandName,
      @JsonProperty("legal_name") String legalName,
      @JsonProperty("tax_number") String taxNumber,
      @JsonProperty("client_type") String clientType,
      @JsonProperty("bank_account") String bankAccount,
      @JsonProperty("personal_code") String personalCode,
      @JsonProperty("shipping_city") String shippingCity,
      @JsonProperty("shipping_state") String shippingState,
      @JsonProperty("street_address") String streetAddress,
      @JsonProperty("delivery_methods") List<Map<String, Object>> deliveryMethods,
      @JsonProperty("shipping_country") String shippingCountry,
      @JsonProperty("shipping_zip_code") String shippingZipCode,
      @JsonProperty("registration_number") String registrationNumber,
      @JsonProperty("shipping_street_address") String shippingStreetAddress) {}

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record TransactionData(
      @JsonProperty("payment_method") String paymentMethod,
      @JsonProperty("flow") String flow,
      @JsonProperty("country") String country,
      @JsonProperty("extra") Map<String, Object> extra,
      @JsonProperty("attempts") List<Attempt> attempts) {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Attempt(
        @JsonProperty("flow") String flow,
        @JsonProperty("type") String type,
        @JsonProperty("error") AttemptError error,
        @JsonProperty("extra") Map<String, Object> extra,
        @JsonProperty("country") String country,
        @JsonProperty("client_ip") String clientIp,
        @JsonProperty("fee_amount") Long feeAmount,
        @JsonProperty("successful") Boolean successful,
        @JsonProperty("payment_method") String paymentMethod,
        @JsonProperty("processing_time") Long processingTime) {}

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record AttemptError(
        @JsonProperty("code") String code, @JsonProperty("message") String message) {}
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record IssuerDetails(
      @JsonProperty("website") String website,
      @JsonProperty("brand_name") String brandName,
      @JsonProperty("legal_city") String legalCity,
      @JsonProperty("legal_name") String legalName,
      @JsonProperty("tax_number") String taxNumber,
      @JsonProperty("bank_accounts") List<BankAccount> bankAccounts,
      @JsonProperty("legal_country") String legalCountry,
      @JsonProperty("legal_zip_code") String legalZipCode,
      @JsonProperty("registration_number") String registrationNumber,
      @JsonProperty("legal_street_address") String legalStreetAddress) {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record BankAccount(
        @JsonProperty("bank_code") String bankCode,
        @JsonProperty("bank_account") String bankAccount) {}
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonIgnoreProperties(ignoreUnknown = true)
  public record StatusHistory(
      @JsonProperty("status") String status, @JsonProperty("timestamp") Long timestamp) {}
}
