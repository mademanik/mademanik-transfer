package com.morefin.pg.katarun.common;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.gatewaygrpcservices.payments.paymentgateway.services.paymentprovider.PaymentProviderRepository;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.transaction.resourceactions.TransactionRepository;
import com.morefin.pg.katarun.client.Katarun3dsAuthorizeApiClient;
import com.morefin.pg.katarun.model.KatarunCallbackContext;
import com.morefin.pg.katarun.model.KatarunConfig;
import com.morefin.pg.katarun.model.KatarunDirectPaymentResponse;
import com.morefin.pg.katarun.util.KatarunObjectTransformer;
import com.morefin.pg.katarun.util.KatarunTransactionStatus;
import com.morefin.pg.katarun.util.TransactionStatusMapper;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

import java.net.URI;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;

@ApplicationScoped
public class Katarun3dsFinalizeManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    KatarunObjectTransformer objectTransformer;

    @Inject
    TransactionRepository transactionRepository;

    @Inject
    PaymentProviderRepository paymentProviderRepository;

    @Inject
    DtoMapperService mapperService;

    BiFunction<KatarunCallbackContext, Throwable, KatarunCallbackContext> defaultFinalizeExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(context, failure));
        return context;
    };

    public Uni<Response> finalize3dTransaction(String referenceNumber, MultivaluedMap<String, String> callbackRequest, String tenantId) {
        KatarunCallbackContext ctx = new KatarunCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateCallbackContext(ctx1, referenceNumber, callbackRequest, tenantId))
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::completeAuthorization)
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifyResponse)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinal3dResponse);
    }

    private Uni<KatarunCallbackContext> hydrateCallbackContext(KatarunCallbackContext ctx, String referenceNumber, MultivaluedMap<String, String> callbackRequestAsMap, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseCallbackRequest(ctx, referenceNumber, callbackRequestAsMap, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    private KatarunCallbackContext parseCallbackRequest(KatarunCallbackContext ctx, String referenceNumber, MultivaluedMap<String, String> callbackRequestAsMap, String tenantId) {
        ctx.setTenantId(tenantId);
        ctx.setReferenceNumber(referenceNumber);
        ctx.setCallbackRequestAsMap(callbackRequestAsMap);
        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    private Uni<KatarunCallbackContext> getTransactionData(KatarunCallbackContext ctx) {
        return transactionRepository.withTransaction(connection ->
                transactionRepository.findByReferenceNumber(connection, ctx.getTenantId(), ctx.getReferenceNumber())
                        .map(optionalTransaction -> optionalTransaction
                                .map(transaction -> {
                                    ctx.setTransactionEntity(transaction);
                                    ctx.setTransactionId(transaction.getId());
                                    return ctx;
                                })
                                .orElseThrow(() -> new IllegalStateException("Transaction not found"))
                        ));
    }

    private Uni<KatarunCallbackContext> getPaymentProviderAccountDataByPpaId(KatarunCallbackContext ctx) {
        return paymentProviderRepository.findAccountBy(ctx.getTenantId(), ctx.getTransactionEntity().getPaymentProviderAccountId())
                .map(optionalAccount -> optionalAccount
                        .map(ppa -> {
                            ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, KatarunConfig.class));
                            return ctx;
                        })
                        .orElseThrow(() -> new IllegalStateException("PaymentProviderAccount not found")));
    }

    private Uni<KatarunCallbackContext> completeAuthorization(KatarunCallbackContext ctx) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_PREPARE_API_CLIENT, ctx1 -> {
                    var data = ctx.getTransactionEntity().getData().getMap();
                    Object callbackUrl = data.get("callback_url");
                    if (callbackUrl == null) {
                        throw new IllegalStateException("Missing callback_url for Katarun 3DS finalize");
                    }
                    Katarun3dsAuthorizeApiClient apiClient = RestClientBuilder.newBuilder()
                            .baseUri(callbackUrl.toString())
                            .build(Katarun3dsAuthorizeApiClient.class);
                    ctx.setKatarun3dsAuthorizeApiClient(apiClient);
                    return Uni.createFrom().item(ctx);
                })
                .safeFlatMap(PHASE_REQUEST_PAYMENT, ctx1 -> ctx.getKatarun3dsAuthorizeApiClient().completeAuthorization(ctx.getCallbackRequestAsMap()))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseDirectPaymentResponse(ctx, resp))
                .endSubPhase();
    }

    @SneakyThrows
    private KatarunCallbackContext parseDirectPaymentResponse(KatarunCallbackContext context, Response response) {
        context.setDirectPaymentResponseAsString(response.readEntity(String.class));
        context.setDirectPaymentResponse(mapperService.mapAndValidate(context.getDirectPaymentResponseAsString(), KatarunDirectPaymentResponse.class));
        return context;
    }

    private KatarunCallbackContext verifyResponse(KatarunCallbackContext ctx) {
        KatarunTransactionStatus transactionStatus = KatarunTransactionStatus.fromValue(ctx.getDirectPaymentResponse().getStatus());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        switch (status) {
            case DECLINED, ERROR -> ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, new Exception("Failed to make payment")));
        }
        return ctx;
    }

    private Response buildFinal3dResponse(KatarunCallbackContext ctx) {
        KatarunTransactionStatus transactionStatus = KatarunTransactionStatus.fromValue(ctx.getDirectPaymentResponse().getStatus());
        ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

        switch (status) {
            case APPROVED, PENDING -> {
                URI locationUri = URI.create(ctx.getTransactionEntity().getTransactionData().getSuccessUrl());
                return Response.seeOther(locationUri).build();
            }
            default -> {
                URI locationUri = URI.create(ctx.getTransactionEntity().getTransactionData().getErrorUrl());
                return Response.seeOther(locationUri).build();
            }
        }
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }

    private Uni<KatarunCallbackContext> sendGrpcFinalizeRequest(KatarunCallbackContext ctx) {
        return ctx.getTransactionGrpc()
                .finalizeTransaction(ctx.getFinalizeRequest())
                .map(response -> {
                    ctx.setFinalizeResponse(response);
                    return ctx;
                });
    }
}
