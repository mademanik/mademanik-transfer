package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record KatarunRefundRequest(
        @JsonProperty("amount") Long amount,
        @JsonProperty("reason") String reason,
        @JsonProperty("comment") String comment
) {
}
