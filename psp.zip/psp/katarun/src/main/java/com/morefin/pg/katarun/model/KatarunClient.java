package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record KatarunClient(
        @JsonProperty("id") String id,
        @JsonProperty("email") String email,
        @JsonProperty("phone") String phone,
        @JsonProperty("country") String country,
        @JsonProperty("full_name") String fullName,
        @JsonProperty("street_address") String streetAddress,
        @JsonProperty("zip_code") String zipCode,
        @JsonProperty("city") String city
) {
}
