package com.morefin.pg.katarun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record KatarunPurchaseProduct(
        @JsonProperty("name") String name,
        @JsonProperty("price") Long price,
        @JsonProperty("quantity") String quantity,
        @JsonProperty("discount") Long discount,
        @JsonProperty("tax_percent") String taxPercent,
        @JsonProperty("category") String category,
        @JsonProperty("total_price_override") Long totalPriceOverride
) {
}
