package com.morefin.pg.flexepin.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherAuthorizeContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.pg.flexepin.models.ApiResponseDto;
import com.morefin.pg.flexepin.models.AuthorizationContext;
import com.morefin.pg.utils.SignatureUtils;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import static com.morefin.pg.flexepin.util.Constants.CUSTOM_API_ERROR_CODE;
import static com.morefin.pg.flexepin.util.Constants.CUSTOM_ERROR_CODE_INTERNAL;
import static com.morefin.pg.flexepin.util.Constants.REDEEM_HTTP_FORMAT;
import static com.morefin.pg.flexepin.util.Constants.REDEEM_HTTP_METHOD;
import static com.morefin.pg.flexepin.util.Constants.UNEXPECTED_RESPONSE_ERROR;

@ApplicationScoped
public class FlexepinObjectTransformer {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Inject
    SignatureUtils signatureUtils;

    public Uni<Response> createInternalErrorResponse(Throwable e) {
        Log.error(e);
        return Uni.createFrom().item(Response.ok(ApiResponseDto.builder()
                .result(String.valueOf(CUSTOM_ERROR_CODE_INTERNAL))
                .resultDescription(e.getMessage())
                .build()
        ).build());
    }

    public ApiResponseDto createUnexpectedResponseError(Throwable e) {
        Log.errorv("Exception during the deserialization of received API Response. Received exception {0}", e);
        return ApiResponseDto.builder()
                .result(String.valueOf(UNEXPECTED_RESPONSE_ERROR))
                .resultDescription("Unexpected response format, Exception occurred: " + e.getMessage())
                .build();
    }

    public String createApiInvocationError(Throwable e) {
        Log.errorv("Exception during the deserialization of received API Response.Received exception {0}", e);
        try {
            return objectMapper.writeValueAsString(ApiResponseDto.builder()
                    .result(String.valueOf(CUSTOM_API_ERROR_CODE))
                    .resultDescription("Invocation Exception " + e.getMessage())
                    .build());
        } catch (JsonProcessingException ex) {
            return String.format("{\"error\": \"%s\", \"description\": \"%s\"}", CUSTOM_API_ERROR_CODE, e.getMessage());
        }
    }

    public String getCustomerIpData(VoucherAuthorizeContext context) {
        //TODO get and transform customer IP data here
        try {
            ObjectNode customerIpData = objectMapper.createObjectNode();
            customerIpData.put("country", "France");
            customerIpData.put("region", "Île-de-France");
            customerIpData.put("city", "Paris");
            customerIpData.put("latitude", "48.8566");
            customerIpData.put("longitude", "2.3522");
            return objectMapper.writeValueAsString(customerIpData);
        } catch (JsonProcessingException e) {
            return "{\"customerIpData\": \"NA\"}";
        }
    }

    public Uni<ExecuteTransactionResponse> convertToTransactionResponse(ApiResponseDto response, AuthorizationContext context) {
        return Uni.createFrom().item(buildResponse(response, context.transactionId(), context.reference()));
    }

    public CombinedPayload getCombinedPayload(AuthorizationContext context) {
        String requestPayload = createRedeemRequestPayload(context);
        String urlPath = String.format(REDEEM_HTTP_FORMAT, context.voucherPin(), context.terminalId(), context.transactionId());
        String hmacToken = calculateHmacToken(urlPath, context.reference(), requestPayload, context.runtimeAccountConfig().apiKey(), context.runtimeAccountConfig().apiSecret());
        return new CombinedPayload(requestPayload, hmacToken);
    }

    public ApiResponseDto convertToApiResponse(String response) {
        try {
            return objectMapper.readValue(response, ApiResponseDto.class);
        } catch (JsonProcessingException e) {
            Log.errorv("Received unexpected API response:\n{0}", response);
            return createUnexpectedResponseError(e);
        }
    }

    private ExecuteTransactionResponse buildResponse(ApiResponseDto response, String tid, String reference) {
        int resultCode = (response.error() != 0) ? response.error() : Integer.parseInt(response.result());
        FlexepinResponseResultMapper resultMapper = FlexepinResponseResultMapper.fromValue(resultCode);
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        var pspRespMessage = StringUtils.isBlank(response.result()) ? response.resultDescription() : response.result();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(resultMapper.getResponseCode().name(), builder::setResponseCode)
                                .set(StringUtils.abbreviate(resultMapper.getDescription(), 49), builder::setResponseMessage)
                                .set(pspRespMessage, builder::setPaymentProviderResponseMessage)
                                .set(String.valueOf(resultCode), builder::setPaymentProviderResponseCode)
                                .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                                .set(tid, builder::setId)
                                .setAny(resultMapper.getTransactionStatus(), builder::setStatus)
                                .set(reference, builder::setReferenceNumber)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private String createRedeemRequestPayload(AuthorizationContext context) {
        try {
            String customerId = String.format("%s_%s_%s_%s",
                    context.userId(),
                    context.customerData().firstName(),
                    context.customerData().lastName(),
                    context.customerData().id());

            ObjectNode jsonPayloadNode = objectMapper.createObjectNode();
            jsonPayloadNode.put("customer_id", customerId);
            jsonPayloadNode.put("customer_ip", context.userIp());
            jsonPayloadNode.put("customer_ip_data", context.userIpData());
            return objectMapper.writeValueAsString(jsonPayloadNode);
        } catch (Exception e) {
            String errorMsg = String.format("Failed to create redeem request payload for transaction %s\n%s", context.transactionId(), e.getMessage());
            Log.errorv(errorMsg, e);
            throw new RuntimeException(errorMsg, e);
        }
    }


    private String calculateHmacToken(String urlPath, String reference, String requestPayload, String apiKey, String apiSecret) {
        try {
            String plainSignature = String.format(
                    "%s\n%s\n%s\n%s",
                    REDEEM_HTTP_METHOD,
                    urlPath,
                    reference,
                    requestPayload
            );
            //Encrypt with HMAC Sha256  the signature body
            String encryptedSignature = signatureUtils.generateHmacSHA256Signature(apiSecret, plainSignature);
            //Create auth header
            return String.format("HMAC %s:%s:%s", apiKey, encryptedSignature, reference);
        } catch (Exception e) {
            Log.error("Failed to calculate HMAC token", e);
            throw new RuntimeException("Failed to calculate HMAC token", e);
        }
    }
}
