package com.morefin.pg.flexepin.util;

public class Constants {
    public static final String REDEEM_HTTP_METHOD = "PUT";
    //Create UrlPath used for request
    public static final String REDEEM_HTTP_FORMAT = "/voucher/redeem/%s/%s/%s";

    public static final String HMAC_ALGORITHM = "HmacSHA256";
    public static final String AUTH_HEADER_NAME = "AUTHENTICATION";
    public static final int CUSTOM_ERROR_CODE_INTERNAL = -999;
    public static final int UNEXPECTED_RESPONSE_ERROR = -888;
    public static final int CUSTOM_API_ERROR_CODE= -777;

}
