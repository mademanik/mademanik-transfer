package com.morefin.pg.flexepin.voucher;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.pg.flexepin.client.FlexepinApiClient;
import com.morefin.pg.flexepin.models.AuthorizationContext;
import com.morefin.pg.flexepin.util.CombinedPayload;
import com.morefin.pg.flexepin.util.FlexepinObjectTransformer;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import org.eclipse.microprofile.rest.client.inject.RestClient;

@ApplicationScoped
public class AuthorizeTransactionManager {

    @RestClient
    @Inject
    FlexepinApiClient apiClient;

    @Inject
    FlexepinObjectTransformer objectTransformer;

    public Uni<ExecuteTransactionResponse> authorize(AuthorizationContext context) {

        return Uni.createFrom().item(context)
                .map(objectTransformer::getCombinedPayload)
                .onFailure().recoverWithItem(CombinedPayload::new)
                .flatMap(combinedPayload -> {
                    if (combinedPayload.getError() != null) {
                        Log.error("Request payload creation failed", combinedPayload.getError());
                        return objectTransformer.createInternalErrorResponse(combinedPayload.getError());
                    }
                    return apiClient.redeem(
                            context.voucherPin(),
                            context.terminalId(),
                            context.transactionId(),
                            combinedPayload.getHmacToken(),
                            combinedPayload.getRequestPayload());
                })
                .onItemOrFailure()
                .transform((response, failure) -> {
                    if (failure == null) {
                        return response.readEntity(String.class);
                    }
                    return ((WebApplicationException) failure).getResponse().readEntity(String.class);
                })
                .onFailure().recoverWithItem(objectTransformer::createApiInvocationError)
                .map(objectTransformer::convertToApiResponse)
                .onFailure().recoverWithItem(objectTransformer::createUnexpectedResponseError)
                .flatMap(response -> objectTransformer.convertToTransactionResponse(response, context));
    }
}

