package com.morefin.pg.flexepin.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public record ApiResponseDto(
        @JsonProperty("transaction_id") String transactionId,
        @JsonProperty("trans_no") String transNo,
        @JsonProperty("result") String result,
        @JsonProperty("result_description") String resultDescription,
        @JsonProperty("serial") String serial,
        @JsonProperty("value") int value,
        @JsonProperty("cost") int cost,
        @JsonProperty("currency") String currency,
        @JsonProperty("status") String status,
        @JsonProperty("description") String description,
        @JsonProperty("ean") String ean,
        @JsonProperty("error") int error) {
}