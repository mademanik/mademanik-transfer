package com.morefin.pg.flexepin.voucher;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherPaymentProcessingService;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.CustomerData;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessingspi.JavaPaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.pg.flexepin.models.AuthorizationContext;
import com.morefin.pg.flexepin.models.FlexepinPaymentMethodData;
import com.morefin.pg.flexepin.models.RuntimeAccountConfig;
import com.morefin.pg.flexepin.util.FlexepinObjectTransformer;
import com.morefin.pg.flexepin.voucher.admin.Config;
import com.morefin.pg.flexepin.voucher.admin.FlexepinAdminPaymentProcessingServiceImpl;
import com.morefin.pg.flexepin.voucher.admin.FlexepinPaymentMethodTypeModule;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Map;
import java.util.Optional;

@ApplicationScoped
@Unremovable
public class FlexepinPaymentProcessingServiceImpl implements VoucherPaymentProcessingService {

    @Inject
    AuthorizeTransactionManager authorizeTransactionManager;

    @Inject
    Config config;

    @Inject
    FlexepinAdminPaymentProcessingServiceImpl adminPaymentProcessingService;

    @Inject
    protected FlexepinObjectTransformer objectTransformer;

    @Override
    public Uni<ExecuteTransactionResponse> authorize(VoucherAuthorizeContext context) {
        var transaction = context.transaction();
        var runtimeAccountConfig = context.paymentProviderAccount().getData().getJsonObject("configuration").mapTo(RuntimeAccountConfig.class);

        return authorizeTransactionManager.authorize(
                new AuthorizationContext(
                        runtimeAccountConfig,
                        transaction.getId(),
                        transaction.getTerminalId(),
                        JsonObject.mapFrom(context.paymentMethod().data()).mapTo(FlexepinPaymentMethodData.class).voucherPin(),
                        transaction.getUserId(),
                        transaction.getUserIp(),
                        objectTransformer.getCustomerIpData(context),
                        transaction.getReference(),
                        new CustomerData(
                                transaction.getCustomerFirstName(),
                                transaction.getCustomerLastName(),
                                null, null, null, null, null, null,
                                transaction.getCustomerId()
                        )
                )
        );
    }

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return FlexepinPaymentMethodTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public String masked(String s, Map<String, String> map) {
        return "****";
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return new JavaPaymentProviderServiceConfig(config.providerSettings(), true, config.accountSettings());
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }

}
