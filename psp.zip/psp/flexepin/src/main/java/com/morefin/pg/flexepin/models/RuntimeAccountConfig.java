package com.morefin.pg.flexepin.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
    @JsonProperty("api_key")
    String apiKey,
    @JsonProperty("api_secret")
    String apiSecret

) {
}
