package com.morefin.pg.flexepin.util;

import lombok.Data;

@Data
public class CombinedPayload {
    String requestPayload;
    String hmacToken;
    Throwable error;

    public CombinedPayload(String requestPayload, String hmacToken) {
        this.requestPayload = requestPayload;
        this.hmacToken = hmacToken;
    }

    public CombinedPayload(Throwable error) {
        this.error = error;
    }
}