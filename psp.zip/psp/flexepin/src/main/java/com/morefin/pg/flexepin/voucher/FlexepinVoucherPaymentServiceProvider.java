package com.morefin.pg.flexepin.voucher;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherPaymentProcessingServiceProvider;
import com.morefin.pg.flexepin.voucher.admin.FlexepinPaymentMethodTypeModule;
import io.quarkus.arc.Arc;

public class FlexepinVoucherPaymentServiceProvider implements VoucherPaymentProcessingServiceProvider {
    @Override
    public VoucherPaymentProcessingService create() {
        try (var instance = Arc.container().instance(FlexepinPaymentProcessingServiceImpl.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return FlexepinPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return FlexepinPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return FlexepinPaymentMethodTypeModule.MODULE_ID;
    }
}
