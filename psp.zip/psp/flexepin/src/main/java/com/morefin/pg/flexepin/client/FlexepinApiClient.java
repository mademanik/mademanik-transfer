package com.morefin.pg.flexepin.client;

import io.quarkus.rest.client.reactive.ComputedParamContext;
import io.quarkus.rest.client.reactive.NotBody;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import static com.morefin.pg.flexepin.util.Constants.AUTH_HEADER_NAME;

@Path("/voucher")
@RegisterRestClient(configKey = "flexepin")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface FlexepinApiClient {

    @PUT
    @Path("/redeem/{voucherPin}/{terminalId}/{transactionId}")
    @ClientHeaderParam(name = AUTH_HEADER_NAME, value = "{getHmacToken}")
    Uni<Response> redeem(@PathParam("voucherPin") String voucherPin,
                         @PathParam("terminalId") String terminalId,
                         @PathParam("transactionId") String transactionId,
                         @NotBody String hmacToken,
                         String requestBody);


    @GET
    @Path("/validate/{voucherPin}/{terminalId}/{transactionId}")
    @ClientHeaderParam(name = AUTH_HEADER_NAME, value = "{getHmacToken}")
    Uni<Response> validate(@PathParam("voucherPin") String voucherPin,
                           @PathParam("terminalId") String terminalId,
                           @PathParam("transactionId") String transactionId,
                           @NotBody String hmacToken);


    default String getHmacToken(ComputedParamContext context) {
        return context.methodParameters().get(3).value().toString();
    }
}
