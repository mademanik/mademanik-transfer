package com.morefin.pg.flexepin.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public record FlexepinPaymentMethodData(
        @JsonProperty("voucherPin") String voucherPin
) {
}
