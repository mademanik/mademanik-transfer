package com.morefin.pg.flexepin.util;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import lombok.Getter;

import static com.morefin.pg.flexepin.util.Constants.CUSTOM_API_ERROR_CODE;
import static com.morefin.pg.flexepin.util.Constants.CUSTOM_ERROR_CODE_INTERNAL;
import static com.morefin.pg.flexepin.util.Constants.UNEXPECTED_RESPONSE_ERROR;

@Getter
public enum FlexepinResponseResultMapper {
    INTERNAL_ERROR(CUSTOM_ERROR_CODE_INTERNAL, "Internal error during creation of request payload", "Internal error during creation of request payload", ProcessingCode.TRX_STATUS_FAILED, ExecuteTransactionResponse.Status.ERROR),
    UNEXPECTED_RESPONSE_ERROR_CODE(UNEXPECTED_RESPONSE_ERROR, "Unexpected response format", "Unexpected API response format", ProcessingCode.TRX_STATUS_FAILED, ExecuteTransactionResponse.Status.ERROR),
    API_ERROR(CUSTOM_API_ERROR_CODE, "API invocation exception", "Unexpected failure during API invocation", ProcessingCode.TRX_STATUS_FAILED, ExecuteTransactionResponse.Status.ERROR),
    SUCCESS(0, "Success", "Transaction has been processed successfully", ProcessingCode.TRX_STATUS_APPROVED, ExecuteTransactionResponse.Status.APPROVED),
    UNAUTHENTICATED(401, "You are not authorized or authenticated to access this resource", "You are not authorized or authenticated to access this resource", ProcessingCode.TRX_STATUS_FAILED, ExecuteTransactionResponse.Status.ERROR),
    UNAUTHORIZED(403, "You are not authorized to access this resource", "You are not authorized to access this resource", ProcessingCode.TRX_STATUS_FAILED, ExecuteTransactionResponse.Status.ERROR),
    ERROR(503, "Error - Maintenance Mode", "Maintenance Mode", ProcessingCode.INVALID_REQUEST_MERCHANT_INACTIVE, ExecuteTransactionResponse.Status.ERROR),
    NOT_ACCEPTED(4019, "Voucher Type or value is not accepted", "The voucher type or Value is not accepted by merchant", ProcessingCode.TRX_STATUS_DECLINED, ExecuteTransactionResponse.Status.DECLINED),
    LOCKED(4071, "Voucher Type or value is not accepted", "The voucher type or Value is not accepted by merchant", ProcessingCode.TRX_STATUS_CANCELED, ExecuteTransactionResponse.Status.DECLINED),
    USED(4072, "Voucher is used", "The voucher has already been used", ProcessingCode.TRX_STATUS_DECLINED, ExecuteTransactionResponse.Status.DECLINED),
    NOT_ACTIVE(4073, "Voucher is not active", "The voucher is not in an active status and can not be used", ProcessingCode.TRX_STATUS_DECLINED, ExecuteTransactionResponse.Status.DECLINED),
    EXPIRED(4074, "Voucher is expired", "The voucher has expired and can not be used", ProcessingCode.TRX_STATUS_DECLINED, ExecuteTransactionResponse.Status.DECLINED),
    NOT_FOUND(4075, "Voucher is not found", "The voucher can not be found", ProcessingCode.TRX_STATUS_DECLINED, ExecuteTransactionResponse.Status.DECLINED),
    INSUFFICIENT_VALUE(4080, "Voucher has insufficient value", "The voucher value is insufficient for the request", ProcessingCode.TRX_STATUS_DECLINED_INSUFFICIENT_FUNDS, ExecuteTransactionResponse.Status.DECLINED),
    STORE_DATA_NOT_AVAILABLE(5000, "Store data is not available", "Store data is not available", ProcessingCode.TRX_STATUS_DECLINED, ExecuteTransactionResponse.Status.DECLINED),
    QUARANTINED(10251, "Voucher is Quarantined", "The voucher presented for redemption is Quarantined", ProcessingCode.TRX_STATUS_CANCELED, ExecuteTransactionResponse.Status.DECLINED);

    private final int value;
    private final String description;
    private final String meaning;
    private final ProcessingCode responseCode;
    private final ExecuteTransactionResponse.Status transactionStatus;

    FlexepinResponseResultMapper(int value, String description, String meaning, ProcessingCode responseCode, ExecuteTransactionResponse.Status transactionStatus) {
        this.value = value;
        this.description = description;
        this.meaning = meaning;
        this.responseCode = responseCode;
        this.transactionStatus = transactionStatus;
    }

    public static FlexepinResponseResultMapper fromValue(int value) {
        for (FlexepinResponseResultMapper mapper : FlexepinResponseResultMapper.values()) {
            if (mapper.value == value) {
                return mapper;
            }
        }
        throw new IllegalArgumentException("Unknown value: " + value);
    }
}
