package com.morefin.pg.flexepin.models;

import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.CustomerData;

public record AuthorizationContext(
        RuntimeAccountConfig runtimeAccountConfig,
        String transactionId,
        String terminalId,
        String voucherPin,
        String userId,
        String userIp,
        String userIpData,
        String reference,
        CustomerData customerData
) {
}
