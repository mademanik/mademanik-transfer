package com.morefin.pg.mifinity.util;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.common.TransactionStatusMapper;
import com.morefin.pg.common.TransactionUtils;
import com.morefin.pg.mifinity.http.MifinityCallbackResource;
import com.morefin.pg.mifinity.model.AccountToAccountTransferDto;
import com.morefin.pg.mifinity.model.AccountToAccountTransferResponseDto;
import com.morefin.pg.mifinity.model.ErrorResponseDto;
import com.morefin.pg.mifinity.model.InitIframeDto;
import com.morefin.pg.mifinity.model.MifinityCallbackContext;
import com.morefin.pg.mifinity.model.MifinityTransactionContext;
import com.morefin.pg.mifinity.model.MifinityWithdrawalContext;
import com.morefin.pg.mifinity.model.PayAnyBankDto;
import com.morefin.pg.mifinity.model.PayAnyBankResponseDto;
import com.morefin.pg.mifinity.model.PaymentStatusResponseDto;
import com.morefin.pg.mifinity.model.RuntimeAccountConfig;
import com.morefin.pg.mifinity.http.MifinityWidgetPage;
import com.morefin.pg.mifinity.util.Constants;
import com.morefin.pg.model.RequestValidationException;
import com.morefin.pg.model.UnexpectedResponseException;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.safeuni.ErrorDescription;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.tuples.Tuple2;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.UriBuilder;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_READ_PAYLOAD;
import static com.morefin.pg.common.Constants.PHASE_REQUEST_PAYMENT;
import static com.morefin.pg.common.Constants.PHASE_VALIDATE_REQUEST;
import static com.morefin.pg.common.Constants.REASON_API_INVOCATION_FAILURE;
import static com.morefin.pg.common.Constants.REASON_INVALID_INPUT;
import static com.morefin.pg.common.Constants.REASON_TIMEOUT;
import static com.morefin.pg.common.Constants.REASON_UNAUTHORIZED;
import static com.morefin.pg.common.Constants.REASON_UNEXPECTED_RESPONSE_FORMAT;
import static com.morefin.pg.common.Constants.REASON_UNKNOWN_API_ERROR;
import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class MifinityObjectTransformer {

    @Inject
    TransactionUtils transactionUtils;

    public InitIframeDto buildPaymentRequest(TransactionTypeContext context, RuntimeAccountConfig accountConfig) {
        var transaction = context.getTransaction();

        var money = MifinityObjectTransformer.mapToMoney(transaction);
        var client = MifinityObjectTransformer.mapToClient(transaction);
        var address = MifinityObjectTransformer.mapToAddress(transaction);

        var successUrl = UriBuilder.fromUri(context.getTenantConfig().url())
                .path(MifinityCallbackResource.class)
                .path(MifinityCallbackResource.class, "returnSuccess")
                .build().toString();
        var errorUrl = UriBuilder.fromUri(context.getTenantConfig().url())
                .path(MifinityCallbackResource.class)
                .path(MifinityCallbackResource.class, "returnError")
                .build().toString();

        return new InitIframeDto(
                transaction.getDescription(),
                accountConfig.brandId(),
                accountConfig.destinationAccountNumber(),
                transaction.getId(),
                generateUniqueKey(),
                successUrl,
                errorUrl,
                generateCustomerId(context), //TODO replace with transaction.getCustomerId() when has real value
                money,
                client,
                address,
                accountConfig.paymentMethod()
        );
    }

    /**
     * Generates a cryptographically secure, random Base64-encoded key with a length between 48 and 255 characters.
     * <p>
     * The function uses {@link SecureRandom} to generate a random number of bytes, which are then encoded using
     * {@link Base64} with URL-safe encoding (without padding). The length of the key is chosen randomly
     * within the specified range (48 to 255 characters).
     *
     * @return A randomly generated, URL-safe Base64-encoded string with a length between 48 and 255 characters.
     */
    public String generateUniqueKey() {
        SecureRandom random = new SecureRandom();

        int length = 48 + random.nextInt(208); // 208 = (255 - 48 + 1)

        byte[] bytes = new byte[length];
        random.nextBytes(bytes);

        String key = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        return key.substring(0, Math.min(length, key.length())); // Trim to required length
    }

    private String generateCustomerId(TransactionTypeContext context) {
        return StringUtils.substring(String.format("%s_%s_%s", context.getTransaction().getCustomerFirstName(),
                context.getTransaction().getCustomerLastName(),
                context.getTransaction().getCustomerEmail()), 0, 48);
    }

    public static InitIframeDto.Client mapToClient(ImmutableTypedTransactionEntity transaction) {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        String nationalNumber = null;
        String countryCode = null;

        try {
            var parsedNumber = phoneUtil.parse(transaction.getCustomerPhoneNumber(),
                    transaction.getCustomerCountry().length() == 2 ? transaction.getCustomerCountry() : null);

            nationalNumber = String.valueOf(parsedNumber.getNationalNumber());
            countryCode = "+" + parsedNumber.getCountryCode();

        } catch (NumberParseException e) {
            Log.errorf("Invalid phone number=%s", transaction.getCustomerPhoneNumber());
        }

        return new InitIframeDto.Client(
                transaction.getCustomerFirstName(),
                transaction.getCustomerLastName(),
                transaction.getCustomerEmail(),
                transaction.getCustomerCountry(),
                "1991-01-01", // TODO: replace with real birthdate
                nationalNumber,
                countryCode
        );
    }

    public static InitIframeDto.Address mapToAddress(ImmutableTypedTransactionEntity transaction) {
        return new InitIframeDto.Address(
                transaction.getCustomerAddress(),
                transaction.getCustomerCountry(),
                transaction.getCustomerCity(),
                transaction.getCustomerPostalCode()
        );
    }

    public static InitIframeDto.Money mapToMoney(ImmutableTypedTransactionEntity transaction) {
        return new InitIframeDto.Money(
                BigDecimal.valueOf(transaction.getAmount()).divide(BigDecimal.valueOf(100)).toString(),
                transaction.getCurrency()
        );
    }

    public AccountToAccountTransferDto buildWithdrawalRequest(TransactionTypeContext context, RuntimeAccountConfig accountConfig, String destinationAccount) {
        var transaction = context.getTransaction();
        var money = mapToMoney(transaction);
        return new AccountToAccountTransferDto(
                accountConfig.destinationAccountNumber(),
                destinationAccount,
                money,
                transaction.getDescription(),
                transaction.getId()
        );
    }

    public PayAnyBankDto buildPayAnyBankRequest(TransactionTypeContext context, RuntimeAccountConfig accountConfig, Map<String, String> paymentMethodData) {
        var transaction = context.getTransaction();
        var money = mapToMoney(transaction);
        
        var customerName = StringUtils.trimToEmpty(transaction.getCustomerFirstName()) + 
                          (StringUtils.isNotBlank(transaction.getCustomerLastName()) ? 
                           " " + StringUtils.trimToEmpty(transaction.getCustomerLastName()) : "");
        
        var fields = Map.of(
                "IBAN", paymentMethodData.getOrDefault("IBAN", ""),
                "BIC", paymentMethodData.getOrDefault("BIC", ""),
                "BANK_NAME", paymentMethodData.getOrDefault("BANK_NAME", ""),
                "CUSTOMER_NAME", customerName,
                "CUSTOMER_ADDRESS", StringUtils.defaultString(transaction.getCustomerAddress()),
                "CUSTOMER_CITY", StringUtils.defaultString(transaction.getCustomerCity()),
                "CUSTOMER_ZIP", StringUtils.defaultString(transaction.getCustomerPostalCode())
        );
        
        var country = paymentMethodData.getOrDefault("country", transaction.getCustomerCountry());
        var currency = paymentMethodData.getOrDefault("currency", transaction.getCurrency());
        var description = transaction.getDescription();
        
        var bankPayee = new PayAnyBankDto.BankPayee(
                country,
                currency,
                description,
                fields
        );
        
        return new PayAnyBankDto(
                accountConfig.destinationAccountNumber(),
                transaction.getId(),
                description,
                money,
                bankPayee
        );
    }

    public MifinityCallbackContext buildFinalizeTransactionRequest(MifinityCallbackContext callbackContext) {
        callbackContext.setFinalizeRequest(
                PaymentStatusResponseDto.Status.SUCCESSFUL == callbackContext.getCallbackPaymentStatus() ?
                        FinalizeTransactionRequest.newBuilder()
                                .setId(callbackContext.getCallbackDto().traceId())
                                .setStatus(TransactionStatus.APPROVED)
                                .setResponseMessage("Transaction status: APPROVED")
                                .setPaymentProviderResponseCode(TransactionStatus.APPROVED.name())
                                .setPaymentProviderResponseMessage(TransactionStatus.APPROVED.name())
                                .build()
                        :
                        FinalizeTransactionRequest.newBuilder()
                                .setId(callbackContext.getCallbackDto().traceId())
                                .setStatus(TransactionStatus.DECLINED)
                                .setResponseMessage("Transaction status: DECLINED")
                                .setPaymentProviderResponseCode(callbackContext.getCallbackDto().detailedStatus())
                                .setPaymentProviderResponseMessage(callbackContext.getCallbackDto().errorMessage())
                                .build()
        );
        return callbackContext;
    }

    public ExecuteTransactionResponse mapToExecuteTransactionResponse(MifinityTransactionContext transactionContext) {
        if (transactionContext.getErrorDescription() != null) {
            return buildErrorResponseInternal(transactionContext);
        } else {
            return buildPendingTransactionResponse(transactionContext);
        }
    }

    public ExecuteTransactionResponse mapToExecuteTransactionResponse(MifinityWithdrawalContext withdrawalContext) {
        if (withdrawalContext.getErrorDescription() != null) {
            return buildErrorResponseInternal(withdrawalContext);
        }

        var withdrawalType = withdrawalContext.getWithdrawalType();
        var transactionId = withdrawalContext.getContext().getTransaction().getId();

        if (Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK.equalsIgnoreCase(withdrawalType)) {
            var payAnyBankTransactionDto = withdrawalContext.getPayAnyBankResponseDto().payload().get(0);
            return buildApprovedTransactionResponse(payAnyBankTransactionDto, transactionId);
        }

        // account to account
        var accountToAccountTransferResponseDto = withdrawalContext.getWithdrawalResponseDto();
        return buildApprovedTransactionResponse(accountToAccountTransferResponseDto, transactionId);
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(MifinityTransactionContext transactionContext) {
        var redirectUrl = UriBuilder.fromUri(transactionContext.getContext().getTenantConfig().url())
                .path(MifinityWidgetPage.class)
            //to fix this for test ERROR_RESPONSE_200_ANOTHER_PARSEABLE_RESPONSE because its npe and goes to default finalize response
                .resolveTemplate("token", transactionContext.getPaymentResponseDto().payload().get(0).initializationToken())
                .build().toString();

        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                //TODO: set all response data here
                .setResponse(ExecuteTransactionResponse.Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name()).build())
                .setRedirect(
                        new GrpcBuilder<>(builder)
                                .set(redirectUrl, builder::setUrl)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private static ExecuteTransactionResponse buildErrorResponseInternal(BaseTransactionContext<String> context) {
        TransactionStatusMapper responseMapping = TransactionStatusMapper.fromValue(context.getErrorDescription().getReason());
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        Map<String, Object> errorMap = Collections.emptyMap();
        if (context.getErrorDescription() != null &&
            context.getErrorDescription().getErrorResponse() != null) {
            errorMap = JsonObject.mapFrom(context.getErrorDescription().getErrorResponse()).getMap();
        }
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(builder)
                        .set(responseMapping.getResponseCode().name(), builder::setResponseCode)
                        .set(StringUtils.abbreviate(context.getErrorDescription().getResponseMessage(), 50), builder::setResponseMessage)
                        .setAny(context.getErrorDescription().getPaymentProviderResponseMessage(), builder::setPaymentProviderResponseMessage)
                        .setAny(context.getErrorDescription().getPaymentProviderResponseCode(), builder::setPaymentProviderResponseCode)
                        .setAndMap(errorMap, GrpcFactory::fromMap, builder::setData)
                        .set(context.getErrorDescription().getReason(), builder::setPaymentProviderStatus)
                        .setAny(responseMapping.getTransactionStatus(), builder::setStatus)
                        .getBuilder().build())
                .build();
    }

    public ErrorDescription<ErrorResponseDto> buildErrorDescription(BaseTransactionContext<String> context, Throwable failure) {
        String reason;
        return switch (context.getPhase()) {
            case PHASE_HYDRATE_CONTEXT, PHASE_VALIDATE_REQUEST:
                reason = transactionUtils.getContextPreparationFailureReason(failure);
                yield buildInternalErrorResponse(reason, failure);
            case PHASE_REQUEST_PAYMENT:
                yield switch (context.getSubPhase()) {
                    case PHASE_PSP_INVOKE:
                        reason = transactionUtils.getApiFailureReason(failure);
                        yield handlePaymentRequestFailure(reason, failure);
                    case PHASE_READ_PAYLOAD:
                        reason = transactionUtils.getDeserializationFailureReason(failure);
                        yield buildInternalErrorResponse(reason, failure);
                    default:
                        yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
                };
            default:
                yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
        };
    }

    private ErrorDescription<ErrorResponseDto> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<ErrorResponseDto>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    private ErrorDescription<ErrorResponseDto> handlePaymentRequestFailure(String reason, Throwable failure) {
        ErrorResponseDto apiErrorResponse = null;
        String respMessage = null;
        Tuple2<String, String> pspErrorInfo = switch (reason) {
            case REASON_TIMEOUT -> Tuple2.of(reason, "Error Message: %s".formatted(failure.getMessage()));
            case REASON_API_INVOCATION_FAILURE, REASON_INVALID_INPUT, REASON_UNAUTHORIZED -> {
                apiErrorResponse = ((WebApplicationException) failure).getResponse().readEntity(ErrorResponseDto.class);
                respMessage = Optional.ofNullable(apiErrorResponse)
                    .map(r -> r.errors())
                    .map(errors -> errors.stream()
                        .map(ErrorResponseDto.Error::toString)
                        .collect(Collectors.joining("\n")))
                    .orElse("");
                yield Tuple2.of(reason, respMessage);
            }
            default -> Tuple2.of(REASON_UNKNOWN_API_ERROR, failure.getMessage());
        };

        respMessage = respMessage == null ? "Reason:%s Message:%s".formatted(reason, failure.getMessage()) : respMessage;
        String errorCode = Optional.ofNullable(apiErrorResponse)
            .map(r -> r.errors())
            .filter(errors -> !errors.isEmpty())
            .map(errors -> errors.get(0).getErrorCode())
            .orElse(null);
        return ErrorDescription.<ErrorResponseDto>builder()
                .reason(pspErrorInfo.getItem1())
                .responseMessage(respMessage)
                .errorResponse(apiErrorResponse)
                .paymentProviderResponseCode(errorCode)
                .paymentProviderResponseMessage(pspErrorInfo.getItem2())
                .build();
    }

    private ExecuteTransactionResponse buildApprovedTransactionResponse(
            AccountToAccountTransferResponseDto.TransactionDto response, String transactionId) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        String referenceNumber = response.transactionReference();
        String responseMessage = "Withdrawal status: " + response.status();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(builder)
                        .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                        .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                        .set(referenceNumber, builder::setReferenceNumber)
                        .set(responseMessage, builder::setResponseMessage)
                        .set(responseMessage, builder::setPaymentProviderResponseMessage)
                        .setAny(response.status(), builder::setPaymentProviderResponseCode)
                        .getBuilder().build())
                .build();
    }

    private ExecuteTransactionResponse buildApprovedTransactionResponse(
            PayAnyBankResponseDto.PayAnyBankTransactionDto response, String transactionId) {
        if (response == null) {
            throw new UnexpectedResponseException("PayAnyBank response payload is null or empty");
        }
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        String referenceNumber = response.transactionReference();
        String responseMessage = "Bank withdrawal completed successfully";
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(builder)
                        .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                        .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                        .set(referenceNumber, builder::setReferenceNumber)
                        .set(responseMessage, builder::setResponseMessage)
                        .set(responseMessage, builder::setPaymentProviderResponseMessage)
                        .setAny(response.transactionId(), builder::setPaymentProviderResponseCode)
                        .getBuilder().build())
                .build();
    }
}
