package com.morefin.pg.mifinity.service;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.domain.tables.pojos.PaymentProviderAccount;
import com.morefin.pg.common.TransactionUtils;
import com.morefin.pg.mifinity.http.MifinityApiClient;
import com.morefin.pg.mifinity.model.CallbackDto;
import com.morefin.pg.mifinity.model.MifinityCallbackContext;
import com.morefin.pg.mifinity.model.PaymentStatusResponseDto;
import com.morefin.pg.mifinity.model.RuntimeAccountConfig;
import com.morefin.pg.mifinity.util.MifinityObjectTransformer;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.PHASE_BUILD_FINALIZE_REQUEST;
import static com.morefin.pg.common.Constants.PHASE_DB_GET_DATA;
import static com.morefin.pg.common.Constants.PHASE_GRPC_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_VERIFY_CALLBACK;

/**
 * Manages the finalization of Mifinity payment transactions.
 *
 * <p>This class handles the callback processing from Mifinity PSP after a payment
 * redirect flow completes. It orchestrates the following steps:</p>
 *
 * <ol>
 *   <li>Validates the callback authenticity and payment status</li>
 *   <li>Verifies the transaction status with Mifinity's payment status API</li>
 *   <li>Confirms the callback status matches the PSP's record</li>
 *   <li>Sends a finalize request to the internal transaction service via gRPC</li>
 * </ol>
 *
 * <p>The class uses a reactive pipeline via {@link SafeUni} to chain these phases
 * with proper error handling at each stage.</p>
 *
 * @see MifinityCallbackContext
 * @see CallbackDto
 */
@ApplicationScoped
public class FinalizeTransactionManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @RestClient
    MifinityApiClient apiClient;

    @Inject
    MifinityObjectTransformer objectTransformer;

    @Inject
    SignatureUtils signatureUtils;

    @Inject
    TransactionUtils transactionUtils;

    private final BiFunction<MifinityCallbackContext, Throwable, MifinityCallbackContext> defaultExceptionHandler = (context, throwable) -> {
        context.setErrorDescription(buildErrorDescription(context, throwable));
        return context;
    };

    private ErrorDescription<Response.Status> buildErrorDescription(MifinityCallbackContext context, Throwable failure) {
        Response.Status responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
        String responseMessage = failure.getMessage();
        switch (context.getPhase()) {
            case PHASE_VERIFY_CALLBACK:
                responseStatus = Response.Status.BAD_REQUEST;
                break;
            case PHASE_PSP_INVOKE:
                responseMessage = transactionUtils.getApiFailureReason(failure);
                break;
        }
        Log.error("Mifinity callback error in phase " + context.getPhase(), failure);

        return ErrorDescription.<Response.Status>builder()
                .errorResponse(responseStatus)
                .responseMessage(responseMessage)
                .build();
    }

    public Uni<Response> finalizeTransaction(CallbackDto responseBody, String tenantId, PaymentStatusResponseDto.Status paymentStatus) {
        MifinityCallbackContext callbackContext = new MifinityCallbackContext();

        return SafeUni.from(callbackContext, defaultExceptionHandler, callbackContext)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, context -> hydrateContext(context, responseBody, tenantId, paymentStatus))
                .safeFlatMap(PHASE_PSP_INVOKE, this::getPspPaymentStatus)
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifyCallback)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinalResponse);
    }

    private Uni<MifinityCallbackContext> hydrateContext(MifinityCallbackContext callbackContext,
                                                        CallbackDto callbackDto,
                                                        String tenantId,
                                                        PaymentStatusResponseDto.Status paymentStatus) {
        callbackContext.setTenantId(tenantId);
        callbackContext.setTransactionGrpc(getTransactionGrpc(tenantId));
        callbackContext.setCallbackDto(callbackDto);
        callbackContext.setCallbackPaymentStatus(paymentStatus);

        return SafeUni.from(callbackContext, defaultExceptionHandler, callbackContext)
                .safeFlatMap(PHASE_DB_GET_DATA, this::setApiKey)
                .endSubPhase();
    }

    private Uni<MifinityCallbackContext> setApiKey(MifinityCallbackContext callbackContext) {
        return signatureUtils.findPaymentProviderSignatureSecret(callbackContext.getCallbackDto().traceId(), callbackContext.getTenantId(), this::getApiKey)
                .map(apiKey -> {
                    callbackContext.setApiKey(apiKey);
                    return callbackContext;
                });
    }

    private String getApiKey(PaymentProviderAccount paymentProviderAccount) {
        return Utils.getRuntimeAccountConfig(paymentProviderAccount, RuntimeAccountConfig.class).apiKey();
    }

    private Uni<MifinityCallbackContext> getPspPaymentStatus(MifinityCallbackContext callbackContext) {
        return apiClient.paymentStatus(callbackContext.getCallbackDto().validationKey(), callbackContext.getApiKey())
                .map(response -> {
                    callbackContext.setPaymentStatusResponse(response);
                    return callbackContext;
                });
    }

    private MifinityCallbackContext verifyCallback(MifinityCallbackContext callbackContext) {
        if (callbackContext.getCallbackPaymentStatus() != callbackContext.getPaymentStatusResponse().payload().get(0).status()) {
            throw new SecurityException("Transaction statuses mismatch!");
        }
        return callbackContext;
    }

    private Uni<MifinityCallbackContext> sendGrpcFinalizeRequest(MifinityCallbackContext callbackContext) {
        var grpc = getTransactionGrpc(callbackContext.getTenantId());
        return grpc.finalizeTransaction(callbackContext.getFinalizeRequest())
                .map(response -> {
                    callbackContext.setFinalizeResponse(response);
                    return callbackContext;
                });
    }

    private Response buildFinalResponse(MifinityCallbackContext callbackContext) {
        if (callbackContext.getErrorDescription() == null) {
            if (callbackContext.getFinalizeResponse().hasRedirect()) {
                return Response.ok().build();
            } else {
                return Response.status(400).build();
            }
        } else {
            return Response.status((Response.Status) callbackContext.getErrorDescription().getErrorResponse())
                    .entity(Map.of("error", callbackContext.getErrorDescription().getResponseMessage())).build();
        }
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "mifinity-service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }

}
