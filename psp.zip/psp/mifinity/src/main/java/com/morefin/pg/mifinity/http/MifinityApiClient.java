package com.morefin.pg.mifinity.http;

import com.morefin.pg.mifinity.model.AccountToAccountTransferDto;
import com.morefin.pg.mifinity.model.InitIframeDto;
import com.morefin.pg.mifinity.model.PayAnyBankDto;
import com.morefin.pg.mifinity.model.PaymentStatusResponseDto;
import com.morefin.pg.mifinity.util.Constants;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "mifinity")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface MifinityApiClient {

    @POST
    @Path(Constants.INIT_IFRAME_URL)
    @ClientHeaderParam(name = "api-version", value = "1")
    Uni<Response> initIframe(InitIframeDto request, @HeaderParam("Key") String apiKey);

    @GET
    @Path("/api/gateway/payment-status/{validationKey}")
    @ClientHeaderParam(name = "api-version", value = "1")
    Uni<PaymentStatusResponseDto> paymentStatus(@PathParam(value = "validationKey") String validationKey, @HeaderParam("Key") String apiKey);

    @POST
    @Path("/api/payments/acct2acct")
    @ClientHeaderParam(name = "api-version", value = "1")
    Uni<Response> accountToAccountTransfer(AccountToAccountTransferDto request, @HeaderParam("Key") String apiKey);

    @POST
    @Path("/api/payments/pab")
    @ClientHeaderParam(name = "api-version", value = "1")
    Uni<Response> payAnyBank(PayAnyBankDto request, @HeaderParam("Key") String apiKey);

}
