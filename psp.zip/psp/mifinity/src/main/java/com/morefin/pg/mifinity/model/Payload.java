package com.morefin.pg.mifinity.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class Payload {
    InitIframeDto requestDto;
    RuntimeAccountConfig runtimeAccountConfig;
    String validationErrorMessage;
}
