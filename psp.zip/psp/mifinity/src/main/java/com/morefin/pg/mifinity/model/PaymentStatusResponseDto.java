package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import java.util.List;

public record PaymentStatusResponseDto(
        @JsonProperty("payload") List<Payload> payload
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Payload(
            @JsonProperty("status") Status status
    ) {
    }

    @Getter
    public enum Status {
        SUCCESSFUL("SUCCESSFUL"),
        PENDING("PENDING"),
        NOT_COMPLETED("NOT_COMPLETED"),
        FAILED("FAILED");

        private final String value;

        Status(String value) {
            this.value = value;
        }

        @JsonCreator
        public static Status fromValue(String value) {
            for (Status status : Status.values()) {
                if (status.value.equalsIgnoreCase(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown status value: " + value);
        }
    }
}
