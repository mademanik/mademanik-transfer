package com.morefin.pg.mifinity.http;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.mifinity.model.CallbackDto;
import com.morefin.pg.mifinity.model.PaymentStatusResponseDto;
import com.morefin.pg.mifinity.service.FinalizeTransactionManager;
import com.morefin.pg.mifinity.util.Constants;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(Constants.CALLBACK_URL)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MifinityCallbackResource {

    @Inject
    FinalizeTransactionManager finalizeTransactionManager;

    @Inject
    Tenant tenant;

    @Path(Constants.CALLBACK_SUCCESS_URL)
    @POST
    public Uni<Response> returnSuccess(CallbackDto body) {
        return finalizeTransactionManager.finalizeTransaction(body, tenant.id(), PaymentStatusResponseDto.Status.SUCCESSFUL);
    }

    @Path(Constants.CALLBACK_ERROR_URL)
    @POST
    public Uni<Response> returnError(CallbackDto body) {
        return finalizeTransactionManager.finalizeTransaction(body, tenant.id(), PaymentStatusResponseDto.Status.FAILED);
    }
}
