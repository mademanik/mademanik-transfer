package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public record AccountToAccountTransferDto(
        @JsonProperty("sourceAccount") String sourceAccount,
        @JsonProperty("destinationAccount") String destinationAccount,
        @JsonProperty("money") InitIframeDto.Money money,
        @JsonProperty("description") String description,
        @JsonProperty("traceId") String traceId
) {}
