package com.morefin.pg.mifinity.processing;

import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.mifinity.admin.MifinityPaymentMethodTypeModule;
import io.quarkus.arc.Arc;

public class MifinityHppPaymentProcessingServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return MifinityPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return MifinityPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return MifinityPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(MifinityPaymentProcessingService.class)) {
            return instance.get();
        }
    }
}
