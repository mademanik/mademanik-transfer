package com.morefin.pg.mifinity.util;

public class Constants {
    public static final String INIT_IFRAME_URL = "/pegasus-ci/api/gateway/init-iframe";
    public static final String CALLBACK_URL = "/psp/mifinity/callback";
    public static final String CALLBACK_SUCCESS_URL = "/success";
    public static final String CALLBACK_ERROR_URL = "/error";
    
    public static final String WITHDRAWAL_TYPE_ACCOUNT_TO_ACCOUNT = "account_to_account";
    public static final String WITHDRAWAL_TYPE_PAY_ANY_BANK = "pay_any_bank";
}
