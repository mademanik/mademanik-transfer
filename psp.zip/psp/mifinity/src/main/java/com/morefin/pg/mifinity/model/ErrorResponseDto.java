package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import java.util.List;

public record ErrorResponseDto(
        @JsonProperty("errors") List<Error> errors
) {
    @Getter
    public static class Error {
        @JsonProperty("type")
        String type;
        @JsonProperty("errorCode")
        String errorCode;
        @JsonProperty("message")
        String message;
        @JsonProperty("field")
        String field;

        @Override
        public String toString() {
            return "Error{type='%s', errorCode='%s', message='%s', field='%s'}"
                    .formatted(type, errorCode, message, field);
        }
    }
}
