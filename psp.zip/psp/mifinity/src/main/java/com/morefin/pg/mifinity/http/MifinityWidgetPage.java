package com.morefin.pg.mifinity.http;

import com.morefin.pg.mifinity.util.Config;
import io.quarkus.qute.Template;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/psp/mifinity/{token}")
@ApplicationScoped
public class MifinityWidgetPage {

    @Inject
    Config config;

    @Inject
    Template widget;

    @GET
    @Produces(MediaType.TEXT_HTML)
    public Response get(@PathParam("token") String token) {
        String html = widget
                .data("token", token)
                .data("widgetUrl", config.widgetUrl())
                .render();

        return Response.ok(html).build();
    }
}
