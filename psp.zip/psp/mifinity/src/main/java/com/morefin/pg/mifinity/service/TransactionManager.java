package com.morefin.pg.mifinity.service;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.mifinity.http.MifinityApiClient;
import com.morefin.pg.mifinity.model.AccountToAccountTransferResponseDto;
import com.morefin.pg.mifinity.model.IframeResponseDto;
import com.morefin.pg.mifinity.model.MifinityTransactionContext;
import com.morefin.pg.mifinity.model.MifinityWithdrawalContext;
import com.morefin.pg.mifinity.model.PayAnyBankResponseDto;
import com.morefin.pg.mifinity.model.RuntimeAccountConfig;
import com.morefin.pg.mifinity.util.Constants;
import com.morefin.pg.mifinity.util.MifinityObjectTransformer;
import com.morefin.pg.model.RequestValidationException;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.DtoValidationService;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_READ_PAYLOAD;
import static com.morefin.pg.common.Constants.PHASE_REQUEST_PAYMENT;
import static com.morefin.pg.common.Constants.PHASE_VALIDATE_REQUEST;
import static com.morefin.pg.common.Constants.REASON_UNEXPECTED_RESPONSE_FORMAT;

@ApplicationScoped
public class TransactionManager {

    @RestClient
    MifinityApiClient apiClient;

    @Inject
    MifinityObjectTransformer objectTransformer;

    @Inject
    DtoValidationService dtoValidationService;

    BiFunction<MifinityTransactionContext, Throwable, MifinityTransactionContext> defaultExceptionHandler = (context, throwable) -> {
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, throwable));
        return context;
    };

    BiFunction<MifinityWithdrawalContext, Throwable, MifinityWithdrawalContext> withdrawalExceptionHandler = (context, throwable) -> {
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, throwable));
        return context;
    };

    public Uni<ExecuteTransactionResponse> requestHpp(TransactionTypeContext context) {
        MifinityTransactionContext transactionContext = new MifinityTransactionContext();

        return SafeUni.from(context, defaultExceptionHandler, transactionContext)
                .safeMap(PHASE_HYDRATE_CONTEXT, transactionTypeContext -> hydrateContext(transactionContext, transactionTypeContext))
                .safeMap(PHASE_VALIDATE_REQUEST, this::validateRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::executeRequest)
                .finalize(objectTransformer::mapToExecuteTransactionResponse);
    }

    private MifinityTransactionContext hydrateContext(MifinityTransactionContext transactionContext, TransactionTypeContext context) {
        var accountConfig = Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), RuntimeAccountConfig.class);
        return transactionContext.toBuilder()
                .context(context)
                .accountConfig(accountConfig)
                .paymentRequestDto(objectTransformer.buildPaymentRequest(context, accountConfig))
                .build();
    }

    private MifinityTransactionContext validateRequest(MifinityTransactionContext transactionContext) {
        var validationMessage = dtoValidationService.validateRequest(transactionContext.getPaymentRequestDto());

        if (validationMessage != null) {
            throw new RequestValidationException(validationMessage);
        }
        return transactionContext;
    }

    private Uni<MifinityTransactionContext> executeRequest(MifinityTransactionContext transactionContext) {
        return SafeUni.from(transactionContext, defaultExceptionHandler, transactionContext)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> apiClient.initIframe(transactionContext.getPaymentRequestDto(), transactionContext.getAccountConfig().apiKey()))
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentResponse(transactionContext, response))
                .endSubPhase();
    }

    private MifinityTransactionContext parsePaymentResponse(MifinityTransactionContext transactionContext, Response response) {
        transactionContext.setPaymentResponseDto(response.readEntity(IframeResponseDto.class));
        return transactionContext;
    }

    public Uni<ExecuteTransactionResponse> withdrawal(TransactionTypeContext context) {
        MifinityWithdrawalContext withdrawalContext = new MifinityWithdrawalContext();

        return SafeUni.from(context, withdrawalExceptionHandler, withdrawalContext)
                .safeMap(PHASE_HYDRATE_CONTEXT, transactionTypeContext -> hydrateWithdrawalContext(withdrawalContext, transactionTypeContext))
                .safeMap(PHASE_VALIDATE_REQUEST, this::validateWithdrawalRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::executeWithdrawalRequest)
                .finalize(objectTransformer::mapToExecuteTransactionResponse);
    }

    private MifinityWithdrawalContext hydrateWithdrawalContext(MifinityWithdrawalContext withdrawalContext, TransactionTypeContext context) {
        var accountConfig = Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), RuntimeAccountConfig.class);
        var paymentMethodData = context.getPaymentMethod().data();
        var withdrawalType = paymentMethodData.get("withdrawal_type");

        validateWithdrawalType(withdrawalType);

        if (!Constants.WITHDRAWAL_TYPE_ACCOUNT_TO_ACCOUNT.equalsIgnoreCase(withdrawalType) &&
            !Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK.equalsIgnoreCase(withdrawalType)) {
            throw new RequestValidationException("Invalid withdrawal_type: " + withdrawalType + 
                ". Supported types are: " + Constants.WITHDRAWAL_TYPE_ACCOUNT_TO_ACCOUNT + 
                ", " + Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK);
        }
        
        if (Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK.equalsIgnoreCase(withdrawalType)) {
            return withdrawalContext.toBuilder()
                    .context(context)
                    .accountConfig(accountConfig)
                    .withdrawalType(Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK)
                    .payAnyBankRequestDto(objectTransformer.buildPayAnyBankRequest(context, accountConfig, paymentMethodData))
                    .build();
        } else {
            var destinationAccount = paymentMethodData.get("destinationAccount");
            if (destinationAccount == null || destinationAccount.isEmpty()) {
                destinationAccount = context.getTransaction().getCustomerEmail();
            }
            return withdrawalContext.toBuilder()
                    .context(context)
                    .accountConfig(accountConfig)
                    .withdrawalType(Constants.WITHDRAWAL_TYPE_ACCOUNT_TO_ACCOUNT)
                    .withdrawalRequestDto(objectTransformer.buildWithdrawalRequest(context, accountConfig, destinationAccount))
                    .build();
        }
    }

    private MifinityWithdrawalContext validateWithdrawalRequest(MifinityWithdrawalContext withdrawalContext) {
        var withdrawalType = withdrawalContext.getWithdrawalType();
        validateWithdrawalType(withdrawalType);

        if (Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK.equalsIgnoreCase(withdrawalType)) {
            var validationMessage = dtoValidationService.validateRequest(withdrawalContext.getPayAnyBankRequestDto());
            if (validationMessage != null) {
                throw new RequestValidationException(validationMessage);
            }
        } else if (Constants.WITHDRAWAL_TYPE_ACCOUNT_TO_ACCOUNT.equalsIgnoreCase(withdrawalType)) {
            var validationMessage = dtoValidationService.validateRequest(withdrawalContext.getWithdrawalRequestDto());
            if (validationMessage != null) {
                throw new RequestValidationException(validationMessage);
            }
        } else {
            throw new RequestValidationException("Invalid withdrawal_type: " + withdrawalType + 
                ". Supported types are: " + Constants.WITHDRAWAL_TYPE_ACCOUNT_TO_ACCOUNT + 
                ", " + Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK);
        }
        return withdrawalContext;
    }

    private Uni<MifinityWithdrawalContext> executeWithdrawalRequest(MifinityWithdrawalContext withdrawalContext) {
        var withdrawalType = withdrawalContext.getWithdrawalType();
        validateWithdrawalType(withdrawalType);

        if (Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK.equalsIgnoreCase(withdrawalType)) {
            return SafeUni.from(withdrawalContext, withdrawalExceptionHandler, withdrawalContext)
                    .safeFlatMap(PHASE_PSP_INVOKE, ctx -> apiClient.payAnyBank(withdrawalContext.getPayAnyBankRequestDto(), withdrawalContext.getAccountConfig().apiKey()))
                    .safeMap(PHASE_READ_PAYLOAD, response -> parsePayAnyBankResponse(withdrawalContext, response))
                    .endSubPhase();
        } 

        return SafeUni.from(withdrawalContext, withdrawalExceptionHandler, withdrawalContext)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> apiClient.accountToAccountTransfer(withdrawalContext.getWithdrawalRequestDto(), withdrawalContext.getAccountConfig().apiKey()))
                .safeMap(PHASE_READ_PAYLOAD, response -> parseAccountToAccountResponse(withdrawalContext, response))
                .endSubPhase();
    }

    private void validateWithdrawalType(String withdrawalType) {
        if (withdrawalType == null || withdrawalType.isEmpty()) {
            throw new RequestValidationException("withdrawal_type is mandatory. Supported types are: " +
                    Constants.WITHDRAWAL_TYPE_ACCOUNT_TO_ACCOUNT + ", " + Constants.WITHDRAWAL_TYPE_PAY_ANY_BANK);
        }
    }

    private MifinityWithdrawalContext parseAccountToAccountResponse(MifinityWithdrawalContext withdrawalContext, Response response) {
        var responseDto = response.readEntity(AccountToAccountTransferResponseDto.class);
        AccountToAccountTransferResponseDto.TransactionDto transactionData = null;
        if (responseDto != null && responseDto.payload() != null && !responseDto.payload().isEmpty()) {
            transactionData = responseDto.payload().get(0);
        } else {
            withdrawalContext.setErrorDescription(
                    ErrorDescription.builder()
                            .reason(REASON_UNEXPECTED_RESPONSE_FORMAT)
                            .responseMessage("AccountToAccount response is invalid or empty")
                            .build()
            );
        }
        withdrawalContext.setWithdrawalResponseDto(transactionData);
        return withdrawalContext;
    }

    private MifinityWithdrawalContext parsePayAnyBankResponse(MifinityWithdrawalContext withdrawalContext, Response response) {
        var responseDto = response.readEntity(PayAnyBankResponseDto.class);
        withdrawalContext.setPayAnyBankResponseDto(responseDto);
        boolean isPayAnyBankResponseValid = responseDto != null
                && responseDto.payload() != null
                && !responseDto.payload().isEmpty();
        if (!isPayAnyBankResponseValid) {
            withdrawalContext.setErrorDescription(
                    ErrorDescription.builder()
                            .reason(REASON_UNEXPECTED_RESPONSE_FORMAT)
                            .responseMessage("PayAnyBank response is invalid or empty")
                            .build()
            );
        }
        return withdrawalContext;
    }
}