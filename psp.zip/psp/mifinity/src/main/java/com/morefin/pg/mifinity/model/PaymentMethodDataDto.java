package com.morefin.pg.mifinity.model;

public record PaymentMethodDataDto(
        String destinationAccount
) {

}
