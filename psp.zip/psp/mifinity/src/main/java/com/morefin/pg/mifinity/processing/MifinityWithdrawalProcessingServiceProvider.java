package com.morefin.pg.mifinity.processing;

import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingService;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingServiceProvider;
import com.morefin.pg.mifinity.admin.MifinityPaymentMethodTypeModule;
import io.quarkus.arc.Arc;

public class MifinityWithdrawalProcessingServiceProvider implements WithdrawalPaymentProcessingServiceProvider {
    @Override
    public WithdrawalPaymentProcessingService create() {
        try (var instance = Arc.container().instance(MifinityPaymentProcessingService.class)) {
            return instance.get();
        }    }

    @Override
    public String name() {
        return MifinityPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return MifinityPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return MifinityPaymentMethodTypeModule.MODULE_ID;
    }
}
