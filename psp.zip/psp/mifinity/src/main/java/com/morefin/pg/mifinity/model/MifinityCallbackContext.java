package com.morefin.pg.mifinity.model;

import com.morefin.common.grpc.transaction.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@SuperBuilder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Getter
@Setter
@NoArgsConstructor
public class MifinityCallbackContext extends BaseTransactionContext<String> {
    String tenantId;
    TransactionGrpc transactionGrpc;
    CallbackDto callbackDto;
    PaymentStatusResponseDto.Status callbackPaymentStatus;
    String apiKey;
    PaymentStatusResponseDto paymentStatusResponse;
    FinalizeTransactionRequest finalizeRequest;
    ExecuteTransactionResponse finalizeResponse;

}