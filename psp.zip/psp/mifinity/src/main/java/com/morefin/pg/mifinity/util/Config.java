package com.morefin.pg.mifinity.util;

import io.smallrye.config.ConfigMapping;
import jakarta.enterprise.context.ApplicationScoped;

@ConfigMapping(prefix = "mifinity")
@ApplicationScoped
public interface Config {

    String widgetUrl();
}
