package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CallbackDto(
        @JsonProperty("traceId") String traceId,
        @JsonProperty("validationKey") String validationKey,
        // available for the error callback
        @JsonProperty("errorMessage") String errorMessage,
        @JsonProperty("detailedStatus") String detailedStatus
) {
}
