package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PayAnyBankResponseDto(
        @JsonProperty("payload") List<PayAnyBankTransactionDto> payload
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record PayAnyBankTransactionDto(
            @JsonProperty("transactionId") String transactionId,
            @JsonProperty("transactionReference") String transactionReference,
            @JsonProperty("traceId") String traceId,
            @JsonProperty("datePosted") String datePosted,
            @JsonProperty("sourceMoney") MoneyInfo sourceMoney,
            @JsonProperty("destinationMoney") MoneyInfo destinationMoney,
            @JsonProperty("exchangeRate") BigDecimal exchangeRate,
            @JsonProperty("totalFees") MoneyInfo totalFees
    ) {
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public record MoneyInfo(
                @JsonProperty("amount") BigDecimal amount,
                @JsonProperty("currency") String currency,
                @JsonProperty("displayable") String displayable
        ) {}
    }
}
