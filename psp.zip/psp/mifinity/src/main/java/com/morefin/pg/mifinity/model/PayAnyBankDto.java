package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PayAnyBankDto(
        @JsonProperty("sourceAccount") String sourceAccount,
        @JsonProperty("traceId") String traceId,
        @JsonProperty("description") String description,
        @JsonProperty("money") InitIframeDto.Money money,
        @JsonProperty("bankPayee") BankPayee bankPayee
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record BankPayee(
            @JsonProperty("country") String country,
            @JsonProperty("currency") String currency,
            @JsonProperty("description") String description,
            @JsonProperty("fields") Map<String, String> fields
    ) {}
}
