package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;


public record IframeResponseDto(
        @JsonProperty("payload") List<Payload> payload
        ) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Payload(
            @JsonProperty("traceId") String traceId,
            @JsonProperty("initializationToken") String initializationToken
    ) {
    }
}