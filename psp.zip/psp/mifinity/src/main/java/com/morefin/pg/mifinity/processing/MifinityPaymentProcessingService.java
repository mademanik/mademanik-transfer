package com.morefin.pg.mifinity.processing;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.pg.mifinity.admin.MifinityAPMAdminPaymentProcessingService;
import com.morefin.pg.mifinity.admin.MifinityPaymentMethodTypeModule;
import com.morefin.pg.mifinity.service.TransactionManager;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingService;


import java.util.Optional;

@ApplicationScoped
@Unremovable
public class MifinityPaymentProcessingService implements APMProcessingService, WithdrawalPaymentProcessingService {

    @Inject
    MifinityAPMAdminPaymentProcessingService adminPaymentProcessingService;

    @Inject
    TransactionManager transactionManager;

    @Override
    public Uni<ExecuteTransactionResponse> request(TransactionTypeContext context) {
        return transactionManager.requestHpp(context);
    }

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return MifinityPaymentMethodTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String id) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }

    @Override
    public Uni<ExecuteTransactionResponse> authorizeWithdrawal(TransactionTypeContext context) {
        return transactionManager.withdrawal(context);
    }
}
