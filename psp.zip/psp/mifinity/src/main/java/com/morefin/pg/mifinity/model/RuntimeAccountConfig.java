package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
        @JsonProperty("apiKey")
        String apiKey,
        @JsonProperty("brandId")
        String brandId,
        @JsonProperty("destinationAccountNumber")
        String destinationAccountNumber,
        @JsonProperty("paymentMethod")
        String paymentMethod
) {
}
