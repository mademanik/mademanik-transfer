package com.morefin.pg.mifinity.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class InitIframeDto {

    @NotNull
    @JsonProperty("description")
    private String description;

    @NotNull
    @JsonProperty("brandId")
    private String brandId;

    @NotNull
    @JsonProperty("destinationAccountNumber")
    private String destinationAccountNumber;

    @NotNull
    @JsonProperty("traceId")
    private String traceId;

    @Size(min = 48, max = 255)
    @NotNull
    @JsonProperty("validationKey")
    private String validationKey;

    @JsonProperty("returnUrl")
    private String returnUrl;

    @JsonProperty("errorUrl")
    private String errorUrl;

    @Size(min = 1, max = 48)
    @JsonProperty("clientReference")
    private String clientReference;

    @Valid
    @JsonProperty("money")
    private Money money;

    @Valid
    @JsonProperty("client")
    private Client client;

    @Valid
    @JsonProperty("address")
    private Address address;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    @AllArgsConstructor
    public static class Money {

        @NotNull
        @JsonProperty("amount")
        private String amount;

        @NotNull
        @JsonProperty("currency")
        private String currency;
    }

    @AllArgsConstructor
    public static class Client {

        @NotNull
        @JsonProperty("firstName")
        private String firstName;

        @NotNull
        @JsonProperty("lastName")
        private String lastName;

        @NotNull
        @JsonProperty("emailAddress")
        private String emailAddress;

        @NotNull
        @JsonProperty("nationality")
        private String nationality;

        @NotNull
        @Pattern(
                regexp = "^(\\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$",
                message = "Date must be in YYYY-MM-DD format"
        )
        @JsonProperty("dob")
        private String dob;

        @JsonProperty("phone")
        private String phone;

        @JsonProperty("dialingCode")
        private String dialingCode;
    }

    @AllArgsConstructor
    public static class Address {

        @NotNull
        @JsonProperty("addressLine1")
        private String addressLine1;

        @NotNull
        @JsonProperty("countryCode")
        private String countryCode;

        @NotNull
        @JsonProperty("city")
        private String city;

        @JsonProperty("postalCode")
        private String postalCode;
    }
}
