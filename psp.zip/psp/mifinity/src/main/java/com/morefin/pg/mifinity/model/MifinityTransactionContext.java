package com.morefin.pg.mifinity.model;

import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@SuperBuilder(toBuilder = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
@Getter
@Setter
@NoArgsConstructor
public class MifinityTransactionContext extends BaseTransactionContext<String> {
    TransactionTypeContext context;
    RuntimeAccountConfig accountConfig;
    InitIframeDto paymentRequestDto;
    IframeResponseDto paymentResponseDto;
}
