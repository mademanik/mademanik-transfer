package com.morefin.pg.huch.client;

import com.morefin.pg.huch.model.GetTransactionRequest;
import com.morefin.pg.huch.model.PaymentRequest;
import com.morefin.pg.huch.model.WithdrawalRequest;
import io.quarkus.rest.client.reactive.*;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "huch")
@Produces(MediaType.APPLICATION_JSON)
@Path("/api")
public interface HuchApiClient {
    @POST
    @Path("/oauth2/token")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @ClientFormParams({
            @ClientFormParam(name = "grant_type", value = "client_credentials"),
    })
    Uni<Response> authenticate(@FormParam("client_id") String clientId, @FormParam("client_secret") String clientSecret);

    @POST
    @Path("/payout/create")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> withdrawal(WithdrawalRequest request, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @POST
    @Path("/payment")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> payment(PaymentRequest request, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @GET
    @Path("/payment/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> getPayment(@PathParam("id") String id, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @ClientExceptionMapper
    static RuntimeException toException(Response response) {
        String responseAsString = response.readEntity(String.class);
        return new RuntimeException(response.getStatusInfo().getReasonPhrase() + "; body: " + responseAsString);
    }
}