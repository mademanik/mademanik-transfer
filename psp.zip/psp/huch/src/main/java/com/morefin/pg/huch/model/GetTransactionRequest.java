package com.morefin.pg.huch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetTransactionRequest {
    @JsonProperty("api_version")
    private Integer apiVersion;

    @JsonProperty("merchant_account")
    private String merchantAccount;

    @JsonProperty("merchant_password")
    private String merchantPassword;

    @JsonProperty("transaction_unique_id")
    private String transactionUniqueId;

    @JsonProperty("transaction_type")
    private String transactionType;

}
