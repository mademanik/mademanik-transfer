package com.morefin.pg.huch.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.huch.client.HuchApiClient;
import com.morefin.pg.huch.model.*;
import com.morefin.pg.huch.util.HuchObjectTransformer;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
public class TransactionManager {

    @Inject
    @RestClient
    HuchApiClient apiClient;

    @Inject
    HuchObjectTransformer objectTransformer;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    DtoMapperService mapperService;

    @Inject
    Utils pspUtils;

    private final BiFunction<HuchTransactionContext, Throwable, HuchTransactionContext> defaultExceptionHandler = (context, failure) -> {
        System.out.printf("Error execute Huch: %s", failure.getMessage());
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> executeHPPRequest(TransactionTypeContext authContext) {
        HuchTransactionContext ctx = new HuchTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydratePaymentContext(ctx, authContext, true))
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::authenticate)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::registerPaymentRequest)
                .finalize(objectTransformer::convertToCardResponse);
    }

    public Uni<ExecuteTransactionResponse> withdrawal(TransactionTypeContext authContext) {
        HuchTransactionContext ctx = new HuchTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydratePaymentContext(ctx, authContext, false))
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::authenticate)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::registerWithdrawalRequest)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private String mapToJson(Map<String, String> map) {
        Gson gson = new Gson();
        return gson.toJson(map);
    }

    private Uni<HuchTransactionContext> hydratePaymentContext(HuchTransactionContext context, TransactionTypeContext authContext, Boolean isHpp) {
        var transaction = authContext.getTransaction();
        var paymentProviderAccount = authContext.getPaymentProviderAccount();

        var browserInfo = objectMapper.convertValue(transaction.getTransactionData().getOptions().get("browser_info"), BrowserInfo.class);
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx -> {
                    RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(paymentProviderAccount, RuntimeAccountConfig.class);
                    context.setTransactionContext(authContext);
                    context.setRuntimeAccountConfig(rac);
                    context.setIsHpp(isHpp);

                    context.setCustomerData(objectTransformer.groupCustomerData(transaction));
                    context.setAmount(transaction.getAmount());
                    context.setCurrency(transaction.getCurrency());
                    context.setTransactionType(transaction.getTransactionType());
                    context.setStatementDescriptor(authContext.getMerchant().getName());
                    context.setDescription(nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()));

                    if ( !isHpp ) {
                        String jsonData = this.mapToJson(authContext.getPaymentMethod().data());
                        PaymentMethodData paymentMethodData = mapperService.mapAndValidate(jsonData, PaymentMethodData.class);
                        context.setIban(paymentMethodData.getIban());
                        context.setBic(paymentMethodData.getBic());
                        context.setReceiverName(paymentMethodData.getName());
                    }

                    context.setReference(transaction.getId());
                    context.setUserIp(transaction.getUserIp());
                    context.setBrowserInfo(browserInfo);
                    context.setSuccessUrl(transaction.getTransactionData().getSuccessUrl());
                    context.setCancelUrl(transaction.getTransactionData().getCancelUrl());
                    context.setFailureUrl(transaction.getTransactionData().getErrorUrl());

                    return context;
                })
                .safeFlatMap(PHASE_GRPC_INVOKE, ctx -> pspUtils.convertIso2toIso3CountryCode(ctx.getCustomerData().getAddress().getCountry(), ctx.getTransactionContext().getTenantConfig().id()))
                .safeMap(PHASE_HYDRATE_CONTEXT, countryIso3 -> {
                    context.setCountryIso3(countryIso3);
                    return context;
                }).endSubPhase();
    }

    private Uni<HuchTransactionContext> registerWithdrawalRequest(HuchTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_BUILD_PAYLOAD, objectTransformer::mapToWithdrawalRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, req -> apiClient.withdrawal(req, addBearer(context.getAccessToken())))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseWithdrawalResponse(context, resp))
                .endSubPhase();
    }

    private Uni<HuchTransactionContext> registerPaymentRequest(HuchTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_BUILD_PAYLOAD, objectTransformer::mapToPaymentRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, req -> apiClient.payment(req, addBearer(context.getAccessToken())))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parsePaymentResponse(context, resp))
                .endSubPhase();
    }

    private String addBearer(String accessToken) {
        return "Bearer " + accessToken;
    }

    private Uni<HuchTransactionContext> authenticate(HuchTransactionContext context) {
        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, ctx -> apiClient.authenticate(rac.clientId(), rac.clientSecret()))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseAuthenticationResponse(context, resp))
                .endSubPhase();
    }

    @SneakyThrows
    private HuchTransactionContext parseWithdrawalResponse(HuchTransactionContext context, Response response) {
        context.setWithdrawalResponseAsString(response.readEntity(String.class));
        context.setWithdrawalResponse(mapperService.mapAndValidate(
                context.getWithdrawalResponseAsString(),
                WithdrawalResponse.class
        ));

        return context;
    }

    @SneakyThrows
    private HuchTransactionContext parsePaymentResponse(HuchTransactionContext context, Response response) {
        context.setPaymentResponseAsString(response.readEntity(String.class));
        context.setPaymentResponse(mapperService.mapAndValidate(
                context.getPaymentResponseAsString(),
                PaymentResponse.class
        ));

        return context;
    }

    @SneakyThrows
    private HuchTransactionContext parseAuthenticationResponse(HuchTransactionContext context, Response response) {
        context.setAuthenticationResponseAsString(response.readEntity(String.class));
        context.setAuthenticationResponse(mapperService.mapAndValidate(
                context.getAuthenticationResponseAsString(),
                AuthenticationResponse.class
        ));

        context.setAccessToken(context.getAuthenticationResponse().getAccessToken());

        return context;
    }
}
