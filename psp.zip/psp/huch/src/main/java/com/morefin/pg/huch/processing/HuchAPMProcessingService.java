package com.morefin.pg.huch.processing;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.pg.huch.HuchTypeModule;
import com.morefin.pg.huch.admin.HuchAdminService;
import com.morefin.pg.huch.common.TransactionManager;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class HuchAPMProcessingService implements APMProcessingService, WithdrawalPaymentProcessingService {

    @Inject
    HuchAdminService adminPaymentProcessingService;

    @Inject
    TransactionManager transactionManager;

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return HuchTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public Uni<ExecuteTransactionResponse> request(TransactionTypeContext context) {
        return transactionManager.executeHPPRequest(context);
    }

    @Override
    public Uni<ExecuteTransactionResponse> authorizeWithdrawal(TransactionTypeContext context) {
        return transactionManager.withdrawal(context);
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }


}
