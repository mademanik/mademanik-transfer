package com.morefin.pg.huch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientDetail implements Serializable {
    @JsonProperty("email")
    private String email;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("full_name")
    private String fullName;

    @JsonProperty("bank_account")
    private String bankAccount;

    @JsonProperty("bank_code")
    private String bankCode;

    @JsonProperty("personal_code")
    private String personalCode;

    @JsonProperty("street_address")
    private String streetAddress;

    @JsonProperty("country")
    private String country;

    @JsonProperty("city")
    private String city;

    @JsonProperty("zip_code")
    private String zipCode;

    @JsonProperty("state")
    private String state;

    @JsonProperty("cc")
    private String[] cc;

    @JsonProperty("bcc")
    private String[] bcc;

    @JsonProperty("registration_number")
    private String registrationNumber;

    @JsonProperty("tax_number")
    private String taxNumber;
}
