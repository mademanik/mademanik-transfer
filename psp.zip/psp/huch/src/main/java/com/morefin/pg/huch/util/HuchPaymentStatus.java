package com.morefin.pg.huch.util;

import lombok.Getter;

@Getter
public enum HuchPaymentStatus {
    NEW("Payment has just been initiated. No customer action yet."),
    PENDING("Payment ongoing. Waiting for customer to complete payment."),
    BANK_CONNECTION_FAILED(
            "Unable to contact the bank. You can still retry with another bank."
    ),
    AWAITING_CONFIRMATION(
            "Awaiting bank verification or customer action on the bank side."
    ),
    PROCESSING(
            "Payment is being processed by the bank. Settlement has not been done yet. "
                    + "Be aware that it can be REJECTED."
    ),
    FORCE_PAID("Payment has been manually marked as accepted."),
    PAID(
            "Payment has been accepted by the bank and funds transfer is ongoing. "
                    + "In very rare cases, banks can block these transfers for AML issues."
    ),
    PAID_RECEIVED(
            "Payment has been accepted by the bank and received into your bank account."
    ),
    EXPIRED("Customer did not complete payment before 24 hours."),
    CANCELLED("Customer clicked on the close button and abandoned the payment."),
    FAILED("Cancelled or rejected by the bank."),
    AUTH_FAILED("Error on authentication with the bank."),
    EXECUTE_FAILED("Bank error while executing the payment.");

    private final String description;

    HuchPaymentStatus(String description) {
        this.description = description;
    }
}