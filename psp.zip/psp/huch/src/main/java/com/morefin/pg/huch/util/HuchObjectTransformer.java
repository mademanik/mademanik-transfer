package com.morefin.pg.huch.util;

import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.huch.common.RuntimeAccountConfig;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.huch.model.*;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

import java.math.BigDecimal;

import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class HuchObjectTransformer {

    public static final String DEFAULT_STATE_NA = "NA";

    public Customer groupCustomerData(ImmutableTypedTransactionEntity transaction) {
        return Customer.builder().firstName(transaction.getCustomerFirstName())
                .lastName(transaction.getCustomerLastName())
                .phone(transaction.getCustomerPhoneNumber())
                .email(transaction.getCustomerEmail())
                .category("Gaming")
                .address(
                        Address.builder().
                                streetAddress(transaction.getCustomerAddress())
                                .city(transaction.getCustomerCity())
                                .country(transaction.getCustomerCountry())
                                .postcode(transaction.getCustomerPostalCode())
                                .state(DEFAULT_STATE_NA)
                                .build())
                .dateOfBirth("01-01-1980") // Hardcoded, TO BE CHANGED later
                .gender("MALE") // Hardcoded, TO BE CHANGED later
                .build();
    }

    public WithdrawalRequest mapToWithdrawalRequest(HuchTransactionContext context) {
        return mapWithdrawalRequest(context).build();
    }

    public PaymentRequest mapToPaymentRequest(HuchTransactionContext context) {
        return mapPaymentRequest(context).build();
    }

    public ExecuteTransactionResponse convertToCardResponse(HuchTransactionContext context) {
        String id = context.getTransactionContext().getTransaction().getId();
        String responseAsString = "";
        if ( context.getIsHpp() ) {
            if ( context.getPaymentResponse() != null ) {
                id = context.getPaymentResponse().getPaymentId();
            }
            responseAsString = context.getPaymentResponseAsString();
        } else {
            if ( context.getWithdrawalResponse() != null ) {
                id = context.getWithdrawalResponse().getData().getPayoutId();
            }
            responseAsString = context.getWithdrawalResponseAsString();
        }

        if ( context.getErrorDescription() == null && (context.getWithdrawalResponse() != null || context.getPaymentResponse() != null) ) {
            ExecuteTransactionResponse.Status status = null;
            if ( context.getIsHpp() ) {
                HuchPaymentStatus paymentStatus = HuchPaymentStatus.valueOf(context.getPaymentResponse().getPaymentStatus().toUpperCase());
                status = TransactionStatusMapper.parsePaymentStatus(paymentStatus);
            } else {
                WithdrawalResponse.ResponseData data = context.getWithdrawalResponse().getData();
                HuchWithdrawalStatus transactionStatus = HuchWithdrawalStatus.valueOf(data.getStatus().toUpperCase());
                status = TransactionStatusMapper.parseWithdrawalStatus(transactionStatus);
            }
            switch (status) {
                case APPROVED -> {
                    return buildDirectApprovedTransactionResponse(id, responseAsString);
                }
                case PENDING -> {
                    if ( context.getIsHpp() ) {
                        String url = context.getPaymentResponse().getUrl();
                        return buildRedirectPendingTransactionResponse(id, url, responseAsString);
                    }
                    return buildPendingTransactionResponse(id, responseAsString);
                }
            }
        }

        String message = context.getErrorDescription() != null ? context.getErrorDescription().getResponseMessage() : "";
        return buildDeclinedTransactionResponse(id, message + " " + responseAsString);
    }

    private WithdrawalRequest.WithdrawalRequestBuilder mapWithdrawalRequest(HuchTransactionContext context) {
        String baseUrl = context.getTransactionContext().getTenantConfig().url();
//        String baseUrl = "https://webhook.site/9d1a77fd-7a6c-42cf-9b65-7e62b1d8f28f";
//        String baseUrl = "https://cnocz-114-10-119-239.a.free.pinggy.link";
        String webhookUrl = baseUrl + "/psp/huch/callback";

        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();
        var transaction = context.getTransactionContext().getTransaction();
        BigDecimal number = BigDecimal.valueOf(transaction.getAmount());
        Customer customer = context.getCustomerData();
        Address address = customer.getAddress();

        WithdrawalRequest.PayoutInfo payoutInfo = WithdrawalRequest.PayoutInfo.builder()
                .customerIban(context.getIban())
                .customerBic(context.getBic())
                .bankName(context.getReceiverName())
                .bankCountry(address.getCountry())
                .build();

        WithdrawalRequest.CustomerBillingInfo billingInfo = WithdrawalRequest.CustomerBillingInfo.builder()
                .customerFirstName(customer.getFirstName())
                .customerLastName(customer.getLastName())
                .customerCountryAlpha2(address.getCountry())
                .customerCity(address.getCity())
                .customerStreetAddress(address.getStreetAddress())
                .customerPostcode(address.getPostcode())
                .build();

        String label = "Withdrawal of " + transaction.getId();

        return WithdrawalRequest.builder()
                .merchantId(rac.merchantId())
                .merchantTransactionId(transaction.getId())
                .amount(number)
                .currency(transaction.getCurrency())
                .customerEmail(customer.getEmail())
                .customerIp(transaction.getUserIp())
                .customerPhoneNumber(customer.getPhone())
                .label(label.substring(0, 25))
                .webhookUrl(webhookUrl)
                .payoutInfo(payoutInfo)
                .customerBillingInfo(billingInfo);
    }

    private PaymentRequest.PaymentRequestBuilder mapPaymentRequest(HuchTransactionContext context) {
        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();
        var transaction = context.getTransactionContext().getTransaction();
        BigDecimal number = BigDecimal.valueOf(transaction.getAmount());
        Customer customer = context.getCustomerData();
        Address address = customer.getAddress();

        String baseUrl = context.getTransactionContext().getTenantConfig().url();
//        String baseUrl = "https://webhook.site/9d1a77fd-7a6c-42cf-9b65-7e62b1d8f28f";
//        String baseUrl = "https://cnocz-114-10-119-239.a.free.pinggy.link";
        String returnUrl = baseUrl + "/psp/huch/return/" + context.getTransactionContext().getTransaction().getId();

        String label = "Payment of " + transaction.getId();

        PaymentRequest.CustomerBillingInfo customerBillingInfo = PaymentRequest.CustomerBillingInfo.builder()
                .customerBirthDate(customer.getDateOfBirth())
                .customerGender(customer.getGender())
                .customerFirstName(customer.getFirstName())
                .customerLastName(customer.getLastName())
                .customerStreetAddress(address.getStreetAddress())
                .customerCity(address.getCity())
                .customerPostcode(address.getPostcode())
                .customerCountryAlpha2(address.getCountry())
                .customerIpAddress(transaction.getUserIp())
                .build();

        return PaymentRequest.builder()
                .merchantId(rac.merchantId())
                .currency(transaction.getCurrency())
                .amount(number)
                .label(label)
                .shopName(context.getTransactionContext().getMerchant().getName())
                .orderRef(transaction.getId())
                .successUrl(returnUrl)
                .pendingBankConfirmationUrl(returnUrl)
                .declineUrl(returnUrl)
                .customerEmail(customer.getEmail())
                .customerPhoneNumber(customer.getPhone())
                .customerBillingInfo(customerBillingInfo);
    }

    private ExecuteTransactionResponse buildDirectApprovedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildDeclinedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_DECLINED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_PENDING.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.PENDING, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildRedirectPendingTransactionResponse(String referenceNumber, String url, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_PENDING.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.PENDING, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .setRedirect(ExecuteTransactionResponse.Redirect.newBuilder()
                        .setUrl(url)
                )
                .build();
    }

    public ErrorDescription<String> buildErrorDescription(HuchTransactionContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

//        return switch (context.getPhase()) {
//            default:
//                yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
//        };
        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    private ErrorDescription<String> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<String>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    public ErrorDescription<?> buildFinalizeErrorDescription(HuchCallbackContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during processing of transaction {0} with message {1} during phase {2} and sub-phase {3} ",
                context.getTransactionId(), failure, context.getPhase(), context.getSubPhase());
        reason = "Bad request";
        return ErrorDescription.<Response.Status>builder()
                .reason(reason)
                .errorResponse(Response.Status.BAD_REQUEST)
                .responseMessage(failure.getMessage())
                .build();
    }

    public HuchCallbackContext buildFinalizeTransactionRequest(HuchCallbackContext context) {
        if ( context.getErrorDescription() != null ) {
            return context;
        }

        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder();
        builder.setReferenceNumber(context.getReferenceNumber())
                .setId(context.getTransactionId());

        builder.setResponseMessage(context.getCallbackRequestAsString())
                .setPaymentProviderResponseMessage(context.getCallbackRequestAsString());

        ExecuteTransactionResponse.Status transactionStatus;

        if ( !context.getIsWebhook() ) {
            HuchPaymentStatus status = HuchPaymentStatus.valueOf(context.getStatus().toUpperCase());
            transactionStatus = TransactionStatusMapper.parsePaymentStatus(status);

        } else if ( context.getIsWithdrawal() ) {
            HuchWithdrawalStatus status = HuchWithdrawalStatus.valueOf(context.getWebhookRequest().getStatus().toUpperCase());
            transactionStatus = TransactionStatusMapper.parseWithdrawalStatus(status);
        } else {
            HuchPaymentStatus status = HuchPaymentStatus.valueOf(context.getWebhookRequest().getPaymentStatus().toUpperCase());
            transactionStatus = TransactionStatusMapper.parsePaymentStatus(status);
        }

        switch (transactionStatus) {
            case APPROVED -> {
                String code = ProcessingCode.TRX_STATUS_APPROVED.name();
                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.APPROVED);
            }
            case PENDING -> {
                String code = ProcessingCode.TRX_STATUS_PENDING.name();

                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.PENDING);
            }
            default -> {
                builder.setStatus(TransactionStatus.DECLINED);
                if ( context.getErrorDescription() == null ) {
                    String code = ProcessingCode.TRX_STATUS_DECLINED.name();
                    builder.setResponseCode(code)
                            .setPaymentProviderResponseCode(code);
                }
            }
        }

        context.setFinalizeRequest(builder.build());

        return context;
    }
}

