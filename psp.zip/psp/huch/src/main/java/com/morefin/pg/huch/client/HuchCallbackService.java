package com.morefin.pg.huch.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.huch.common.FinalizeManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

@Path("/psp/huch")
@Produces(MediaType.APPLICATION_JSON)
public class HuchCallbackService {

    @Inject
    FinalizeManager finalizeManager;

    @Inject
    Tenant tenant;

    @Path("/callback")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Uni<Response> callbackUrl(String callbackRequest) {
        return finalizeManager.finalizeWebhookTransaction(callbackRequest, tenant.id());
    }

    @Path("/return/{id}")
    @GET
    public Uni<Response> returnUrl(@PathParam("id") String id) {
        return finalizeManager.finalizeReturnTransaction(id, tenant.id());
    }
}