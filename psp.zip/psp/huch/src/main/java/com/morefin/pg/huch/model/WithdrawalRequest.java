package com.morefin.pg.huch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WithdrawalRequest {
    @JsonProperty("merchant_id")
    private String merchantId;

    @JsonProperty("merchant_transaction_id")
    private String merchantTransactionId;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("customer_email")
    private String customerEmail;

    @JsonProperty("customer_ip")
    private String customerIp;

    @JsonProperty("customer_phone_number")
    private String customerPhoneNumber;

    @JsonProperty("payout_info")
    private PayoutInfo payoutInfo;

    @JsonProperty("customer_billing_info")
    private CustomerBillingInfo customerBillingInfo;

    @JsonProperty("label")
    private String label;

    @JsonProperty("webhook_url")
    private String webhookUrl;

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class PayoutInfo {
        @JsonProperty("customer_iban")
        private String customerIban;

        @JsonProperty("customer_bic")
        private String customerBic;

        @JsonProperty("bank_name")
        private String bankName;

        @JsonProperty("bank_country")
        private String bankCountry;
    }

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class CustomerBillingInfo {
        @JsonProperty("customer_first_name")
        private String customerFirstName;

        @JsonProperty("customer_last_name")
        private String customerLastName;

        @JsonProperty("customer_country_alpha_2")
        private String customerCountryAlpha2;

        @JsonProperty("customer_city")
        private String customerCity;

        @JsonProperty("customer_street_address")
        private String customerStreetAddress;

        @JsonProperty("customer_postcode")
        private String customerPostcode;
    }
}
