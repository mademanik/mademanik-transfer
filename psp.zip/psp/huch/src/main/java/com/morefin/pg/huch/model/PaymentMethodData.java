package com.morefin.pg.huch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentMethodData {
    @JsonProperty("payment_provider_account_id")
    private String paymentProviderAccountId;

    @JsonProperty("iban")
    private String iban;

    @JsonProperty("bic")
    private String bic;

    @JsonProperty("name")
    private String name;
}
