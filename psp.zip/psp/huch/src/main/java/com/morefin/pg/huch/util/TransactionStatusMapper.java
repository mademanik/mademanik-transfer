package com.morefin.pg.huch.util;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;

public class TransactionStatusMapper {
    public static ExecuteTransactionResponse.Status parseWithdrawalStatus(HuchWithdrawalStatus transactionStatus) {
        return switch (transactionStatus) {
            case COMPLETED -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING, NEW, AWAITING_CONFIRMATION, PROCESSING, ON_HOLD_KYC -> ExecuteTransactionResponse.Status.PENDING;
            case FAILED, CANCELLED -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }

    public static ExecuteTransactionResponse.Status parsePaymentStatus(HuchPaymentStatus transactionStatus) {
        return switch (transactionStatus) {
            case PAID, FORCE_PAID, PAID_RECEIVED -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING, NEW, AWAITING_CONFIRMATION, PROCESSING -> ExecuteTransactionResponse.Status.PENDING;
            case FAILED, CANCELLED, BANK_CONNECTION_FAILED, EXPIRED, AUTH_FAILED, EXECUTE_FAILED -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }
}