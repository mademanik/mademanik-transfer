package com.morefin.pg.huch.model;

import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.huch.common.RuntimeAccountConfig;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class HuchTransactionContext extends BaseTransactionContext<String> {

    TransactionTypeContext transactionContext;
    RuntimeAccountConfig runtimeAccountConfig;
    Boolean isHpp = false;

    Customer customerData;
    String countryIso3;
    String transactionType;
    Long amount;
    String currency;

    String iban;
    String bic;
    String receiverName;

    String statementDescriptor;
    String description;
    String reference;
    String userIp;
    String successUrl;
    String cancelUrl;
    String failureUrl;

    BrowserInfo browserInfo;

    AuthenticationResponse authenticationResponse;
    String authenticationResponseAsString;
    String accessToken;

    WithdrawalResponse withdrawalResponse;
    String withdrawalResponseAsString;

    PaymentResponse paymentResponse;
    String paymentResponseAsString;

    public HuchTransactionContext() {
        super("INITIAL_PAYMENT_PHASE");
    }
}