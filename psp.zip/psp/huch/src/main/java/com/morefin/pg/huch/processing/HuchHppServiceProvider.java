package com.morefin.pg.huch.processing;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.huch.HuchTypeModule;
import io.quarkus.arc.Arc;

public class HuchHppServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return HuchTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return HuchTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return HuchTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(HuchAPMProcessingService.class)) {
            return instance.get();
        }
    }
}
