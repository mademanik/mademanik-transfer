package com.morefin.pg.huch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetTransactionResponse implements Serializable {
    @JsonProperty("payment_status")
    private String paymentStatus;

    @JsonProperty("status_info")
    private String statusInfo;

    @JsonProperty("payment_id")
    private String paymentId;

    @JsonProperty("shop_name")
    private String shopName;

    @JsonProperty("type")
    private String type;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("label")
    private String label;

    @JsonProperty("merchant_id")
    private String merchantId;

    @JsonProperty("merchant_name")
    private String merchantName;

    @JsonProperty("merchant_logo")
    private String merchantLogo;

    @JsonProperty("url")
    private String url;

    @JsonProperty("is_mobile_platform")
    private Boolean isMobilePlatform;

    @JsonProperty("order_ref")
    private String orderRef;

    @JsonProperty("environment")
    private String environment;

    @JsonProperty("redirect_url")
    private String redirectUrl;

    @JsonProperty("bank_id")
    private String bankId;

    @JsonProperty("qr_code")
    private String qrCode;
}
