package com.morefin.pg.huch.processing;

import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingService;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingServiceProvider;
import com.morefin.pg.huch.HuchTypeModule;
import io.quarkus.arc.Arc;

public class HuchWithdrawalServiceProvider implements WithdrawalPaymentProcessingServiceProvider {
    @Override
    public WithdrawalPaymentProcessingService create() {
        try(var instance = Arc.container().instance(HuchAPMProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return HuchTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return HuchTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return HuchTypeModule.MODULE_ID;
    }
}
