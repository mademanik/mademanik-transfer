package com.morefin.pg.huch.common;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.gatewaygrpcservices.payments.paymentgateway.services.paymentprovider.PaymentProviderRepository;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionData;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.transaction.resourceactions.TransactionRepository;
import com.morefin.pg.huch.client.HuchApiClient;
import com.morefin.pg.huch.model.*;
import com.morefin.pg.huch.util.HuchPaymentStatus;
import com.morefin.pg.huch.util.TransactionStatusMapper;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.huch.util.HuchObjectTransformer;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;

@ApplicationScoped
public class FinalizeManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    HuchObjectTransformer objectTransformer;

    @Inject
    TransactionRepository transactionRepository;

    @Inject
    PaymentProviderRepository paymentProviderRepository;

    @Inject
    DtoMapperService mapperService;

    @Inject
    @RestClient
    HuchApiClient apiClient;

    BiFunction<HuchCallbackContext, Throwable, HuchCallbackContext> defaultFinalizeExceptionHandler = (context, failure) -> {
        System.out.printf("Error finalize Huch: %s", failure.getMessage());
        context.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(context, failure));
        return context;
    };

    public Uni<Response> finalizeWebhookTransaction(String callbackRequest, String tenantId) {
        HuchCallbackContext ctx = new HuchCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
            .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateWebhookContext(ctx1, callbackRequest, tenantId))
            .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
            .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
            .unwrap().map(this::buildFinalResponse);
    }

    public Uni<Response> finalizeReturnTransaction(String id, String tenantId) {
        HuchCallbackContext ctx = new HuchCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateReturnContext(ctx1, id, tenantId))
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap().map(this::buildFinalReturnResponse);
    }

    private Uni<HuchCallbackContext> hydrateWebhookContext(HuchCallbackContext ctx, String callbackRequestAsString, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseWebhookRequest(ctx, callbackRequestAsString, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    private Uni<HuchCallbackContext> hydrateReturnContext(HuchCallbackContext ctx, String id, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseReturnRequest(ctx, id, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::authenticate)
                .safeFlatMap(PHASE_GET_PAYMENT, this::getPayment)
                .endSubPhase();
    }

    private Uni<HuchCallbackContext> authenticate(HuchCallbackContext context) {
        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();
        return SafeUni.from(context, defaultFinalizeExceptionHandler, context)
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, ctx -> apiClient.authenticate(rac.clientId(), rac.clientSecret()))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseAuthenticationResponse(context, resp))
                .endSubPhase();
    }

    private Uni<HuchCallbackContext> getPayment(HuchCallbackContext context) {
        return SafeUni.from(context, defaultFinalizeExceptionHandler, context)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, ctx -> apiClient.getPayment(context.getTransactionEntity().getReferenceNumber(), "Bearer " + context.getAccessToken()))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseGetTransactionResponse(context, resp))
                .endSubPhase();
    }

    @SneakyThrows
    private HuchCallbackContext parseWebhookRequest(HuchCallbackContext ctx, String callbackRequestAsString, String tenantId) {
        //Additional step to preserve the request payload for future logging
        ctx.setIsWebhook(true);
        ctx.setTenantId(tenantId);
        ctx.setCallbackRequestAsString(callbackRequestAsString);

        ctx.setWebhookRequest(mapperService.mapAndValidate(ctx.getCallbackRequestAsString(), WebhookRequest.class));

        if ( ctx.getWebhookRequest().getPayoutId() == null ) {
            ctx.setReferenceNumber(ctx.getWebhookRequest().getPaymentId());
        } else {
            ctx.setIsWithdrawal(true);
            ctx.setReferenceNumber(ctx.getWebhookRequest().getPayoutId());
            ctx.setTransactionId(ctx.getWebhookRequest().getMerchantTransactionId());
        }

        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    @SneakyThrows
    private HuchCallbackContext parseReturnRequest(HuchCallbackContext ctx, String id, String tenantId) {
        //Additional step to preserve the request payload for future logging
        ctx.setTenantId(tenantId);
        ctx.setTransactionId(id);

        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    private Uni<HuchCallbackContext> getTransactionData(HuchCallbackContext ctx) {
        if ( ctx.getTransactionId() != null ) {
            return transactionRepository.findById(ctx.getTransactionId(), ctx.getTenantId())
                .map(optionalTransaction -> optionalTransaction
                    .map(transaction -> {
                        ctx.setTransactionEntity(transaction);
                        return ctx;
                    })
                    .orElseThrow(() -> new IllegalStateException("Transaction not found")));
        }
        return transactionRepository.withTransaction(connection -> {
            return transactionRepository.findByReferenceNumber(connection, ctx.getTenantId(), ctx.getReferenceNumber())
                    .map(optionalTransaction -> optionalTransaction
                            .map(transaction -> {
                                ctx.setTransactionEntity(transaction);
                                ctx.setTransactionId(transaction.getId());
                                return ctx;
                            })
                            .orElseThrow(() -> new IllegalStateException("Transaction not found")));
        });
    }

    private Uni<HuchCallbackContext> getPaymentProviderAccountDataByPpaId(HuchCallbackContext ctx) {
        return paymentProviderRepository.findAccountBy(ctx.getTenantId(), ctx.getTransactionEntity().getPaymentProviderAccountId())
                .map(optionalAccount -> optionalAccount
                        .map(ppa -> {
                            ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, RuntimeAccountConfig.class));
                            return ctx;
                        })
                        .orElseThrow(() -> new IllegalStateException("PaymentProviderAccount not found")));
    }

    private Response buildFinalResponse(HuchCallbackContext ctx) {
        Response.ResponseBuilder responseBuilder = Response.status(Response.Status.OK);
        if ( ctx.getErrorDescription() != null ) {
            responseBuilder
                    .entity(Map.of("error", ctx.getErrorDescription().getResponseMessage()));
        } else {
            responseBuilder.entity("OK");
        }
        return responseBuilder.build();
    }

    private Response buildFinalReturnResponse(HuchCallbackContext ctx) {
        if ( ctx.getErrorDescription() != null ) {
            return Response.serverError().build();
        }

        HuchPaymentStatus status = HuchPaymentStatus.valueOf(ctx.getStatus().toUpperCase());
        ExecuteTransactionResponse.Status transactionStatus = TransactionStatusMapper.parsePaymentStatus(status);

        TypedTransactionData transactionData = ctx.getTransactionEntity().getTransactionData();
        URI locationUri;
        switch (transactionStatus) {
            case APPROVED, PENDING -> {
                locationUri = URI.create(transactionData.getSuccessUrl());
            }
            default -> {
                if ( status.equals(HuchPaymentStatus.CANCELLED) ) {
                    locationUri = URI.create(transactionData.getCancelUrl());
                } else {
                    locationUri = URI.create(transactionData.getErrorUrl());
                }
                return Response.seeOther(locationUri).build();
            }
        }
        return Response.seeOther(locationUri).build();
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }

    private Uni<HuchCallbackContext> sendGrpcFinalizeRequest(HuchCallbackContext ctx) {
        if ( ctx.getErrorDescription() != null ) {
            return Uni.createFrom().item(ctx);
        }
        return ctx.getTransactionGrpc().
                finalizeTransaction(ctx.getFinalizeRequest())
                .map(response -> {
                    ctx.setFinalizeResponse(response);
                    return ctx;
                });
    }

    @SneakyThrows
    private HuchCallbackContext parseAuthenticationResponse(HuchCallbackContext context, Response response) {
        context.setAuthenticationResponseAsString(response.readEntity(String.class));
        context.setAuthenticationResponse(mapperService.mapAndValidate(
                context.getAuthenticationResponseAsString(),
                AuthenticationResponse.class
        ));

        context.setAccessToken(context.getAuthenticationResponse().getAccessToken());

        return context;
    }

    @SneakyThrows
    private HuchCallbackContext parseGetTransactionResponse(HuchCallbackContext context, Response response) {
        String responseAsString = response.readEntity(String.class);
        GetTransactionResponse transactionResponse = mapperService.mapAndValidate(
                responseAsString,
                GetTransactionResponse.class
        );

        context.setStatus(transactionResponse.getPaymentStatus());
        context.setReferenceNumber(transactionResponse.getPaymentId());
        context.setCallbackRequestAsString(responseAsString);

        return context;
    }
}
