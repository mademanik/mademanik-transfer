package com.morefin.pg.huch.client;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

@ApplicationScoped
public class HuchApiClientImpl {

    @Produces
    HuchApiClient apiClient() {
        return RestClientBuilder.newBuilder()
                .build(HuchApiClient.class);
    }
}
