package com.morefin.pg.huch.util;

import lombok.Getter;

@Getter
public enum HuchWithdrawalStatus {
    NEW("Payout initiated, no action yet"),
    PENDING("The transaction is temporarily on hold for one of these reasons"),
    COMPLETED("Transaction completed successfully"),
    FAILED("The transaction is failed for one of these reasons"),
    CANCELLED("Transaction cancelled"),
    INTERNAL_ERROR("Failed to initiate the transaction"),
    AWAITING_CONFIRMATION("Transaction in process"),
    PROCESSING("Transaction is processing by the bank"),
    ON_HOLD_KYC("Additional KYC checks required");

    private final String description;

    HuchWithdrawalStatus(String description) {
        this.description = description;
    }
}