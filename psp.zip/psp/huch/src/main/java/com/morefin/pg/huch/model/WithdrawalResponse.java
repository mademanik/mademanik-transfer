package com.morefin.pg.huch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WithdrawalResponse implements Serializable {
    @JsonProperty("status")
    private Integer status;

    @JsonProperty("message")
    private String message;

    @JsonProperty("data")
    private ResponseData data;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ResponseData {

        @JsonProperty("payout_id")
        private String payoutId;

        @JsonProperty("payment_flow")
        private String paymentFlow;

        @JsonProperty("amount")
        private Integer amount;

        @JsonProperty("currency")
        private String currency;

        @JsonProperty("label")
        private String label;

        @JsonProperty("status_description")
        private String statusDescription;

        @JsonProperty("status")
        private String status;

        @JsonProperty("merchant_id")
        private String merchantId;

        @JsonProperty("merchant_transaction_id")
        private String merchantTransactionId;

        @JsonProperty("environment")
        private String environment;
    }
}
