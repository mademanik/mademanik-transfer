package com.morefin.pg.huch.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Set;

public record RuntimeAccountConfig(
        @JsonProperty("merchant_id")
        String merchantId,
        @JsonProperty("client_id")
        String clientId,
        @JsonProperty("client_secret")
        String clientSecret
) {
}
