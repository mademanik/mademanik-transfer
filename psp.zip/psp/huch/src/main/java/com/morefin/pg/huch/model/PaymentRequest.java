package com.morefin.pg.huch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentRequest {
    @JsonProperty("merchant_id")
    private String merchantId;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("label")
    private String label;

    @JsonProperty("shop_name")
    private String shopName;

    @JsonProperty("order_ref")
    private String orderRef;

    @JsonProperty("success_url")
    private String successUrl;

    @JsonProperty("pending_bank_confirmation_url")
    private String pendingBankConfirmationUrl;

    @JsonProperty("decline_url")
    private String declineUrl;

    @JsonProperty("customer_email")
    private String customerEmail;

    @JsonProperty("customer_phone_number")
    private String customerPhoneNumber;

    @JsonProperty("customer_billing_info")
    private CustomerBillingInfo customerBillingInfo;

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class CustomerBillingInfo {

        @JsonProperty("customer_birth_date")
        private String customerBirthDate;

        @JsonProperty("customer_gender")
        private String customerGender;

        @JsonProperty("customer_first_name")
        private String customerFirstName;

        @JsonProperty("customer_last_name")
        private String customerLastName;

        @JsonProperty("customer_street_address")
        private String customerStreetAddress;

        @JsonProperty("customer_city")
        private String customerCity;

        @JsonProperty("customer_postcode")
        private String customerPostcode;

        @JsonProperty("customer_country_alpha_2")
        private String customerCountryAlpha2;

        @JsonProperty("customer_region_alpha_2")
        private String customerRegionAlpha2;

        @JsonProperty("customer_ip_address")
        private String customerIpAddress;
    }
}
