package com.morefin.pg.finrax.util;

public class Constants {
    public static final int ERROR_CODE_AUTH_HEADER_FAILURE = 488;
    public static final int ERROR_CODE_VALIDATION_FAILURE = 489;
    public static final int ERROR_CODE_UNPROCESSABLE_ENTITY = -1;

    public static final String CALLBACK_URL_GENERAL = "/psp/finrax/callback";
    public static final String CALLBACK_URL_DEPOSIT_RECEIVED = "/deposit-received";
    // TODO check when implementing withdrawal.
    public static final String CALLBACK_URL_WITHDRAWAL = "/withdrawal";
    public static final String CALLBACK_URL_WITHDRAWAL_APPROVAL = "/withdrawal-approval";

    public static final String SIGNATURE_HEADER = "Signature";
    public static final String TIMESTAMP_HEADER = "Timestamp";
}
