package com.morefin.pg.finrax.models;

public enum SupportedCurrencies {
    AED, ARS, AUD, BDT, BGN, BRL, CAD, CHF, CLP, CNY, CZK, DKK, EUR, GBP, HKD, HRK, HUF, IDR,
    ILS, INR, ISK, JPY, KES, KRW, MXN, MYR, NGN, NOK, NZD, PEN, PHP, PLN, QAR, RON, RUB, SEK,
    SGD, THB, TRY, USD, VND, ZAR;

    public static SupportedCurrencies fromString(String currency) {
        try {
            return SupportedCurrencies.valueOf(currency.toUpperCase());
        } catch (IllegalArgumentException e) {
            return EUR; // Default to EUR if no match
        }
    }
}

