package com.morefin.pg.finrax.service;

import com.morefin.payments.crypto.CryptoPaymentProcessingServiceProvider;
import com.morefin.payments.crypto.spy.CryptoPaymentProcessingService;
import com.morefin.pg.finrax.admin.FinraxPaymentMethodTypeModule;
import io.quarkus.arc.Arc;
import io.quarkus.arc.Unremovable;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
@Unremovable
public class FinraxPaymentProcessingServiceProvider implements CryptoPaymentProcessingServiceProvider {

    @Override
    public CryptoPaymentProcessingService create() {
        try (var instance = Arc.container().instance(FinraxPaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return FinraxPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return FinraxPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return FinraxPaymentMethodTypeModule.MODULE_ID;
    }
}
