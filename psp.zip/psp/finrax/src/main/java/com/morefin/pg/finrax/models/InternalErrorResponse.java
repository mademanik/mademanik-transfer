package com.morefin.pg.finrax.models;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import lombok.AllArgsConstructor;
import lombok.Getter;

import static com.morefin.pg.finrax.util.Constants.ERROR_CODE_AUTH_HEADER_FAILURE;
import static com.morefin.pg.finrax.util.Constants.ERROR_CODE_UNPROCESSABLE_ENTITY;
import static com.morefin.pg.finrax.util.Constants.ERROR_CODE_VALIDATION_FAILURE;

@AllArgsConstructor
@Getter
public enum InternalErrorResponse {
    AUTH_HEADER_FAILURE(ERROR_CODE_AUTH_HEADER_FAILURE, ProcessingCode.TRX_STATUS_FAILED, ExecuteTransactionResponse.Status.ERROR),
    VALIDATION_FAILURE(ERROR_CODE_VALIDATION_FAILURE, ProcessingCode.INVALID_REQUEST, ExecuteTransactionResponse.Status.ERROR),
    UNPROCESSABLE_CONTENT_FAILURE(ERROR_CODE_UNPROCESSABLE_ENTITY, ProcessingCode.TRX_STATUS_FAILED, ExecuteTransactionResponse.Status.ERROR);

    private final int statusCode;
    private final ProcessingCode processingCode;
    private final ExecuteTransactionResponse.Status transactionResponseStatus;

    public static InternalErrorResponse fromStatusCode(int statusCode) {
        for (InternalErrorResponse supportedError : values()) {
            if (supportedError.statusCode == statusCode) {
                return supportedError;
            }
        }
        throw new IllegalArgumentException("Unknown status code " + statusCode);
    }
}
