package com.morefin.pg.finrax.util;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
        @JsonProperty("api_key")
        String apiKey,
        @JsonProperty("api_secret")
        String apiSecret,
        @JsonProperty("business_id")
        String businessId,
        @JsonProperty("public_key")
        String publicKey
) {
}
