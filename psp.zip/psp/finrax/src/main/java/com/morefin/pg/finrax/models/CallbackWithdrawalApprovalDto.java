package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// TODO check when implementing withdrawal.
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CallbackWithdrawalApprovalDto implements CallbackDto {

    @JsonProperty("withdrawalId")
    private String withdrawalId;

    @JsonProperty("clientWithdrawalId")
    private String clientWithdrawalId;

    @JsonProperty("status")
    private String status;

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public String getReference() {
        return this.getClientWithdrawalId();
    }
}
