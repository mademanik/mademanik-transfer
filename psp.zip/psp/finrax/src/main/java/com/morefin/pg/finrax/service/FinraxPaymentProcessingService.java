package com.morefin.pg.finrax.service;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.payments.crypto.spy.CryptoPaymentProcessingService;
import com.morefin.pg.finrax.admin.FinraxAdminPaymentProcessingService;
import com.morefin.pg.finrax.admin.FinraxPaymentMethodTypeModule;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class FinraxPaymentProcessingService implements CryptoPaymentProcessingService {

    @Inject
    TransactionManagerService transactionManager;

    @Inject
    FinraxAdminPaymentProcessingService adminPaymentProcessingService;

    @Override
    public Uni<ExecuteTransactionResponse> deposit(TransactionTypeContext context) {
        return transactionManager.deposit(context);
    }

    // TODO check when implementing withdrawal.
    @Override
    public Uni<ExecuteTransactionResponse> withdrawal(TransactionTypeContext context) {
        return Uni.createFrom().failure(new IllegalArgumentException("Transaction type=%s not supported".formatted(context.getTransaction().getTransactionType())));
    }

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return FinraxPaymentMethodTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }
}
