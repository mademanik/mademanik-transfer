package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record DepositResponseDto(
        @JsonProperty("paymentUrl")
        String paymentUrl
) {
}
