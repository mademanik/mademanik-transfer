package com.morefin.pg.finrax.service;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.domain.tables.pojos.PaymentProviderAccount;
import com.morefin.pg.finrax.models.CallbackDto;
import com.morefin.pg.finrax.util.FinraxObjectTransformer;
import com.morefin.pg.finrax.util.RuntimeAccountConfig;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.Set;

@ApplicationScoped
public class TransactionFinalizationService {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    SignatureUtils signatureUtils;

    @Inject
    Utils utils;

    public <T extends CallbackDto> Uni<Response> finalizeTransaction(String responseBody, String signature, String timestamp, String tenantId, Class<T> dtoClass) {
        var grpc = GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                getServiceAccount(),
                Constants.LOCALHOST);

        return Uni.createFrom().item(utils.deserializeJson(responseBody, dtoClass))
                .flatMap(apiResponseDto -> validateCallbackResponse(apiResponseDto.getReference(), responseBody, signature, timestamp, tenantId)
                        .replaceWith(apiResponseDto)
                )
                .map(FinraxObjectTransformer::mapToFinalizeTransactionRequest)
                .flatMap(grpc::finalizeTransaction)
                .map(result -> {
                    if (result.hasRedirect()) {
                        return Response.ok().build();
                    } else {
                        return Response.status(400).build();
                    }
                })
                .onFailure(SecurityException.class)
                .recoverWithItem(() ->
                        Response.status(Response.Status.BAD_REQUEST)
                                .entity(Map.of("error", "Invalid signature")).build()
                )
                .onFailure()
                .recoverWithItem(throwable ->
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                                .entity(Map.of("error", throwable.getMessage())).build()
                );
    }

    private Uni<Void> validateCallbackResponse(String transactionId, String rawBody, String signature, String timestamp, String tenantId
    ) {
        return signatureUtils.findPaymentProviderSignatureSecret(transactionId, tenantId, this::getPublicKey)
                .flatMap(pubKeyBase64 -> {
                    if (StringUtils.isEmpty(signature) || StringUtils.isEmpty(timestamp)) {
                        Log.warn("Missing signature or timestamp in finrax callback");
                        return Uni.createFrom().failure(new SecurityException("Invalid signature or timestamp"));
                    }

                    String signaturePayload = rawBody + "." + timestamp;

                    if (!SignatureUtils.verifySha512Signature(signaturePayload, signature, pubKeyBase64)) {
                        Log.errorf("Invalid signature for transaction: %s", transactionId);
                        return Uni.createFrom().failure(new SecurityException("Invalid signature"));
                    }
                    return Uni.createFrom().voidItem();
                });
    }

    private String getPublicKey(PaymentProviderAccount account) {
        return Utils.getRuntimeAccountConfig(account, RuntimeAccountConfig.class).publicKey();
    }

    private GrpcApiUser getServiceAccount() {
        return GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "finrax-service-account"
        );
    }
}
