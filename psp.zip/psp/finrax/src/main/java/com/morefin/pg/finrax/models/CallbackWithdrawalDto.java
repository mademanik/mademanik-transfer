package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// TODO check when implementing withdrawal.
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CallbackWithdrawalDto implements CallbackDto {

    @JsonProperty("status")
    private String status;

    @JsonProperty("clientWithdrawalId")
    private String clientWithdrawalId;

    @JsonProperty("businessId")
    private String businessId;

    @JsonProperty("withdrawalId")
    private String withdrawalId;

    @JsonProperty("displayCurrency")
    private String displayCurrency;

    @JsonProperty("withdrawCurrency")
    private String withdrawCurrency;

    @JsonProperty("settlementCurrency")
    private String settlementCurrency;

    @JsonProperty("expectedDisplayAmount")
    private String expectedDisplayAmount;

    @JsonProperty("actualDisplayAmount")
    private String actualDisplayAmount;

    @JsonProperty("estimatedWithdrawAmount")
    private String estimatedWithdrawAmount;

    @JsonProperty("actualWithdrawAmount")
    private String actualWithdrawAmount;

    @JsonProperty("deductedSettlementAmount")
    private String deductedSettlementAmount;

    @JsonProperty("withdrawFee")
    private String withdrawFee;

    @JsonProperty("displayFee")
    private String displayFee;

    @JsonProperty("toTxAddress")
    private String toTxAddress;

    @JsonProperty("transactionId")
    private String transactionId;

    @JsonProperty("txAddressOwner")
    private TxAddressOwner txAddressOwner;

    public static class TxAddressOwner {
        @JsonProperty("name")
        private String name;

        @JsonProperty("category")
        private String category;
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public String getReference() {
        return this.getClientWithdrawalId();
    }
}
