package com.morefin.pg.finrax.util;

import com.morefin.common.grpc.payment.TransactionStatus;
import io.quarkus.logging.Log;

public class TransactionStatusMapper {

    public static TransactionStatus parseToGrpcTransactionStatus(String status) {
        return switch (status.toUpperCase()) {
            case "CONFIRMED", "COMPLETED", "APPROVED" -> TransactionStatus.APPROVED;
            case "FAILED", "BLOCKED", "REJECTED" -> TransactionStatus.DECLINED;
            default -> {
                Log.warn("Received unsupported transaction status: " + status);
                throw new IllegalArgumentException("Unsupported transaction status: " + status);
            }
        };
    }

}
