package com.morefin.pg.finrax.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.pg.finrax.models.CallbackDto;
import com.morefin.pg.finrax.models.DepositRequestDto;
import com.morefin.pg.finrax.models.DepositResponseDto;
import com.morefin.pg.finrax.models.ErrorResponse;
import com.morefin.pg.finrax.models.InternalErrorResponse;
import com.morefin.pg.finrax.models.SupportedCurrencies;
import com.morefin.pg.finrax.models.SupportedLocales;
import io.smallrye.mutiny.tuples.Tuple2;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;


@ApplicationScoped
public class FinraxObjectTransformer {

    public static final String PAYMENT_TYPE = "ONE_TIME";
    public static final String RATE_TYPE = "FIXED";
//    public static final String TARGET_AMT_POLICY = "crypto";
//    public static final String WITHDRAWAL_ACCOUNT = "crypto";

    @Inject
    ObjectMapper objectMapper;

    public static FinalizeTransactionRequest mapToFinalizeTransactionRequest(CallbackDto dto) {
        TransactionStatus status = TransactionStatusMapper.parseToGrpcTransactionStatus(dto.getStatus());
        String message = "Transaction %s.".formatted(dto.getStatus());
        return FinalizeTransactionRequest.newBuilder()
                .setId(dto.getReference())
                .setStatus(status)
                .setResponseMessage(message)
                .setPaymentProviderResponseMessage(message)
                .build();
    }

    public static DepositRequestDto createDepositRequestDto(TransactionTypeContext context, RuntimeAccountConfig runtimeAccountConfig) {
        return new DepositRequestDto(
                context.getTransaction().getId(),
                runtimeAccountConfig.businessId(),
                SupportedLocales.fromString(context.getTransaction().getCustomerCountry()).getCode(),
                SupportedCurrencies.fromString(context.getTransaction().getCurrency()).name(),
                BigDecimal.valueOf(context.getTransaction().getAmount()).divide(BigDecimal.valueOf(100)),
                PAYMENT_TYPE,
                RATE_TYPE
        );
    }

    // TODO check when implementing withdrawal.
//    public WithdrawalRequestDto createWithdrawalRequestDto(TransactionTypeContext context, RuntimeAccountConfig runtimeAccountConfig) {
//        Map<String, String> map = ((AuthorizeTransactionContext) context).paymentMethodData();
//        return new WithdrawalRequestDto(
//                context.getTransaction().getCustomerId() + "-" + System.currentTimeMillis(),
//                runtimeAccountConfig.businessId(),
//                map.get("network"),
//                map.get("recipientAddress"),
//                map.get("withdrawCurrency"),
//                context.getTransaction().getCurrency(),
//                BigDecimal.valueOf(context.getTransaction().getAmount()).divide(BigDecimal.valueOf(100)).toString(),
//                TARGET_AMT_POLICY,
//                WITHDRAWAL_ACCOUNT
//        );
//    }

    // TODO check when implementing withdrawal.
//    public WithdrawaResponseDto deserializeWithdrawalResponse(String responseBody) {
//        try {
//            return objectMapper.readValue(responseBody, WithdrawaResponseDto.class);
//        } catch (JsonProcessingException e) {
//            throw new IllegalArgumentException("Invalid withdrawal response body: " + responseBody, e);
//        }
//    }

    public ExecuteTransactionResponse mapToExecuteTransactionResponse(Tuple2<Response, Throwable> processingResponse, String transactionId) {
        try {
            if (processingResponse.getItem1() != null) {
                var responseEntity = processingResponse.getItem1().readEntity(String.class);
                if (processingResponse.getItem1().getStatus() == Constants.ERROR_CODE_VALIDATION_FAILURE
                        || processingResponse.getItem1().getStatus() == Constants.ERROR_CODE_AUTH_HEADER_FAILURE) {
                    return buildInternalErrorTransactionResponse(transactionId, InternalErrorResponse.fromStatusCode(processingResponse.getItem1().getStatus()), responseEntity);
                } else {
                    var response = objectMapper.readValue(responseEntity, DepositResponseDto.class);
                    return buildPendingTransactionResponse(response);
                }
            } else {
                if (processingResponse.getItem2() instanceof WebApplicationException wae) {
                    var errorResponse = wae.getResponse().readEntity(ErrorResponse.class);
                    return buildErrorTransactionResponse(transactionId, errorResponse);
                } else {
                    return buildInternalErrorTransactionResponse(transactionId, InternalErrorResponse.UNPROCESSABLE_CONTENT_FAILURE, processingResponse.getItem2().getMessage());
                }
            }
        } catch (Exception e) {
            return buildInternalErrorTransactionResponse(transactionId, InternalErrorResponse.UNPROCESSABLE_CONTENT_FAILURE, e.getMessage());
        }
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(
            DepositResponseDto response) {
        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                //TODO: set all response data here
                .setResponse(ExecuteTransactionResponse.Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name()).build())
                .setRedirect(
                        new GrpcBuilder<>(builder)
                                .set(response.paymentUrl(), builder::setUrl)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    public ExecuteTransactionResponse buildInternalErrorTransactionResponse(String transactionId, InternalErrorResponse response, String message) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(transactionId, builder::setId)
                                .setAny(response.getTransactionResponseStatus(), builder::setStatus)
                                .set(response.getProcessingCode().name(), builder::setResponseCode)
                                .set(StringUtils.abbreviate(message, 50), builder::setResponseMessage)
                                .getBuilder().build()
                )
                .build();
    }

    public ExecuteTransactionResponse buildErrorTransactionResponse(String transactionId, ErrorResponse err) {
        var responseCode = ProcessingCode.INVALID_REQUEST;
        var responseStatus = ExecuteTransactionResponse.Status.ERROR;
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(transactionId, builder::setId)
                                .setAny(responseStatus, builder::setStatus)
                                .set(responseCode.name(), builder::setResponseCode)
                                .set(StringUtils.abbreviate(err.message(), 50), builder::setResponseMessage)
                                .setAny(err.message(), builder::setPaymentProviderResponseMessage)
                                .setAndMap(JsonObject.mapFrom(err).getMap(), GrpcFactory::fromMap, builder::setData)
                                .getBuilder().build()
                )
                .build();
    }

// TODO check when implementing withdrawal.
//    private ExecuteTransactionResponse buildWithdrawalTransactionResponse(WithdrawaResponseDto dto, String transactionId) {
//        String providerStatus = dto.status() != null ? dto.status() : "UNKNOWN";
//
//        var status = TransactionStatusMapper.parseToExecuteTransactionStatus(providerStatus);
//        var processingCode = TransactionStatusMapper.parseToResponseCode(status);
//        String message = "Transaction is %s".formatted(providerStatus);
//
//        var builder = ExecuteTransactionResponse.Response.newBuilder();
//        return ExecuteTransactionResponse.newBuilder()
//                .setResponse(
//                        new GrpcBuilder<>(builder)
//                                .set(transactionId, builder::setId)
//                                .set(processingCode.name(), builder::setResponseCode)
//                                .set(message, builder::setResponseMessage)
//                                .set("", builder::setApprovalCode)
//                                .setAny(message, builder::setPaymentProviderResponseMessage)
//                                .setAny(providerStatus, builder::setPaymentProviderResponseCode)
//                                .setAndMap(JsonObject.mapFrom(dto).getMap(), GrpcFactory::fromMap, builder::setData)
//                                .set(status.toString(), builder::setPaymentProviderStatus)
//                                .setAny(status, builder::setStatus)
//                                .getBuilder().build()
//                )
//                .build();
//    }

}
