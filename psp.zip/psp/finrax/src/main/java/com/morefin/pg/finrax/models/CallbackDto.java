package com.morefin.pg.finrax.models;

public interface CallbackDto {
    String getStatus();

    String getReference();
}