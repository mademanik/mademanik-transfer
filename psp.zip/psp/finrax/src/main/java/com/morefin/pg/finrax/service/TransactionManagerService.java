package com.morefin.pg.finrax.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.finrax.client.FinraxApiClient;
import com.morefin.pg.finrax.models.Payload;
import com.morefin.pg.finrax.util.FinraxObjectTransformer;
import com.morefin.pg.finrax.util.RuntimeAccountConfig;
import com.morefin.pg.finrax.util.TransactionSignatureUtil;
import com.morefin.pg.utils.DtoValidationService;
import com.morefin.pg.utils.Utils;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.tuples.Tuple2;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jooq.tools.StringUtils;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import static com.morefin.pg.finrax.util.Constants.ERROR_CODE_AUTH_HEADER_FAILURE;
import static com.morefin.pg.finrax.util.Constants.ERROR_CODE_VALIDATION_FAILURE;

@ApplicationScoped
public class TransactionManagerService {

    @RestClient
    FinraxApiClient apiClient;

    @Inject
    FinraxObjectTransformer objectTransformer;

    @Inject
    DtoValidationService dtoValidationService;

    public Uni<ExecuteTransactionResponse> deposit(TransactionTypeContext context) {
        return Uni.createFrom().item(context)
                .map(this::processPayload)
                .flatMap(this::executeRequest)
                .onItemOrFailure()
                .transform((response, failure) -> {
                    Tuple2<Response, Throwable> tuple;
                    if (failure != null) {
                        tuple = Tuple2.of(null, failure);
                    } else {
                        tuple = Tuple2.of(response, null);
                    }
                    return objectTransformer.mapToExecuteTransactionResponse(tuple, context.getTransaction().getId());
                });
    }

    private Payload processPayload(TransactionTypeContext context) {
        Payload payload = buildPayload(context);
        validateDto(payload);
        return buildAuthHeader(payload);
    }

    private Payload buildPayload(TransactionTypeContext context) {
        var runtimeAccountConfig = Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), RuntimeAccountConfig.class);
        var requestDto = FinraxObjectTransformer.createDepositRequestDto(context, runtimeAccountConfig);
        return new Payload(requestDto, runtimeAccountConfig, null, null);
    }

    private Payload validateDto(Payload payload) {
        String error = dtoValidationService.validateRequest(payload.getRequestDto());
        payload.setValidationErrorMessage(error);
        return payload;
    }

    private Payload buildAuthHeader(Payload payload) {
        String pathWithQuery = UriBuilder.fromUri("")
                .path(FinraxApiClient.class)
                .path(FinraxApiClient.class, "deposit")
                .build()
                .toString();
        try {
            payload.setAuthHeader(TransactionSignatureUtil.buildAuthHeader(pathWithQuery, payload.getRequestDto(), payload.getRuntimeAccountConfig()));
        } catch (JsonProcessingException | NoSuchAlgorithmException | InvalidKeyException e) {
            Log.errorf(e, "Failed to build auth header: " + e.getMessage());
        }
        return payload;
    }

    private Uni<Response> executeRequest(Payload payload) {
        if (!StringUtils.isEmpty(payload.getValidationErrorMessage())) {
            return Uni.createFrom().item(() -> Response.status(ERROR_CODE_VALIDATION_FAILURE).entity(payload.getValidationErrorMessage()).build());
        } else if (StringUtils.isEmpty(payload.getAuthHeader())) {
            return Uni.createFrom().item(() -> Response.status(ERROR_CODE_AUTH_HEADER_FAILURE).entity("Failed to build authentication header.").build());
        } else {
            return apiClient.deposit(payload.getRequestDto(), payload.getAuthHeader());
        }
    }

    // TODO check when implementing withdrawal.
//    public Uni<ExecuteTransactionResponse> withdrawal(TransactionTypeContext context) {
//        var runtimeAccountConfig = Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), RuntimeAccountConfig.class);
//        WithdrawalRequestDto requestDto = objectTransformer.createWithdrawalRequestDto(context, runtimeAccountConfig);
//        String pathWithQuery = UriBuilder.fromUri("")
//                .path(FinraxApiClient.class)
//                .path(FinraxApiClient.class, "withdrawal")
//                .build().toString();
//        try {
//            String authHeader = TransactionSignatureUtil.buildAuthHeader(pathWithQuery, requestDto, runtimeAccountConfig);
//            return apiClient.withdrawal(requestDto, authHeader)
//                    .onItemOrFailure()
//                    .transform((responseBody, failure) -> {
//                        if (failure == null) {
//                            return objectTransformer.deserializeWithdrawalResponse(responseBody);
//                        }
//                        return ((WebApplicationException) failure).getResponse().readEntity(ErrorResponse.class);
//                    })
//                    .map(resp -> objectTransformer.mapToExecuteTransactionResponse(resp, context.getTransaction().getId()));
//        } catch (Exception e) {
//            return Uni.createFrom().item(
//                    objectTransformer.buildErrorTransactionResponse(new ErrorResponse(context.getTransaction().getId(), "Failed to build header: " + e.getMessage()), context.getTransaction().getId())
//            );
//        }
//    }
}
