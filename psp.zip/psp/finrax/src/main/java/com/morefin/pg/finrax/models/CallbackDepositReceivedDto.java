package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CallbackDepositReceivedDto implements CallbackDto {

    @JsonProperty("clientPaymentId")
    private String clientPaymentId;

    @JsonProperty("status")
    private String status;

    @Override
    public String getReference() {
        return this.clientPaymentId;
    }

    @Override
    public String getStatus() {
        return status;
    }

}
