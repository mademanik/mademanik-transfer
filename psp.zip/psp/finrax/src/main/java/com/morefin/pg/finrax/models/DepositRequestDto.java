package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;

@AllArgsConstructor
@Getter
public class DepositRequestDto {

    @NotNull
    @JsonProperty("clientPaymentId")
    private String clientPaymentId;

    @NotNull
    @JsonProperty("businessId")
    private String businessId;

    // lower case
    @NotNull
    @Size(min = 2, max = 2)
    @JsonProperty("locale")
    private String locale;

    @NotNull
    @Size(min = 3, max = 3)
    @JsonProperty("displayCurrency")
    private String displayCurrency;

    @NotNull
    @JsonProperty("displayAmount")
    private BigDecimal displayAmount;

    @NotNull
    @JsonProperty(value = "type", defaultValue = "ONE_TIME")
    private String type;

    @NotNull
    @JsonProperty(value = "rateType", defaultValue = "FIXED")
    private String rateType;

}
