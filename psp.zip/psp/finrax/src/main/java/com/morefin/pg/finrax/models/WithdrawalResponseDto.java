package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

// TODO check when implementing withdrawal.
@JsonIgnoreProperties(ignoreUnknown = true)
public record WithdrawalResponseDto(

        @JsonProperty("withdrawId")
        String withdrawId,

        @JsonProperty("clientWithdrawId")
        String clientWithdrawId,

        @JsonProperty("recipientAddress")
        String recipientAddress,

        @JsonProperty("network")
        String network,

        @JsonProperty("initiatedBy")
        String initiatedBy,

        @JsonProperty("status")
        String status,

        @JsonProperty("displayCurrency")
        String displayCurrency,

        @JsonProperty("estimatedDisplayAmount")
        String estimatedDisplayAmount,

        @JsonProperty("displayServiceFee")
        String displayServiceFee,

        @JsonProperty("withdrawCurrency")
        String withdrawCurrency,

        @JsonProperty("estimatedWithdrawAmount")
        String estimatedWithdrawAmount,

        @JsonProperty("settlementCurrency")
        String settlementCurrency,

        @JsonProperty("settlementDeductedAmount")
        String settlementDeductedAmount,

        @JsonProperty("settlementServiceFee")
        String settlementServiceFee,

        @JsonProperty("uniformCurrency")
        String uniformCurrency,

        @JsonProperty("uniformAmount")
        String uniformAmount,

        @JsonProperty("uniformServiceFee")
        String uniformServiceFee,

        @JsonProperty("createdAt")
        Long createdAt

) {
}
