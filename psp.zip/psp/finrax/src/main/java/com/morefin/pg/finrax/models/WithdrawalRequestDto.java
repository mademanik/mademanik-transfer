package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// TODO check when implementing withdrawal.
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WithdrawalRequestDto {
    @JsonProperty("clientWithdrawalId")
    private String clientWithdrawalId;

    @JsonProperty("businessId")
    private String businessId;

    @JsonProperty("network")
    private String network;

    @JsonProperty("address")
    private String address;

    @JsonProperty("withdrawCurrency")
    private String withdrawCurrency;

    @JsonProperty("displayCurrency")
    private String displayCurrency;

    @JsonProperty("displayAmount")
    private String displayAmount;

    @JsonProperty("targetAmountPolicy")
    private String targetAmountPolicy;

    @JsonProperty("withdrawalAccount")
    private String withdrawalAccount;

}
