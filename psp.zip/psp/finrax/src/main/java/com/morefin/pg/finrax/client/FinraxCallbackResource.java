package com.morefin.pg.finrax.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.finrax.models.CallbackDepositReceivedDto;
import com.morefin.pg.finrax.models.CallbackWithdrawalApprovalDto;
import com.morefin.pg.finrax.models.CallbackWithdrawalDto;
import com.morefin.pg.finrax.service.TransactionFinalizationService;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import static com.morefin.pg.finrax.util.Constants.CALLBACK_URL_DEPOSIT_RECEIVED;
import static com.morefin.pg.finrax.util.Constants.CALLBACK_URL_GENERAL;
import static com.morefin.pg.finrax.util.Constants.CALLBACK_URL_WITHDRAWAL;
import static com.morefin.pg.finrax.util.Constants.CALLBACK_URL_WITHDRAWAL_APPROVAL;
import static com.morefin.pg.finrax.util.Constants.SIGNATURE_HEADER;
import static com.morefin.pg.finrax.util.Constants.TIMESTAMP_HEADER;

@Path(CALLBACK_URL_GENERAL)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FinraxCallbackResource {

    @Inject
    Tenant tenant;

    @Inject
    TransactionFinalizationService finalizeTransactionManager;

    @POST
    @Path(CALLBACK_URL_DEPOSIT_RECEIVED)
    public Uni<Response> depositCallbackReceived(
            String rawJson,
            @HeaderParam(SIGNATURE_HEADER) String signature,
            @HeaderParam(TIMESTAMP_HEADER) String timestamp
    ) {
        return finalizeTransactionManager.finalizeTransaction(rawJson, signature, timestamp, tenant.id(), CallbackDepositReceivedDto.class);
    }

    // TODO check when implementing withdrawal.
    @POST
    @Path(CALLBACK_URL_WITHDRAWAL)
    public Uni<Response> withdrawalCallbackReceived(
            String rawJson,
            @HeaderParam(SIGNATURE_HEADER) String signature,
            @HeaderParam(TIMESTAMP_HEADER) String timestamp
    ) {
        return finalizeTransactionManager.finalizeTransaction(rawJson, signature, timestamp, tenant.id(), CallbackWithdrawalDto.class);
    }

    // TODO check when implementing withdrawal.
    /**
     * Received when withdrawal that was pending approval is either approved or rejected
     */
    @POST
    @Path(CALLBACK_URL_WITHDRAWAL_APPROVAL)
    public Uni<Response> withdrawalCallbackApproval(
            String rawJson,
            @HeaderParam(SIGNATURE_HEADER) String signature,
            @HeaderParam(TIMESTAMP_HEADER) String timestamp
    ) {
        return finalizeTransactionManager.finalizeTransaction(rawJson, signature, timestamp, tenant.id(), CallbackWithdrawalApprovalDto.class);
    }
}
