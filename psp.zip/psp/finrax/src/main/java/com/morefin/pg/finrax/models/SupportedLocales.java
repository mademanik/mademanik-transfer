package com.morefin.pg.finrax.models;

public enum SupportedLocales {
    ARABIC("ar"),
    BULGARIAN("bg"),
    CHINESE("zh"),
    ENGLISH("en"),
    FRENCH("fr"),
    GERMAN("de"),
    JAPANESE("ja"),
    LITHUANIAN("lt"),
    PORTUGUESE("pt"),
    RUSSIAN("ru"),
    SPANISH("es"),
    TURKISH("tr");

    private final String code;

    SupportedLocales(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static SupportedLocales fromString(String locale) {
        for (SupportedLocales supportedLocale : values()) {
            if (supportedLocale.code.equalsIgnoreCase(locale)) {
                return supportedLocale;
            }
        }
        return ENGLISH;
    }
}
