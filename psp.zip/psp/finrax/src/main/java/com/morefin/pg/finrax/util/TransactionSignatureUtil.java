package com.morefin.pg.finrax.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class TransactionSignatureUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static String buildAuthHeader(String pathWithQuery, Object requestDto, RuntimeAccountConfig accountConfig) throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException {
        long timestamp = System.currentTimeMillis();

        String jsonBodyString = objectMapper.writeValueAsString(requestDto);
        String signaturePayload = pathWithQuery + timestamp + jsonBodyString;

        String signature = generateSignature(signaturePayload, accountConfig);

        return String.format(
                "FRX-API api-key=%s, signature=%s, timestamp=%d",
                accountConfig.apiKey(),
                signature,
                timestamp
        );
    }

    private static String generateSignature(String data, RuntimeAccountConfig accountConfig) throws InvalidKeyException, NoSuchAlgorithmException {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(accountConfig.apiSecret().getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));

        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (byte b : hash) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }
}
