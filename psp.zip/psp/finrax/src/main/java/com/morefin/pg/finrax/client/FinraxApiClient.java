package com.morefin.pg.finrax.client;

import com.morefin.pg.finrax.models.DepositRequestDto;
import com.morefin.pg.finrax.models.WithdrawalRequestDto;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;


@Path("/api/v1")
@RegisterRestClient(configKey = "finrax")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface FinraxApiClient {

    @POST
    @Path("/payments")
    Uni<Response> deposit(DepositRequestDto request, @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);

    // TODO check when implementing withdrawal.
    @POST
    @Path("/withdrawals")
    Uni<Response> withdrawal(WithdrawalRequestDto request, @HeaderParam(HttpHeaders.AUTHORIZATION) String authHeader);
}
