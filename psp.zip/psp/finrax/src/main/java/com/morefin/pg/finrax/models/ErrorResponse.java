package com.morefin.pg.finrax.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public record ErrorResponse(
        @JsonProperty("requestId")
        String requestId,
        @JsonProperty("message")
        String message
) {
}
