package com.morefin.pg.finrax.models;

import com.morefin.pg.finrax.util.RuntimeAccountConfig;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class Payload {
    DepositRequestDto requestDto;
    RuntimeAccountConfig runtimeAccountConfig;
    String authHeader;
    String validationErrorMessage;
}
