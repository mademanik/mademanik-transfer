package com.morefin.pg.nixxe.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public record ApiErrorResponseDto(
        @JsonProperty("error")
        ErrorResponse error
) {
    public record ErrorResponse(
            @JsonProperty("code")
            Integer code,
            @JsonProperty("message")
            String message,
            @JsonProperty("data")
            Object data
    ) {
    }

}
