package com.morefin.pg.nixxe.authentication;

import com.morefin.common.authenticationadminspi.admin.spi.AdminAuthenticationService;
import com.morefin.common.authenticationgatewayspi.spi.AuthenticationServiceLookupContext;
import com.morefin.common.authenticationgatewayspi.spi.card.CardAuthenticateResponse;
import com.morefin.common.authenticationgatewayspi.spi.card.CardAuthenticationService;
import com.morefin.common.authenticationgatewayspi.spi.card.ChallengeResponse;
import com.morefin.common.authenticationgatewayspi.spi.card.ChallengeResponseRequest;
import com.morefin.common.authenticationgatewayspi.spi.card.DelegatedThreeDs;
import com.morefin.common.authenticationgatewayspi.spi.card.ThreeDSAuthenticationRequest;
import com.morefin.common.authenticationgatewayspi.spi.card.VersioningRequest;
import com.morefin.common.common.framework.context.MethodContext;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.security.interfaces.RSAPublicKey;


@ApplicationScoped
@Unremovable
public class NixxeCardAuthenticationService implements CardAuthenticationService {

    private static final DelegatedThreeDs DELEGATED = new DelegatedThreeDs("nixxe-three-ds-authentication");

    @Inject
    NixxeAdminAuthenticationService nixxeAdminAuthenticationService;

    @Override
    public Uni<CardAuthenticateResponse> threeDSAuthentication(MethodContext<ThreeDSAuthenticationRequest> request) {
        return Uni.createFrom().failure(new IllegalStateException("threeDSAuthentication not supported"));
    }

    @Override
    public Uni<CardAuthenticateResponse> versioning(MethodContext<VersioningRequest> request) {
        return Uni.createFrom().item(DELEGATED);
    }

    @Override
    public Uni<ChallengeResponse> challengeResponse(ChallengeResponseRequest request) {
        return Uni.createFrom().failure(new IllegalStateException("challengeResponse not supported"));
    }


    @Override
    public RSAPublicKey publicKey() {
        throw new IllegalStateException("Not implemented");
    }

    @Override
    public String name() {
        return NixxeCardAuthenticationModule.MODULE_ID;
    }

    @Override
    public String id() {
        return NixxeCardAuthenticationModule.MODULE_ID;
    }

    @Override
    public boolean isApplicable(AuthenticationServiceLookupContext context) {
        var paymentMethodType = context.paymentMethodType();
        var paymentMethodSupported = "card".equalsIgnoreCase(paymentMethodType) || "saved_card".equalsIgnoreCase(paymentMethodType);
        return "ecommerce".equalsIgnoreCase(context.channel()) && paymentMethodSupported;
    }

    @Override
    public String type() {
        return "delegated";
    }

    @Override
    public AdminAuthenticationService admin() {
        return nixxeAdminAuthenticationService;
    }

}
