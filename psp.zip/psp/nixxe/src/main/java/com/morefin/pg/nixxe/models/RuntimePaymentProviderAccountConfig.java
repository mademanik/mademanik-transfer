package com.morefin.pg.nixxe.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimePaymentProviderAccountConfig(
        @JsonProperty("api_key")
        String apiKey,
        @JsonProperty("signature_password")
        String signaturePassword,
        @JsonProperty("is_prod_environment")
        Boolean isProdEnvironment,
        @JsonProperty("routing_id")
        Integer routingId
) {
}