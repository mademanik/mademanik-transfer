package com.morefin.pg.nixxe.util;

public class Constants {
    public static final String CALLBACK_URL = "/psp/nixxe/callback";

    public static final int VALIDATION_ERROR_CODE = 480;
    public static final String UNEXPECTED_PSP_RESPONSE_MESSAGE = "Unexpected PSP response";

}
