package com.morefin.pg.nixxe.client;

import com.morefin.pg.nixxe.models.AuthorizeTransactionRequestDto;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/v1/payment")
@RegisterRestClient(configKey = "nixxe")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface NixxeApiClient {

    @POST
    @Path("/server-to-server")
    Uni<Response> authorize(AuthorizeTransactionRequestDto request, @HeaderParam("x-api-key") String apiKey);
}
