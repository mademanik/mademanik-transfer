package com.morefin.pg.nixxe.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CallbackResponseDto(
        @JsonProperty("transaction_id")
        String transactionId,
        @JsonProperty("transaction_type")
        String transactionType,
        @JsonProperty("tracking_id")
        String trackingId,
        @JsonProperty("status")
        Status status,
        @JsonProperty("provider")
        String provider
) {
    @AllArgsConstructor
    @Getter
    public enum Status {
        SUCCESSFUL("successful"),
        PENDING("pending"),
        REJECTED("rejected"),
        EXPIRED("expired");

        private final String value;

        @JsonCreator
        public static Status fromValue(String value) {
            for (Status status : Status.values()) {
                if (status.value.equalsIgnoreCase(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown status value: " + value);
        }
    }
}
