package com.morefin.pg.nixxe.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.pg.nixxe.admin.card.Config;
import com.morefin.pg.nixxe.admin.card.NixxeAdminPaymentProcessingServiceImpl;
import com.morefin.pg.nixxe.common.AuthorizeTransactionManager;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class NixxePaymentProcessingService implements EcommerceCardPaymentProcessingService {

    @Inject
    Config config;

    @Inject
    NixxeAdminPaymentProcessingServiceImpl adminPaymentProcessingService;

    @Inject
    AuthorizeTransactionManager authorizeTransactionManager;

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext context) {
        return authorizeTransactionManager.authorize(context);
    }

    @Override
    public Uni<ExecuteTransactionResponse> manage(ManageTransactionContext context) {
        return Uni.createFrom()
                .failure(new IllegalArgumentException("Transaction type %s not supported".formatted(context.transactionType().toLowerCase())));
    }

    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String id) {
        return Optional.empty();
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }

}
