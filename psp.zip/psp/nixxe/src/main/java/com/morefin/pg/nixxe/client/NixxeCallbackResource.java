package com.morefin.pg.nixxe.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.nixxe.common.FinalizeTransactionManager;
import com.morefin.pg.nixxe.util.Constants;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(Constants.CALLBACK_URL)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class NixxeCallbackResource {

    @Inject
    FinalizeTransactionManager finalizeTransactionManager;

    @Inject
    Tenant tenant;

    @POST
    public Uni<Response> returnUrl(String body, @HeaderParam("x-signature") String signature) {
        return finalizeTransactionManager.finalizeTransaction(body, signature, tenant.id());
    }
}
