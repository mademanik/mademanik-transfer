package com.morefin.pg.nixxe.models;

import lombok.Getter;

@Getter
public class Payload {
    private AuthorizeTransactionRequestDto requestDto;
    private RuntimePaymentProviderAccountConfig accountConfig;
    private String error;

    public Payload(AuthorizeTransactionRequestDto requestDto, RuntimePaymentProviderAccountConfig accountConfig) {
        this.requestDto = requestDto;
        this.accountConfig = accountConfig;
    }

    public Payload(String error) {
        this.error = error;
    }

}
