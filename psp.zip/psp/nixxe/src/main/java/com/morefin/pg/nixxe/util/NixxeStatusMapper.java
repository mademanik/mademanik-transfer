package com.morefin.pg.nixxe.util;

import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.pg.nixxe.models.CallbackResponseDto;

public class NixxeStatusMapper {

    public static TransactionStatus parseToGrpcTransactionStatus(CallbackResponseDto callbackDto) {
        return switch (callbackDto.status()) {
            case SUCCESSFUL -> TransactionStatus.APPROVED;
            case PENDING -> TransactionStatus.PENDING;
            case REJECTED -> TransactionStatus.DECLINED;
            case EXPIRED -> TransactionStatus.DECLINED; // TODO when working TransactionStatus.SESSION_EXPIRED;
        };
    }


}
