package com.morefin.pg.nixxe.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;

@AllArgsConstructor
public class AuthorizeTransactionRequestDto {

    @JsonProperty("request")
    @Valid
    Request request;

    @AllArgsConstructor
    public static class Request {
        @NotNull
        @Pattern(regexp = "test|prod")
        @JsonProperty("mode")
        private String mode;

        @NotNull
        @JsonProperty("routing_id")
        int routing_id;

        @JsonProperty("settings")
        Settings settings;

        @NotNull
        @JsonProperty("user_id")
        String userId;

        @NotNull
        @JsonProperty("tracking_id")
        String trackingId;

        @NotNull
        @JsonProperty("ip")
        String ip;

        @NotNull
        @JsonProperty("amount")
        BigDecimal amount;

        @NotNull
        @JsonProperty("currency")
        String currency;

        @NotNull
        @Valid
        @JsonProperty("customer")
        Customer customer;

        @NotNull
        @Valid
        @JsonProperty("card_details")
        CardDetails cardDetails;

        @AllArgsConstructor
        public static class Settings {
            @JsonProperty("status_url")
            String statusUrl;

            @JsonProperty("return_url")
            String returnUrl;
        }

        @AllArgsConstructor
        public static class Customer {

            @NotNull
            @JsonProperty("first_name")
            String firstName;

            @NotNull
            @JsonProperty("last_name")
            String lastName;

            @NotNull
            @Email
            @JsonProperty("email")
            String email;

            @NotNull
            @JsonProperty("zip_code")
            String zipCode;

            @NotNull
            @JsonProperty("address")
            String address;

            @NotNull
            @JsonProperty("city")
            String city;

            @NotNull
            @Pattern(
                    regexp = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/(\\d{4})$",
                    message = "Date must be in DD/MM/YYYY format"
            )
            @JsonProperty("dob")
            String dateOfBirth;

            @NotNull
            @Size(min = 2, max = 2)
            @JsonProperty("country_code")
            String country_code;

            @NotNull
            @Valid
            @JsonProperty("phone")
            Phone phone;


            @AllArgsConstructor
            public static class Phone {
                @NotNull
                @Size(min = 2, max = 2)
                @JsonProperty("country")
                String country;

                @NotNull
                @JsonProperty("number")
                String number;

                @NotNull
                @JsonProperty("prefix")
                String prefix;
            }

        }

        @AllArgsConstructor
        public static class CardDetails {
            @NotNull
            @JsonProperty("holder_name")
            String holderName;

            @NotNull
            @Size(min = 13, max = 16)
            @JsonProperty("card_number")
            String cardNumber;

            @NotNull
            @Digits(integer = 3, fraction = 0)
            @JsonProperty("cvc")
            String cvc;

            @NotNull
            @Digits(integer = 2, fraction = 0)
            @JsonProperty("exp_month")
            String expiryMonth;

            @NotNull
            @Size(min = 2, max = 4)
            @JsonProperty("exp_year")
            String expiryYear;
        }
    }

}
