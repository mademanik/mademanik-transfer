package com.morefin.pg.nixxe.common;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.keymanagementspi.keys.KeyManagementService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.nixxe.client.NixxeApiClient;
import com.morefin.pg.nixxe.client.NixxeCallbackResource;
import com.morefin.pg.nixxe.models.AuthorizeTransactionRequestDto;
import com.morefin.pg.nixxe.models.Payload;
import com.morefin.pg.nixxe.models.RuntimePaymentProviderAccountConfig;
import com.morefin.pg.nixxe.util.NixxeObjectTransformer;
import com.morefin.pg.utils.DtoValidationService;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.tuples.Tuple2;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;

import static com.morefin.pg.nixxe.util.Constants.VALIDATION_ERROR_CODE;

@ApplicationScoped
public class AuthorizeTransactionManager {

    @RestClient
    NixxeApiClient apiClient;

    @Inject
    KeyManagementService keyManagementService;

    @Inject
    NixxeObjectTransformer objectTransformer;

    @Inject
    DtoValidationService validationService;

    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext c) {
        return Uni.createFrom().item(c)
                .flatMap(this::buildPayload)
                .map(this::validateRequest)
                .flatMap(this::executeRequest)
                .onItemOrFailure()
                .transform((response, failure) -> {
                    Tuple2<Response, Throwable> tuple;
                    if (failure != null) {
                        tuple = Tuple2.of(null, failure);
                    } else {
                        tuple = Tuple2.of(response, null);
                    }
                    return objectTransformer.mapToExecuteTransactionResponse(tuple, c.authorizeContext().getTransaction().getId());
                });
    }

    private Uni<Payload> buildPayload(CardAuthorizeContext c) {
        return Uni.createFrom().item(c)
                .flatMap(x -> {
                    var card = x.card();
                    return keyManagementService.decrypt(
                            x.authorizeContext().getMerchant().getPrivateKey(),
                            card.encryptedCardNumber(),
                            card.encryptedCvv()
                    );
                })
                .map(list -> {
                    var transactionTypeContext = c.authorizeContext();
                    var cardDetails = new AuthorizeTransactionRequestDto.Request.CardDetails(
                            StringUtils.join(transactionTypeContext.getTransaction().getCustomerFirstName(), " ",
                                    transactionTypeContext.getTransaction().getCustomerLastName()),
                            new String(list.get(0), StandardCharsets.UTF_8),
                            new String(list.get(1), StandardCharsets.UTF_8),
                            String.valueOf(c.card().expirationMonth()),
                            String.valueOf(c.card().expirationYear())
                    );
                    return buildPayload(transactionTypeContext, cardDetails);
                });
    }

    private Payload buildPayload(TransactionTypeContext transactionTypeContext, AuthorizeTransactionRequestDto.Request.CardDetails cardDetails) {
        var transaction = transactionTypeContext.getTransaction();

        var customer = objectTransformer.mapToCustomer(transaction);
        var accountConfig = Utils.getRuntimeAccountConfig(transactionTypeContext.getPaymentProviderAccount(), RuntimePaymentProviderAccountConfig.class);
        var authorizeContext = new AuthorizeTransactionRequestDto(
                new AuthorizeTransactionRequestDto.Request(
                        accountConfig.isProdEnvironment() ? "prod" : "test",
                        accountConfig.routingId(),
                        new AuthorizeTransactionRequestDto.Request.Settings(
                                UriBuilder.fromUri(transactionTypeContext.getTenantConfig().url())
                                        .path(NixxeCallbackResource.class)
                                        .build().toString(),
                                transaction.getTransactionData().getSuccessUrl()
                        ),
                        generateCustomerId(transactionTypeContext), //TODO replace with transaction.getCustomerId() when has real value
                        transaction.getId(),
                        transaction.getUserIp(),
                        BigDecimal.valueOf(transaction.getAmount()).divide(BigDecimal.valueOf(100)),
                        transaction.getCurrency().toUpperCase(),
                        customer,
                        cardDetails
                )
        );

        return new Payload(authorizeContext, accountConfig);
    }

    private String generateCustomerId(TransactionTypeContext context) {
        return String.format("%s_%s_%s", context.getTransaction().getCustomerFirstName(),
                context.getTransaction().getCustomerLastName(),
                context.getTransaction().getCustomerEmail());
    }

    private Payload validateRequest(Payload payload) {
        String errorMessage = validationService.validateRequest(payload.getRequestDto());

        if (!StringUtils.isEmpty(errorMessage)) {
            return new Payload(errorMessage);
        }
        return payload;
    }

    private Uni<Response> executeRequest(Payload payload) {
        if (payload.getError() == null) {
            return apiClient.authorize(payload.getRequestDto(), payload.getAccountConfig().apiKey());
        }
        return Uni.createFrom().item(() -> Response.status(VALIDATION_ERROR_CODE).entity(payload.getError()).build());
    }

}
