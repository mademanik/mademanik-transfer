package com.morefin.pg.nixxe.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.nixxe.models.ApiErrorResponseDto;
import com.morefin.pg.nixxe.models.ApiResponseDto;
import com.morefin.pg.nixxe.models.AuthorizeTransactionRequestDto;
import com.morefin.pg.nixxe.models.CallbackResponseDto;
import com.morefin.pg.utils.SignatureUtils;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.tuples.Tuple2;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.stream.Collectors;

import static com.morefin.pg.nixxe.util.Constants.UNEXPECTED_PSP_RESPONSE_MESSAGE;
import static com.morefin.pg.nixxe.util.Constants.VALIDATION_ERROR_CODE;

@ApplicationScoped
public class NixxeObjectTransformer {

    public AuthorizeTransactionRequestDto.Request.Customer mapToCustomer(ImmutableTypedTransactionEntity transaction) {

        AuthorizeTransactionRequestDto.Request.Customer.Phone phone = null;
        Phonenumber.PhoneNumber number = null;
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();

        try {
            number = phoneUtil.parse(transaction.getCustomerPhoneNumber(),
                    transaction.getCustomerCountry().length() == 2 ? transaction.getCustomerCountry() : null);
        } catch (NumberParseException e) {
            Log.errorf("Invalid phone number=%s", transaction.getCustomerPhoneNumber());
        }

        if (number != null) {
            phone = new AuthorizeTransactionRequestDto.Request.Customer.Phone(
                    phoneUtil.getRegionCodeForCountryCode(number.getCountryCode()),
                    String.valueOf(number.getNationalNumber()),
                    String.valueOf(number.getCountryCode())
            );
        }

        return new AuthorizeTransactionRequestDto.Request.Customer(
                transaction.getCustomerFirstName(),
                transaction.getCustomerLastName(),
                transaction.getCustomerEmail(),
                transaction.getCustomerPostalCode(),
                transaction.getCustomerAddress(),
                transaction.getCustomerCity(),
                "12/12/1990",// null, // TODO use real date of birth
                transaction.getCustomerCountry(),
                phone
        );
    }

    public static String calculateResponseSignature(String jsonData, String signaturePassword) {
        return SignatureUtils.encryptWithSha1(jsonData + signaturePassword);
    }

    public FinalizeTransactionRequest mapToFinalizeTransactionRequest(CallbackResponseDto callbackDto) {
        var pspResponseMessage = "Transaction with type %s is %s. Provider: %s".formatted(callbackDto.transactionType(), callbackDto.status(), callbackDto.provider());
        var message = "Transaction " + callbackDto.status();
        return FinalizeTransactionRequest.newBuilder()
                .setId(callbackDto.trackingId())
                .setStatus(NixxeStatusMapper.parseToGrpcTransactionStatus(callbackDto))
                .setResponseMessage(message)
                .setPaymentProviderResponseCode(callbackDto.status().getValue())
                .setPaymentProviderResponseMessage(pspResponseMessage)
                .build();
    }

    /**
     * Mapper to ExecuteTransactionResponse
     *
     * @param response      Tuple2. Only one of the 2 items is not null.
     *                      <p> First item - Response containing the Api response (Api returned status code 200)
     *                      or contains Response with status code {@link Constants#VALIDATION_ERROR_CODE}
     *                      and Entity containing the validation errors as String message</p>
     *                      <p> Second item - Throwable containing the failure thrown if the Api request failed</p>
     * @param transactionId Id of the transaction
     * @return ExecuteTransactionResponse
     */
    public ExecuteTransactionResponse mapToExecuteTransactionResponse(Tuple2<Response, Throwable> response, String transactionId) {

        var builder = ExecuteTransactionResponse.Response.newBuilder();
        var grpcBuilder = new GrpcBuilder<>(builder)
                .set(transactionId, builder::setId)
                .set(ProcessingCode.TRX_STATUS_FAILED.name(), builder::setResponseCode)
                .setAny(ExecuteTransactionResponse.Status.ERROR, builder::setStatus);

        Object responseObject = null;


        if (response.getItem1() != null) {
            String responseString = response.getItem1().readEntity(String.class);

            if (response.getItem1().getStatus() == VALIDATION_ERROR_CODE) {
                grpcBuilder
                        .set(ProcessingCode.INVALID_REQUEST.name(), builder::setResponseCode)
                        .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                        .set(StringUtils.abbreviate(responseString, 49), builder::setResponseMessage);
            } else {
                var apiResponseDto = mapResponseEntity(responseString, ApiResponseDto.class);
                if (apiResponseDto != null) {
                    if (apiResponseDto.errors() == null) {
                        return buildPendingTransactionResponse(apiResponseDto);
                    } else {
                        String responseMessage = apiResponseDto.errors().stream()
                                .map(error -> String.valueOf(error.detail())).collect(Collectors.joining("; "));
                        responseObject = apiResponseDto;
                        grpcBuilder
                                .set(StringUtils.abbreviate(responseMessage, 49), builder::setResponseMessage)
                                .setAny(apiResponseDto.transactionStatus(), builder::setPaymentProviderResponseCode)
                                .setAny(responseMessage, builder::setPaymentProviderResponseMessage);
                    }
                } else {
                    responseObject = mapResponseEntity(responseString, Object.class);
                    grpcBuilder
                            .set(UNEXPECTED_PSP_RESPONSE_MESSAGE, builder::setResponseMessage)
                            .setAny(String.valueOf(response.getItem1().getStatus()), builder::setPaymentProviderResponseCode)
                            .setAny(responseString, builder::setPaymentProviderResponseMessage);
                }
            }
        } else {
            if (response.getItem2() instanceof WebApplicationException apiException) {
                String responseString = apiException.getResponse().readEntity(String.class);
                var apiErrorResponseDto = mapResponseEntity(responseString, ApiErrorResponseDto.class);

                if (apiErrorResponseDto != null) {
                    responseObject = apiErrorResponseDto;
                    grpcBuilder
                            .set(ProcessingCode.INVALID_REQUEST.name(), builder::setResponseCode)
                            .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                            .set(StringUtils.abbreviate(apiErrorResponseDto.error().message(), 50), builder::setResponseMessage)
                            .setAny(String.valueOf(apiErrorResponseDto.error().code()), builder::setPaymentProviderResponseCode)
                            .setAny(apiErrorResponseDto.error().message(), builder::setPaymentProviderResponseMessage);
                } else {
                    responseObject = mapResponseEntity(responseString, Object.class);
                    grpcBuilder
                            .set(UNEXPECTED_PSP_RESPONSE_MESSAGE, builder::setResponseMessage)
                            .setAny(String.valueOf(apiException.getResponse().getStatus()), builder::setPaymentProviderResponseCode)
                            .setAny(responseString, builder::setPaymentProviderResponseMessage);
                }
            } else {
                Log.error("Unexpected type of response:" + response.getItem2().getClass().getName(), response.getItem2());
                grpcBuilder
                        .set(StringUtils.abbreviate(response.getItem2().getMessage(), 49), builder::setResponseMessage);
            }
        }

        grpcBuilder
                .setAndMap(responseObject != null ? JsonObject.mapFrom(responseObject).getMap() : Map.of(), GrpcFactory::fromMap, builder::setData);


        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        grpcBuilder.getBuilder().build()
                )
                .build();
    }

    /**
     * Tries to convert JSON formatted String to specific class. Returns null if conversion fails.
     *
     * @param responseBody JSON formatted String
     * @param responseType class to which the body will be mapped to
     * @return Instance of the given object type or null if the responseBody is not in the correct format.
     */
    private static <T> T mapResponseEntity(String responseBody, Class<T> responseType) {
        var objectMapper = new ObjectMapper();
        try {
            return objectMapper.readValue(responseBody, responseType);
        } catch (JsonProcessingException e) {
            Log.errorf("Received unexpected format that can not be parsed to %s", responseType);
        }
        return null;
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(
            ApiResponseDto response) {
        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                //TODO: set all response data here
                .setResponse(ExecuteTransactionResponse.Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name()).build())
                .setRedirect(
                        new GrpcBuilder<>(builder)
                                .set(response.url(), builder::setUrl)
                                .getBuilder()
                                .build()
                )
                .build();
    }

}
