package com.morefin.pg.nixxe.common;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.domain.tables.pojos.PaymentProviderAccount;
import com.morefin.pg.nixxe.models.CallbackResponseDto;
import com.morefin.pg.nixxe.models.RuntimePaymentProviderAccountConfig;
import com.morefin.pg.nixxe.util.NixxeObjectTransformer;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

import java.util.Map;
import java.util.Set;

@ApplicationScoped
public class FinalizeTransactionManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    NixxeObjectTransformer objectTransformer;

    @Inject
    SignatureUtils signatureUtil;

    @Inject
    Utils utils;

    public Uni<Response> finalizeTransaction(String body, String signature, String tenantId) {
        var grpc = GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                getServiceAccount(),
                Constants.LOCALHOST);

        var callbackResponseDto = utils.deserializeJson(body, CallbackResponseDto.class);

        if (callbackResponseDto.status().equals(CallbackResponseDto.Status.PENDING)) {
            return Uni.createFrom().item(Response.ok().build());
        }

        return Uni.createFrom().item(callbackResponseDto)
                .flatMap(responseDto -> signatureUtil.validateCallbackResponse(body, signature,
                                responseDto.trackingId(), tenantId,
                                NixxeObjectTransformer::calculateResponseSignature, this::getRuntimeSignatureKey)
                        .replaceWith(responseDto))
                .map(objectTransformer::mapToFinalizeTransactionRequest)
                .flatMap(grpc::finalizeTransaction)
                .map(result -> {
                    if (result.hasRedirect()) {
                        return Response.ok().build();
                    } else {
                        return Response.status(400).build();
                    }
                })
                .onFailure(SecurityException.class)
                .recoverWithItem(() ->
                        Response.status(Response.Status.BAD_REQUEST)
                                .entity(Map.of("error", "Invalid signature")).build()
                )
                .onFailure()
                .recoverWithItem(throwable ->
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                                .entity(Map.of("error", throwable.getMessage())).build()
                );
    }

    private GrpcApiUser getServiceAccount() {
        return GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "nixxe-service-account"
        );
    }

    private String getRuntimeSignatureKey(PaymentProviderAccount account) {
        var accountConfig = Utils.getRuntimeAccountConfig(account, RuntimePaymentProviderAccountConfig.class);
        return accountConfig.signaturePassword();
    }

}
