package com.morefin.pg.nixxe.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import com.morefin.pg.nixxe.admin.card.NixxeAdminPaymentProcessingServiceProvider;
import io.quarkus.arc.Arc;

import java.util.List;

public class NixxeCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {

    NixxeAdminPaymentProcessingServiceProvider adminServiceProvider;

    public NixxeCardServiceProvider() {
        adminServiceProvider = new NixxeAdminPaymentProcessingServiceProvider();
    }

    @Override
    public String name() {
        return adminServiceProvider.name();
    }

    @Override
    public String id() {
        return adminServiceProvider.id();
    }

    @Override
    public String type() {
        return adminServiceProvider.type();
    }

    @Override
    public EcommerceCardPaymentProcessingService create() {
        try (var instance = Arc.container().instance(NixxePaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return adminServiceProvider.types();
    }
}
