package com.morefin.pg.nixxe.authentication;

import com.morefin.common.authenticationgatewayspi.spi.AuthenticationServiceProvider;
import com.morefin.common.authenticationgatewayspi.spi.BaseAuthenticationService;
import io.quarkus.arc.Arc;

public class NixxeAuthenticationServiceProvider implements AuthenticationServiceProvider {

    @Override
    public BaseAuthenticationService create() {

        try (var instance = Arc.container().instance(NixxeCardAuthenticationService.class)) {
            return instance.get();
        }
    }
}
