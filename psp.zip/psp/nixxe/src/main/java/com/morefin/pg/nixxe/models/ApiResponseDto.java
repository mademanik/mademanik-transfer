package com.morefin.pg.nixxe.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public record ApiResponseDto(
        @JsonProperty("url")
        String url,
        @JsonProperty("transaction_status")
        String transactionStatus,
        @JsonProperty("errors")
        List<Error> errors
) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Error(
            @JsonProperty("provider_id")
            String providerId,
            @JsonProperty("detail")
            String detail
    ) {
    }
}
