package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record NaeweWithdrawalCallback(
    @JsonProperty("status")
    String status,
    @JsonAlias({"clientWithdrawalId", "clientWithdrawId"})
    String clientWithdrawalId,
    @JsonProperty("withdrawId")
    String withdrawId
) implements NaeweCallbackPayload {

    @Override
    public String reference() {
        return clientWithdrawalId;
    }
}