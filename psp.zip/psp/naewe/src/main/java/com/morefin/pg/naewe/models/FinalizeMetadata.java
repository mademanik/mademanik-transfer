package com.morefin.pg.naewe.models;

import java.math.BigDecimal;

public record FinalizeMetadata(
    BigDecimal expectedDisplayAmount,
    BigDecimal actualDisplayAmount
) {
}
