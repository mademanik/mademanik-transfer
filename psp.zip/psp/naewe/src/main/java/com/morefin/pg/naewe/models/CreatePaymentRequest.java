package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record CreatePaymentRequest(
    @NotBlank
    String businessId,
    @NotBlank
    String clientPaymentId,
    @NotBlank
    String locale,
    @NotBlank
    String type,
    @NotBlank
    String rateType,
    @NotBlank
    String displayCurrency,
    @NotBlank
    String displayAmount,
    String redirectUrl,
    String redirectMode
) {
}
