package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record NaeweWithdrawalApprovalCallback(
    @JsonProperty("status")
    String status,
    @JsonProperty("approvalState")
    String approvalState,
    @JsonAlias({"clientWithdrawalId", "clientWithdrawId"})
    String clientWithdrawalId,
    @JsonProperty("withdrawId")
    String withdrawId
) implements NaeweCallbackPayload {

    @Override
    public String status() {
        if (approvalState != null && !approvalState.isBlank()) {
            return approvalState;
        }
        return status;
    }

    @Override
    public String reference() {
        return clientWithdrawalId;
    }
}
