package com.morefin.pg.naewe.client;

import com.morefin.pg.naewe.models.CreatePaymentRequest;
import com.morefin.pg.naewe.models.RequestCryptoWithdrawalRequest;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/v1")
@RegisterRestClient(configKey = "naewe")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface NaeweApiClient {

    @POST
    @Path("/payments")
    Uni<Response> createPayment(
        CreatePaymentRequest request,
        @HeaderParam(HttpHeaders.AUTHORIZATION) String authorizationHeader
    );

    @POST
    @Path("/withdrawals")
    Uni<Response> requestWithdrawal(
        RequestCryptoWithdrawalRequest request,
        @HeaderParam(HttpHeaders.AUTHORIZATION) String authorizationHeader
    );
}
