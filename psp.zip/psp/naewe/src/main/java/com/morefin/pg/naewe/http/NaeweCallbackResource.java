package com.morefin.pg.naewe.http;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.naewe.service.NaeweTransactionManagerService;
import com.morefin.pg.naewe.util.NaeweConstants;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path(NaeweConstants.CALLBACK_BASE_PATH)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class NaeweCallbackResource {

    @Inject
    Tenant tenant;

    @Inject
    NaeweTransactionManagerService transactionManagerService;

    @POST
    @Path(NaeweConstants.CALLBACK_DEPOSIT_PATH)
    public Uni<Response> depositCallback(
        String rawJson,
        @HeaderParam(NaeweConstants.SIGNATURE_HEADER) String signature,
        @HeaderParam(NaeweConstants.TIMESTAMP_HEADER) String timestamp
    ) {
        return transactionManagerService.handleDepositCallback(rawJson, signature, timestamp, tenant.id());
    }

    @POST
    @Path(NaeweConstants.CALLBACK_WITHDRAWAL_PATH)
    public Uni<Response> withdrawalCallback(
        String rawJson,
        @HeaderParam(NaeweConstants.SIGNATURE_HEADER) String signature,
        @HeaderParam(NaeweConstants.TIMESTAMP_HEADER) String timestamp
    ) {
        return transactionManagerService.handleWithdrawalCallback(rawJson, signature, timestamp, tenant.id());
    }

    @POST
    @Path(NaeweConstants.CALLBACK_WITHDRAWAL_APPROVAL_PATH)
    public Uni<Response> withdrawalApprovalCallback(
        String rawJson,
        @HeaderParam(NaeweConstants.SIGNATURE_HEADER) String signature,
        @HeaderParam(NaeweConstants.TIMESTAMP_HEADER) String timestamp
    ) {
        return transactionManagerService.handleWithdrawalApprovalCallback(rawJson, signature, timestamp, tenant.id());
    }
}
