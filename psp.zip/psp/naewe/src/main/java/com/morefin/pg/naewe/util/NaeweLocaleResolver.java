package com.morefin.pg.naewe.util;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class NaeweLocaleResolver {

    private static final Map<String, String> COUNTRY_TO_LOCALE = new ConcurrentHashMap<>();

    static {
        COUNTRY_TO_LOCALE.put("AE", "ar");
        COUNTRY_TO_LOCALE.put("BG", "bg");
        COUNTRY_TO_LOCALE.put("CN", "zh");
        COUNTRY_TO_LOCALE.put("HK", "zh");
        COUNTRY_TO_LOCALE.put("MO", "zh");
        COUNTRY_TO_LOCALE.put("TW", "zh");
        COUNTRY_TO_LOCALE.put("US", "en");
        COUNTRY_TO_LOCALE.put("GB", "en");
        COUNTRY_TO_LOCALE.put("AU", "en");
        COUNTRY_TO_LOCALE.put("CA", "fr");
        COUNTRY_TO_LOCALE.put("NZ", "en");
        COUNTRY_TO_LOCALE.put("IE", "en");
        COUNTRY_TO_LOCALE.put("FR", "fr");
        COUNTRY_TO_LOCALE.put("BE", "fr");
        COUNTRY_TO_LOCALE.put("CH", "fr");
        COUNTRY_TO_LOCALE.put("LU", "fr");
        COUNTRY_TO_LOCALE.put("MC", "fr");
        COUNTRY_TO_LOCALE.put("DE", "de");
        COUNTRY_TO_LOCALE.put("JP", "ja");
        COUNTRY_TO_LOCALE.put("LT", "lt");
        COUNTRY_TO_LOCALE.put("PT", "pt");
        COUNTRY_TO_LOCALE.put("BR", "pt");
        COUNTRY_TO_LOCALE.put("RU", "ru");
        COUNTRY_TO_LOCALE.put("ES", "es");
        COUNTRY_TO_LOCALE.put("CD", "fr");
        COUNTRY_TO_LOCALE.put("CG", "fr");
        COUNTRY_TO_LOCALE.put("CI", "fr");
        COUNTRY_TO_LOCALE.put("SN", "fr");
        COUNTRY_TO_LOCALE.put("BF", "fr");
        COUNTRY_TO_LOCALE.put("NE", "fr");
        COUNTRY_TO_LOCALE.put("ML", "fr");
        COUNTRY_TO_LOCALE.put("TG", "fr");
        COUNTRY_TO_LOCALE.put("BJ", "fr");
        COUNTRY_TO_LOCALE.put("GN", "fr");
        COUNTRY_TO_LOCALE.put("TD", "fr");
        COUNTRY_TO_LOCALE.put("CF", "fr");
        COUNTRY_TO_LOCALE.put("CM", "fr");
        COUNTRY_TO_LOCALE.put("GA", "fr");
        COUNTRY_TO_LOCALE.put("MG", "fr");
        COUNTRY_TO_LOCALE.put("KM", "fr");
        COUNTRY_TO_LOCALE.put("SC", "fr");
        COUNTRY_TO_LOCALE.put("MU", "fr");
        COUNTRY_TO_LOCALE.put("BI", "fr");
        COUNTRY_TO_LOCALE.put("DJ", "fr");
        COUNTRY_TO_LOCALE.put("RW", "fr");
        COUNTRY_TO_LOCALE.put("GQ", "fr");
        COUNTRY_TO_LOCALE.put("MR", "fr");
        COUNTRY_TO_LOCALE.put("VU", "fr");
        COUNTRY_TO_LOCALE.put("DZ", "fr");
        COUNTRY_TO_LOCALE.put("MA", "fr");
        COUNTRY_TO_LOCALE.put("TN", "fr");
        COUNTRY_TO_LOCALE.put("LB", "fr");
        COUNTRY_TO_LOCALE.put("HT", "fr");
        COUNTRY_TO_LOCALE.put("GP", "fr");
        COUNTRY_TO_LOCALE.put("MQ", "fr");
        COUNTRY_TO_LOCALE.put("GF", "fr");
        COUNTRY_TO_LOCALE.put("RE", "fr");
        COUNTRY_TO_LOCALE.put("YT", "fr");
        COUNTRY_TO_LOCALE.put("PM", "fr");
        COUNTRY_TO_LOCALE.put("BL", "fr");
        COUNTRY_TO_LOCALE.put("MF", "fr");
        COUNTRY_TO_LOCALE.put("NC", "fr");
        COUNTRY_TO_LOCALE.put("PF", "fr");
        COUNTRY_TO_LOCALE.put("WF", "fr");
        COUNTRY_TO_LOCALE.put("TF", "fr");
        COUNTRY_TO_LOCALE.put("MX", "es");
        COUNTRY_TO_LOCALE.put("CO", "es");
        COUNTRY_TO_LOCALE.put("AR", "es");
        COUNTRY_TO_LOCALE.put("CL", "es");
        COUNTRY_TO_LOCALE.put("PE", "es");
        COUNTRY_TO_LOCALE.put("TR", "tr");
    }

    private NaeweLocaleResolver() {
    }

    public static String resolve(String localeHint, String countryCode) {
        String normalizedLocale = normalize(localeHint);
        if (isSupportedCode(normalizedLocale)) {
            return normalizedLocale;
        }

        String normalizedCountry = normalizeCountry(countryCode);
        if (COUNTRY_TO_LOCALE.containsKey(normalizedCountry)) {
            return COUNTRY_TO_LOCALE.get(normalizedCountry);
        }

        return "en";
    }

    private static boolean isSupportedCode(String code) {
        if (code == null || code.isBlank()) {
            return false;
        }
        return switch (code.toLowerCase(Locale.ROOT)) {
            case "ar", "bg", "zh", "en", "fr", "de", "ja", "lt", "pt", "ru", "es", "tr" -> true;
            default -> false;
        };
    }

    private static String normalize(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.contains("-") || trimmed.contains("_")) {
            String[] parts = trimmed.split("[-_]");
            if (parts.length > 0 && isSupportedCode(parts[0])) {
                return parts[0].toLowerCase(Locale.ROOT);
            }
        }
        return trimmed.toLowerCase(Locale.ROOT);
    }

    private static String normalizeCountry(String country) {
        if (country == null) {
            return "";
        }
        return country.trim().toUpperCase(Locale.ROOT);
    }
}
