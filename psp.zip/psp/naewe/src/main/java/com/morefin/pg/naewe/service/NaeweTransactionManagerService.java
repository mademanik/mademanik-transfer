package com.morefin.pg.naewe.service;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.domain.tables.pojos.PaymentProviderAccount;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.naewe.client.NaeweApiClient;
import com.morefin.pg.naewe.models.CreatePaymentRequest;
import com.morefin.pg.naewe.models.NaeweCallbackPayload;
import com.morefin.pg.naewe.models.NaeweDepositCallback;
import com.morefin.pg.naewe.models.NaeweWithdrawalApprovalCallback;
import com.morefin.pg.naewe.models.NaeweWithdrawalCallback;
import com.morefin.pg.naewe.models.RequestCryptoWithdrawalRequest;
import com.morefin.pg.naewe.util.NaeweLocaleResolver;
import com.morefin.pg.naewe.util.NaeweSignatureUtil;
import com.morefin.pg.naewe.util.RuntimeAccountConfig;
import com.morefin.pg.utils.DtoValidationService;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.math.BigDecimal;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

@ApplicationScoped
public class NaeweTransactionManagerService {

    private static final String PAYMENT_TYPE_ONE_TIME = "ONE_TIME";
    private static final String RATE_TYPE_FLOATING = "FLOATING";
    private static final String DEFAULT_LOCALE = "en";
    private static final String DEFAULT_TARGET_POLICY = "FIAT";


    @Inject
    DtoValidationService dtoValidationService;

    @Inject
    NaeweObjectTransformer transformer;

    @Inject
    @RestClient
    NaeweApiClient apiClient;

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    SignatureUtils signatureUtils;

    @Inject
    Utils utils;

    public Uni<ExecuteTransactionResponse> deposit(TransactionTypeContext context) {
        String transactionId = context.getTransaction().getId();
        DepositPayload payload;
        try {
            payload = buildDepositPayload(context);
        } catch (Exception e) {
            Log.errorf(e, "Failed to prepare Naewe deposit payload for trxId=%s", transactionId);
            return Uni.createFrom().item(transformer.buildValidationError(transactionId, e.getMessage()));
        }

        if (payload.validationError() != null) {
            return Uni.createFrom().item(transformer.buildValidationError(transactionId, payload.validationError()));
        }

        return apiClient.createPayment(payload.request(), payload.authorizationHeader())
            .onItemOrFailure()
            .transform((response, failure) -> transformer.mapDepositResponse(response, failure, transactionId));
    }

    public Uni<ExecuteTransactionResponse> withdrawal(TransactionTypeContext context) {
        String transactionId = context.getTransaction().getId();
        WithdrawalPayload payload;
        try {
            payload = buildWithdrawalPayload(context);
        } catch (Exception e) {
            Log.errorf(e, "Failed to prepare Naewe withdrawal payload for trxId=%s", transactionId);
            return Uni.createFrom().item(transformer.buildValidationError(transactionId, e.getMessage()));
        }

        if (payload.validationError() != null) {
            return Uni.createFrom().item(transformer.buildValidationError(transactionId, payload.validationError()));
        }

        return apiClient.requestWithdrawal(payload.request(), payload.authorizationHeader())
            .onItemOrFailure()
            .transform((response, failure) -> transformer.mapWithdrawalResponse(response, failure, transactionId));
    }

    public Uni<Response> handleDepositCallback(String rawJson, String signature, String timestamp, String tenantId) {
        return processCallback(rawJson, signature, timestamp, tenantId, NaeweDepositCallback.class, transformer::mapDepositCallback);
    }

    public Uni<Response> handleWithdrawalCallback(String rawJson, String signature, String timestamp, String tenantId) {
        return processCallback(rawJson, signature, timestamp, tenantId, NaeweWithdrawalCallback.class, transformer::mapWithdrawalCallback);
    }

    public Uni<Response> handleWithdrawalApprovalCallback(String rawJson, String signature, String timestamp, String tenantId) {
        return processCallback(rawJson, signature, timestamp, tenantId, NaeweWithdrawalApprovalCallback.class, transformer::mapWithdrawalApprovalCallback);
    }

    private DepositPayload buildDepositPayload(TransactionTypeContext context)
        throws NoSuchAlgorithmException, InvalidKeyException, com.fasterxml.jackson.core.JsonProcessingException {
        RuntimeAccountConfig accountConfig = loadAccountConfig(context);
        var testDepositFlag = context.getTransaction().getMetadata().getString("test_deposit_flag");

        CreatePaymentRequest request = new CreatePaymentRequest(
            accountConfig.businessId(),
            testDepositFlag == null || testDepositFlag.isEmpty() ?
                context.getTransaction().getId() :
                "%s-%s".formatted(testDepositFlag, context.getTransaction().getId()),
            resolveLocale(context),
            PAYMENT_TYPE_ONE_TIME,
            RATE_TYPE_FLOATING,
            resolveDisplayCurrency(context, accountConfig),
            resolveDisplayAmount(context),
            resolveRedirectUrl(context),
            null
        );

        String validationMessage = dtoValidationService.validateRequest(request);
        validationMessage = appendMissingConfigMessage(validationMessage, accountConfig.apiKey(), "Missing api_key configuration.");
        validationMessage = appendMissingConfigMessage(validationMessage, accountConfig.apiSecret(), "Missing api_secret configuration.");

        String authHeader = null;
        if (validationMessage == null) {
            String path = UriBuilder.fromUri("")
                .path(NaeweApiClient.class)
                .path(NaeweApiClient.class, "createPayment")
                .build()
                .toString();
            authHeader = NaeweSignatureUtil.buildAuthHeader(path, request, accountConfig);
        }

        if (StringUtils.isBlank(authHeader)) {
            validationMessage = StringUtils.defaultIfBlank(validationMessage, "Failed to build authentication header.");
        }

        return new DepositPayload(request, accountConfig, authHeader, validationMessage);
    }

    private WithdrawalPayload buildWithdrawalPayload(TransactionTypeContext context)
        throws NoSuchAlgorithmException, InvalidKeyException, com.fasterxml.jackson.core.JsonProcessingException {
        RuntimeAccountConfig accountConfig = loadAccountConfig(context);
        JsonObject paymentMethod = resolvePaymentData(context);
        //TODO: this should be handled elsewhere
        JsonObject paymentData = paymentMethod.getJsonObject("data");
        String withdrawCurrency = paymentData.getString("currency");
        String recipientAddress = paymentData.getString("wallet");
        String destinationTag = paymentData.getString("tag_memo");
        String network = StringUtils.defaultIfBlank(paymentData.getString("network"), accountConfig.network());
        //TODO: end
        String targetAmountPolicy = StringUtils.defaultIfBlank(accountConfig.targetAmountPolicy(), DEFAULT_TARGET_POLICY);

        var testWithdrawalFlag = context.getTransaction().getMetadata().getString("test_withdrawal_flag");
        RequestCryptoWithdrawalRequest request = new RequestCryptoWithdrawalRequest(
            accountConfig.businessId(),
            testWithdrawalFlag == null || testWithdrawalFlag.isEmpty() ?
                context.getTransaction().getId() :
                "%s-%s".formatted(testWithdrawalFlag, context.getTransaction().getId()),
            recipientAddress,
            destinationTag,
            network,
            withdrawCurrency,
            resolveDisplayCurrency(context, accountConfig),
            targetAmountPolicy,
            resolveDisplayAmount(context),
            null,
            null
        );

        String validationMessage = dtoValidationService.validateRequest(request);
        validationMessage = appendMissingConfigMessage(validationMessage, accountConfig.apiKey(), "Missing api_key configuration.");
        validationMessage = appendMissingConfigMessage(validationMessage, accountConfig.apiSecret(), "Missing api_secret configuration.");
        if (paymentMethod.isEmpty()) {
            validationMessage = appendValidation(validationMessage, "Withdrawal details are required.");
        }

        String authHeader = null;
        if (validationMessage == null) {
            String path = UriBuilder.fromUri("")
                .path(NaeweApiClient.class)
                .path(NaeweApiClient.class, "requestWithdrawal")
                .build()
                .toString();
            authHeader = NaeweSignatureUtil.buildAuthHeader(path, request, accountConfig);
        }

        if (StringUtils.isBlank(authHeader)) {
            validationMessage = StringUtils.defaultIfBlank(validationMessage, "Failed to build authentication header.");
        }

        return new WithdrawalPayload(request, accountConfig, authHeader, validationMessage);
    }

    private RuntimeAccountConfig loadAccountConfig(TransactionTypeContext context) {
        return Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), RuntimeAccountConfig.class);
    }

    private JsonObject resolvePaymentData(TransactionTypeContext context) {
        String paymentDataRaw = context.getPaymentDataRaw();
        if (StringUtils.isBlank(paymentDataRaw)) {
            return new JsonObject();
        }
        try {
            return new JsonObject(paymentDataRaw);
        } catch (Exception e) {
            Log.warnf("Invalid payment data for Naewe withdrawal. trxId=%s data=%s", context.getTransaction().getId(), paymentDataRaw);
            return new JsonObject();
        }
    }

    private String resolveLocale(TransactionTypeContext context) {
        var transaction = context.getTransaction();
        String localeHint = null;
        if (transaction.getTransactionData() != null && transaction.getTransactionData().getOptions() != null) {
            Object value = transaction.getTransactionData().getOptions().get("locale");
            if (value instanceof String localeString) {
                localeHint = localeString;
            }
        }
        String country = transaction.getCustomerCountry();
        return NaeweLocaleResolver.resolve(localeHint, country);
    }

    private String resolveDisplayCurrency(TransactionTypeContext context, RuntimeAccountConfig config) {
        String currency = context.getTransaction().getCurrency();
        return StringUtils.defaultIfBlank(currency, "EUR");
    }

    private String resolveDisplayAmount(TransactionTypeContext context) {
        Long amount = context.getTransaction().getAmount();
        if (amount == null) {
            return "0.00";
        }
        return BigDecimal.valueOf(amount).movePointLeft(2).toPlainString();
    }

    private String resolveRedirectUrl(TransactionTypeContext context) {
        if (context.getTransaction() != null && context.getTransaction().getTransactionData() != null) {
            return StringUtils.trimToNull(context.getTransaction().getTransactionData().getSuccessUrl());
        }
        return null;
    }

    private <T extends NaeweCallbackPayload> Uni<Response> processCallback(
        String rawJson,
        String signature,
        String timestamp,
        String tenantId,
        Class<T> payloadClass,
        Function<T, FinalizeTransactionRequest> mapper
    ) {
        T payload;
        try {
            payload = utils.deserializeJson(rawJson, payloadClass);
        } catch (Exception e) {
            Log.errorf(e, "Failed to deserialize Naewe callback body: %s", rawJson);
            return Uni.createFrom().item(Response.status(Response.Status.BAD_REQUEST)
                .entity(Map.of("error", "Invalid payload"))
                .build());
        }

        if (payload == null || StringUtils.isBlank(payload.reference())) {
            return Uni.createFrom().item(Response.status(Response.Status.BAD_REQUEST)
                .entity(Map.of("error", "Missing transaction reference"))
                .build());
        }

        final String transactionId = payload.reference();

        final String strippedTransactionId = NaeweObjectTransformer.stripFirstPrefix(transactionId);

        return validateCallback(strippedTransactionId, rawJson, signature, timestamp, tenantId)
            .replaceWith(payload)
            .map(mapper)
            .flatMap(request -> finalizeTransaction(tenantId, request))
            .onFailure(SecurityException.class)
            .recoverWithItem(() -> Response.status(Response.Status.BAD_REQUEST)
                .entity(Map.of("error", "Invalid signature"))
                .build())
            .onFailure(IllegalArgumentException.class)
            .recoverWithItem(throwable -> Response.status(Response.Status.BAD_REQUEST)
                .entity(Map.of("error", throwable.getMessage()))
                .build())
            .onFailure()
            .recoverWithItem(throwable -> {
                Log.errorf(throwable, "Failed to process Naewe callback for trxId=%s", transactionId);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(Map.of("error", throwable.getMessage()))
                    .build();
            });
    }

    private Uni<Void> validateCallback(String transactionId, String rawJson, String signature, String timestamp, String tenantId) {
        if (StringUtils.isBlank(signature) || StringUtils.isBlank(timestamp)) {
            return Uni.createFrom().failure(new SecurityException("Missing signature or timestamp"));
        }

        return signatureUtils.findPaymentProviderSignatureSecret(transactionId, tenantId, this::getPublicKey)
            .flatMap(publicKey -> {
                if (StringUtils.isBlank(publicKey)) {
                    return Uni.createFrom().failure(new SecurityException("Missing Naewe public key"));
                }

                String signaturePayload = rawJson + "." + timestamp;
                if (!SignatureUtils.verifySha512Signature(signaturePayload, signature, publicKey)) {
                    Log.errorf("Invalid Naewe callback signature for trxId=%s", transactionId);
                    return Uni.createFrom().failure(new SecurityException("Invalid signature"));
                }
                return Uni.createFrom().voidItem();
            });
    }

    private Uni<Response> finalizeTransaction(String tenantId, FinalizeTransactionRequest request) {
        if (request == null || StringUtils.isBlank(request.getId())) {
            return Uni.createFrom().item(Response.status(Response.Status.BAD_REQUEST)
                .entity(Map.of("error", "Missing transaction identifier"))
                .build());
        }

        var grpc = GrpcClientFactory.grpc(transactionGrpc, tenantId, getServiceAccount(), Constants.LOCALHOST);
        return grpc.finalizeTransaction(request)
            .replaceWith(Response.ok().build());
    }

    private String getPublicKey(PaymentProviderAccount account) {
        return Utils.getRuntimeAccountConfig(account, RuntimeAccountConfig.class).publicKey();
    }

    private GrpcApiUser getServiceAccount() {
        return GrpcApiUser.serviceAccount(Set.of(), Map.of(), "naewe-service-account");
    }

    private String appendMissingConfigMessage(String currentMessage, String value, String message) {
        if (StringUtils.isBlank(value)) {
            return appendValidation(currentMessage, message);
        }
        return currentMessage;
    }

    private String appendValidation(String currentMessage, String newMessage) {
        if (StringUtils.isBlank(newMessage)) {
            return currentMessage;
        }
        if (currentMessage == null) {
            return newMessage;
        }
        return currentMessage + "\n" + newMessage;
    }


    private record DepositPayload(
        CreatePaymentRequest request,
        RuntimeAccountConfig accountConfig,
        String authorizationHeader,
        String validationError
    ) {
    }

    private record WithdrawalPayload(
        RequestCryptoWithdrawalRequest request,
        RuntimeAccountConfig accountConfig,
        String authorizationHeader,
        String validationError
    ) {
    }
}
