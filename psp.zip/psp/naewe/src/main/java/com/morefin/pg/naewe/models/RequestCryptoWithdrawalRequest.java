package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record RequestCryptoWithdrawalRequest(
    @NotBlank
    String businessId,
    @NotBlank
    String clientWithdrawalId,
    @NotBlank
    String recipientAddress,
    String destinationTag,
    String network,
    @NotBlank
    String withdrawCurrency,
    @NotBlank
    String displayCurrency,
    @NotBlank
    String targetAmountPolicy,
    @NotBlank
    String targetAmount,
    String settlementCurrency,
    String blockchainFeePaidBy
) {
}
