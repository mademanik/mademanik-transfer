package com.morefin.pg.naewe.util;

public final class NaeweConstants {

    private NaeweConstants() {
    }

    public static final String CALLBACK_BASE_PATH = "/psp/naewe/callback";
    public static final String CALLBACK_DEPOSIT_PATH = "/deposit";
    public static final String CALLBACK_WITHDRAWAL_PATH = "/withdrawal";
    public static final String CALLBACK_WITHDRAWAL_APPROVAL_PATH = "/withdrawal-approval";

    public static final String SIGNATURE_HEADER = "Signature";
    public static final String TIMESTAMP_HEADER = "Timestamp";
}
