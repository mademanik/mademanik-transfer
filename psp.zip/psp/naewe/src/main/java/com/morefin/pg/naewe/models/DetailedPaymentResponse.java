package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record DetailedPaymentResponse(
    String paymentId,
    String status,
    String url
) {
}
