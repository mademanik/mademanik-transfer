package com.morefin.pg.naewe.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public final class NaeweSignatureUtil {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final String HMAC_ALGORITHM = "HmacSHA256";

    private NaeweSignatureUtil() {
    }
    
    public static String buildAuthHeader(String pathWithQuery, Object requestDto, RuntimeAccountConfig config)
        throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException {
        long timestamp = System.currentTimeMillis();
        String body = OBJECT_MAPPER.writeValueAsString(requestDto);
        String signaturePayload = pathWithQuery + timestamp + body;
        String signature = generateSignature(signaturePayload, config);
        return "FRX-API API-Key=%s,Signature=%s,Timestamp=%d".formatted(
            config.apiKey(),
            signature,
            timestamp
        );
    }

    private static String generateSignature(String payload, RuntimeAccountConfig config)
        throws NoSuchAlgorithmException, InvalidKeyException {
        Mac mac = Mac.getInstance(HMAC_ALGORITHM);
        mac.init(new SecretKeySpec(config.apiSecret().getBytes(StandardCharsets.UTF_8), HMAC_ALGORITHM));
        byte[] hash = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(hash.length * 2);
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
