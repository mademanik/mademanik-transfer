package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record NaeweErrorResponse(
    String errorCode,
    String errorMessage,
    String message,
    String status
) {
    public String resolvedMessage() {
        if (message != null && !message.isBlank()) {
            return message;
        }
        if (errorMessage != null && !errorMessage.isBlank()) {
            return errorMessage;
        }
        if (status != null && !status.isBlank()) {
            return status;
        }
        return errorCode;
    }
}
