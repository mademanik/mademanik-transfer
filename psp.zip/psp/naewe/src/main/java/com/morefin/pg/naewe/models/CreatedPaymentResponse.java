package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CreatedPaymentResponse(
    DetailedPaymentResponse paymentInfo,
    String paymentUrl
) {
}
