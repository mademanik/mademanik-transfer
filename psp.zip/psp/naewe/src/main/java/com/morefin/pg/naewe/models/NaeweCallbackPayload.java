package com.morefin.pg.naewe.models;

public interface NaeweCallbackPayload {
    String status();
    String reference();
}
