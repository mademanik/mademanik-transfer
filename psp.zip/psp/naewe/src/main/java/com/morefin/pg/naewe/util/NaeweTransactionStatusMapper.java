package com.morefin.pg.naewe.util;

import com.morefin.common.grpc.payment.TransactionStatus;
import io.quarkus.logging.Log;

public final class NaeweTransactionStatusMapper {

    private NaeweTransactionStatusMapper() {
    }

    public static TransactionStatus mapDepositStatus(String status) {
        String normalized = normalize(status);
        return switch (normalized) {
            case "CONFIRMED" -> TransactionStatus.APPROVED;
            case "UNPROCESSABLE", "BLOCKED" -> TransactionStatus.DECLINED;
            default -> {
                logUnsupportedStatus("deposit", status);
                throw new IllegalArgumentException("Unsupported deposit status: " + status);
            }
        };
    }

    public static TransactionStatus mapWithdrawalStatus(String status) {
        String normalized = normalize(status);
        return switch (normalized) {
            case "COMPLETED", "BROADCASTED" -> TransactionStatus.APPROVED;
            case "FAILED", "BLOCKED", "REJECTED" -> TransactionStatus.DECLINED;
            case "PENDING" -> TransactionStatus.PENDING;
            default -> {
                logUnsupportedStatus("withdrawal", status);
                throw new IllegalArgumentException("Unsupported withdrawal status: " + status);
            }
        };
    }

    public static TransactionStatus mapWithdrawalApprovalStatus(String status) {
        String normalized = normalize(status);
        return switch (normalized) {
            case "APPROVED" -> TransactionStatus.PENDING;
            case "REJECTED" -> TransactionStatus.DECLINED;
            default -> {
                logUnsupportedStatus("withdrawal-approval", status);
                throw new IllegalArgumentException("Unsupported withdrawal approval status: " + status);
            }
        };
    }

    private static String normalize(String status) {
        if (status == null) {
            return "";
        }
        return status.trim().toUpperCase();
    }

    private static void logUnsupportedStatus(String callbackType, String status) {
        Log.warnf("Received unsupported Naewe %s status: %s", callbackType, status);
    }
}
