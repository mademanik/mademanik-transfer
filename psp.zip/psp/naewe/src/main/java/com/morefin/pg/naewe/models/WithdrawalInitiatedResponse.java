package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record WithdrawalInitiatedResponse(
    String withdrawId,
    String status,
    String settlementCurrency,
    String settlementDeductedAmount,
    String estimatedWithdrawAmount
) {
}
