package com.morefin.pg.naewe.util;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
    @JsonProperty("api_key")
    String apiKey,
    @JsonProperty("api_secret")
    String apiSecret,
    @JsonProperty("business_id")
    String businessId,
    @JsonProperty("deposit_currency")
    String depositCurrency,
    @JsonProperty("network")
    String network,
    @JsonProperty("settlement_currency")
    String settlementCurrency,
    @JsonProperty("blockchain_fee_paid_by")
    String blockchainFeePaidBy,
    @JsonProperty("target_amount_policy")
    String targetAmountPolicy,
    @JsonProperty("public_key")
    String publicKey
) {
}
