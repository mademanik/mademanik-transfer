package com.morefin.pg.naewe.processing;

import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.naewe.NaeweTypeModule;
import io.quarkus.arc.Arc;

public class NaeweAPMServiceProvider implements APMProcessingServiceProvider {
    @Override
    public APMProcessingService create() {
        try(var instance = Arc.container().instance(NaeweProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return NaeweTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return NaeweTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return NaeweTypeModule.MODULE_ID;
    }
}
