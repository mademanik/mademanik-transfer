package com.morefin.pg.naewe.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.Struct;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.pg.naewe.models.*;
import com.morefin.pg.naewe.util.NaeweTransactionStatusMapper;
import io.quarkus.logging.Log;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;

import java.math.BigDecimal;
import java.util.Objects;

@ApplicationScoped
public class NaeweObjectTransformer {

    private static final String DEPOSIT_PENDING_MESSAGE = "Naewe payment initiated.";
    private static final String WITHDRAWAL_PENDING_MESSAGE = "Naewe withdrawal requested.";

    private static final String[] testPrefixes =
        {"exact-", "underpaid-", "overpaid-", "follow-up-", "below-minimum-", "blocked-", "completed-", "failed-"};

    @Inject
    ObjectMapper objectMapper;

    public ExecuteTransactionResponse mapDepositResponse(Response response, Throwable failure, String transactionId) {
        if (failure != null) {
            Log.errorf(failure, "Naewe deposit request failed for trxId=%s", transactionId);
            return buildErrorResponse(transactionId, ProcessingCode.INVALID_REQUEST, getErrorMessage(failure));
        }
        return handleDepositResponse(response, transactionId);
    }


    private String getErrorMessage(Throwable throwable) {
        return switch (throwable){
            case WebApplicationException wae -> wae.getResponse().readEntity(String.class);
            default -> throwable.getMessage();
        };
    }

    public ExecuteTransactionResponse mapWithdrawalResponse(Response response, Throwable failure, String transactionId) {
        if (failure != null) {
            Log.errorf(failure, "Naewe withdrawal request failed for trxId=%s", transactionId);
            return buildErrorResponse(transactionId, ProcessingCode.INVALID_REQUEST, getErrorMessage(failure));
        }
        return handleWithdrawalResponse(response, transactionId);
    }

    public ExecuteTransactionResponse buildValidationError(String transactionId, String message) {
        return buildErrorResponse(transactionId, ProcessingCode.INVALID_REQUEST, message);
    }

    public FinalizeTransactionRequest mapDepositCallback(NaeweDepositCallback callback) {
        TransactionStatus status = NaeweTransactionStatusMapper.mapDepositStatus(callback.status());
        String message = "Naewe deposit status: %s".formatted(callback.status());
        String stripped = stripFirstPrefix(callback.reference());
        return buildFinalizeRequest(stripped, status, message,
            new FinalizeMetadata(callback.expectedDisplayAmount(), callback.actualDisplayAmount()));
    }

    public FinalizeTransactionRequest mapWithdrawalCallback(NaeweWithdrawalCallback callback) {
        TransactionStatus status = NaeweTransactionStatusMapper.mapWithdrawalStatus(callback.status());
        String message = "Naewe withdrawal status: %s".formatted(callback.status());
        String stripped = stripFirstPrefix(callback.reference());
        return buildFinalizeRequest(stripped, status, message, null);
    }

    public FinalizeTransactionRequest mapWithdrawalApprovalCallback(NaeweWithdrawalApprovalCallback callback) {
        TransactionStatus status = NaeweTransactionStatusMapper.mapWithdrawalApprovalStatus(callback.status());
        String message = "Naewe withdrawal approval state: %s".formatted(callback.status());
        String stripped = stripFirstPrefix(callback.reference());
        return buildFinalizeRequest(stripped, status, message, null);
    }

    public static String stripFirstPrefix(String s) {
        for (String p : testPrefixes) {
            if (s.startsWith(p)) {
                return s.substring(p.length());
            }
        }
        return s;
    }

    private ExecuteTransactionResponse handleDepositResponse(Response response, String transactionId) {
        String body = safeReadBody(response);
        if (response.getStatusInfo().getFamily() == Response.Status.Family.SUCCESSFUL) {
            try {
                CreatedPaymentResponse created = objectMapper.readValue(body, CreatedPaymentResponse.class);
                String paymentUrl = resolvePaymentUrl(created);
                if (paymentUrl == null || paymentUrl.isBlank()) {
                    Log.errorf("Naewe deposit response missing paymentUrl. trxId=%s body=%s", transactionId, body);
                    return buildErrorResponse(transactionId, ProcessingCode.INVALID_REQUEST, "Missing paymentUrl in response.");
                }
                JsonObject data = JsonObject.mapFrom(created);
                return buildPendingResponse(transactionId, DEPOSIT_PENDING_MESSAGE, paymentUrl, data);
            } catch (JsonProcessingException e) {
                Log.errorf(e, "Failed to parse Naewe deposit response for trxId=%s body=%s", transactionId, body);
                return buildErrorResponse(transactionId, ProcessingCode.INVALID_REQUEST, e.getOriginalMessage());
            }
        }
        return buildErrorFromBody(transactionId, response.getStatus(), body);
    }

    private ExecuteTransactionResponse handleWithdrawalResponse(Response response, String transactionId) {
        String body = safeReadBody(response);
        if (response.getStatus() == Response.Status.ACCEPTED.getStatusCode()) {
            try {
                IntegratorCryptoWithdrawalPendingApprovalResponse pending =
                    objectMapper.readValue(body, IntegratorCryptoWithdrawalPendingApprovalResponse.class);
                JsonObject data = JsonObject.mapFrom(pending);
                String message = pending.approvalState() != null
                    ? "Naewe withdrawal pending approval (%s).".formatted(pending.approvalState())
                    : WITHDRAWAL_PENDING_MESSAGE;
                return buildPendingResponse(transactionId, message, null, data);
            } catch (JsonProcessingException e) {
                Log.errorf(e, "Failed to parse pending approval withdrawal response for trxId=%s body=%s", transactionId, body);
                return buildErrorResponse(transactionId, ProcessingCode.INVALID_REQUEST, e.getOriginalMessage());
            }
        }

        if (response.getStatusInfo().getFamily() == Response.Status.Family.SUCCESSFUL) {
            try {
                WithdrawalInitiatedResponse initiated =
                    objectMapper.readValue(body, WithdrawalInitiatedResponse.class);
                JsonObject data = JsonObject.mapFrom(initiated);
                String message = initiated.status() != null
                    ? "Naewe withdrawal status: %s".formatted(initiated.status())
                    : WITHDRAWAL_PENDING_MESSAGE;
                return buildPendingResponse(transactionId, message, null, data);
            } catch (JsonProcessingException e) {
                Log.errorf(e, "Failed to parse withdrawal response for trxId=%s body=%s", transactionId, body);
                return buildErrorResponse(transactionId, ProcessingCode.INVALID_REQUEST, e.getOriginalMessage());
            }
        }

        return buildErrorFromBody(transactionId, response.getStatus(), body);
    }

    private ExecuteTransactionResponse buildPendingResponse(String transactionId, String message, String redirectUrl, JsonObject data) {
        ExecuteTransactionResponse.Response.Builder responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        new GrpcBuilder<>(responseBuilder)
            .set(transactionId, responseBuilder::setId)
            .set(message, responseBuilder::setResponseMessage)
            .setAny(ExecuteTransactionResponse.Status.PENDING, responseBuilder::setStatus)
            .set(ProcessingCode.TRX_STATUS_PENDING.name(), responseBuilder::setResponseCode)
            .setAny(message, responseBuilder::setPaymentProviderResponseMessage)
            .setAndMap(data, GrpcFactory::fromJson, responseBuilder::setData);

        ExecuteTransactionResponse.Builder builder = ExecuteTransactionResponse.newBuilder()
            .setResponse(responseBuilder.build());

        if (redirectUrl != null) {
            ExecuteTransactionResponse.Redirect.Builder redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();
            redirectBuilder.setUrl(redirectUrl);
            builder.setRedirect(redirectBuilder.build());
        }

        return builder.build();
    }

    private ExecuteTransactionResponse buildErrorResponse(String transactionId, ProcessingCode code, String message) {
        ExecuteTransactionResponse.Response.Builder responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        new GrpcBuilder<>(responseBuilder)
            .set(transactionId, responseBuilder::setId)
            .setAny(ExecuteTransactionResponse.Status.ERROR, responseBuilder::setStatus)
            .set(code.name(), responseBuilder::setResponseCode)
            .set(message, responseBuilder::setResponseMessage)
            .setAny(message, responseBuilder::setPaymentProviderResponseMessage)
            .setAny(Struct.getDefaultInstance(), responseBuilder::setData);

        return ExecuteTransactionResponse.newBuilder()
            .setResponse(responseBuilder.build())
            .build();
    }

    private FinalizeTransactionRequest buildFinalizeRequest(String transactionId, TransactionStatus status, String message, FinalizeMetadata metadata) {
        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder();
        ProcessingCode processingCode = mapProcessingCode(status);
        var grpc = new GrpcBuilder<>(builder)
            .set(transactionId, builder::setId)
            .setAny(status, builder::setStatus)
            .set(processingCode.name(), builder::setResponseCode)
            .set(message, builder::setResponseMessage)
            // TODO: we need to update amount of the transaction for this
            .setAny(message, builder::setPaymentProviderResponseMessage);

        if (metadata == null || Objects.equals(metadata.expectedDisplayAmount(), metadata.actualDisplayAmount()))
            return  builder.build();

        var big100 = BigDecimal.valueOf(100);

        grpc.set(metadata.actualDisplayAmount().multiply(big100).intValue(), builder::setAmount);

        return builder.build();
    }

    private ProcessingCode mapProcessingCode(TransactionStatus status) {
        return switch (status) {
            case APPROVED -> ProcessingCode.TRX_STATUS_APPROVED;
            case DECLINED -> ProcessingCode.TRX_STATUS_DECLINED;
            case PENDING -> ProcessingCode.TRX_STATUS_PENDING;
            case CANCELED -> ProcessingCode.TRX_STATUS_CANCELED;
            case CREATED, UNRECOGNIZED, SESSION_EXPIRED, INVALID -> ProcessingCode.TRX_STATUS_FAILED;
            default -> ProcessingCode.TRX_STATUS_FAILED;
        };
    }

    private ExecuteTransactionResponse buildErrorFromBody(String transactionId, int status, String body) {
        try {
            NaeweErrorResponse error = objectMapper.readValue(body, NaeweErrorResponse.class);
            String message = error.resolvedMessage();
            return buildErrorResponse(transactionId, resolveProcessingCode(status), message);
        } catch (Exception e) {
            Log.errorf(e, "Failed to parse Naewe error response. trxId=%s status=%s body=%s", transactionId, status, body);
            return buildErrorResponse(transactionId, resolveProcessingCode(status), body);
        }
    }

    private String resolvePaymentUrl(CreatedPaymentResponse response) {
        if (response == null) {
            return null;
        }
        if (response.paymentUrl() != null && !response.paymentUrl().isBlank()) {
            return response.paymentUrl();
        }
        if (response.paymentInfo() != null) {
            return response.paymentInfo().url();
        }
        return null;
    }

    private ProcessingCode resolveProcessingCode(int status) {
        if (status >= 500) {
            return ProcessingCode.TRX_STATUS_FAILED;
        }
        return ProcessingCode.INVALID_REQUEST;
    }

    private String safeReadBody(Response response) {
        if (response == null) {
            return "";
        }
        try {
            return response.readEntity(String.class);
        } catch (IllegalStateException e) {
            Log.warnf("Unable to read Naewe response body: %s", e.getMessage());
            return "";
        }
    }
}
