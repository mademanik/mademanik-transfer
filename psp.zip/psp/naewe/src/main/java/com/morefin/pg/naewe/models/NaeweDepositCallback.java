package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public record NaeweDepositCallback(
    @JsonProperty("clientPaymentId")
    String clientPaymentId,
    @JsonProperty("status")
    String status,
    @JsonProperty("paymentId")
    String paymentId,
    @JsonProperty("actualDisplayAmount")
    BigDecimal actualDisplayAmount,
    @JsonProperty("expectedDisplayAmount")
    BigDecimal expectedDisplayAmount
) implements NaeweCallbackPayload {

    @Override
    public String reference() {
        return clientPaymentId;
    }
}
