package com.morefin.pg.naewe.processing;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeEnum;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingService;
import com.morefin.pg.naewe.admin.NaeweAdminService;
import com.morefin.pg.naewe.service.NaeweTransactionManagerService;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.Optional;

@ApplicationScoped
@Unremovable
public class NaeweProcessingService implements APMProcessingService, WithdrawalPaymentProcessingService {
    @Inject
    NaeweAdminService naeweAdminService;

    @Inject
    NaeweTransactionManagerService transactionManagerService;

    private static final PaymentMethodTypeIdentifier PAYMENT_METHOD_TYPE =
        new PaymentMethodTypeIdentifier("naewe", PaymentMethodTypeEnum.ALTERNATIVE_PAYMENT_METHOD, "Naewe Alternative Payment Method");

    @Override
    public Uni<ExecuteTransactionResponse> request(TransactionTypeContext context) {
        return transactionManagerService.deposit(context);
    }

    @Override
    public Uni<ExecuteTransactionResponse> authorizeWithdrawal(TransactionTypeContext context) {
        return transactionManagerService.withdrawal(context);
    }

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return PAYMENT_METHOD_TYPE;
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return naeweAdminService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String id) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return naeweAdminService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }
}
