package com.morefin.pg.naewe.processing;

import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingService;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.grpc.bank.WithdrawalPaymentProcessingServiceProvider;
import com.morefin.pg.naewe.NaeweTypeModule;
import io.quarkus.arc.Arc;

public class NaeweWithdrawalServiceProvider implements WithdrawalPaymentProcessingServiceProvider {
    @Override
    public WithdrawalPaymentProcessingService create() {
        try(var instance = Arc.container().instance(NaeweProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return NaeweTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return NaeweTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return NaeweTypeModule.MODULE_ID;
    }
}
