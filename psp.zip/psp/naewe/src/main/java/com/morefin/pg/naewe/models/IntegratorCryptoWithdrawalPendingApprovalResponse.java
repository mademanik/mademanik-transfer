package com.morefin.pg.naewe.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record IntegratorCryptoWithdrawalPendingApprovalResponse(
    String withdrawId,
    String status,
    String approvalState
) {
}
