package com.finrelay.pg.empcorp.cashlib;

import com.finrelay.pg.empcorp.cashlib.admin.CashlibAdminPaymentProcessingServiceImpl;
import com.finrelay.pg.empcorp.cashlib.admin.CashlibPaymentMethodTypeModule;
import com.finrelay.pg.empcorp.cashlib.admin.Config;
import com.finrelay.pg.empcorp.common.RuntimeAccountConfig;
import com.finrelay.pg.empcorp.common.RuntimePaymentProviderConfig;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherPaymentProcessingService;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessingspi.JavaPaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.common.paymentprocessingspi.paymentmethod.PaymentMethodTypeIdentifier;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Map;
import java.util.Optional;

@ApplicationScoped
@Unremovable
public class CashlibPaymentProcessingServiceImpl implements VoucherPaymentProcessingService {

    @Inject
    AuthorizeTransaction authorizeTransaction;

    @Inject
    Config config;

    @Inject
    CashlibAdminPaymentProcessingServiceImpl adminPaymentProcessingService;

    @Override
    public Uni<ExecuteTransactionResponse> authorize(VoucherAuthorizeContext context) {
        var transaction = context.transaction();
        var runtimeAccountConfig = context.paymentProviderAccount().getData().getJsonObject("configuration").mapTo(RuntimeAccountConfig.class);
        var configuration = Optional.ofNullable(context.paymentProvider().getData().getJsonObject("configuration"))
            .orElse(new JsonObject());
        var runtimePaymentProviderConfig = JsonObject.mapFrom(configuration).mapTo(RuntimePaymentProviderConfig.class);
        return authorizeTransaction.authorize(
            new AuthorizeTransaction.Context(
                transaction.getMetadata(),
                runtimeAccountConfig,
                runtimePaymentProviderConfig,
                transaction,
                transaction.getAmount(),
                context.tenantConfig().url(),
                transaction.getId(),
                transaction.getDescription(),
                transaction.getReference(),
                transaction.getUserIp(),
                JsonObject.mapFrom(context.paymentMethod().data()).mapTo(CashlibPaymentMethodData.class)
            )
        );
    }

    @Override
    public PaymentMethodTypeIdentifier paymentMethodType() {
        return CashlibPaymentMethodTypeModule.PAYMENT_METHOD_TYPE_IDENTIFIER;
    }

    @Override
    public String masked(String s, Map<String, String> map) {
        return "****";
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return new JavaPaymentProviderServiceConfig(config.providerSettings(), true, config.accountSettings());
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }

}
