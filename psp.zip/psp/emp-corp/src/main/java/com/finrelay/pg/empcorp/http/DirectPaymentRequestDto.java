package com.finrelay.pg.empcorp.http;

import jakarta.ws.rs.FormParam;
import org.apache.commons.lang3.StringUtils;

public class DirectPaymentRequestDto {
    @FormParam("Amount")
    Long amount;
    @FormParam("Uid")
    String uid;
    @FormParam("Tid")
    String tid;
    @FormParam("Email")
    String email;
    @FormParam("Firstname")
    String firstname;
    @FormParam("Lastname")
    String lastname;
    @FormParam("CardNumber")
    String cardNumber;
    @FormParam("CardMonth")
    String cardMonth;
    @FormParam("CardYear")
    String cardYear;
    @FormParam("CardCVV")
    Integer cardCvv;
    @FormParam("CardOwner")
    String cardOwner;
    @FormParam("ClientIp")
    String clientIp;
    @FormParam("Description")
    String description;
    @FormParam("Address")
    String address;
    @FormParam("ZipCode")
    String zipCode;
    @FormParam("City")
    String city;
    @FormParam("Country")
    String country;
    @FormParam("Phone")
    String phone;
    @FormParam("BirthDate")
    String birthDate;
    @FormParam("BirthPlace")
    String birthPlace;
    @FormParam("OriginalAmount")
    Integer originalAmount;
    @FormParam("OriginalCurrency")
    String originalCurrency;
    @FormParam("ConvertCurrency")
    String convertCurrency;
    @FormParam("ReturnUrl")
    String returnUrl;
    @FormParam("3DS")
    String threeDs;
    @FormParam("PreAuth")
    String preAuth;

    public DirectPaymentRequestDto(
        Long amount,
        String uid,
        String tid,
        String email,
        String firstname,
        String lastname,
        String cardNumber,
        Integer cardMonth,
        Integer cardYear,
        Integer cardCvv,
        String cardOwner,
        String clientIp,
        String description,
        String address,
        String zipCode,
        String city,
        String country,
        String phone,
        String birthDate,
        String birthPlace,
        Integer originalAmount,
        String originalCurrency,
        String convertCurrency,
        String returnUrl,
        String threeDs,
        String preAuth) {
        this.amount = amount;
        this.uid = uid;
        this.tid = tid;
        this.email = email;
        this.firstname = firstname;
        this.lastname = lastname;
        this.cardNumber = cardNumber;
        this.cardMonth = StringUtils.leftPad(cardMonth.toString(), 2, '0');
        this.cardYear = cardYear.toString();
        this.cardCvv = cardCvv;
        this.cardOwner = cardOwner;
        this.clientIp = clientIp;
        this.description = description;
        this.address = address;
        this.zipCode = zipCode;
        this.city = city;
        this.country = country;
        this.phone = phone;
        this.birthDate = birthDate;
        this.birthPlace = birthPlace;
        this.originalAmount = originalAmount;
        this.originalCurrency = originalCurrency;
        this.convertCurrency = convertCurrency;
        this.returnUrl = returnUrl;
        this.threeDs = threeDs;
        this.preAuth = preAuth;
    }
}
