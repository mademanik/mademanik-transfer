package com.finrelay.pg.empcorp.common;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimePaymentProviderConfig(
    @JsonProperty("test")
    Boolean test
) {
}
