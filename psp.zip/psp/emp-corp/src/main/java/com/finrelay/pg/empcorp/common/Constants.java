package com.finrelay.pg.empcorp.common;

public class Constants {
    public static final String EMP_CORP_RESOURCE_PATH = "/emp-corp";
    public static final String RETURN_URL_ENDPOINT = "/return-url";

    private Constants() {}
}
