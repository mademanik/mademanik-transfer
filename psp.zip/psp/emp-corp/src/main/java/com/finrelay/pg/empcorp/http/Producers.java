package com.finrelay.pg.empcorp.http;

import com.finrelay.pg.empcorp.card.admin.Config;
import com.finrelay.pg.empcorp.common.EmpCorpEnvironment;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

import java.net.URI;

@ApplicationScoped
public class Producers {

    @Inject
    Config config;

    @Produces
    @Named(EmpCorpEnvironment.PROD)
    HttpService prod() {
        return RestClientBuilder.newBuilder()
            .baseUri(config.prod().apiUrl())
            .build(HttpService.class);
    }

    @Produces
    @Named(EmpCorpEnvironment.TEST)
    HttpService test() {
        return RestClientBuilder.newBuilder()
            .baseUri(config.test().apiUrl())
            .build(HttpService.class);
    }
}
