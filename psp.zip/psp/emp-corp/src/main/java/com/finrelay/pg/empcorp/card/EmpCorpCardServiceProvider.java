package com.finrelay.pg.empcorp.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import io.quarkus.arc.Arc;
import com.finrelay.pg.empcorp.card.admin.EmpCorpCardProcessingModule;

import java.util.List;

public class EmpCorpCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {

    @Override
    public String name() {
        return EmpCorpCardProcessingModule.MODULE_ID;
    }

    @Override
    public String id() {
        return EmpCorpCardProcessingModule.MODULE_ID;
    }

    @Override
    public String type() {
        return "CARD";
    }

    @Override
    public EcommerceCardPaymentProcessingService create() {
        try (var instance = Arc.container().instance(PaymentProcessingServiceImpl.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return List.of(
            "card",
            "saved_card"
        );
    }
}
