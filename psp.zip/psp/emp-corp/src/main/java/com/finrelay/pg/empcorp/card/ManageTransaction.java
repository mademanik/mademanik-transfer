package com.finrelay.pg.empcorp.card;

import com.finrelay.pg.empcorp.common.EmpCorpEnvironment;
import com.finrelay.pg.empcorp.common.RuntimeAccountConfig;
import com.finrelay.pg.empcorp.common.RuntimePaymentProviderConfig;
import com.finrelay.pg.empcorp.http.ApiResponseDto;
import com.finrelay.pg.empcorp.http.HttpService;
import com.finrelay.pg.empcorp.http.RefundRequestDto;
import com.finrelay.pg.empcorp.http.ResponseCodeMapper;
import com.finrelay.pg.empcorp.http.TransactionStatus;
import com.finrelay.pg.empcorp.http.TransactionStatusMapper;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.util.Optional;

@RequestScoped
public class ManageTransaction {

    HttpService prodHttpService;

    HttpService testHttpService;

    @Inject
    ResponseCodeMapper responseCodeMapper;

    /**
     * Required for CDI
     */
    @SuppressWarnings("unused")
    public ManageTransaction() {
    }

    @SuppressWarnings("unused")
    @Inject
    public ManageTransaction(@Named(EmpCorpEnvironment.PROD) HttpService prodHttpService, @Named(EmpCorpEnvironment.TEST) HttpService testHttpService) {
        this.prodHttpService = prodHttpService;
        this.testHttpService = testHttpService;
    }

    public Uni<ExecuteTransactionResponse> manageTransaction(ManageTransaction.Context context) {
        return Uni.createFrom().item(context)
            .map(this::getRequestFromContext)
            .flatMap(req -> {
                var testEnvironment = Optional.ofNullable(context.runtimePaymentProviderConfig).map(RuntimePaymentProviderConfig::test).orElse(true);
                var httpService = testEnvironment ? testHttpService : prodHttpService;
                return httpService.refund(req, context.runtimeAccountConfig.apiKey());
            })
            .map(this::convertToCardResponse);
    }

    private ExecuteTransactionResponse convertToCardResponse(ApiResponseDto response) {
        // TODO: implement this
        var parsedResponseCode = TransactionStatusMapper.parseTransactionStatus(TransactionStatus.valueOf(response.result().getStatus().toUpperCase()));
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder().setResponse(
                new GrpcBuilder<>(builder)
                    // Probably using the wrong grpc model here - anyway i cannot map anything since there aren't relevant methods for setting response attributes
                    .getBuilder().build()
            )
            .build();
    }

    RefundRequestDto getRequestFromContext(ManageTransaction.Context context) {
        return new RefundRequestDto(
            context.id
        );
    }

    public record Context(
        RuntimeAccountConfig runtimeAccountConfig,
        RuntimePaymentProviderConfig runtimePaymentProviderConfig,
        String id
    ) {
    }
}
