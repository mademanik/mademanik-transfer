package com.finrelay.pg.empcorp.http;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.annotation.Nullable;

public record ApiResponseDto(
    @JsonProperty("Code")
    Integer code,
    @Nullable
    @JsonProperty("Result")
    Result result
)
{
    public static class Result {
        @JsonProperty("OperationType")
        String operationType;
        @JsonProperty("Status")
        String status;
        @JsonProperty("Tid")
        String tid;
        @JsonProperty("Reference")
        String reference;
        @JsonProperty("Amount")
        String amount;
        @JsonProperty("Userld")
        String userld;
        @JsonProperty("Message")
        String message;
        @JsonProperty("Error")
        String error;
        @JsonProperty("3DSecureUrl")
        String threeDSecureUrl;
        @JsonProperty("Date")
        String date;

        public String getOperationType() {
            return operationType;
        }

        public String getStatus() {
            return status;
        }

        public String getTid() {
            return tid;
        }

        public String getReference() {
            return reference;
        }

        public String getAmount() {
            return amount;
        }

        public String getUserld() {
            return userld;
        }

        public String getMessage() {
            return message;
        }

        public String getError() {
            return error;
        }

        public String getThreeDSecureUrl() {
            return threeDSecureUrl;
        }

        public String getDate() {
            return date;
        }

        public void setOperationType(String operationType) {
            this.operationType = operationType;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public void setTid(String tid) {
            this.tid = tid;
        }

        public void setReference(String reference) {
            this.reference = reference;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public void setUserld(String userld) {
            this.userld = userld;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public void setError(String error) {
            this.error = error;
        }

        public void setThreeDSecureUrl(String threeDSecureUrl) {
            this.threeDSecureUrl = threeDSecureUrl;
        }

        public void setDate(String date) {
            this.date = date;
        }
    }
}
