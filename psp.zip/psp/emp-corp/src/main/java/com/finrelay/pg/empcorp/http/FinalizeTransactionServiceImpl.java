package com.finrelay.pg.empcorp.http;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

import java.net.URI;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@ApplicationScoped
public class FinalizeTransactionServiceImpl implements FinalizeTransactionService {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Override
    public Uni<Response> finalizeTransaction(EmpCorpCallbackDto body, String tenantId) {
        var grpc = GrpcClientFactory.grpc(
            transactionGrpc,
            tenantId,
            getServiceAccount(),
            Constants.LOCALHOST);
        return Uni.createFrom().item(body)
            .map(this::fromBody)
            .flatMap(req -> {
                return grpc.finalizeTransaction(req)
                    .map(result -> {
                        if (result.hasRedirect()) {
                            return Response.temporaryRedirect(URI.create(result.getRedirect().getUrl())).build();
                        } else {
                            return Response.status(400).build();
                        }
                    });
            });
    }

    private FinalizeTransactionRequest fromBody(EmpCorpCallbackDto callbackDto) {
        var message = Optional.ofNullable(callbackDto.getMessage())
            .orElse(callbackDto.getError());
        return FinalizeTransactionRequest.newBuilder()
            .setResponseMessage(message)
            .setPaymentProviderResponseMessage(message)
            .setStatus(parseTransactionStatus(callbackDto))
            .setReferenceNumber(callbackDto.getReference())
            .setId(callbackDto.getTid()).build();
    }

    static TransactionStatus parseTransactionStatus(EmpCorpCallbackDto callbackDto) {
        return switch (callbackDto.getStatus()) {
            case "captured" -> TransactionStatus.APPROVED;
            case "pending" -> TransactionStatus.PENDING;
            default -> TransactionStatus.DECLINED;
        };
    }

    private GrpcApiUser getServiceAccount() {
        return GrpcApiUser.serviceAccount(
            Set.of(),
            Map.of(),
            "service-account"
        );
    }
}