package com.finrelay.pg.empcorp.card;

import com.finrelay.pg.empcorp.common.EmpCorpEnvironment;
import com.finrelay.pg.empcorp.common.RuntimeAccountConfig;
import com.finrelay.pg.empcorp.common.RuntimePaymentProviderConfig;
import com.finrelay.pg.empcorp.http.ApiResponseDto;
import com.finrelay.pg.empcorp.http.DirectPaymentRequestDto;
import com.finrelay.pg.empcorp.http.EmpCorpResource;
import com.finrelay.pg.empcorp.http.HttpService;
import com.finrelay.pg.empcorp.http.ResponseCodeMapper;
import com.finrelay.pg.empcorp.http.TransactionStatus;
import com.finrelay.pg.empcorp.http.TransactionStatusMapper;
import com.morefin.common.common.payments.core.tenant.TenantsConfig;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.CustomerData;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.utils.Utils;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.annotation.Nullable;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.ws.rs.core.UriBuilder;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;
import java.util.Optional;

import static com.finrelay.pg.empcorp.http.ResponseCodeMapper.INVALID_REQUEST;

@ApplicationScoped
public class AuthorizeTransaction {

    HttpService prodHttpService;

    HttpService testHttpService;

    @Inject
    ResponseCodeMapper responseCodeMapper;

    @Inject
    Utils pspUtils;

    /**
     * Required for CDI
     */
    @SuppressWarnings("unused")
    public AuthorizeTransaction() {
    }

    @SuppressWarnings("unused")
    @Inject
    public AuthorizeTransaction(@Named(EmpCorpEnvironment.PROD) HttpService prodHttpService, @Named(EmpCorpEnvironment.TEST) HttpService testHttpService) {
        this.prodHttpService = prodHttpService;
        this.testHttpService = testHttpService;
    }

    public Uni<ExecuteTransactionResponse> authorize(Context context) {
        return Uni.createFrom().item(context)
            .flatMap(this::getRequestFromContext)
            .flatMap(req -> {
                var testEnvironment = Optional.ofNullable(context.runtimePaymentProviderConfig).map(RuntimePaymentProviderConfig::test).orElse(true);
                var httpService = testEnvironment ? testHttpService : prodHttpService;
                return httpService.authorize(req, context.runtimeAccountConfig.apiKey());
            })
            .invoke(t -> {
                Log.infov("Received response, response={0}", JsonObject.mapFrom(t));
            })
            .map(response -> convertToCardResponse(response, context));
    }

    Uni<DirectPaymentRequestDto> getRequestFromContext(Context context) {
        var transaction = context.transaction();
        var customerData = new CustomerData(
            transaction.getCustomerFirstName(),
            transaction.getCustomerLastName(),
            transaction.getCustomerAddress(),
            transaction.getCustomerCity(),
            transaction.getCustomerCountry(),
            transaction.getCustomerPostalCode(),
            transaction.getCustomerEmail(),
            transaction.getCustomerPhoneNumber(),
            transaction.getCustomerId()
        );
        return pspUtils.convertIso2toIso3CountryCode(
            customerData.country(),
            context.transaction().getTenantId()
        ).map(countryCode -> {

            return new DirectPaymentRequestDto(
                context.amount,
                DigestUtils.sha256Hex(Objects.requireNonNull(Optional.of(customerData).map(CustomerData::id).orElse(
                    customerData.email()
                ), "missing required parameter Uid (customer.id or customer.email)")),
                context.id(),
                customerData.email(),
                customerData.firstName(),
                customerData.lastName(),
                context.cardNumber,
                context.expirationMonth,
                context.expirationYear,
                Integer.parseInt(context.cvv),
                StringUtils.join(customerData.firstName(), customerData.lastName(), ' '),
                context.userIp(),
                context.description,
                customerData.address(),
                customerData.postalCode(),
                customerData.city(),
                countryCode,
                customerData.phoneNumber(),
                // TODO: this should be runtime value collected on hpp
                "1991-01-01",
                null,
                null,
                context.transaction.getCurrency(),
                null,
                UriBuilder.fromUri(context.tenantConfig().url())
                    .path(EmpCorpResource.class)
                    .path(EmpCorpResource.class, "returnUrl")
                    .build().toString(),
                "no",
                "no"
            );
        });
    }


    private ExecuteTransactionResponse convertToCardResponse(ApiResponseDto response, Context context) {
        var paymentProviderResponseCode = Optional.ofNullable(response.result()).map(r -> {
            return TransactionStatusMapper.parseTransactionStatus(TransactionStatus.valueOf(r.getStatus().toUpperCase()));
        }).orElse(ExecuteTransactionResponse.Status.ERROR);
        var responseCode = switch (paymentProviderResponseCode) {
            case APPROVED -> ProcessingCode.TRX_STATUS_APPROVED;
            case PENDING -> ProcessingCode.TRX_STATUS_PENDING;
            case DECLINED -> ProcessingCode.TRX_STATUS_DECLINED;
            case ERROR -> ProcessingCode.TRX_STATUS_FAILED;
            default -> throw new IllegalStateException("Unexpected value: " + paymentProviderResponseCode);
        };

        return switch (paymentProviderResponseCode) {
            case DECLINED -> buildResponse(responseCode, response, paymentProviderResponseCode, context.id);
            case APPROVED -> buildResponse(responseCode, response, paymentProviderResponseCode, context.id);
            case PENDING -> buildPendingResponse(response, context.id);
            case ERROR -> buildResponse(responseCode, response, paymentProviderResponseCode, context.id);
            default -> throw new IllegalStateException("Unexpected value: " + paymentProviderResponseCode);
        };
    }

    private ExecuteTransactionResponse buildPendingResponse(ApiResponseDto response, String id) {
        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        Objects.requireNonNull(response.result(), "Missing response result for pending transaction");
        return ExecuteTransactionResponse.newBuilder()
            //TODO: set all response data here
            .setResponse(ExecuteTransactionResponse.Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name()).build())
            .setRedirect(
                new GrpcBuilder<>(builder)
                    .set(response.result().getThreeDSecureUrl(), builder::setUrl)
                    .getBuilder()
                    .build()
            )
            .build();
    }

    private ExecuteTransactionResponse buildResponse(
        ProcessingCode responseCode,
        ApiResponseDto response,
        ExecuteTransactionResponse.Status paymentProviderResponseCode,
        String tid) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        @Nullable
        var result = response.result();
        var paymentProviderResponseMessage = Optional.ofNullable(result).map(ApiResponseDto.Result::getMessage).orElse("not-set");
        var message = responseCodeMapper.getMessage(response.code());
        return ExecuteTransactionResponse.newBuilder()
            .setResponse(
                new GrpcBuilder<>(builder)
                    .set(responseCode.name(), builder::setResponseCode)
                    .set(response.result() != null ? response.result().getReference() : null, builder::setReferenceNumber)
                    .set(message, builder::setResponseMessage)
                    .set(tid, builder::setId)
                    .set("", builder::setApprovalCode)
                    .setAny(paymentProviderResponseMessage, builder::setPaymentProviderResponseMessage)
                    .setAny(Optional.ofNullable(response.code()).orElse(INVALID_REQUEST).toString(), builder::setPaymentProviderResponseCode)
                    .setAndMap(JsonObject.mapFrom(response).getMap(), GrpcFactory::fromMap, builder::setData)
                    .set(paymentProviderResponseCode.toString(), builder::setPaymentProviderStatus)
                    .setAny(paymentProviderResponseCode, builder::setStatus)
                    .getBuilder().build()
            )
            .build();
    }

    public record Context(
        JsonObject metadata,
        RuntimeAccountConfig runtimeAccountConfig,
        RuntimePaymentProviderConfig runtimePaymentProviderConfig,
        ImmutableTypedTransactionEntity transaction,
        Long amount,
        String cardNumber,
        String cvv,
        Integer expirationMonth,
        Integer expirationYear,
        String baseUrl,
        String id,
        String description,
        String reference,
        String userIp,
        TenantsConfig.TenantConfig tenantConfig
    ) {
    }
}
