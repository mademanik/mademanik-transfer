package com.finrelay.pg.empcorp.http;

import com.finrelay.pg.empcorp.cashlib.CashlibPaymentRequestDto;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/")
@RegisterRestClient
public interface HttpService {

    @Path("/api/payment/direct")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    Uni<ApiResponseDto> authorize(DirectPaymentRequestDto body, @SuppressWarnings("UastIncorrectHttpHeaderInspection") @HeaderParam("EPRO-API-KEY") String xApiKey);

    @Path("/api/refund")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    Uni<ApiResponseDto> refund(RefundRequestDto body, @SuppressWarnings("UastIncorrectHttpHeaderInspection") @HeaderParam("EPRO-API-KEY") String xApiKey);

    @Path("/api/payment/cashlib")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    Uni<ApiResponseDto> cashlib(CashlibPaymentRequestDto body, @SuppressWarnings("UastIncorrectHttpHeaderInspection") @HeaderParam("EPRO-API-KEY") String xApiKey);
}
