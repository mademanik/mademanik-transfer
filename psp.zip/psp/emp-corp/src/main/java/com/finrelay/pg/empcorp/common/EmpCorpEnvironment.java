package com.finrelay.pg.empcorp.common;

public class EmpCorpEnvironment {
    public static final String TEST = "test";
    public static final String PROD = "prod";
}
