package com.finrelay.pg.empcorp.http;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;

public class TransactionStatusMapper {

    public static ExecuteTransactionResponse.Status parseTransactionStatus(TransactionStatus transactionStatus) {
        return switch (transactionStatus) {
            case CAPTURED -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING -> ExecuteTransactionResponse.Status.PENDING;
            case FAILED, UNKNOWN -> ExecuteTransactionResponse.Status.DECLINED;
            case REJECTED_PW -> ExecuteTransactionResponse.Status.DECLINED;
        };
    }
}