package com.finrelay.pg.empcorp.http;

import com.morefin.common.common.payments.core.tenant.Tenant;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/emp-corp")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public class EmpCorpResource {

    @Inject
    FinalizeTransactionService finalizeTransactionService;

    @Inject
    Tenant tenant;

    @Path("/return-url")
    @POST
    public Uni<Response> returnUrl(EmpCorpCallbackDto body) {
        return finalizeTransactionService.finalizeTransaction(body, tenant.id());
    }
}
