package com.finrelay.pg.empcorp.cashlib;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

public record CashlibPaymentMethodData(
    @NotNull
    @JsonProperty("email")
    @Schema(name = "email", description = "Sample value -> johndoe@example.com")
    @Email
    String email,
    @NotNull
    @JsonProperty("firstName")
    @Schema(name = "firstName", description = "Sample value -> John")
    @Size(min = 1, max = 100)
    String firstName,
    @NotNull
    @JsonProperty("lastName")
    @Schema(name = "lastName", description = "Sample value -> Doe")
    @Size(min = 1, max = 100)
    String lastName,
    @NotNull
    @JsonProperty("address")
    @Schema(name = "address", description = "Sample value -> 123 Main Street")
    @Size(min = 1, max = 100)
    String address,
    @NotNull
    @JsonProperty("zipCode")
    @Size(min = 1, max = 100)
    @Schema(name = "zip_code", description = "Sample value -> 12345")
    String zipCode,
    @NotNull
    @JsonProperty("city")
    @Size(min = 1, max = 100)
    @Schema(name = "city", description = "Sample value -> Los Angeles")
    String city,
    @NotNull
    @JsonProperty("country")
    @Size(min = 2, max = 2)
    @Schema(name = "country", description = "Sample value -> US")
    String country,
    @NotNull
    @JsonProperty("phone")
    @Schema(name = "phone", description = "Sample value -> 1 555-555-5555")
    @Size(min = 1, max = 100)
    String phone,
    @NotNull
    @JsonProperty("birthDate")
    @Schema(name = "birthDate", description = "Sample value -> 1990-01-01")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Date must be in the format yyyy-MM-dd")
    String birthDate,
    @NotNull
    @JsonProperty("birthPlace")
    @Schema(name = "birthPlace", description = "Sample value -> Los Angeles, US")
    @Size(min = 1, max = 100)
    String birthPlace
) {
}
