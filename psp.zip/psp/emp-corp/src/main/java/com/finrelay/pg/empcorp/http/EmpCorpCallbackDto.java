package com.finrelay.pg.empcorp.http;

import jakarta.ws.rs.FormParam;

public class EmpCorpCallbackDto {
    @FormParam("OperationType")
    String operationType;
    @FormParam("Status")
    String status;
    @FormParam("Tid")
    String tid;
    @FormParam("Reference")
    String reference;
    @FormParam("Date")
    String date;
    @FormParam("Amount")
    String amount;
    @FormParam("UserId")
    String userId;
    @FormParam("Message")
    String message;
    @FormParam("3D")
    String threeDs;
    @FormParam("OneClick")
    String oneClick;
    @FormParam("Error")
    String error;

    public EmpCorpCallbackDto() {
    }

    public EmpCorpCallbackDto(String operationType, String status, String tid, String reference, String date, String amount, String userId, String message, String threeDs, String oneClick) {
        this.operationType = operationType;
        this.status = status;
        this.tid = tid;
        this.reference = reference;
        this.date = date;
        this.amount = amount;
        this.userId = userId;
        this.message = message;
        this.threeDs = threeDs;
        this.oneClick = oneClick;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getThreeDs() {
        return threeDs;
    }

    public void setThreeDs(String threeDs) {
        this.threeDs = threeDs;
    }

    public String getOneClick() {
        return oneClick;
    }

    public void setOneClick(String oneClick) {
        this.oneClick = oneClick;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}