package com.finrelay.pg.empcorp.http;

import jakarta.ws.rs.FormParam;

public class RefundRequestDto {

    @FormParam("Tid")
    String tid;

    public RefundRequestDto(String tid) {
        this.tid = tid;
    }
}
