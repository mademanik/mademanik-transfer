package com.finrelay.pg.empcorp.cashlib;

import com.finrelay.pg.empcorp.common.EmpCorpEnvironment;
import com.finrelay.pg.empcorp.common.RuntimeAccountConfig;
import com.finrelay.pg.empcorp.common.RuntimePaymentProviderConfig;
import com.finrelay.pg.empcorp.http.ApiResponseDto;
import com.finrelay.pg.empcorp.http.EmpCorpResource;
import com.finrelay.pg.empcorp.http.HttpService;
import com.finrelay.pg.empcorp.http.ResponseCodeMapper;
import com.finrelay.pg.empcorp.http.TransactionStatus;
import com.finrelay.pg.empcorp.http.TransactionStatusMapper;
import com.morefin.common.common.payments.core.IdGenerator;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.grpc.country.CountryGrpc;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse.Redirect;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse.Response;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse.Status;
import com.morefin.common.outboxspi.OutboxService;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.payments.shared.event.Events;
import com.morefin.common.payments.shared.event.StoreActionLogEvent;
import com.morefin.common.grpc.action_log.CreateActionLogRequest;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.utils.Utils;
import io.opentelemetry.api.trace.Span;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.unchecked.Unchecked;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonObject;
import io.vertx.mutiny.pgclient.PgPool;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.validation.Validator;
import jakarta.ws.rs.core.UriBuilder;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.EnumUtils;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.Optional;

import static com.finrelay.pg.empcorp.http.ResponseCodeMapper.SUCCESS_CODE;

@ApplicationScoped
public class AuthorizeTransaction {

    HttpService prodHttpService;

    HttpService testHttpService;

    @Inject
    ResponseCodeMapper responseCodeMapper;

    @Inject
    Validator validator;

    @Inject
    PgPool pgPool;

    @Inject
    OutboxService outboxService;

    @GrpcClient("country-svc")
    CountryGrpc countryGrpc;

    @Inject
    Utils pspUtils;

    /**
     * Required for CDI
     */
    @SuppressWarnings("unused")
    public AuthorizeTransaction() {
    }

    @SuppressWarnings("unused")
    @Inject
    public AuthorizeTransaction(
        @Named(EmpCorpEnvironment.PROD) HttpService prodHttpService,
        @Named(EmpCorpEnvironment.TEST) HttpService testHttpService
    ) {
        this.prodHttpService = prodHttpService;
        this.testHttpService = testHttpService;
    }

    public Uni<ExecuteTransactionResponse> authorize(Context context) {

        return Uni.createFrom().item(context)
            .flatMap(ctx -> {

                var violations = validator.validate(ctx.paymentMethodData());

                if (!violations.isEmpty()) {
                    return Uni.createFrom().item(declinedResponse("Invalid request", violations.toString(), context.id, null));
                } else {
                    var testEnvironment = Optional.ofNullable(context.runtimePaymentProviderConfig).map(RuntimePaymentProviderConfig::test).orElse(true);
                    var httpService = testEnvironment ? testHttpService : prodHttpService;

                    return getRequestFromContext(ctx).flatMap(req -> {
                        return httpService.cashlib(req, context.runtimeAccountConfig.apiKey())
                            .invoke(r -> {
                                Log.infov("Received response={0}", Json.encode(r));
                            })
                            .map(response -> convertToCardResponse(response, context.id));
                    });
                }
            });

    }

    Uni<CashlibPaymentRequestDto> getRequestFromContext(Context context) {
        var paymentMethodData = context.paymentMethodData();
        return pspUtils.convertIso2toIso3CountryCode(
            paymentMethodData.country(),
            context.transaction().getTenantId()
        ).map(Unchecked.function(countryCode -> {
            var returnUrl = UriBuilder.fromUri(context.baseUrl())
                .path(EmpCorpResource.class)
                .path(EmpCorpResource.class, "returnUrl")
                .build().toString();

            return new CashlibPaymentRequestDto(
                context.amount,
                calculateUid(context, paymentMethodData),
                context.id(),
                paymentMethodData.email(),
                paymentMethodData.firstName(),
                paymentMethodData.lastName(),
                context.userIp(),
                context.description,
                paymentMethodData.address(),
                paymentMethodData.zipCode(),
                paymentMethodData.city(),
                countryCode,
                paymentMethodData.phone(),
                paymentMethodData.birthDate(),
                null,
                null,
                null,
                null,
                returnUrl
            );
        }));
    }

    private static String calculateUid(Context context, CashlibPaymentMethodData paymentMethodData) {
        return DigestUtils.sha256Hex(Objects.requireNonNull(Optional.ofNullable(context.transaction().getCustomerId()).orElse(
            paymentMethodData.email()
        ), "missing required parameter Uid (customer.id or customer.email)"));
    }


    private ExecuteTransactionResponse convertToCardResponse(ApiResponseDto response, String id) {

        var code = response.code();
        if (code == null) {
            return declinedResponse("Response code null", "Response code null", id, null);
        }

        if (code == SUCCESS_CODE) {
            var result = response.result();
            var transactionStatus = Optional.ofNullable(EnumUtils.getEnum(TransactionStatus.class, result.getStatus().toUpperCase()))
                .orElse(TransactionStatus.UNKNOWN);

            var parsedResponseCode = TransactionStatusMapper.parseTransactionStatus(transactionStatus);
            return switch (parsedResponseCode) {
                case DECLINED ->
                    declinedResponse(result.getMessage(), result.getError(), result.getTid(), result.getReference());
                case APPROVED -> approvedResponse(response);
                case PENDING, PENDING_APPROVAL -> pendingResponse(response);
                case ERROR, UNRECOGNIZED -> errorResponse(response);
            };
        } else {
            return declinedResponse(
                responseCodeMapper.getMessage(code),
                responseCodeMapper.getMessage(code),
                id,
                null
            );
        }


    }

    private ExecuteTransactionResponse errorResponse(ApiResponseDto response) {
        var responseMessage = Optional.ofNullable(response.result().getMessage()).orElseGet(
            () -> Optional.ofNullable(response.result().getError()).orElse("Declined"));
        return ExecuteTransactionResponse.newBuilder()
            .setResponse(
                Response.newBuilder()
                    .setResponseCode(ProcessingCode.TRX_STATUS_FAILED.name())
                    .setResponseMessage(responseMessage)
                    .setPaymentProviderResponseMessage(responseMessage)
                    .setId(response.result().getTid())
                    .setStatus(Status.ERROR)
                    .setReferenceNumber(response.result().getReference())
                    .build()
            )
            .build();
    }

    private ExecuteTransactionResponse pendingResponse(ApiResponseDto response) {
        return ExecuteTransactionResponse.newBuilder()
            //TODO: set all response data here
            .setResponse(Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name()).build())
            .setRedirect(Redirect.newBuilder()
                .setUrl(response.result().getThreeDSecureUrl())
            ).build();
    }

    private ExecuteTransactionResponse approvedResponse(ApiResponseDto response) {
        return ExecuteTransactionResponse.newBuilder()
            .setResponse(
                Response.newBuilder()
                    .setResponseCode(ProcessingCode.TRX_STATUS_APPROVED.name())
                    .setResponseMessage("Approved")
                    .setPaymentProviderResponseMessage("Approved")
                    .setId(response.result().getTid())
                    .setStatus(Status.APPROVED)
                    .setReferenceNumber(response.result().getReference())
                    .build()
            )
            .build();
    }

    private ExecuteTransactionResponse declinedResponse(String message, String error, String tid, String reference) {
        var responseMessage = Optional.ofNullable(message).orElseGet(
            () -> Optional.ofNullable(error).orElse("Declined"));
        var builder = Response.newBuilder();

        return ExecuteTransactionResponse.newBuilder()
            .setResponse(
                new GrpcBuilder<>(builder)
                    .set(ProcessingCode.TRX_STATUS_DECLINED.name(), builder::setResponseCode)
                    .set(responseMessage, builder::setResponseMessage)
                    .set(responseMessage, builder::setPaymentProviderResponseMessage)
                    .set(tid, builder::setId)
                    .setAny(Status.DECLINED, builder::setStatus)
                    .set(reference, builder::setReferenceNumber)
                    .getBuilder()
                    .build()
            )
            .build();
    }

    Uni<String> logRequest(String transactionId, String merchantId, String tenant) {
        return pgPool.withTransaction(conn -> {
            var message = CreateActionLogRequest.newBuilder()
                .setId(IdGenerator.generate())
                .setMethod("authorize")
                .setResource("ecommmerce:platform:transaction")
                .setAction("cashlibAuthorize")
                .setTraceId(Span.current().getSpanContext().getTraceId())
                .setResourceId(transactionId)
                .setType("request")
                .setData(new JsonObject().encode()).build();
            return outboxService.insert(conn, new OutboxService.InsertRequest<>(
                Events.STORE_ACTION_LOG,
                IdGenerator.generate(),
                tenant,
                new StoreActionLogEvent(message.toByteArray()),
                JsonObject.of("transaction_id", transactionId),
                "ecommerce:platform:merchant:%s".formatted(merchantId),
                "cashlib",
                OffsetDateTime.now(),
                IdGenerator.generate(),
                IdGenerator.generate(),
                merchantId
            ));
        });
    }

    public record Context(
        JsonObject metadata,
        RuntimeAccountConfig runtimeAccountConfig,
        RuntimePaymentProviderConfig runtimePaymentProviderConfig,
        ImmutableTypedTransactionEntity transaction,
        Long amount,
        String baseUrl,
        String id,
        String description,
        String reference,
        String userIp,
        CashlibPaymentMethodData paymentMethodData
    ) {
    }
}
