package com.finrelay.pg.empcorp.card.authentication;

import com.morefin.common.authenticationgatewayspi.spi.AuthenticationServiceProvider;
import com.morefin.common.authenticationgatewayspi.spi.BaseAuthenticationService;
import io.quarkus.arc.Arc;

public class EmpCorpAuthenticationServiceProvider implements AuthenticationServiceProvider {

    @Override
    public BaseAuthenticationService create() {

        try (var instance = Arc.container().instance(EmpCorpCardAuthenticationService.class)) {
            return instance.get();
        }
    }
}
