package com.finrelay.pg.empcorp.cashlib;

import com.finrelay.pg.empcorp.cashlib.admin.CashlibProcessingModule;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.voucher.VoucherPaymentProcessingServiceProvider;
import io.quarkus.arc.Arc;

public class CashlibVoucherPaymentServiceProvider implements VoucherPaymentProcessingServiceProvider {
    @Override
    public VoucherPaymentProcessingService create() {
        try (var instance = Arc.container().instance(CashlibPaymentProcessingServiceImpl.class)) {
            return instance.get();
        }
    }

    @Override
    public String name() {
        return CashlibProcessingModule.MODULE_ID;
    }

    @Override
    public String id() {
        return CashlibProcessingModule.MODULE_ID;
    }

    @Override
    public String type() {
        return CashlibProcessingModule.MODULE_ID;
    }
}
