package com.finrelay.pg.empcorp.http;

public enum TransactionStatus {
    CAPTURED("Final status when the transaction was successfully processed."),
    PENDING("Status when the transaction is pending"),
    FAILED("The transaction has failed."),
    REJECTED_PW("Status when the transaction has been declined by EMP Corp due to checks made on card information"),
    UNKNOWN("Unknown transaction status");

    private final String description;

    TransactionStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}