package com.finrelay.pg.empcorp.http;

import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.core.Response;

public interface FinalizeTransactionService {
    Uni<Response> finalizeTransaction(EmpCorpCallbackDto callbackDto, String tenantId);
}
