package com.finrelay.pg.empcorp.http;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.validation.constraints.NotNull;

import java.util.HashMap;
import java.util.Map;

@ApplicationScoped
public class ResponseCodeMapper {

    private Map<Integer, String> responseMessages;
    public static final int SUCCESS_CODE = 0;
    public static final int INVALID_REQUEST = 1;

    @PostConstruct
    public void initialize() {
        this.responseMessages = new HashMap<>();

        responseMessages.put(SUCCESS_CODE, "SUCCESS");
        responseMessages.put(1, "Invalid request");
        responseMessages.put(2, "Invalid protocol, HTTPS must be used");
        responseMessages.put(3, "Invalid API key");
        responseMessages.put(4, "API key is not supplied");
        responseMessages.put(5, "Missing parameters");
        responseMessages.put(6, "Incorrect merchant configuration");
        responseMessages.put(7, "Oneclick payments not allowed on this account");
        responseMessages.put(8, "3DSecure payments not allowed on this account");
        responseMessages.put(9, "Evoucher purchase not allowed on this account");
        responseMessages.put(10, "Service unavailable");
        responseMessages.put(11, "Server IP address not allowed");
        responseMessages.put(12, "Transaction declined by merchant");
        responseMessages.put(13, "Transaction declined by merchant");
        responseMessages.put(14, "Transaction declined by merchant");
        responseMessages.put(15, "Your account is 3DS only, please use 3DS=yes");
        responseMessages.put(16, "Your account is VIC only, please use VIC=yes");
        responseMessages.put(17, "A payment must be either 3DS or VIC");
        responseMessages.put(18, "VIC payments not allowed on this account");
        responseMessages.put(19, "Oneclick payments not supported on this account");
        responseMessages.put(20, "3DSecure payments not supported on this account");
        responseMessages.put(21, "Incorrect merchant configuration, please contact us");
        responseMessages.put(22, "Maestro cards require 3DSecure");
        responseMessages.put(23, "MasterCard transactions not supported");
        responseMessages.put(24, "iDEAL payments not supported on this account");
        responseMessages.put(25, "Only iDEAL payment are supported on this account");
        responseMessages.put(26, "Prepaid, gift and virtual cards not supported on this account");
        responseMessages.put(27, "Unknown BIN");
        responseMessages.put(28, "Pre authorization not supported on this account");
        responseMessages.put(29, "Pre authorization is not supported for oneclick payment");
        responseMessages.put(30, "Refund not available for this payment method");
        responseMessages.put(100, "Client not found");
        responseMessages.put(101, "Can’t create client, contact us if the problem persists");
        responseMessages.put(102, "Transaction not found");
        responseMessages.put(103, "Invalid transaction");
        responseMessages.put(104, "TID already used for another transaction");
        responseMessages.put(105, "OneClick payment impossible, no credit card found for the given UID");
        responseMessages.put(106, "ReturnUrl is mandatory with 3DS enabled");
        responseMessages.put(107, "This user is not allowed to make any payment");
        responseMessages.put(108, "No valid credit card found for the given UID");
        responseMessages.put(109, "This user is not allowed to make any payment");
        responseMessages.put(110, "Can't add a card for this client, contact us if the problem persists");
        responseMessages.put(111, "No credit card found for this Alias");
        responseMessages.put(112, "This user is not allowed to make any payment");
        responseMessages.put(113, "This user is not allowed to make any payment");
        responseMessages.put(114, "Incorrect value Amount, greater than maximum refund for this transaction");
        responseMessages.put(115, "Partial refund not allowed for this transaction");
        responseMessages.put(116, "Partial refund needs to be done in the transaction's currency");
        responseMessages.put(117, "Transaction already refunded");
        responseMessages.put(118, "Only one partial refund can be done, full refund only can be done from now for this transaction");
        responseMessages.put(119, "Parameter Firstname and Lastname must be different");
        responseMessages.put(120, "This user is not allowed to make any payment");
        responseMessages.put(121, "This user have already exceeded the maximum allowed refund");
        responseMessages.put(150, "Export failed or being generated, please try again later");
        responseMessages.put(151, "Invalid parameter ChargebackUrl, do not forget protocol");
        responseMessages.put(152, "Invalid parameter Date, supported formats are YYYY-MM or YYYY-MM-DD");
        responseMessages.put(200, "Invalid parameter Amount, must be numeric only (1052 for 10.52 euros)");
        responseMessages.put(201, "Invalid parameter Uid, must only contain [a-zA-Z0-9-_]");
        responseMessages.put(202, "Invalid parameter Tid, must only contain [a-zA-Z0-9-_]");
        responseMessages.put(203, "Invalid parameter Email");
        responseMessages.put(204, "Invalid parameter Firstname or Lastname, must only contain [a-zA-Z- ] with or without accents");
        responseMessages.put(205, "Invalid parameter ClientIP");
        responseMessages.put(206, "Invalid parameter CardNumber, check format or Luhn algorithm");
        responseMessages.put(207, "Invalid parameter CardMonth or CardYear, month is always composed of 2 digits and year of 4 digits");
        responseMessages.put(208, "Invalid parameter CardCVV, must contain 3 or 4 digits");
        responseMessages.put(209, "Invalid or missing parameter CallingCode, it should be numeric only");
        responseMessages.put(210, "Invalid parameter CardOwner, must only contain [a-zA-Z- ] with or without accents");
        responseMessages.put(211, "Invalid parameter Address, must only contain [a-zA-Z0-9- ] with or without accents");
        responseMessages.put(212, "Invalid parameter ZipCode, must only contain [a-zA-Z0-9- ]");
        responseMessages.put(213, "Invalid parameter City, must only contain [a-zA-Z- ] with or without accents");
        responseMessages.put(214, "Invalid parameter Country, check ISO 3166-1 Alpha-3");
        responseMessages.put(215, "Invalid parameter Phone");
        responseMessages.put(216, "Invalid parameter BirthDate, check format YYYY-MM-DD");
        responseMessages.put(217, "Invalid parameter BirthPlace, must only contain [a-zA-Z- ] with or without accents");
        responseMessages.put(218, "Invalid parameter ReturnUrl, do not forget protocol");
        responseMessages.put(219, "Invalid parameter OriginalAmount, must be numeric only (1052 for 10.52 euros)");
        responseMessages.put(220, "Invalid parameter OriginalCurrency, check ISO 4217");
        responseMessages.put(221, "Invalid parameter Alias");
        responseMessages.put(222, "These fields are mandatory with your payment account");
        responseMessages.put(223, "Invalid parameter BankAddress, must only contain [a-zA-Z0-9- ] with or without accents");
        responseMessages.put(224, "Invalid parameter Currency, check ISO 4217");
        responseMessages.put(300, "Parameter Amount exceeds the maximum allowed by transaction");
        responseMessages.put(301, "Maximum number of transactions per day per email reached");
        responseMessages.put(302, "Maximum amount per week per email reached");
        responseMessages.put(303, "Maximum number of iDEAL transactions per day per email reached");
        responseMessages.put(304, "Maximum amount of iDEAL per week per email reached");
        responseMessages.put(305, "Maximum of failed transactions per day per email reached");
        responseMessages.put(306, "Maximum of different valid credit cards per email reached");
        responseMessages.put(307, "Maximum amount per email reached");
        responseMessages.put(308, "Maximum of customers for this credit card reached");
        responseMessages.put(400, "MerchantID currency conversion not supported");
        responseMessages.put(401, "OriginalCurrency must be filled if you want Epro to convert your currency");
        responseMessages.put(402, "OriginalAmount must be filled if you want Epro to convert your currency");
        responseMessages.put(403, "OriginalCurrency conversion is not currently supported");
        responseMessages.put(404, "OriginalCurrency, OriginalAmount and ConvertCurrency are only available on EUR accounts");
        responseMessages.put(500, "Error while sending SMS to the customer");
    }

    @NotNull
    public String getMessage(Integer code) {
        return responseMessages.getOrDefault(code, "Unknown response code");
    }
}
