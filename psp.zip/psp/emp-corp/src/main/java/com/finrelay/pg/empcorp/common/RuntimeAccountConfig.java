package com.finrelay.pg.empcorp.common;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
    @JsonProperty("api_key")
    String apiKey
) {
}
