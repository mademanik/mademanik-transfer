package com.finrelay.pg.empcorp.card;

import com.finrelay.pg.empcorp.card.admin.Config;
import com.finrelay.pg.empcorp.card.admin.EcommerceAdminPaymentProcessingServiceImpl;
import com.finrelay.pg.empcorp.common.RuntimeAccountConfig;
import com.finrelay.pg.empcorp.common.RuntimePaymentProviderConfig;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.keymanagementspi.keys.KeyManagementService;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProviderAccount;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import io.smallrye.mutiny.unchecked.Unchecked;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static com.morefin.pg.common.Constants.PPA_DEFAULT_DESCRIPTION;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
@Unremovable
public class PaymentProcessingServiceImpl implements EcommerceCardPaymentProcessingService {

    @Inject
    AuthorizeTransaction authorizeTransaction;

    @Inject
    Config config;

    @Inject
    ManageTransaction manageTransaction;

    @Inject
    KeyManagementService keyManagementService;

    @Inject
    EcommerceAdminPaymentProcessingServiceImpl adminPaymentProcessingService;

    @Override
    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext c) {
        return Uni.createFrom().item(c)
            .flatMap(x -> {
                var card = x.card();
                return keyManagementService.decrypt(
                    x.authorizeContext().getMerchant().getPrivateKey(),
                    card.encryptedCardNumber(),
                    card.encryptedCvv()
                );
            })
            .map(Unchecked.function((list) -> {
                var transactionTypeContext = c.authorizeContext();
                var transaction = transactionTypeContext.getTransaction();
                var paymentProviderAccount = c.authorizeContext().getPaymentProviderAccount();
                var runtimeAccountConfig = getRuntimeAccountConfig(transactionTypeContext.getPaymentProviderAccount());
                var runtimePaymentProviderConfig = getRuntimePaymentProviderConfig(transactionTypeContext.getPaymentProvider());
                return new AuthorizeTransaction.Context(
                    transaction.getMetadata(),
                    runtimeAccountConfig,
                    runtimePaymentProviderConfig,
                    transaction,
                    transaction.getAmount(),
                    new String(list.get(0), StandardCharsets.UTF_8),
                    new String(list.get(1), StandardCharsets.UTF_8),
                    c.card().expirationMonth(),
                    c.card().expirationYear(),
                    transactionTypeContext.getTenantConfig().url(),
                    transaction.getId(),
                    nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION),
                            transaction.getDescription()),
                    transaction.getReference(),
                    transaction.getUserIp(),
                    transactionTypeContext.getTenantConfig()
                );
            })).flatMap(authorizeTransaction::authorize);
    }

    @Override
    public Uni<ExecuteTransactionResponse> manage(ManageTransactionContext manageTransactionContext) {
        return Uni.createFrom().item(manageTransactionContext)
                .flatMap(ctx -> {
                    var runtimeAccountConfig = getRuntimeAccountConfig(ctx.paymentProviderAccount());
                    var runtimePaymentProviderConfig = getRuntimePaymentProviderConfig(ctx.paymentProvider());
                    var context = new ManageTransaction.Context(
                            runtimeAccountConfig,
                            runtimePaymentProviderConfig,
                            // Your own transaction identifier.
                            manageTransactionContext.transaction().getParentId()
                    );
                    return manageTransaction.manageTransaction(context);
                });
    }

    private static RuntimePaymentProviderConfig getRuntimePaymentProviderConfig(TypedPaymentProvider paymentProvider) {
        var configuration = paymentProvider.getData().getJsonObject("configuration", new JsonObject());
        return configuration.mapTo(RuntimePaymentProviderConfig.class);
    }

    private static RuntimeAccountConfig getRuntimeAccountConfig(TypedPaymentProviderAccount paymentProviderAccount) {
        var configuration = paymentProviderAccount.getData().getJsonObject("configuration", new JsonObject());
        return JsonObject.mapFrom(configuration).mapTo(RuntimeAccountConfig.class);
    }

    @Override
    public PaymentProviderServiceConfig config() {
        return adminPaymentProcessingService.config();
    }

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {
        return Optional.empty();
    }

    @Override
    public BaseAdminPaymentProcessingService admin() {
        return adminPaymentProcessingService;
    }

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {
        return true;
    }
}
