curl --location 'https://epro.empcorp.com/api/payment/direct' \
--header 'EPRO-API-KEY: ZDQzYzkyNWUzZmU1Zjg2NDAyNTExMWI5YjFjM2Y2YzkxZDkzZjc2NjMzNjA5ZGI5MzU5MGU0MjJmZjk5MDUxMA==' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'Amount=1234' \
--data-urlencode 'Uid=Abc123' \
--data-urlencode 'Tid=ksksklslsal' \
--data-urlencode 'Email=john@doe.com' \
--data-urlencode 'Firstname=John' \
--data-urlencode 'Lastname=Doe' \
--data-urlencode 'CardNumber=4000000000001091' \
--data-urlencode 'CardMonth=09' \
--data-urlencode 'CardYear=2025' \
--data-urlencode 'CardCVV=123' \
--data-urlencode 'CardOwner=John Doe' \
--data-urlencode 'ClientIp=77.77.216.188' \
--data-urlencode 'Description=test trx' \
--data-urlencode 'Address=laticka 14' \
--data-urlencode 'ZipCode=75001' \
--data-urlencode 'City=Paris' \
--data-urlencode 'Country=FRA' \
--data-urlencode 'Phone=+1 123-456-7890' \
--data-urlencode 'BirthDate=1991-01-31' \
--data-urlencode 'BirthPlace=Paris' \
--data-urlencode 'OriginalAmount=' \
--data-urlencode 'OriginalCurrency=' \
--data-urlencode 'ConvertCurrency=no' \
--data-urlencode 'ReturnUrl=https://webhook.site/5c34a2b0-3eff-4f7c-9d0b-7bd2407d5a99' \
--data-urlencode '3DS=no' \
--data-urlencode 'PreAuth=no'

# Sample form url encoded return url redirect
#OperationType=payment&Status=captured&Tid=222122&Reference=8124-1728517121-2738-3658982&Date=2024-10-10+01%3A38%3A41&Amount=12.34&UserId=Abc123&Message=Payment+was+successful&3DSecure=yes&OneClick=no

#Testni voucher 6987950089358325