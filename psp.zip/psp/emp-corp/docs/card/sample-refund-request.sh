curl --location 'https://epro.empcorp.com/api/refund' \
--header 'EPRO-API-KEY: <token>' \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'Tid=ksksklslsal'

# Sample form url encoded return url redirect
#OperationType=payment&Status=captured&Tid=222122&Reference=8124-1728517121-2738-3658982&Date=2024-10-10+01%3A38%3A41&Amount=12.34&UserId=Abc123&Message=Payment+was+successful&3DSecure=yes&OneClick=no

#Testni voucher 6987950089358325