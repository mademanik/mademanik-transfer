package com.morefin.pg.paytently.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.gatewaygrpcservices.payments.paymentgateway.services.paymentprovider.PaymentProviderRepository;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.keymanagementspi.keys.KeyManagementService;
import com.morefin.common.paymentgateway.services.transaction.TransactionRepository;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProviderAccount;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.paytently.client.PaytentlyApiClient;
import com.morefin.pg.paytently.model.*;
import com.morefin.pg.paytently.util.PaytentlyObjectTransformer;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.RestClientBuilder;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import javax.naming.AuthenticationException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
public class TransactionManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    @RestClient
    PaytentlyApiClient apiClient;

    @Inject
    KeyManagementService keyManagementService;

    @Inject
    PaytentlyObjectTransformer objectTransformer;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    TransactionRepository transactionRepository;

    @Inject
    PaymentProviderRepository paymentProviderRepository;

    @Inject
    DtoMapperService mapperService;

    @Inject
    Utils pspUtils;

    private final BiFunction<PaytentlyTransactionContext, Throwable, PaytentlyTransactionContext> defaultExceptionHandler = (context, failure) -> {
        System.out.printf("Error execute Paytently: %s", failure.getMessage());
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, failure));
        return context;
    };

    private final BiFunction<PaytentlyRefundContext, Throwable, PaytentlyRefundContext> defaultRefundHandler = (context, failure) -> {
        System.out.printf("Error refund Paytently: %s", failure.getMessage());
        context.setErrorDescription(objectTransformer.buildRefundErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> executeHPPRequest(TransactionTypeContext authContext) {
        PaytentlyTransactionContext ctx = new PaytentlyTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, decrypted -> hydratePaymentContext(ctx, authContext))
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::authenticate)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::registerPaymentRequest)
                .finalize(objectTransformer::convertToCardResponse);
    }

    public Uni<ExecuteTransactionResponse> executePaymentRequest(CardAuthorizeContext authContext) {
        PaytentlyTransactionContext ctx = new PaytentlyTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_DECRYPT_CARD_DETAILS, this::decryptCardDetails)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, decrypted -> hydratePaymentContext(ctx, authContext, decrypted))
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::authenticate)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::registerPaymentRequest)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private Uni<PaytentlyTransactionContext> hydratePaymentContext(PaytentlyTransactionContext context, CardAuthorizeContext authContext, List<byte[]> decryptedCardData) {
        var transaction = authContext.authorizeContext().getTransaction();
        var paymentProviderAccount = authContext.authorizeContext().getPaymentProviderAccount();
        var browserInfo = objectMapper.convertValue(transaction.getTransactionData().getOptions().get("browser_info"), BrowserInfo.class);
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx -> {
                    RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(paymentProviderAccount, RuntimeAccountConfig.class);
                    context.setTransactionContext(authContext.authorizeContext());
                    context.setRuntimeAccountConfig(rac);

                    context.setCardNumber(new String(decryptedCardData.get(0), StandardCharsets.UTF_8));
                    context.setCvc(new String(decryptedCardData.get(1), StandardCharsets.UTF_8));
                    context.setExpirationMonth(authContext.card().expirationMonth());
                    context.setExpirationYear(authContext.card().expirationYear());

                    context.setCustomerData(objectTransformer.groupCustomerData(transaction));
                    context.setAmount(transaction.getAmount());
                    context.setCurrency(transaction.getCurrency());
                    context.setTransactionType(transaction.getTransactionType());
                    context.setStatementDescriptor(authContext.authorizeContext().getMerchant().getName());
                    context.setDescription(nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()));

                    context.setReference(transaction.getId());
                    context.setUserIp(transaction.getUserIp());
                    context.setBrowserInfo(browserInfo);
                    context.setSuccessUrl(transaction.getTransactionData().getSuccessUrl());
                    context.setCancelUrl(transaction.getTransactionData().getCancelUrl());
                    context.setFailureUrl(transaction.getTransactionData().getErrorUrl());

                    return context;
                })
                .safeFlatMap(PHASE_GRPC_INVOKE, ctx -> pspUtils.convertIso2toIso3CountryCode(ctx.getCustomerData().getAddress().getCountry(), ctx.getTransactionContext().getTenantConfig().id()))
                .safeMap(PHASE_HYDRATE_CONTEXT, countryIso3 -> {
                    context.setCountryIso3(countryIso3);
                    return context;
                })
                .endSubPhase();
    }

    private Uni<PaytentlyTransactionContext> hydratePaymentContext(PaytentlyTransactionContext context, TransactionTypeContext authContext) {
        var transaction = authContext.getTransaction();
        var paymentProviderAccount = authContext.getPaymentProviderAccount();
        var browserInfo = objectMapper.convertValue(transaction.getTransactionData().getOptions().get("browser_info"), BrowserInfo.class);
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx -> {
                    RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(paymentProviderAccount, RuntimeAccountConfig.class);
                    context.setTransactionContext(authContext);
                    context.setRuntimeAccountConfig(rac);
                    context.setIsHpp(true);

                    context.setCustomerData(objectTransformer.groupCustomerData(transaction));
                    context.setAmount(transaction.getAmount());
                    context.setCurrency(transaction.getCurrency());
                    context.setTransactionType(transaction.getTransactionType());
                    context.setStatementDescriptor(authContext.getMerchant().getName());
                    context.setDescription(nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()));

                    context.setReference(transaction.getId());
                    context.setUserIp(transaction.getUserIp());
                    context.setBrowserInfo(browserInfo);
                    context.setSuccessUrl(transaction.getTransactionData().getSuccessUrl());
                    context.setCancelUrl(transaction.getTransactionData().getCancelUrl());
                    context.setFailureUrl(transaction.getTransactionData().getErrorUrl());

                    return context;
                })
                .safeFlatMap(PHASE_GRPC_INVOKE, ctx -> pspUtils.convertIso2toIso3CountryCode(ctx.getCustomerData().getAddress().getCountry(), ctx.getTransactionContext().getTenantConfig().id()))
                .safeMap(PHASE_HYDRATE_CONTEXT, countryIso3 -> {
                    context.setCountryIso3(countryIso3);
                    return context;
                }).endSubPhase();
    }

    private Uni<List<byte[]>> decryptCardDetails(CardAuthorizeContext x) {
        return keyManagementService.decrypt(
                x.authorizeContext().getMerchant().getPrivateKey(),
                x.card().encryptedCardNumber(),
                x.card().encryptedCvv()
        );
    }

    private Uni<PaytentlyTransactionContext> authenticate(PaytentlyTransactionContext context) {
        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();

        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, ctx -> authenticate(rac))
                .safeMap(PHASE_READ_PAYLOAD, accessToken -> {
                    context.setAccessToken(accessToken);
                    return accessToken;
                })
                .endSubPhase();
    }

    private Uni<PaytentlyRefundContext> authenticate(PaytentlyRefundContext context) {
        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();

        return SafeUni.from(context, defaultRefundHandler, context)
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, ctx -> authenticate(rac))
                .safeMap(PHASE_READ_PAYLOAD, accessToken -> {
                    context.setAccessToken(accessToken);
                    return accessToken;
                })
                .endSubPhase();
    }

    private Uni<String> authenticate(RuntimeAccountConfig rac) {
        return Uni.createFrom().item(rac)
                .flatMap(rac1 -> apiClient.authenticate(rac1.clientId(), rac1.clientSecret()))
                .map(this::parseAuthenticationResponse);
    }

    private Uni<PaytentlyTransactionContext> registerPaymentRequest(PaytentlyTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_BUILD_PAYLOAD, objectTransformer::mapToRegisterPaymentRequest)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, req -> apiClient.registerPaymentRequest(req, addBearer(context.getAccessToken())))
                .safeMap(PHASE_READ_PAYLOAD, resp -> parseRegisterPaymentResponse(context, resp))
                .endSubPhase();
    }


    private String addBearer(String token) {
        return "Bearer " + token;
    }

    @SneakyThrows
    private PaytentlyTransactionContext parseRegisterPaymentResponse(PaytentlyTransactionContext context, Response response) {
        context.setPaymentResponseAsString(response.readEntity(String.class));
        context.setPaymentResponse(mapperService.mapAndValidate(
                context.getPaymentResponseAsString(),
                PaymentResponse.class
        ));

        return context;
    }

    @SneakyThrows
    private String parseAuthenticationResponse(Response response) {
        String responseAsString = response.readEntity(String.class);
        AuthenticationResponse authenticationResponse = mapperService.mapAndValidate(
                responseAsString,
                AuthenticationResponse.class
        );
        if ( authenticationResponse.getAccessToken() == null || authenticationResponse.getAccessToken().equals("") ) {
            throw new AuthenticationException("Authentication failed");
        }

        return authenticationResponse.getAccessToken();
    }

    public Uni<ExecuteTransactionResponse> requestRefund(ManageTransactionContext manageContext) {
        PaytentlyRefundContext ctx = new PaytentlyRefundContext();
        return SafeUni.from(ctx, defaultRefundHandler, ctx)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateRefundContext(ctx1, manageContext))
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::authenticate)
                .safeFlatMap(PHASE_REQUEST_REFUND, this::requestPaymentRefund)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private Uni<PaytentlyRefundContext> requestPaymentRefund(PaytentlyRefundContext context) {
        return SafeUni.from(context, defaultRefundHandler, context)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> apiClient.requestRefund(context.getReferenceNumber(), context.getRefundPaymentRequest(), addBearer(context.getAccessToken())))
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentRefundResponse(context, response))
                .endSubPhase();
    }

    @SneakyThrows
    private PaytentlyRefundContext hydrateRefundContext(PaytentlyRefundContext context, ManageTransactionContext manageContext) {
        var parentTransactionRefNum = manageContext.transactionTypeContext().getParentTransaction().getReferenceNumber();

        RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(manageContext.transactionTypeContext().getPaymentProviderAccount(), RuntimeAccountConfig.class);
        context.setContext(manageContext);
        context.setRuntimeAccountConfig(rac);
        context.setReferenceNumber(parentTransactionRefNum);
        context.setRefundPaymentRequest(objectTransformer.buildPaymentRefundRequest(manageContext));

        return context;
    }

    @SneakyThrows
    private PaytentlyRefundContext parsePaymentRefundResponse(PaytentlyRefundContext ctx, Response response) {
        //preserve payment api invocation response for later usage
        ctx.setRefundResponseAsString(response.readEntity(String.class));
        //make attempt to transform to successful response
        ctx.setRefundPaymentResponse(mapperService.mapAndValidate(ctx.getRefundResponseAsString(), RefundPaymentResponse.class));
        return ctx;
    }
}
