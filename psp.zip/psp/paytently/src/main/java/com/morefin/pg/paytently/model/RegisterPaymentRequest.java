package com.morefin.pg.paytently.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;

@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RegisterPaymentRequest {
    @JsonProperty("reference")
    private String reference;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("customer")
    private Customer customer;

    @JsonProperty("method")
    private Method method;

    @JsonProperty("billing_address")
    private BillingAddress billingAddress;

    @JsonProperty("device_ip_address")
    private String deviceIpAddress;

    @JsonProperty("urls")
    private Urls urls;

    @JsonProperty("route")
    private Route route;

    @JsonProperty("metadata")
    private Map<String, String> metadata;

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Customer {

        @JsonProperty("id")
        private String id;

        @JsonProperty("first_name")
        private String firstName;

        @JsonProperty("last_name")
        private String lastName;

        @JsonProperty("birth_date")
        private String birthDate;

        @JsonProperty("nationality")
        private String nationality;

        @JsonProperty("contact")
        private Contact contact;

        @SuperBuilder
        @AllArgsConstructor
        @NoArgsConstructor
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Contact {
            @JsonProperty("phone")
            private Phone phone;

            @JsonProperty("email")
            private String email;

            @SuperBuilder
            @AllArgsConstructor
            @NoArgsConstructor
            @Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class Phone {
                @JsonProperty("country_code")
                private String countryCode;

                @JsonProperty("number")
                private String number;
            }
        }
    }

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Method {
        @JsonProperty("type")
        private String type;

        @JsonProperty("card")
        private Card card;

        @SuperBuilder
        @AllArgsConstructor
        @NoArgsConstructor
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Card {
            @JsonProperty("number")
            private String number;

            @JsonProperty("cvv")
            private String cvv;

            @JsonProperty("expiry_year")
            private String expiryYear;

            @JsonProperty("expiry_month")
            private String expiryMonth;

            @JsonProperty("name_on_card")
            private String nameOnCard;
        }
    }

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class BillingAddress {
        @JsonProperty("line_one")
        private String lineOne;

        @JsonProperty("city")
        private String city;

        @JsonProperty("postal_code")
        private String postalCode;

        @JsonProperty("country")
        private String country;
    }

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Urls {
        @JsonProperty("authorize")
        private Authorize authorize;

        @JsonProperty("webhook")
        private String webhook;

        @JsonProperty("merchant_website")
        private String merchantWebsite;

        @SuperBuilder
        @AllArgsConstructor
        @NoArgsConstructor
        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Authorize {
            @JsonProperty("success")
            private String success;

            @JsonProperty("failure")
            private String failure;
        }
    }

    @SuperBuilder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Route {
        @JsonProperty("id")
        private String id;
    }
}
