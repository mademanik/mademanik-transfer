package com.morefin.pg.paytently.model;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.paytently.common.RuntimeAccountConfig;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PaytentlyRefundContext extends BaseTransactionContext<String> {

    ManageTransactionContext context;
    RuntimeAccountConfig runtimeAccountConfig;

    RefundPaymentRequest refundPaymentRequest;
    RefundPaymentResponse refundPaymentResponse;
    String refundResponseAsString;

    String referenceNumber;
    AuthenticationResponse authenticationResponse;
    String authenticationResponseAsString;
    String accessToken;

    public PaytentlyRefundContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}