package com.morefin.pg.paytently.model;

import com.morefin.pg.paytently.common.RuntimeAccountConfig;

public record AuthContext(
        RuntimeAccountConfig runtimeAccountConfig,
        Customer customerData,
        String transactionType,
        String paymentMethodBrand,
        Long amount,
        String currency,
        String cardNumber,
        String cvc,
        Integer expirationMonth,
        Integer expirationYear,
        String statementDescriptor,
        String description,
        String reference,
        String userIp,
        String successUrl,
        String cancelUrl,
        String failureUrl
) {
}