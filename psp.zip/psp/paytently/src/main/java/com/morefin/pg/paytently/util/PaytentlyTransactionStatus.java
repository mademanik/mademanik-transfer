package com.morefin.pg.paytently.util;

import lombok.Getter;

@Getter
public enum PaytentlyTransactionStatus {
    PENDING("pending"),
    FLAGGED_FOR_REVIEW("flagged_for_review"),
    AUTHORIZED("authorized"),
    CAPTURED("captured"),
    COMPLETED("completed"),
    ABANDONED("abandoned"),
    FAILED("failed"),
    DECLINED("declined"),
    VOIDED("voided");

    private final String value;

    PaytentlyTransactionStatus(String value) {
        this.value = value;
    }

    public static PaytentlyTransactionStatus fromValue(String value) {
        PaytentlyTransactionStatus status = null;
        for ( PaytentlyTransactionStatus CONSTANT : PaytentlyTransactionStatus.values() ) {
            if ( CONSTANT.getValue().equalsIgnoreCase(value) ) {
                status = CONSTANT;
                break;
            }
        }
        if ( status == null ) {
            throw new IllegalArgumentException(String.format("PaytentlyTransactionStatus is not found: %s", value));
        }
        return status;
    }

}