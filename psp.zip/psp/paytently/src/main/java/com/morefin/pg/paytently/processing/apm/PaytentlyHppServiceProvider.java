package com.morefin.pg.paytently.processing.apm;
import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.paytently.admin.apm.PaytentlyAPMTypeModule;
import io.quarkus.arc.Arc;

public class PaytentlyHppServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return PaytentlyAPMTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return PaytentlyAPMTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return PaytentlyAPMTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(PaytentlyAPMProcessingService.class)) {
            return instance.get();
        }
    }
}
