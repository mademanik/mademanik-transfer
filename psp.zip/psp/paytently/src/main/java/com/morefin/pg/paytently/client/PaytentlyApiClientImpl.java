package com.morefin.pg.paytently.client;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.eclipse.microprofile.rest.client.RestClientBuilder;

@ApplicationScoped
public class PaytentlyApiClientImpl {

    @Produces
    PaytentlyApiClient apiClient() {
        return RestClientBuilder.newBuilder()
                .build(PaytentlyApiClient.class);
    }
}
