package com.morefin.pg.paytently.util;

import java.util.Arrays;

public class SupportedWebhookEvents {
    private static String[] supportedEvents = {
            "payment_captured",
            "payment_declined",
            "payment_failed",
            "payment_abandoned",
            "refund_completed",
            "refund_declined",
            "refund_failed",
    };

    public static boolean isEventSupported(String event) {
        return Arrays.stream(supportedEvents).anyMatch(x -> x.equals(event));
    }
}
