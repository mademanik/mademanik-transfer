package com.morefin.pg.paytently.processing.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import com.morefin.common.grpc.payment_provider.PaymentProviderType;
import com.morefin.pg.paytently.admin.card.PaytentlyCardProcessingModule;
import io.quarkus.arc.Arc;

import java.util.List;

public class PaytentlyCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {


    @Override
    public String name() {
        return PaytentlyCardProcessingModule.MODULE_ID;
    }

    @Override
    public String id() {
        return PaytentlyCardProcessingModule.MODULE_ID;
    }

    @Override
    public String type() {
        return PaymentProviderType.CARD.name();
    }

    @Override
    public EcommerceCardPaymentProcessingService create() {
        try (var instance = Arc.container().instance(PaytentlyCardPaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return List.of(
                "card",
                "saved_card"
        );
    }
}
