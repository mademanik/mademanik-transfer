package com.morefin.pg.paytently.client;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.paytently.common.FinalizeManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.jboss.resteasy.reactive.RestPath;

@Path("/psp/paytently")
@Produces(MediaType.APPLICATION_JSON)
public class PaytentlyCallbackService {

    @Inject
    FinalizeManager finalizeManager;

    @Inject
    Tenant tenant;

    @Path("/return/{transactionId}")
    @GET
    public Uni<Response> returnUrl(@RestPath("transactionId") String transactionId) {
        return finalizeManager.finalizeReturnTransaction(transactionId, tenant.id());
    }

    @Path("/callback")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Uni<Response> callbackUrl(String callbackRequest) {
        return finalizeManager.finalizeWebhookTransaction(callbackRequest, tenant.id());
    }
}