package com.morefin.pg.paytently.model;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.paytently.common.RuntimeAccountConfig;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PaytentlyTransactionContext extends BaseTransactionContext<String> {

    TransactionTypeContext transactionContext;
    RuntimeAccountConfig runtimeAccountConfig;
    Boolean isHpp = false;

    Customer customerData;
    String countryIso3;
    String transactionType;
    Long amount;
    String currency;
    String cardNumber;
    String cvc;
    Integer expirationMonth;
    Integer expirationYear;
    String statementDescriptor;
    String description;
    String reference;
    String userIp;
    String successUrl;
    String cancelUrl;
    String failureUrl;

    BrowserInfo browserInfo;

    String accessToken;

    PaymentResponse paymentResponse;
    String paymentResponseAsString;

    public PaytentlyTransactionContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}