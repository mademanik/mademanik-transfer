package com.morefin.pg.paytently.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Set;

public record RuntimeAccountConfig(
        @JsonProperty("client_id")
        String clientId,
        @JsonProperty("client_secret")
        String clientSecret,
        @JsonProperty("route_id")
        String routeId,
        @JsonProperty("apm_payment_method")
        String apmPaymentMethod
) {
}
