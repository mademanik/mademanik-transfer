package com.morefin.pg.paytently.util;

public class Constants {
    public static final String PAYMENT_METHOD_CARD = "card";
}
