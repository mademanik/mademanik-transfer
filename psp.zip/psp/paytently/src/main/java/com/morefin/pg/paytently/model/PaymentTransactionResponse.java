package com.morefin.pg.paytently.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentTransactionResponse implements Serializable {
    @JsonProperty("id")
    private String id;

    @JsonProperty("status")
    private String status;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("amount")
    private Integer amount;

    @JsonProperty("amount_details")
    private AmountDetails amountDetails;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("customer")
    private Customer customer;

    @JsonProperty("billing_address")
    private BillingAddress billingAddress;

    @JsonProperty("device_ip_address")
    private String deviceIpAddress;

    @JsonProperty("application")
    private Application application;

    @JsonProperty("method")
    private Method method;

    @JsonProperty("urls")
    private Urls urls;

    @JsonProperty("metadata")
    private Map<String, String> metadata;

    @JsonProperty("requested_on")
    private String requestedOn;

    @JsonProperty("completed_on")
    private String completedOn;

    @JsonProperty("route")
    private Route route;

    @JsonProperty("_links")
    private Links links;

    // ===================== NESTED CLASSES =====================
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class AmountDetails {
        @JsonProperty("total_authorized")
        private Integer totalAuthorized;

        @JsonProperty("total_captured")
        private Integer totalCaptured;

        @JsonProperty("total_refunded")
        private Integer totalRefunded;

        @JsonProperty("available_to_capture")
        private Integer availableToCapture;

        @JsonProperty("available_to_refund")
        private Integer availableToRefund;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Customer {
        @JsonProperty("id")
        private String id;

        @JsonProperty("first_name")
        private String firstName;

        @JsonProperty("last_name")
        private String lastName;

        @JsonProperty("birth_date")
        private String birthDate;

        @JsonProperty("nationality")
        private String nationality;

        @JsonProperty("contact")
        private Contact contact;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Contact {
        @JsonProperty("phone")
        private Phone phone;

        @JsonProperty("email")
        private String email;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Phone {
        @JsonProperty("country_code")
        private String countryCode;

        @JsonProperty("number")
        private String number;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class BillingAddress {
        @JsonProperty("line_one")
        private String lineOne;

        @JsonProperty("postal_code")
        private String postalCode;

        @JsonProperty("city")
        private String city;

        @JsonProperty("country")
        private String country;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Application {
        @JsonProperty("id")
        private String id;

        @JsonProperty("entity_id")
        private String entityId;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Method {
        @JsonProperty("type")
        private String type;

        @JsonProperty("card")
        private Card card;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Card {
        @JsonProperty("number")
        private String number;

        @JsonProperty("scheme")
        private String scheme;

        @JsonProperty("segment")
        private String segment;

        @JsonProperty("type")
        private String type;

        @JsonProperty("issuer")
        private Issuer issuer;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Issuer {
        @JsonProperty("name")
        private String name;

        @JsonProperty("country")
        private String country;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Urls {
        @JsonProperty("authorize")
        private Authorize authorize;

        @JsonProperty("webhook")
        private String webhook;

        @JsonProperty("merchant_website")
        private String merchantWebsite;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Authorize {
        @JsonProperty("success")
        private String success;

        @JsonProperty("failure")
        private String failure;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Route {
        @JsonProperty("id")
        private String id;

        @JsonProperty("channel")
        private Channel channel;

        @JsonProperty("external_transaction_id")
        private String externalTransactionId;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Channel {
        @JsonProperty("id")
        private String id;

        @JsonProperty("name")
        private String name;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Links {
        @JsonProperty("self")
        private Link self;

        @JsonProperty("refund")
        private Link refund;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Link {
        @JsonProperty("href")
        private String href;

        @JsonProperty("method")
        private String method;
    }
}
