package com.morefin.pg.paytently.model;

import com.morefin.common.grpc.transaction.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionEntity;
import com.morefin.pg.safeuni.BaseTransactionContext;
import com.morefin.pg.paytently.common.RuntimeAccountConfig;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PaytentlyCallbackContext extends BaseTransactionContext<String> {

    RuntimeAccountConfig runtimeAccountConfig;

    Boolean isWebhook = false;
    String tenantId;
    String referenceNumber;
    String transactionId;
    String status;
    com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse.Status transactionStatus;
    WebhookRequest webhookRequest;

    String callbackRequestAsString;

    TypedTransactionEntity transactionEntity;
    TransactionGrpc transactionGrpc;

    FinalizeTransactionRequest finalizeRequest;
    ExecuteTransactionResponse finalizeResponse;

    String accessToken;

    PaymentTransactionResponse paymentTransactionResponse;
    String paymentTransactionResponseAsString;

    public PaytentlyCallbackContext() {
        super("INITIAL_PAYMENT_PHASE");
    }


}