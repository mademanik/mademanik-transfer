package com.morefin.pg.paytently.client;

import com.morefin.pg.paytently.model.RefundPaymentRequest;
import com.morefin.pg.paytently.model.RegisterPaymentRequest;
import io.quarkus.rest.client.reactive.*;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "paytently")
@Produces(MediaType.APPLICATION_JSON)
public interface PaytentlyApiClient {

    @POST
    @Path("/auth/token")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @ClientFormParams({
            @ClientFormParam(name = "grant_type", value = "client_credentials"),
            @ClientFormParam(name = "audience", value = "${quarkus.rest-client.paytently.url}"),
    })
    Uni<Response> authenticate(@FormParam("client_id") String clientId, @FormParam("client_secret") String clientSecret);

    @POST
    @Path("/payments")
    Uni<Response> registerPaymentRequest(RegisterPaymentRequest requestPayload, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @POST
    @Path("/payments/{id}/refunds")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> requestRefund(@PathParam("id") String id, RefundPaymentRequest requestPayload, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @GET
    @Path("/payments/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    Uni<Response> getPayment(@PathParam("id") String id, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @ClientExceptionMapper
    static RuntimeException toException(Response response) {
        String responseAsString = response.readEntity(String.class);
        return new RuntimeException(response.getStatusInfo().getReasonPhrase() + "; body: " + responseAsString);
    }
}