package com.morefin.pg.paytently.util;

import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;

public class TransactionStatusMapper {
    public static ExecuteTransactionResponse.Status parseTransactionStatus(PaytentlyTransactionStatus transactionStatus) {
        return switch (transactionStatus) {
            case CAPTURED, COMPLETED -> ExecuteTransactionResponse.Status.APPROVED;
            case PENDING, ABANDONED, FLAGGED_FOR_REVIEW -> ExecuteTransactionResponse.Status.PENDING;
            case DECLINED, FAILED -> ExecuteTransactionResponse.Status.DECLINED;
            default -> ExecuteTransactionResponse.Status.ERROR;
        };
    }
}