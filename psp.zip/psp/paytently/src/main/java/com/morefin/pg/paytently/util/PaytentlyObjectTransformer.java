package com.morefin.pg.paytently.util;

import com.google.i18n.phonenumbers.Phonenumber;
import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.paytently.model.*;
import com.morefin.pg.utils.Utils;
import io.quarkus.logging.Log;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.Response;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class PaytentlyObjectTransformer {

    public static final String DEFAULT_STATE_NA = "NA";

    public Customer groupCustomerData(ImmutableTypedTransactionEntity transaction) {
        return Customer.builder().firstName(transaction.getCustomerFirstName())
                .lastName(transaction.getCustomerLastName())
                .phone(transaction.getCustomerPhoneNumber())
                .email(transaction.getCustomerEmail())
                .dateOfBirth("1991-12-12") // TODO use real date of birth
                .category("Gaming")
                .address(
                        Address.builder().
                                streetAddress(transaction.getCustomerAddress())
                                .city(transaction.getCustomerCity())
                                .country(transaction.getCustomerCountry())
                                .postcode(transaction.getCustomerPostalCode())
                                .state(DEFAULT_STATE_NA)
                                .build())
                .build();
    }

    public RegisterPaymentRequest mapToRegisterPaymentRequest(PaytentlyTransactionContext context) {
        return mapRegisterPaymentRequest(context).build();
    }

    public ExecuteTransactionResponse convertToCardResponse(PaytentlyTransactionContext context) {
        PaymentResponse paymentResponse = context.getPaymentResponse();

        if ( context.getErrorDescription() == null ) {
            PaytentlyTransactionStatus transactionStatus = PaytentlyTransactionStatus.fromValue(paymentResponse.getStatus());
            ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

            switch (status) {
                case APPROVED -> {
                    return buildDirectApprovedTransactionResponse(paymentResponse.getId(), context.getPaymentResponseAsString());
                }
                case PENDING -> {
                    if ( paymentResponse.getStatus().equals(PaytentlyTransactionStatus.PENDING.getValue()) ) {
                        return buildPendingRedirectTransactionResponse(
                                paymentResponse.getId(),
                                paymentResponse,
                                context.getPaymentResponseAsString()
                        );
                    }
                    return buildPendingTransactionResponse(paymentResponse.getId(), context.getPaymentResponseAsString());
                }
                default -> throw new IllegalStateException("Unexpected value: " + status);
            }
        }

        String message = context.getErrorDescription() != null ? context.getErrorDescription().getResponseMessage() : "";
        String id = paymentResponse != null ? paymentResponse.getId() : "";
        return buildDeclinedTransactionResponse(id, message + " " + context.getPaymentResponseAsString());
    }

    public ExecuteTransactionResponse convertToCardResponse(PaytentlyRefundContext context) {
        RefundPaymentResponse refundPaymentResponse = context.getRefundPaymentResponse();

        if ( context.getErrorDescription() == null ) {
            PaytentlyTransactionStatus transactionStatus = PaytentlyTransactionStatus.fromValue(refundPaymentResponse.getStatus());
            ExecuteTransactionResponse.Status status = TransactionStatusMapper.parseTransactionStatus(transactionStatus);

            switch (status) {
                case APPROVED -> {
                    return buildDirectApprovedTransactionResponse(refundPaymentResponse.getId(), context.getRefundResponseAsString());
                }
                case PENDING -> {
                    return buildPendingTransactionResponse(refundPaymentResponse.getId(), context.getRefundResponseAsString());
                }
            }
        }

        String message = context.getErrorDescription() != null ? context.getErrorDescription().getResponseMessage() : "";
        String id = refundPaymentResponse != null ? refundPaymentResponse.getId() : "";
        return buildDeclinedTransactionResponse(id, message + " " + context.getRefundResponseAsString());
    }

    private RegisterPaymentRequest.RegisterPaymentRequestBuilder mapRegisterPaymentRequest(PaytentlyTransactionContext context) {
        BigDecimal number = BigDecimal.valueOf(context.getAmount());
        String baseUrl = context.getTransactionContext().getTenantConfig().url();
//        String baseUrl = "https://webhook.site/b36553b0-aa88-4f82-beb2-b16a83a928e6";
//        String baseUrl = "https://yellow-hands-own.loca.lt";
        String webhookUrl = baseUrl + "/psp/paytently/callback";
        String returnUrl = baseUrl + "/psp/paytently/return/" + context.getTransactionContext().getTransaction().getId();

        RegisterPaymentRequest.Urls urls = RegisterPaymentRequest.Urls.builder()
                .merchantWebsite(context.getTransactionContext().getTenantConfig().url())
                .webhook(webhookUrl)
                .authorize(
                        RegisterPaymentRequest.Urls.Authorize.builder()
                                .success(returnUrl)
                                .failure(returnUrl)
                                .build()
                )
                .build();

        Address address = context.getCustomerData().getAddress();
        Phonenumber.PhoneNumber phoneNumber = Utils.getPhoneNumber(context.getCustomerData().getPhone());
        RegisterPaymentRequest.Customer customer = RegisterPaymentRequest.Customer.builder()
                .id(context.getTransactionContext().getTransaction().getId())
                .firstName(context.getCustomerData().getFirstName())
                .lastName(context.getCustomerData().getLastName())
                .nationality(context.getCountryIso3())
                .birthDate(context.getCustomerData().getDateOfBirth())
                .contact(RegisterPaymentRequest.Customer.Contact.builder()
                        .phone(
                                RegisterPaymentRequest.Customer.Contact.Phone.builder()
                                        .countryCode(Integer.toString(phoneNumber.getCountryCode()))
                                        .number("0" + String.valueOf(phoneNumber.getNationalNumber()))
                                        .build()
                        )
                        .email(context.getCustomerData().getEmail())
                        .build()
                )
                .build();

        RegisterPaymentRequest.Method method;
        if ( context.getIsHpp() ) {
            method = RegisterPaymentRequest.Method.builder()
                    .type(context.getRuntimeAccountConfig().apmPaymentMethod())
                    .build();
        } else {
            method = RegisterPaymentRequest.Method.builder()
                    .type(Constants.PAYMENT_METHOD_CARD)
                    .card(RegisterPaymentRequest.Method.Card.builder()
                            .nameOnCard(context.getCustomerData().getFirstName() + " " + context.getCustomerData().getLastName())
                            .number(context.getCardNumber())
                            .expiryMonth(Utils.zeroPadMonth(context.getExpirationMonth()))
                            .expiryYear(Utils.trimExpirationYear(context.getExpirationYear()).toString())
                            .cvv(context.getCvc())
                            .build())
                    .build();
        }

        RegisterPaymentRequest.Route route = RegisterPaymentRequest.Route.builder()
                .id(context.getRuntimeAccountConfig().routeId())
                .build();

        RegisterPaymentRequest.BillingAddress billingAddress = RegisterPaymentRequest.BillingAddress.builder()
                .lineOne(address.getStreetAddress())
                .postalCode(address.getPostcode())
                .city(address.getCity())
                .country(context.getCountryIso3())
                .build();

        return RegisterPaymentRequest.builder()
                .reference(context.getTransactionContext().getTransaction().getId())
                .amount(number)
                .currency(context.getCurrency())
                .customer(customer)
                .deviceIpAddress(context.getUserIp())
                .urls(urls)
                .method(method)
                .billingAddress(billingAddress)
                .route(route);
    }

    private DirectPaymentRequest.DirectPaymentRequestBuilder mapDirectPaymentRequest(PaytentlyTransactionContext context) {
        BrowserInfo browserInfo = context.getBrowserInfo();
        Customer customer = context.getCustomerData();
        return DirectPaymentRequest.builder()
                .cardholderName(customer.getFirstName() + " " + customer.getLastName())
                .cardNumber(context.getCardNumber())
                .expires(Utils.zeroPadMonth(context.getExpirationMonth()) + "/" + Utils.trimExpirationYear(context.getExpirationYear()))
                .cvc(context.getCvc())
                .rememberCard("off")
                .remoteIp(context.getUserIp())
                .userAgent(browserInfo.getUserAgent())
                .acceptHeader(browserInfo.getAcceptHeader())
                .language(browserInfo.getLanguage())
                .javaEnabled(browserInfo.isJavaEnabled())
                .javascriptEnabled(true)
                .colorDepth(browserInfo.getColorDepth())
                .utcOffset(browserInfo.getTimeZoneOffset())
                .screenWidth(browserInfo.getScreenWidth())
                .screenHeight(browserInfo.getScreenHeight());
    }

    private ExecuteTransactionResponse buildDirectApprovedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_APPROVED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.APPROVED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildPendingRedirectTransactionResponse(String referenceNumber, PaymentResponse paymentResponse, String responseAsString) {
        var builder = ExecuteTransactionResponse.newBuilder();
        var responseBuilder = ExecuteTransactionResponse.Response.newBuilder();
        String method = paymentResponse.getLinks().getAuthorize().getMethod();
        String url = paymentResponse.getLinks().getAuthorize().getHref();
        builder.setResponse(
                new GrpcBuilder<>(responseBuilder)
                        .set(ProcessingCode.TRX_STATUS_PENDING.name(), responseBuilder::setResponseCode)
                        .setAny(ExecuteTransactionResponse.Status.PENDING, responseBuilder::setStatus)
                        .set(referenceNumber, responseBuilder::setReferenceNumber)
                        .set(responseAsString, responseBuilder::setResponseMessage)
                        .set(responseAsString, responseBuilder::setPaymentProviderResponseMessage)
                        .getBuilder()
                        .build()
        );
        if ( method.equals("POST") ) {
            var formBuilder = ExecuteTransactionResponse.FormSubmit.newBuilder();
            Map<String, String> formData = Map.of();
            builder.setFormSubmit(
                    formBuilder
                            .setUrl(url)
                            .putAllData(formData)
                            .build()
            );
        } else if ( method.equals("GET") ) {
            var redirectBuilder = ExecuteTransactionResponse.Redirect.newBuilder();

            builder.setRedirect(
                    new GrpcBuilder<>(redirectBuilder)
                            .set(url, redirectBuilder::setUrl)
                            .getBuilder()
                            .build()
            );
        }
        return builder.build();
    }

    private ExecuteTransactionResponse buildDeclinedTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_DECLINED.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.DECLINED, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(String referenceNumber, String responseAsString) {
        var builder = ExecuteTransactionResponse.Response.newBuilder();

        return ExecuteTransactionResponse.newBuilder()
                .setResponse(
                        new GrpcBuilder<>(builder)
                                .set(ProcessingCode.TRX_STATUS_PENDING.name(), builder::setResponseCode)
                                .setAny(ExecuteTransactionResponse.Status.PENDING, builder::setStatus)
                                .set(referenceNumber, builder::setReferenceNumber)
                                .set(responseAsString, builder::setResponseMessage)
                                .set(responseAsString, builder::setPaymentProviderResponseMessage)
                                .getBuilder()
                                .build()
                )
                .build();
    }


    public ErrorDescription<String> buildErrorDescription(PaytentlyTransactionContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

//        return switch (context.getPhase()) {
//            default:
//                yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
//        };
        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    public ErrorDescription<String> buildRefundErrorDescription(PaytentlyRefundContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

//        return switch (context.getPhase()) {
//            default:
//                yield buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
//        };
        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    private ErrorDescription<String> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<String>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

    public ErrorDescription<?> buildFinalizeErrorDescription(PaytentlyCallbackContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during processing of transaction {0} with message {1} during phase {2} and sub-phase {3} ",
                context.getTransactionId(), failure, context.getPhase(), context.getSubPhase());
        reason = "Bad request";
        return ErrorDescription.<Response.Status>builder()
                .reason(reason)
                .errorResponse(Response.Status.BAD_REQUEST)
                .responseMessage(failure.getMessage())
                .build();
    }

    public PaytentlyCallbackContext buildFinalizeTransactionRequest(PaytentlyCallbackContext context) {
        FinalizeTransactionRequest.Builder builder = FinalizeTransactionRequest.newBuilder();
        builder.setReferenceNumber(context.getReferenceNumber())
                .setId(context.getTransactionId());

        if ( context.getIsWebhook() ) {
            builder.setResponseMessage(context.getCallbackRequestAsString())
                    .setPaymentProviderResponseMessage(context.getCallbackRequestAsString());
        } else {
            builder.setResponseMessage(context.getStatus())
                .setPaymentProviderResponseMessage(context.getStatus());
        }

        switch (context.getTransactionStatus()) {
            case APPROVED -> {
                String code = ProcessingCode.TRX_STATUS_APPROVED.name();
                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.APPROVED);
            }
            case PENDING -> {
                String code = ProcessingCode.TRX_STATUS_PENDING.name();

                builder.setResponseCode(code)
                        .setPaymentProviderResponseCode(code)
                        .setStatus(TransactionStatus.PENDING);
            }
            default -> {
                builder.setStatus(TransactionStatus.DECLINED);
                if ( context.getErrorDescription() == null ) {
                    String code = ProcessingCode.TRX_STATUS_DECLINED.name();
                    builder.setResponseCode(code)
                            .setPaymentProviderResponseCode(code);
                }
            }
        }

        context.setFinalizeRequest(builder.build());

        return context;
    }

    public RefundPaymentRequest buildPaymentRefundRequest(ManageTransactionContext context) {
        return mapRefundPaymentRequest(context).build();
    }

    private RefundPaymentRequest.RefundPaymentRequestBuilder mapRefundPaymentRequest(ManageTransactionContext context) {
        BigDecimal number = BigDecimal.valueOf(context.transaction().getAmount());
        var parentTransactionRefNum = context.transactionTypeContext().getParentTransaction().getReferenceNumber();

        return RefundPaymentRequest.builder()
                .amount(number)
                .reference(parentTransactionRefNum);
    }
}

