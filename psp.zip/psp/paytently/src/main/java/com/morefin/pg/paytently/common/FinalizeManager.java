package com.morefin.pg.paytently.common;

import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.gatewaygrpcservices.payments.paymentgateway.services.paymentprovider.PaymentProviderRepository;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.services.payment_gateway.ext_domain.TypedTransactionData;
import com.morefin.paymentgateway.service.gateway.grpc.processing.services.payments.transaction.resourceactions.TransactionRepository;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.paytently.client.PaytentlyApiClient;
import com.morefin.pg.paytently.model.*;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.paytently.util.PaytentlyObjectTransformer;
import com.morefin.pg.paytently.util.PaytentlyTransactionStatus;
import com.morefin.pg.paytently.util.SupportedWebhookEvents;
import com.morefin.pg.paytently.util.TransactionStatusMapper;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.eclipse.microprofile.rest.client.RestClientBuilder;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import javax.naming.AuthenticationException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;

@ApplicationScoped
public class FinalizeManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    PaytentlyObjectTransformer objectTransformer;

    @Inject
    TransactionRepository transactionRepository;

    @Inject
    PaymentProviderRepository paymentProviderRepository;

    @Inject
    DtoMapperService mapperService;

    @Inject
    @RestClient
    PaytentlyApiClient apiClient;

    BiFunction<PaytentlyCallbackContext, Throwable, PaytentlyCallbackContext> defaultFinalizeExceptionHandler = (context, failure) -> {
        System.out.printf("Error finalize Paytently: %s", failure.getMessage());
        context.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(context, failure));
        return context;
    };

    public Uni<Response> finalizeReturnTransaction(String transactionId, String tenantId) {
        PaytentlyCallbackContext ctx = new PaytentlyCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateCallbackContext(ctx1, transactionId, tenantId))
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::authenticate)
                .safeFlatMap(PHASE_GET_PAYMENT, this::getPayment)
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifyResponse)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinalReturnResponse);
    }

    public Uni<Response> finalizeWebhookTransaction(String callbackRequest, String tenantId) {
        PaytentlyCallbackContext ctx = new PaytentlyCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateWebhookContext(ctx1, callbackRequest, tenantId))
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifyEvent)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinalResponse);
    }

    private Uni<PaytentlyCallbackContext> hydrateWebhookContext(PaytentlyCallbackContext ctx, String callbackRequestAsString, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseWebhookRequest(ctx, callbackRequestAsString, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    private Uni<PaytentlyCallbackContext> hydrateCallbackContext(PaytentlyCallbackContext ctx, String transactionId, String tenantId) {
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> parseCallbackRequest(ctx, transactionId, tenantId))
                .safeFlatMap(PHASE_DB_GET_TRANSACTION_DATA, this::getTransactionData)
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountDataByPpaId)
                .endSubPhase();
    }

    private PaytentlyCallbackContext parseCallbackRequest(PaytentlyCallbackContext ctx, String transactionId, String tenantId) {
        //Additional step to preserve the request payload for future logging
        ctx.setTenantId(tenantId);
        ctx.setTransactionId(transactionId);

        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    @SneakyThrows
    private PaytentlyCallbackContext parseWebhookRequest(PaytentlyCallbackContext ctx, String callbackRequestAsString, String tenantId) {
        //Additional step to preserve the request payload for future logging
        ctx.setIsWebhook(true);
        ctx.setTenantId(tenantId);
        ctx.setCallbackRequestAsString(callbackRequestAsString);
        ctx.setWebhookRequest(mapperService.mapAndValidate(ctx.getCallbackRequestAsString(), WebhookRequest.class));

        String status;
        if ( ctx.getWebhookRequest().getEventType().startsWith("refund") ) {
            WebhookRequest.Refund refund = ctx.getWebhookRequest().getData().getRefund();
            ctx.setReferenceNumber(refund.getId());
            ctx.setTransactionId(refund.getReference());
            status = refund.getStatus();
        } else {
            WebhookRequest.WebhookData data = ctx.getWebhookRequest().getData();
            ctx.setReferenceNumber(data.getId());
            ctx.setTransactionId(data.getReference());
            status = data.getStatus();
        }

        ExecuteTransactionResponse.Status transactionStatus = TransactionStatusMapper.parseTransactionStatus(
                PaytentlyTransactionStatus.fromValue(status)
        );
        ctx.setTransactionStatus(transactionStatus);

        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        return ctx;
    }

    private Uni<PaytentlyCallbackContext> authenticate(PaytentlyCallbackContext context) {
        RuntimeAccountConfig rac = context.getRuntimeAccountConfig();

        return SafeUni.from(context, defaultFinalizeExceptionHandler, context)
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, ctx -> apiClient.authenticate(rac.clientId(), rac.clientSecret()))
                .safeMap(PHASE_VERIFY_CALLBACK, this::parseAuthenticationResponse)
                .safeMap(PHASE_READ_PAYLOAD, accessToken -> {
                    context.setAccessToken(accessToken);
                    return accessToken;
                })
                .endSubPhase();
    }

    private Uni<PaytentlyCallbackContext> getPayment(PaytentlyCallbackContext context) {
        return SafeUni.from(context, defaultFinalizeExceptionHandler, context)
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, ctx -> apiClient.getPayment(context.getTransactionEntity().getReferenceNumber(), "Bearer " + context.getAccessToken()))
                .safeMap(PHASE_READ_PAYLOAD, response -> this.parseGetPaymentResponse(context, response))
                .endSubPhase();
    }

    @SneakyThrows
    private String parseAuthenticationResponse(Response response) {
        String responseAsString = response.readEntity(String.class);
        AuthenticationResponse authenticationResponse = mapperService.mapAndValidate(
                responseAsString,
                AuthenticationResponse.class
        );
        if ( authenticationResponse.getAccessToken() == null || authenticationResponse.getAccessToken().equals("") ) {
            throw new AuthenticationException("Authentication failed");
        }

        return authenticationResponse.getAccessToken();
    }

    @SneakyThrows
    private PaytentlyCallbackContext parseGetPaymentResponse(PaytentlyCallbackContext context, Response response) {
        context.setPaymentTransactionResponseAsString(response.readEntity(String.class));
        context.setPaymentTransactionResponse(
                mapperService.mapAndValidate(
                context.getPaymentTransactionResponseAsString(),
                PaymentTransactionResponse.class
                )
        );
        context.setReferenceNumber(context.getPaymentTransactionResponse().getId());

        return context;
    }

    private Uni<PaytentlyCallbackContext> getTransactionData(PaytentlyCallbackContext ctx) {
        if ( ctx.getTransactionId() != null ) {
            return transactionRepository.findById(ctx.getTransactionId(), ctx.getTenantId())
                    .map(optionalTransaction -> optionalTransaction
                            .map(transaction -> {
                                ctx.setTransactionEntity(transaction);
                                return ctx;
                            })
                            .orElseThrow(() -> new IllegalStateException("Transaction not found")));
        }
        return transactionRepository.withTransaction(connection -> {
            return transactionRepository.findByReferenceNumber(connection, ctx.getTenantId(), ctx.getReferenceNumber())
                    .map(optionalTransaction -> optionalTransaction
                            .map(transaction -> {
                                ctx.setTransactionEntity(transaction);
                                ctx.setTransactionId(transaction.getId());
                                return ctx;
                            })
                            .orElseThrow(() -> new IllegalStateException("Transaction not found")));
        });
    }

    private Uni<PaytentlyCallbackContext> getPaymentProviderAccountDataByPpaId(PaytentlyCallbackContext ctx) {
        return paymentProviderRepository.findAccountBy(ctx.getTenantId(), ctx.getTransactionEntity().getPaymentProviderAccountId())
                .map(optionalAccount -> optionalAccount
                        .map(ppa -> {
                            ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, RuntimeAccountConfig.class));
                            return ctx;
                        })
                        .orElseThrow(() -> new IllegalStateException("PaymentProviderAccount not found")));
    }

    private PaytentlyCallbackContext verifyResponse(PaytentlyCallbackContext ctx) {
        ctx.setStatus(ctx.getPaymentTransactionResponse().getStatus());
        ExecuteTransactionResponse.Status transactionStatus = TransactionStatusMapper.parseTransactionStatus(
                PaytentlyTransactionStatus.fromValue(ctx.getStatus())
        );
        ctx.setTransactionStatus(transactionStatus);

        switch (ctx.getTransactionStatus()) {
            case DECLINED, ERROR -> {
                ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, new Exception("Failed to make payment")));
            }
        }
        return ctx;
    }

    private PaytentlyCallbackContext verifyEvent(PaytentlyCallbackContext ctx) {
        if ( !SupportedWebhookEvents.isEventSupported(ctx.getWebhookRequest().getEventType()) ) {
            throw new BadRequestException("Event is not supported");
        }
        return ctx;
    }

    private Response buildFinalReturnResponse(PaytentlyCallbackContext ctx) {
        TypedTransactionData transactionData = ctx.getTransactionEntity().getTransactionData();
        URI locationUri;
        if ( ctx.getTransactionStatus() != null && transactionData != null ) {
            switch (ctx.getTransactionStatus()) {
                case APPROVED, PENDING -> {
                    PaytentlyTransactionStatus transactionStatus = PaytentlyTransactionStatus.fromValue(ctx.getStatus());
                    if ( transactionStatus.equals(PaytentlyTransactionStatus.ABANDONED) ) {
                        locationUri = URI.create(transactionData.getCancelUrl());
                    } else {
                        locationUri = URI.create(transactionData.getSuccessUrl());
                    }
                    return Response.seeOther(locationUri).build();
                }
                default -> {
                    locationUri = URI.create(transactionData.getErrorUrl());
                    return Response.seeOther(locationUri).build();
                }
            }
        }
        return Response.serverError().entity("Internal server error").build();
    }

    private Response buildFinalResponse(PaytentlyCallbackContext ctx) {
        Response.ResponseBuilder responseBuilder = Response.status(Response.Status.OK);
        if ( ctx.getErrorDescription() != null ) {
            responseBuilder
                    .entity(Map.of("error", ctx.getErrorDescription().getResponseMessage()));
        }
        return responseBuilder.build();
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }

    private Uni<PaytentlyCallbackContext> sendGrpcFinalizeRequest(PaytentlyCallbackContext ctx) {
        if ( ctx.getErrorDescription() != null ) {
            return Uni.createFrom().item(ctx);
        }
        return ctx.getTransactionGrpc().
                finalizeTransaction(ctx.getFinalizeRequest())
                .map(response -> {
                    ctx.setFinalizeResponse(response);
                    return ctx;
                });
    }
}
