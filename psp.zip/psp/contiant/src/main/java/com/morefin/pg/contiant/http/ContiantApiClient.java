package com.morefin.pg.contiant.http;

import com.morefin.pg.contiant.model.ApiRequestDto;
import com.morefin.pg.contiant.model.TokenRequest;
import io.quarkus.rest.client.reactive.ComputedParamContext;
import io.smallrye.mutiny.Uni;
import io.vertx.core.json.JsonObject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;


@Path("/")
@RegisterRestClient(configKey = "contiant")
@Produces(MediaType.APPLICATION_JSON)
public interface ContiantApiClient {

    @POST
    @Path("/token")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    Uni<Response> requestAuthToken(@BeanParam TokenRequest payload);

    @POST
    @Path("/payments")
    Uni<Response> requestHppUrlRedirect(
        @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken,
        ApiRequestDto requestPayload
    );
}