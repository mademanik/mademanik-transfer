package com.morefin.pg.contiant.common;

import com.morefin.common.common.payments.grpc.GrpcBuilder;
import com.morefin.common.common.payments.grpc.GrpcFactory;
import com.morefin.common.grpc.payment.TransactionStatus;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.common.paymentprocessingspi.ProcessingCode;
import com.morefin.pg.common.TransactionStatusMapper;
import com.morefin.pg.common.TransactionUtils;
import com.morefin.pg.contiant.model.AccountIdentification;
import com.morefin.pg.contiant.model.AccountsDetails;
import com.morefin.pg.contiant.model.Address;
import com.morefin.pg.contiant.model.ApiErrorResponseDto;
import com.morefin.pg.contiant.model.ApiRequestDto;
import com.morefin.pg.contiant.model.ContiantCallbackContext;
import com.morefin.pg.contiant.model.ContiantTransactionContext;
import com.morefin.pg.contiant.model.Merchant;
import com.morefin.pg.contiant.model.RuntimeAccountConfig;
import com.morefin.pg.contiant.model.TransactionCallbackRequest;
import com.morefin.pg.safeuni.ErrorDescription;
import com.morefin.pg.utils.Utils;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.tuples.Tuple2;
import io.vertx.core.json.JsonObject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.morefin.pg.common.Constants.PHASE_DB_GET_DATA;
import static com.morefin.pg.common.Constants.PHASE_GET_AUTH_TOKEN;
import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_READ_PAYLOAD;
import static com.morefin.pg.common.Constants.PHASE_REQUEST_PAYMENT;
import static com.morefin.pg.common.Constants.PHASE_VERIFY_CALLBACK;
import static com.morefin.pg.common.Constants.REASON_API_INVOCATION_FAILURE;
import static com.morefin.pg.common.Constants.REASON_INVALID_INPUT;
import static com.morefin.pg.common.Constants.REASON_INVALID_SIGNATURE;
import static com.morefin.pg.common.Constants.REASON_TIMEOUT;
import static com.morefin.pg.common.Constants.REASON_TRANSACTION_DECLINED;
import static com.morefin.pg.common.Constants.REASON_UNAUTHORIZED;
import static com.morefin.pg.common.Constants.REASON_UNEXPECTED_RESPONSE_FORMAT;
import static com.morefin.pg.common.Constants.REASON_UNKNOWN_API_ERROR;
import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;
import static com.morefin.pg.contiant.common.Constants.CALLBACK_FINAL_STATUSES;
import static com.morefin.pg.contiant.common.Constants.CURRENCY_GBP;
import static com.morefin.pg.contiant.common.Constants.STATUS_ABANDONED;
import static com.morefin.pg.contiant.common.Constants.STATUS_CANCELLED;
import static com.morefin.pg.contiant.common.Constants.STATUS_COMPLETED;
import static com.morefin.pg.contiant.common.Constants.STATUS_CONFIRMED;
import static com.morefin.pg.contiant.common.Constants.STATUS_FAILED;
import static com.morefin.pg.contiant.common.Constants.STATUS_INITIATED;
import static com.morefin.pg.contiant.common.Constants.STATUS_IN_PROGRESS;
import static com.morefin.pg.contiant.common.Constants.STATUS_PENDING;
import static com.morefin.pg.contiant.common.Constants.STATUS_REJECTED;
import static com.morefin.pg.contiant.common.Constants.STATUS_SCA_REDIRECTED;
import static com.morefin.pg.contiant.common.Constants.STATUS_SETTLED;
import static com.morefin.pg.contiant.common.Constants.STATUS_WAITING;
import static com.morefin.pg.contiant.common.Constants.TYPE_ACCOUNT_NUMBER;
import static com.morefin.pg.contiant.common.Constants.TYPE_BIC;
import static com.morefin.pg.contiant.common.Constants.TYPE_IBAN;
import static com.morefin.pg.contiant.common.Constants.TYPE_SORT_CODE;

@ApplicationScoped
public class ContiantObjectTransformer {

    @Inject
    TransactionUtils transactionUtils;

    public ExecuteTransactionResponse convertToTransactionResponse(ContiantTransactionContext context) {

        ExecuteTransactionResponse resp;
        if (context.getErrorDescription() == null) {
            resp = buildPendingTransactionResponse(context.getRedirectUrl());
        } else {
            resp = buildErrorResponse(context);
        }
        return resp;
    }

    public ErrorDescription<Response.Status> buildFinalizeErrorDescription(ContiantCallbackContext context, Throwable failure) {
        String reason;
        return switch (context.getPhase()) {
            case PHASE_HYDRATE_CONTEXT:
                yield switch (context.getSubPhase()) {
                    case PHASE_READ_PAYLOAD:
                        reason = transactionUtils.getDeserializationFailureReason(failure);
                        yield transactionUtils.buildUnexpectedCallbackFormatError(context.getCallbackRequestAsString(), reason);
                    case PHASE_DB_GET_DATA:
                        reason = transactionUtils.getDeserializationFailureReason(failure);
                        Log.errorv("Exception during obtaining the PPA data from DB for transaction {0} with failure. {1}", context.getCallbackRequestDto().getMerchantReferenceId(), failure.getMessage());
                        yield transactionUtils.handleDbOperationFailure(context.getCallbackRequestAsString(), context.getCallbackRequestDto().getId(), reason, failure);
                    default:
                        reason = transactionUtils.getContextPreparationFailureReason(failure);
                        yield transactionUtils.buildInternalErrorCallbackResponse(reason, failure);
                };
            case PHASE_VERIFY_CALLBACK: {
                if (failure instanceof SecurityException) {
                    yield transactionUtils.buildBadRequestCallbackResponse(REASON_INVALID_SIGNATURE, failure);
                } else {
                    yield transactionUtils.buildInternalErrorCallbackResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
                }
            }
            // This case also covers the logic for building an error response in the following phases PHASE_BUILD_FINALIZE_REQUEST,PHASE_GRPC_INVOKE:
            default:
                yield transactionUtils.buildInternalErrorCallbackResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
        };
    }

    public ErrorDescription<ApiErrorResponseDto> buildErrorDescription(ContiantTransactionContext context, Throwable failure) {
        String reason;
        return switch (context.getPhase()) {
            case PHASE_HYDRATE_CONTEXT:
                reason = transactionUtils.getContextPreparationFailureReason(failure);
                yield transactionUtils.buildInternalErrorResponse(reason, failure);
            case PHASE_GET_AUTH_TOKEN:
                yield switch (context.getSubPhase()) {
                    case PHASE_GET_AUTH_TOKEN:
                        reason = transactionUtils.getApiFailureReason(failure);
                        yield handleGetAuthTokenFailure(context, reason, failure);
                    case PHASE_READ_PAYLOAD:
                        reason = transactionUtils.getDeserializationFailureReason(failure);
                        yield handleGetAuthTokenFailure(context, reason, failure);
                    default:
                        yield transactionUtils.buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);

                };
            case PHASE_REQUEST_PAYMENT:
                yield switch (context.getSubPhase()) {
                    case PHASE_PSP_INVOKE:
                        reason = transactionUtils.getApiFailureReason(failure);
                        yield handlePaymentRequestFailure(reason, failure);
                    case PHASE_READ_PAYLOAD:
                        reason = transactionUtils.getDeserializationFailureReason(failure);
                        yield transactionUtils.buildUnexpectedResponseFormatError(context.getResponseAsString(), context.getTransactionId(), reason, failure);
                    default:
                        yield transactionUtils.buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
                };
            default:
                yield transactionUtils.buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
        };
    }

    public ApiRequestDto createApiRequestPayload(TransactionTypeContext context) {
        var transaction = context.getTransaction();
        var runtimeAccountConfig = Utils.getRuntimeAccountConfig(context.getPaymentProviderAccount(), RuntimeAccountConfig.class);
        var identifierBicOrSortCode = CURRENCY_GBP.equals(transaction.getCurrency()) ? TYPE_SORT_CODE : TYPE_BIC;
        var identifierIbanOrAccNumber = CURRENCY_GBP.equals(transaction.getCurrency()) ? TYPE_ACCOUNT_NUMBER : TYPE_IBAN;
        var apiRequestBuilder = ApiRequestDto.builder()
            .amountInMinorUnit(BigDecimal.valueOf(transaction.getAmount()))
            .currency(transaction.getCurrency())
            .country(transaction.getCustomerCountry())
            .consumerId(generateUniqueCustomerId(context))
            .consumerFirstName(transaction.getCustomerFirstName())
            .consumerLastName(transaction.getCustomerLastName())
            .consumerEmail(transaction.getCustomerEmail())
            .returnUrl(transaction.getTransactionData().getSuccessUrl())
            .failUrl(transaction.getTransactionData().getErrorUrl())
            .merchantName(runtimeAccountConfig.merchantName())
            .merchantReferenceId(transaction.getId())
            .accountsDetails(
                AccountsDetails.builder()
                    .merchant(Merchant.builder()
                        .name(runtimeAccountConfig.bankAccountHolderName())
                        .accountIdentifications(new AccountIdentification[]{new AccountIdentification(identifierIbanOrAccNumber, runtimeAccountConfig.merchantIban()),
                            new AccountIdentification(identifierBicOrSortCode, runtimeAccountConfig.merchantBic())})
                        .address(new Address(runtimeAccountConfig.merchantBankCountry(), runtimeAccountConfig.merchantPostCode()))
                        .build())
                    .build());

        if (runtimeAccountConfig.bankId() == null || runtimeAccountConfig.bankId().isEmpty())
            apiRequestBuilder.bankId(runtimeAccountConfig.bankId());

        return apiRequestBuilder.build();
    }

    public ContiantCallbackContext buildFinalizeTransactionRequest(ContiantCallbackContext context) {
        if (isTransactionInFinalState(context)) {
            context.setFinalizeRequest(FinalizeTransactionRequest
                    .newBuilder()
                    .setReferenceNumber(context.getCallbackRequestDto().getId())
                    .setResponseMessage(context.getCallbackRequestDto().getStatus())
                    .setPaymentProviderResponseMessage(context.getCallbackRequestDto().getStatus())
                    .setStatus(parseTransactionStatus(context.getCallbackRequestDto()))
                    .setId(context.getCallbackRequestDto().getMerchantReferenceId())
                    .build());
        }
        return context;
    }

    public boolean isTransactionInFinalState(ContiantCallbackContext ctx) {
        if (ctx.getRuntimeAccountConfig().acceptCompletedAsFinal() && ctx.getCallbackRequestDto().getStatus().equals(STATUS_SETTLED)) {
            return true;
        }
        return CALLBACK_FINAL_STATUSES.contains(ctx.getCallbackRequestDto().getStatus());
    }

    private ErrorDescription<ApiErrorResponseDto> handleGetAuthTokenFailure(ContiantTransactionContext context, String reason, Throwable failure) {
        ApiErrorResponseDto baseErrorResponse = null;
        String respMessage;

        Tuple2<String, String> pspErrorInfo = switch (reason) {
            case REASON_TIMEOUT, REASON_UNAUTHORIZED, REASON_API_INVOCATION_FAILURE ->
                    Tuple2.of(reason, "Error Message: %s".formatted(failure.getMessage()));
            case REASON_INVALID_INPUT -> {
                baseErrorResponse = ((WebApplicationException) failure).getResponse().readEntity(ApiErrorResponseDto.class);
                yield Tuple2.of(baseErrorResponse.getError(), formatErrors(baseErrorResponse.getError(), baseErrorResponse.getErrorMessages()));
            }
            case REASON_UNEXPECTED_RESPONSE_FORMAT ->
                    Tuple2.of(reason, "Response: %s".formatted(context.getResponseAsString()));
            default -> Tuple2.of(REASON_UNKNOWN_API_ERROR, failure.getMessage());
        };
        respMessage = StringUtils.isEmpty(pspErrorInfo.getItem2()) ? "Reason:%s Message:%s".formatted(reason, failure.getMessage()) : pspErrorInfo.getItem2();

        return ErrorDescription.<ApiErrorResponseDto>builder()
                .reason(pspErrorInfo.getItem1())
                .responseMessage(respMessage)
                .errorResponse(baseErrorResponse)
                .paymentProviderResponseCode(baseErrorResponse != null ? baseErrorResponse.getError() : null)
                .paymentProviderResponseMessage(pspErrorInfo.getItem2())
                .build();
    }

    private static String formatErrors(String error, String[] errorMessages) {
        String formattedMessages = (errorMessages == null || errorMessages.length == 0)
                ? ""
                : Arrays.stream(errorMessages)
                .filter(s -> s != null && !s.trim().isEmpty())
                .collect(Collectors.joining(", "));

        return String.format("Error: %s, ErrorMessages: %s", error, formattedMessages);
    }

    private ErrorDescription<ApiErrorResponseDto> handlePaymentRequestFailure(String reason, Throwable failure) {
        ApiErrorResponseDto errorResp = null;
        Tuple2<String, String> pspErrorInfo = switch (reason) {
            case REASON_TIMEOUT, REASON_UNAUTHORIZED ->
                    Tuple2.of(reason, "Error Message: %s".formatted(failure.getMessage()));
            case REASON_API_INVOCATION_FAILURE -> {
                String errorResponse = ((WebApplicationException) failure).getResponse().readEntity(String.class);
                yield Tuple2.of(reason, errorResponse);
            }
            case REASON_INVALID_INPUT -> {
                errorResp = ((WebApplicationException) failure).getResponse().readEntity(ApiErrorResponseDto.class);
                //Handle declined transaction in case populated field status
                yield Tuple2.of(REASON_TRANSACTION_DECLINED, formatErrors(errorResp.getError(), errorResp.getErrorMessages()));

            }
            default -> Tuple2.of(REASON_UNKNOWN_API_ERROR, failure.getMessage());
        };

        String respMessage = "Reason:%s Message:%s".formatted(reason, failure.getMessage());

        return ErrorDescription.<ApiErrorResponseDto>builder()
                .reason(pspErrorInfo.getItem1())
                .responseMessage(respMessage)
                .errorResponse(errorResp)
                .paymentProviderResponseCode(pspErrorInfo.getItem1())
                .paymentProviderResponseMessage(pspErrorInfo.getItem2())
                .build();
    }

    //TODO change the cases based on the feedback about available statuses
    private TransactionStatus parseTransactionStatus(TransactionCallbackRequest callbackDto) {
        return switch (callbackDto.getStatus()) {
            case STATUS_SETTLED, STATUS_COMPLETED -> TransactionStatus.APPROVED;
            case STATUS_CONFIRMED, STATUS_INITIATED, STATUS_WAITING, STATUS_PENDING, STATUS_SCA_REDIRECTED,
                 STATUS_IN_PROGRESS -> TransactionStatus.PENDING;
            case STATUS_FAILED -> TransactionStatus.DECLINED;
            case STATUS_CANCELLED, STATUS_REJECTED -> TransactionStatus.CANCELED;
            case STATUS_ABANDONED -> TransactionStatus.SESSION_EXPIRED;
            default -> TransactionStatus.UNRECOGNIZED;
        };
    }

    private ExecuteTransactionResponse buildPendingTransactionResponse(String redirect) {
        var builder = ExecuteTransactionResponse.Redirect.newBuilder();
        return ExecuteTransactionResponse.newBuilder()
            //TODO: set all response data here
            .setResponse(ExecuteTransactionResponse.Response.newBuilder().setResponseCode(ProcessingCode.TRX_STATUS_PENDING.name()).build())
                .setRedirect(
                        new GrpcBuilder<>(builder)
                                .set(redirect, builder::setUrl)
                                .getBuilder()
                                .build())
                .build();
    }

    private ExecuteTransactionResponse buildErrorResponse(ContiantTransactionContext context) {
        TransactionStatusMapper responseMapping = TransactionStatusMapper.fromValue(context.getErrorDescription().getReason());
        var builder = ExecuteTransactionResponse.Response.newBuilder();
        var respBody = context.getErrorDescription().getErrorResponse();
        return ExecuteTransactionResponse.newBuilder()
                .setResponse(new GrpcBuilder<>(builder)
                        .set(responseMapping.getResponseCode().name(), builder::setResponseCode)
                        .set(StringUtils.abbreviate(context.getErrorDescription().getResponseMessage(), 50), builder::setResponseMessage)
                        .setAny(context.getErrorDescription().getPaymentProviderResponseMessage(), builder::setPaymentProviderResponseMessage)
                        .setAny(context.getErrorDescription().getPaymentProviderResponseCode(), builder::setPaymentProviderResponseCode)
                        .setAndMap(JsonObject.mapFrom(respBody != null ? respBody : Map.of()).getMap(), GrpcFactory::fromMap, builder::setData)
                        .set(context.getErrorDescription().getReason(), builder::setPaymentProviderStatus)
                        .setAny(responseMapping.getTransactionStatus(), builder::setStatus)
                        .getBuilder().build())
                .build();
    }

    private String generateUniqueCustomerId(TransactionTypeContext context) {
        String customerInfo = String.format("%s_%s_%s", context.getTransaction().getCustomerFirstName(),
                context.getTransaction().getCustomerLastName(),
                context.getTransaction().getCustomerEmail());
        return generateUUIDv4FromString(customerInfo);
    }

    /**
     * @param input - String representation of unique customer information
     * @return UUID V4 conversion of the unique customer information
     */
    private static String generateUUIDv4FromString(String input) {
        try {
            // Hash the input string using SHA-256
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));

            // Use the first 16 bytes for UUID generation
            ByteBuffer buffer = ByteBuffer.wrap(hash);
            long mostSigBits = buffer.getLong();
            long leastSigBits = buffer.getLong();

            // Set UUID version to 4 (random)
            mostSigBits &= ~(0xF << 12);  // Clear version bits
            mostSigBits |= (4L << 12);    // Set version to 4

            // Set variant to IETF (RFC 4122)
            leastSigBits &= ~(0xC000000000000000L); // Clear variant bits
            leastSigBits |= (0x8000000000000000L);  // Set to IETF variant

            return new UUID(mostSigBits, leastSigBits).toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }
}