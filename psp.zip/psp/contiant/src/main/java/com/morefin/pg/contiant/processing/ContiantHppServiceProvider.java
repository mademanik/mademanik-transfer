package com.morefin.pg.contiant.processing;

import com.morefin.payments.apm.spi.processing.APMProcessingService;
import com.morefin.payments.apm.spi.processing.APMProcessingServiceProvider;
import com.morefin.pg.contiant.apm.ContiantPaymentMethodTypeModule;
import io.quarkus.arc.Arc;

public class ContiantHppServiceProvider implements APMProcessingServiceProvider {

    @Override
    public String name() {
        return ContiantPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String id() {
        return ContiantPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public String type() {
        return ContiantPaymentMethodTypeModule.MODULE_ID;
    }

    @Override
    public APMProcessingService create() {
        try (var instance = Arc.container().instance(ContiantPaymentProcessingService.class)) {
            return instance.get();
        }
    }
}
