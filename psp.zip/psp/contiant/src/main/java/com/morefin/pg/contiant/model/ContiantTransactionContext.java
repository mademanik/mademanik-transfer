package com.morefin.pg.contiant.model;

import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ContiantTransactionContext extends BaseTransactionContext<ApiErrorResponseDto> {

    RuntimeAccountConfig runtimeAccountConfig;
    TransactionTypeContext context;
    ApiRequestDto paymentRequest;
    String authToken;
    String redirectUrl;
    String transactionId;
    String responseAsString;

    public ContiantTransactionContext(String phase) {
        super(phase);
    }

    public ContiantTransactionContext() {
        super("INITIAL_PAYMENT_PHASE");
    }
}
