package com.morefin.pg.contiant.common;

import java.util.List;

public class Constants {

    public static final String TYPE_IBAN = "IBAN";
    public static final String TYPE_BIC = "BIC";
    public static final String TYPE_SORT_CODE = "SORT_CODE";
    public static final String TYPE_ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
    public static final String CURRENCY_GBP = "GBP";
    public static final String X_CONTIANT_SIGNATURE = "X-Contiant-Signature";
    //Payment Status
    public static final String STATUS_SETTLED = "SETTLED";
    public static final String STATUS_CONFIRMED = "CONFIRMED";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_INITIATED = "INITIATED";
    public static final String STATUS_WAITING = "WAITING";
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_SCA_REDIRECTED = "SCA_REDIRECTED";
    public static final String STATUS_IN_PROGRESS = "IN PROGRESS";
    public static final String STATUS_FAILED = "FAILED";
    public static final String STATUS_CANCELLED = "CANCELLED";
    public static final String STATUS_REJECTED = "REJECTED";
    public static final String STATUS_ABANDONED = "ABANDONED";
    public static final List<String> CALLBACK_FINAL_STATUSES = List.of(STATUS_COMPLETED, STATUS_FAILED,
            STATUS_CANCELLED, STATUS_REJECTED, STATUS_ABANDONED);

}
