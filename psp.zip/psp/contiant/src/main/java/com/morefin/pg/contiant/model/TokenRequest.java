package com.morefin.pg.contiant.model;

import jakarta.ws.rs.FormParam;

public class TokenRequest {
    @FormParam("client_id")
    public String clientId;

    @FormParam("client_secret")
    public String clientSecret;

    public TokenRequest(String clientId, String clientSecret) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }
}
