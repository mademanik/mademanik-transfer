package com.morefin.pg.contiant.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class ApiResponseDto {
    @JsonProperty("id")
    String id;

    @JsonProperty("status")
    String status;

    @NotBlank(message = "Payment Url used for redirect cannot be blank")
    @JsonProperty("paymentUrl")
    String paymentUrl;
}
