package com.morefin.pg.contiant.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionCallbackRequest {

    @JsonProperty("id")
    private String id;

    @JsonProperty("amountInMinorUnit")
    private BigDecimal amountInMinorUnit;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("country")
    private String country;

    @JsonProperty("status")
    private String status;

    @JsonProperty("settledBy")
    private String settledBy;

    @JsonProperty("consumerId")
    private String consumerId;

    @JsonProperty("consumerFirstName")
    private String consumerFirstName;

    @JsonProperty("consumerLastName")
    private String consumerLastName;

    @JsonProperty("consumerEmail")
    private String consumerEmail;

    @JsonProperty("merchantName")
    private String merchantName;

    @JsonProperty("accountsDetails")
    private AccountsDetails accountsDetails;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("merchantReferenceId")
    private String merchantReferenceId;

    @JsonProperty("returnUrl")
    private String returnUrl;

    @JsonProperty("failUrl")
    private String failUrl;

    @JsonProperty("vip")
    private String vip;

    @JsonProperty("bankId")
    private String bankId;
}
