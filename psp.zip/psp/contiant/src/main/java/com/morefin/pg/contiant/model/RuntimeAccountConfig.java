package com.morefin.pg.contiant.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(@JsonProperty("client_id") String clientId,
                                   @JsonProperty("client_secret") String clientSecret,
                                   @JsonProperty("callback_secret") String callbackSecret,
                                   @JsonProperty("merchant_name") String merchantName,
                                   @JsonProperty("merchant_iban") String merchantIban,
                                   @JsonProperty("merchant_bic") String merchantBic,
                                   @JsonProperty("merchant_bank_country") String merchantBankCountry,
                                   @JsonProperty("merchant_post_code") String merchantPostCode,
                                   @JsonProperty("bank_account_holder_name") String bankAccountHolderName,
                                   @JsonProperty("accept_completed_as_final") boolean acceptCompletedAsFinal,
                                   @JsonProperty("bank_id") String bankId) {
}
