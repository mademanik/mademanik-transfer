package com.morefin.pg.contiant.managers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.common.payments.grpc.GrpcApiUser;
import com.morefin.common.common.payments.grpc.GrpcClientFactory;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.common.paymentcommon.payments.paymentgateway.common.Constants;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.contiant.common.ContiantObjectTransformer;
import com.morefin.pg.contiant.http.ContiantApiClient;
import com.morefin.pg.contiant.model.*;
import com.morefin.pg.mapper.DtoMapperService;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.SignatureUtils;
import com.morefin.pg.utils.Utils;
import io.quarkus.grpc.GrpcClient;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.PHASE_BUILD_FINALIZE_REQUEST;
import static com.morefin.pg.common.Constants.PHASE_DB_GET_DATA;
import static com.morefin.pg.common.Constants.PHASE_GET_AUTH_TOKEN;
import static com.morefin.pg.common.Constants.PHASE_GRPC_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_HYDRATE_CONTEXT;
import static com.morefin.pg.common.Constants.PHASE_PSP_INVOKE;
import static com.morefin.pg.common.Constants.PHASE_READ_PAYLOAD;
import static com.morefin.pg.common.Constants.PHASE_REQUEST_PAYMENT;
import static com.morefin.pg.common.Constants.PHASE_VERIFY_CALLBACK;

@ApplicationScoped
public class TransactionManager {

    @GrpcClient("transaction-svc")
    TransactionGrpc transactionGrpc;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    DtoMapperService mapperService;

    @Inject
    SignatureUtils signatureUtils;

    @Inject
    ContiantObjectTransformer objectTransformer;

    @Inject
    @RestClient
    ContiantApiClient apiClient;

    BiFunction<ContiantTransactionContext, Throwable, ContiantTransactionContext> defaultExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, failure));
        return context;
    };

    BiFunction<ContiantCallbackContext, Throwable, ContiantCallbackContext> defaultFinalizeExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> executeHPPRequest(TransactionTypeContext context) {
        ContiantTransactionContext ctx = new ContiantTransactionContext();
        return SafeUni.from(context, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, decrypted -> hydratePaymentContext(ctx, context))
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, this::getAuthToken)
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::requestHppRedirect)
                .finalize(objectTransformer::convertToTransactionResponse);
    }

    public Uni<Response> finalizeTransaction(String callbackRequest, String signatureHeader, String tenantId) {
        ContiantCallbackContext ctx = new ContiantCallbackContext();
        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeFlatMap(PHASE_HYDRATE_CONTEXT, ctx1 -> hydrateCallbackContext(ctx1, signatureHeader, callbackRequest, tenantId))
                .safeMap(PHASE_VERIFY_CALLBACK, this::verifySignature)
                .safeMap(PHASE_BUILD_FINALIZE_REQUEST, objectTransformer::buildFinalizeTransactionRequest)
                .safeFlatMap(PHASE_GRPC_INVOKE, this::sendGrpcFinalizeRequest)
                .unwrap()
                .map(this::buildFinalResponse);
    }

    private Response buildFinalResponse(ContiantCallbackContext ctx) {
        if (objectTransformer.isTransactionInFinalState(ctx)) {
            if (ctx.getErrorDescription() == null) {
                if (ctx.getFinalizeResponse().hasRedirect()) {
                    return Response.ok().build();
                } else {
                    return Response.status(400).build();
                }
            } else {
                return Response.status((Response.Status) ctx.getErrorDescription().getErrorResponse())
                        .entity(Map.of("error", ctx.getErrorDescription().getResponseMessage())).build();
            }
        }
        Log.infov("Received transaction status update with value {0} for Transaction Id = {1}  with PSP id = {2}",
                ctx.getCallbackRequestDto().getStatus(), ctx.getCallbackRequestDto().getMerchantReferenceId(), ctx.getCallbackRequestDto().getId());
        return Response.ok().build();
    }

    private Uni<ContiantCallbackContext> sendGrpcFinalizeRequest(ContiantCallbackContext ctx) {
        if (objectTransformer.isTransactionInFinalState(ctx)) {
            var grpc = getTransactionGrpc(ctx.getTenantId());
            return grpc.finalizeTransaction(ctx.getFinalizeRequest())
                    .map(response -> {
                        ctx.setFinalizeResponse(response);
                        return ctx;
                    });
        }
        Log.infov("Received transaction status update with value {0} for Transaction Id = {1}  with PSP id = {2}",
                ctx.getCallbackRequestDto().getStatus(), ctx.getCallbackRequestDto().getMerchantReferenceId(), ctx.getCallbackRequestDto().getId());
        return Uni.createFrom().item(ctx);
    }

    private Uni<ContiantCallbackContext> hydrateCallbackContext(ContiantCallbackContext ctx, String signatureHeader, String callbackRequest, String tenantId) {
        ctx.setTenantId(tenantId);
        ctx.setTransactionGrpc(getTransactionGrpc(tenantId));
        ctx.setCallbackRequestAsString(callbackRequest);
        ctx.setSignatureHeader(signatureHeader);

        Log.infov("Validating callback response for tenantId: {0} with signature {1} and body:\n{2}",
                tenantId, ctx.getSignatureHeader(), callbackRequest);

        return SafeUni.from(ctx, defaultFinalizeExceptionHandler, ctx)
                .safeMap(PHASE_READ_PAYLOAD, ctx1 -> this.deserializeRequestBody(ctx1, callbackRequest))
                .safeFlatMap(PHASE_DB_GET_DATA, this::getPaymentProviderAccountData)
                .endSubPhase();
    }

    private Uni<ContiantCallbackContext> getPaymentProviderAccountData(ContiantCallbackContext ctx) {
        return signatureUtils.findPaymentProviderAccountData(ctx.getTenantId(), ctx.getCallbackRequestDto().getMerchantReferenceId())
                .map(ppa -> {
                    ctx.setRuntimeAccountConfig(Utils.getRuntimeAccountConfig(ppa, RuntimeAccountConfig.class));
                    return ctx;
                });
    }

    private TransactionGrpc getTransactionGrpc(String tenantId) {
        var serviceAccount = GrpcApiUser.serviceAccount(
                Set.of(),
                Map.of(),
                "contiant-service-account"
        );
        return GrpcClientFactory.grpc(
                transactionGrpc,
                tenantId,
                serviceAccount,
                Constants.LOCALHOST);
    }

    private Uni<ContiantTransactionContext> requestHppRedirect(ContiantTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeFlatMap(PHASE_PSP_INVOKE, ctx -> {
                    return apiClient.requestHppUrlRedirect(
                        "Bearer " + context.getAuthToken(),
                        context.getPaymentRequest()
                    );
                })
                .safeMap(PHASE_READ_PAYLOAD, response -> parsePaymentResponse(context, response))
                .endSubPhase();
    }

    @SneakyThrows
    private ContiantTransactionContext parsePaymentResponse(ContiantTransactionContext ctx, Response response) {
        //preserve payment api invocation response for later usage
        ctx.setResponseAsString(response.readEntity(String.class));
        //make attempt to transform to successful response
        ctx.setRedirectUrl(mapperService.mapAndValidate(ctx.getResponseAsString(), ApiResponseDto.class).getPaymentUrl());
        return ctx;
    }

    private Uni<ContiantTransactionContext> hydratePaymentContext(ContiantTransactionContext context, TransactionTypeContext authContext) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_HYDRATE_CONTEXT, customerCountryCode -> {
                    RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(authContext.getPaymentProviderAccount(), RuntimeAccountConfig.class);

                    context.setContext(authContext);
                    context.setTransactionId(authContext.getTransaction().getId());
                    context.setRuntimeAccountConfig(rac);
                    context.setPaymentRequest(objectTransformer.createApiRequestPayload(authContext));
                    return context;
                }).endSubPhase();
    }

    private Uni<ContiantTransactionContext> getAuthToken(ContiantTransactionContext context) {
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeFlatMap(PHASE_GET_AUTH_TOKEN, payload -> apiClient.requestAuthToken(
                    new TokenRequest(context.getRuntimeAccountConfig().clientId(), context.getRuntimeAccountConfig().clientSecret())
                ))
                .safeMap(PHASE_READ_PAYLOAD, resp -> {
                    context.setAuthToken(resp.readEntity(AuthTokenResponse.class).getAccessToken());
                    return context;
                })
                .endSubPhase();
    }

    private ContiantCallbackContext verifySignature(ContiantCallbackContext ctx) {
        try {
            if (StringUtils.isBlank(ctx.getSignatureHeader())) {
                Log.errorv("Received callback request with blank signature header.");
                ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, new SecurityException("Missing signature")));
                return ctx;
            }
            String[] parts = ctx.getSignatureHeader().split(",");
            String timestamp = parts[0].split("=")[1];
            String signature = parts[1].split("=")[1];
            String message = timestamp + "|" + ctx.getCallbackRequestAsString();
            String calculatedSignature = signatureUtils.generateHmacSHA256Signature(ctx.getRuntimeAccountConfig().callbackSecret(), message);
            if (!calculatedSignature.equals(signature)) {
                Log.errorv("Received request with unexpected signature.");
                ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, new SecurityException("Invalid signature")));
            }
        } catch (Exception e) {
            Log.errorv("Exception while verifying signature.", e);
            ctx.setErrorDescription(objectTransformer.buildFinalizeErrorDescription(ctx, e));
        }
        return ctx;
    }

    @SneakyThrows
    private ContiantCallbackContext deserializeRequestBody(ContiantCallbackContext ctx, String body) {
        Log.infov("Received callback response: {0}", body);
        ctx.setCallbackRequestDto(objectMapper.readValue(body, TransactionCallbackRequest.class));
        return ctx;

    }
}
