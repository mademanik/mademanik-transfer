package com.morefin.pg.contiant.model;

import com.morefin.common.grpc.transaction.ExecuteTransactionResponse;
import com.morefin.common.grpc.transaction.FinalizeTransactionRequest;
import com.morefin.common.grpc.transaction.TransactionGrpc;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ContiantCallbackContext extends BaseTransactionContext<String> {

    RuntimeAccountConfig runtimeAccountConfig;
    String tenantId;
    String signatureHeader;
    String callbackSecret;
    String callbackRequestAsString;
    TransactionCallbackRequest callbackRequestDto;
    TransactionGrpc transactionGrpc;
    FinalizeTransactionRequest finalizeRequest;
    ExecuteTransactionResponse finalizeResponse;


    public ContiantCallbackContext(String phase) {
        super(phase);
    }

    public ContiantCallbackContext() {
        super("INITIAL_PAYMENT_PHASE");
    }
}
