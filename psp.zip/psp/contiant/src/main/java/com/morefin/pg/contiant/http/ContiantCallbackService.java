package com.morefin.pg.contiant.http;

import com.morefin.common.common.payments.core.tenant.Tenant;
import com.morefin.pg.contiant.managers.TransactionManager;
import io.smallrye.mutiny.Uni;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import static com.morefin.pg.contiant.common.Constants.X_CONTIANT_SIGNATURE;

@Path("/psp/contiant")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ContiantCallbackService {

    @Inject
    TransactionManager transactionManager;

    @Inject
    Tenant tenant;

    @Path("/callback")
    @POST
    public Uni<Response> callbackUrl(String callbackRequest, @HeaderParam(X_CONTIANT_SIGNATURE) String signatureHeader) {
        return transactionManager.finalizeTransaction(callbackRequest,
                signatureHeader,
                tenant.id());
    }
}