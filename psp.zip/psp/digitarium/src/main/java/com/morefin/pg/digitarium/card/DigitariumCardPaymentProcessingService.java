package com.morefin.pg.digitarium.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.ManageTransactionContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.common.paymentgatewaydomain.services.payment_gateway.ext_domain.TypedPaymentProvider;
import com.morefin.common.paymentprocessingadminspi.BaseAdminPaymentProcessingService;
import com.morefin.common.paymentprocessinggatewayspi.spi.BasePaymentProcessingExtensionService;
import com.morefin.common.paymentprocessingspi.PaymentProviderServiceConfig;
import com.morefin.pg.digitarium.admin.card.DigitariumCardAdminPaymentProcessingService;
import io.quarkus.arc.Unremovable;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
@Unremovable
public class DigitariumCardPaymentProcessingService implements EcommerceCardPaymentProcessingService {

    @Inject
    DigitariumCardAdminPaymentProcessingService adminPaymentProcessingService;

    @Override
    public Uni<ExecuteTransactionResponse> authorize(CardAuthorizeContext cardAuthorizeContext) {
        return null;
    }

    @Override
    public Uni<ExecuteTransactionResponse> manage(ManageTransactionContext manageTransactionContext) {
        return null;
    }

    @Override
    public PaymentProviderServiceConfig config() {return adminPaymentProcessingService.config();}

    @Override
    public Optional<BasePaymentProcessingExtensionService> extension(String s) {return Optional.empty();}

    @Override
    public BaseAdminPaymentProcessingService admin() {return adminPaymentProcessingService;}

    @Override
    public boolean embeddedAuthentication(TypedPaymentProvider paymentProvider) {return true;}
}
