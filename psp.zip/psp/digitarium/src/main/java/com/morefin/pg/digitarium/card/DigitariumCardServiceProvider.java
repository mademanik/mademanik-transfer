package com.morefin.pg.digitarium.card;

import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingService;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.EcommerceCardPaymentProcessingServiceProvider;
import com.morefin.common.grpc.payment_provider.PaymentProviderType;
import com.morefin.pg.digitarium.admin.card.DigitariumCardProcessingModule;
import io.quarkus.arc.Arc;

import java.util.List;

public class DigitariumCardServiceProvider implements EcommerceCardPaymentProcessingServiceProvider {
    @Override
    public EcommerceCardPaymentProcessingService create() {
        try (var instance = Arc.container().instance(DigitariumCardPaymentProcessingService.class)) {
            return instance.get();
        }
    }

    @Override
    public List<String> types() {
        return List.of(
                "card",
                "saved_card"
        );
    }

    @Override
    public String name() {
        return DigitariumCardProcessingModule.MODULE_ID;
    }

    @Override
    public String id() {
        return DigitariumCardProcessingModule.MODULE_ID;
    }

    @Override
    public String type() {
        return PaymentProviderType.CARD.name();
    }
}
