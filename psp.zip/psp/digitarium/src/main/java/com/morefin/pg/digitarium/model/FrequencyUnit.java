package com.morefin.pg.digitarium.model;

import lombok.Getter;

@Getter
public enum FrequencyUnit {
    MINUTE,
    DAY,
    WEEK,
    MONTH
}
