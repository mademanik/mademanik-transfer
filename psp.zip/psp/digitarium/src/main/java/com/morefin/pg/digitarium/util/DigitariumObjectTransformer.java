package com.morefin.pg.digitarium.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.services.payment_gateway.ext_domain.ImmutableTypedTransactionEntity;
import com.morefin.pg.common.TransactionUtils;
import com.morefin.pg.digitarium.model.Customer;
import com.morefin.pg.digitarium.model.DigitariumTransactionContext;
import com.morefin.pg.digitarium.model.DocumentType;
import com.morefin.pg.safeuni.ErrorDescription;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import static com.morefin.pg.common.Constants.REASON_UNKNOWN_INTERNAL_ERROR;

@ApplicationScoped
public class DigitariumObjectTransformer {

    @Inject
    TransactionUtils transactionUtils;

    @Inject
    ObjectMapper objectMapper;

    public static final String DEFAULT_STATE_NA = "NA";

    public Customer groupCustomerData(ImmutableTypedTransactionEntity trx, String routingGroup) {
        return new Customer(trx.getId(),
                trx.getCustomerCountry(),
                trx.getCustomerFirstName(),
                trx.getCustomerLastName(),
                "01-01-1980", // Hardcoded dateOfBirth, to be change later
                trx.getCustomerEmail(),
                trx.getCustomerPhoneNumber(),
                "EN", // Hardcoded locale, to be change later
                "", // accountNumber
                "", // accountName
                "", // bank
                "", // bankBranch
                DocumentType.BR_CPF, // documentType
                "", // documentNumber
                routingGroup,
                true, // kycStatus
                true, //paymentInstrumentKycStatus
                "", //dateOfFirstDeposit
                0, //depositsAmount
                0, //withdrawalsAmount
                0, //depositsCnt
                0 //withdrawalsCnt
        );
    }

    public ErrorDescription<String> buildErrorDescription(DigitariumTransactionContext context, Throwable failure) {
        String reason;
        Log.errorv("Exception caught during phase {0} sub phase {1} with message {2}", context.getPhase(), context.getSubPhase(), failure);

        return buildInternalErrorResponse(REASON_UNKNOWN_INTERNAL_ERROR, failure);
    }

    private ErrorDescription<String> buildInternalErrorResponse(String reason, Throwable failure) {
        return ErrorDescription.<String>builder()
                .reason(reason)
                .responseMessage(failure.getMessage())
                .build();
    }

}
