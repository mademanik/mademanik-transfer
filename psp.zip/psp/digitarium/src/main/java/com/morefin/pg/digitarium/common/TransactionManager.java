package com.morefin.pg.digitarium.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morefin.common.domain.domain.payment_gateway.BrowserInfo;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.grpc.processing.transactiontype.spi.ExecuteTransactionResponse;
import com.morefin.pg.common.TransactionUtils;
import com.morefin.pg.digitarium.http.DigitariumApiClient;
import com.morefin.pg.digitarium.model.DigitariumTransactionContext;
import com.morefin.pg.digitarium.util.DigitariumObjectTransformer;
import com.morefin.pg.safeuni.SafeUni;
import com.morefin.pg.utils.Utils;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.function.BiFunction;

import static com.morefin.pg.common.Constants.*;
import static com.morefin.pg.utils.Utils.nullSafe;

@ApplicationScoped
public class TransactionManager {

    @Inject
    TransactionUtils transactionUtils;

    @Inject
    DigitariumObjectTransformer objectTransformer;

    @Inject
    @RestClient
    DigitariumApiClient digitariumApiClient;

    @Inject
    ObjectMapper objectMapper;

    private final BiFunction<DigitariumTransactionContext, Throwable, DigitariumTransactionContext> defaultExceptionHandler = (context, failure) -> {
        context.setErrorDescription(objectTransformer.buildErrorDescription(context, failure));
        return context;
    };

    public Uni<ExecuteTransactionResponse> executeDirectPaymentRequest(CardAuthorizeContext authContext) {
        DigitariumTransactionContext ctx = new DigitariumTransactionContext();
        return SafeUni.from(authContext, defaultExceptionHandler, ctx)
                .safeFlatMap(PHASE_DECRYPT_CARD_DETAILS, transactionUtils::decryptCardDetails)
                .safeMap(PHASE_HYDRATE_CONTEXT, decrypted -> hydratePaymentContext(ctx, authContext, decrypted))
                .safeFlatMap(PHASE_REQUEST_PAYMENT, this::requestPaymentTransaction)
                .finalize(objectTransformer::convertToCardResponse);
    }

    private Uni<DigitariumTransactionContext> hydratePaymentContext(DigitariumTransactionContext context, CardAuthorizeContext authContext, List<byte[]> decryptedCardData) {
        var transaction = authContext.authorizeContext().getTransaction();
        var paymentProviderAccount = authContext.authorizeContext().getPaymentProviderAccount();
        var browserInfo = objectMapper.convertValue(transaction.getTransactionData().getOptions().get("browser_info"), BrowserInfo.class);
        return SafeUni.from(context, defaultExceptionHandler, context)
                .safeMap(PHASE_HYDRATE_CONTEXT, ctx -> {
                    RuntimeAccountConfig rac = Utils.getRuntimeAccountConfig(paymentProviderAccount, RuntimeAccountConfig.class);
                    context.setContext(authContext);
                    context.setRuntimeAccountConfig(rac);

                    context.setCardNumber(new String(decryptedCardData.get(0), StandardCharsets.UTF_8));
                    context.setCvc(new String(decryptedCardData.get(1), StandardCharsets.UTF_8));
                    context.setExpirationMonth(authContext.card().expirationMonth());
                    context.setExpirationYear(authContext.card().expirationYear());

                    context.setCustomerData(objectTransformer.groupCustomerData(transaction, rac.routingGroup()));
                    context.setAmount(transaction.getAmount());
                    context.setCurrency(transaction.getCurrency());
                    context.setTransactionType(transaction.getTransactionType());
                    context.setStatementDescriptor(authContext.authorizeContext().getMerchant().getName());
                    context.setDescription(nullSafe(paymentProviderAccount.getData().getString(PPA_DEFAULT_DESCRIPTION), transaction.getDescription()));

                    context.setReference(transaction.getId());
                    context.setUserIp(transaction.getUserIp());
                    context.setBrowserInfo(browserInfo);
                    context.setSuccessUrl(transaction.getTransactionData().getSuccessUrl());
                    context.setCancelUrl(transaction.getTransactionData().getCancelUrl());
                    context.setFailureUrl(transaction.getTransactionData().getErrorUrl());

                    return context;
                }).endSubPhase();
    }

}
