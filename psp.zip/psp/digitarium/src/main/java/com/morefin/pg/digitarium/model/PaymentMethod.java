package com.morefin.pg.digitarium.model;

import lombok.Getter;

@Getter
public enum PaymentMethod {
    BASIC_CARD
}