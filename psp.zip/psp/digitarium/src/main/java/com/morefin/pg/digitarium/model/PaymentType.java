package com.morefin.pg.digitarium.model;

import lombok.Getter;

@Getter
public enum PaymentType {
    DEPOSIT,
    WITHDRAWAL,
    REFUND
}
