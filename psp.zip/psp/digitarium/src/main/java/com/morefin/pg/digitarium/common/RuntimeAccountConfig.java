package com.morefin.pg.digitarium.common;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RuntimeAccountConfig(
        @JsonProperty("signing_key") String signingKey,
        @JsonProperty("api_key") String apiKey,
        @JsonProperty("routing_group") String routingGroup
) {
}
