package com.morefin.pg.digitarium.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public record PaymentRequest(
        String referenceId,
        PaymentType paymentType,
        PaymentMethod paymentMethod,
        BigDecimal amount,
        String currency,
        String parentPaymentId,
        String description,
        Card card,
        Customer customer,
        BillingAddress billingAddress,
        String returnUrl,
        String webhookUrl,
        Boolean startRecurring,
        Boolean preAuth,
        String recurringToken,
        Subscription subscription,
        Map<String, Object> additionalParameters
) {
    public record Card(
            String cardNumber,
            String cardToken,
            String cardholderName,
            String cardSecurityCode,
            String expiryMonth,
            String expiryYear
    ) {
    }

    public record Subscription(
            String description,
            BigDecimal amount,
            String startTime,
            Integer frequency,
            String frequencyUnit,
            Integer numberOfCycles,
            RetryStrategy retryStrategy
    ) {
    }

    public record RetryStrategy(
            Integer frequency,
            FrequencyUnit frequencyUnit,
            Integer numberOfCycles,
            List<Integer> amountAdjustments
    ) {
    }
}
