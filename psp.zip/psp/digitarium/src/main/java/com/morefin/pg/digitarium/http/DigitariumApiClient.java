package com.morefin.pg.digitarium.http;

import com.morefin.pg.digitarium.model.CaptureRequest;
import com.morefin.pg.digitarium.model.PaymentRequest;
import io.smallrye.mutiny.Uni;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "digitarium")
@Produces(MediaType.APPLICATION_JSON)
public interface DigitariumApiClient {
    @POST
    @Path("/api/v1/payments")
    Uni<Response> paymentRequest(PaymentRequest requestPayload, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @GET
    @Path("/api/v1/payments")
    Uni<Response> getPaymentList(@HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @GET
    @Path("/api/v1/payments/{id}")
    Uni<Response> getPaymentById(@PathParam("id") String id, @HeaderParam(HttpHeaders.AUTHORIZATION) String authToken);

    @POST
    @Path("/api/v1/payments/{id}/capture")
    Uni<Response> paymentCapture(@PathParam("id") String id, CaptureRequest requestPayload, @HeaderParam("Authorization") String authToken);

    @POST
    @Path("/api/v1/payments/{id}/void")
    Uni<Response> paymentVoid(@PathParam("id") String id, @HeaderParam("Authorization") String authToken);
}
