package com.morefin.pg.digitarium.model;

import java.math.BigDecimal;

public record CaptureRequest(
        BigDecimal amount
) {
}
