package com.morefin.pg.digitarium.model;

import java.math.BigDecimal;

public record PaymentResponse(
        String timestamp,
        Integer status,
        Result result
) {

    public record Result(
            String id,
            String referenceId,
            String created,
            PaymentType paymentType,
            State state,
            String description,
            String parentPaymentId,
            PaymentMethod paymentMethod,
            PaymentMethodDetails paymentMethodDetails,
            BigDecimal amount,
            String currency,
            BigDecimal customerAmount,
            String customerCurrency,
            String redirectUrl,
            String errorCode,
            String errorMessage,
            String externalResultCode,
            Customer customer,
            BillingAddress billingAddress,
            Boolean startRecurring,
            Boolean preAuth,
            String recurringToken,
            String terminalName,
            BigDecimal externalFeeAmount,
            String externalFeeCurrency
    ) {
    }

    public record PaymentMethodDetails(
            String customerAccountNumber,
            String cardToken,
            String cardholderName,
            String cardExpiryMonth,
            String cardExpiryYear,
            String cardIssuingCountryCode
    ) {
    }
}
