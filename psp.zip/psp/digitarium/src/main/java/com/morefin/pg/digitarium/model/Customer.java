package com.morefin.pg.digitarium.model;

public record Customer(
        String referenceId,
        String citizenshipCountryCode,
        String firstName,
        String lastName,
        String dateOfBirth,
        String email,
        String phone,
        String locale,
        String accountNumber,
        String accountName,
        String bank,
        String bankBranch,
        DocumentType documentType,
        String documentNumber,
        String routingGroup,
        Boolean kycStatus,
        Boolean paymentInstrumentKycStatus,
        String dateOfFirstDeposit,
        Integer depositsAmount,
        Integer withdrawalsAmount,
        Integer depositsCnt,
        Integer withdrawalsCnt
) {
}
