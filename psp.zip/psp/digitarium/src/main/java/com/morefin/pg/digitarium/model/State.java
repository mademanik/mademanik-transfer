package com.morefin.pg.digitarium.model;

import lombok.Getter;

@Getter
public enum State {
    CHECKOUT,
    PENDING,
    AUTHORIZED,
    CANCELLED,
    DECLINED,
    COMPLETED
}
