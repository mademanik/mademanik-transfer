package com.morefin.pg.digitarium.model;

import com.morefin.common.domain.domain.payment_gateway.BrowserInfo;
import com.morefin.common.ecommercetransactiontypes.paymentprocessing.spi.ecommerce.card.CardAuthorizeContext;
import com.morefin.common.paymentprocessinggatewayspi.spi.TransactionTypeContext;
import com.morefin.pg.digitarium.common.RuntimeAccountConfig;
import com.morefin.pg.digitarium.http.DigitariumApiClient;
import com.morefin.pg.safeuni.BaseTransactionContext;
import lombok.*;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@ToString
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DigitariumTransactionContext extends BaseTransactionContext<String> {
    CardAuthorizeContext context;
    RuntimeAccountConfig runtimeAccountConfig;

    Customer customerData;
    String transactionType;
    Long amount;
    String currency;
    String cardNumber;
    String cvc;
    Integer expirationMonth;
    Integer expirationYear;
    String statementDescriptor;
    String description;
    String reference;
    String userIp;
    String successUrl;
    String cancelUrl;
    String failureUrl;

    BrowserInfo browserInfo;

    PaymentResponse paymentResponse;
    String paymentResponseAsString;
    DigitariumApiClient digitariumApiClient;

    public DigitariumTransactionContext() {
        super("INITIAL_PAYMENT_PHASE");
    }
}
